# Vietnamese Precalculus 2e — complete module m49306

Read **[Tốc độ biến thiên và sự biến thiên của đồ thị](index.html)** offline.
This is the complete next module after the published Functions and Domain and
Range recovery package. **The full Vietnamese A30 book remains ongoing.**

## Coverage

All four learning objectives, source-ordered instruction, examples, exercises,
supplied answers and nine glossary definitions are translated. This means
353 translation blocks, 254 MathML trees, 24 unchanged source images and
438 source IDs. There are 61 exercise objects overall, of which **47 are end
exercises**; 24 of those have source-supplied answers and 23 do not. No answers
have been invented to fill source omissions. Solutions from the source are
visibly labeled. Additional self-study/prerequisite guidance is separately
labeled and does not replace translated source content.

## Reproduce and edit

Run `python -X utf8 -B build.py` with Python 3.10 or newer. No network,
third-party Python package, TeX, fonts, JavaScript, or browser is required to
build. Native MathML rendering requires a current MathML-capable browser.
`source.cnxml` is the exact pinned source; `translation-overrides.json` is the
human-editable prose layer; `translation.json` is its complete 353-block export.
`m49306.vi.cnxml` is the complete localized structured source. `SOURCE.json`
provides stable block/slot IDs and asset identities. `build.py` preserves all
source tag counts, stable IDs and formula structure while relocating prose
emphasis to its Vietnamese equivalents. `SUPPORT.html` is separately authored
support. Source graphics retain original pixels, so lettering within images
may remain English; Vietnamese alt text accompanies every image.

The builder deterministically regenerates source, reader and QA metadata and
checks local references, source IDs, formula tokens/structure, assets and UTF-8.
`QA.json` describes evidence and remaining limits. `PUBLIC_FILES.json` is the
exact useful public payload. Root publication adds serialized visual checking;
this helper does not claim a whole-book or every-page visual audit.

## Source notes and terminology

Table 3's original accessible summary gives 243 for 2004, but the source table
cell is 249. The frozen source and translated CNXML retain the original summary;
the HTML accessible description uses 249 with an explicit editorial note.
The source glossary switches between extrema locations and output values;
separate study guidance explains the distinction. Mathematical definitions and
formula signs follow OpenStax, not errors in external terminology references.
See [`TERMINOLOGY_DECISIONS.md`](TERMINOLOGY_DECISIONS.md) and
[rights and original credits](LICENSE.md). The terminology record separates
directly witnessed usage from provisional translator choices and gives precise
questions for later expert review without making review a release hold.

Next canonical source module: **m49308**. The established MV-1/SB-1 learning
routes and prerequisite intent remain active; this checkpoint does not claim
translation of any other book or of the remaining A30 corpus.
