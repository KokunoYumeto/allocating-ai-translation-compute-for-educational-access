# Vietnamese terminology and translation decisions — m49306

This is the reviewable decision log for the complete Vietnamese translation of
OpenStax Precalculus 2e module `m49306`. It records terms that affect meaning or
reader navigation; it is not a claim of native-speaker review. Every entry below
is open to correction when stronger Vietnamese mathematical evidence becomes
available. Missing expert evidence never leaves a source block untranslated.

## Evidence boundary

- Mathematical and structural authority: OpenStax `modules/m49306/index.cnxml`
  at commit `789b54099106b071d1d32bfcee454fed72eb4768`, SHA-256
  `87e3bea0a14b4f487e0a5428b8138a644b0630b692d02c5a0e348e26ae3e6806`.
- Regional language witness already checked in the Vietnamese lane: Bùi Xuân
  Diệu, *Bài giảng Giải tích I*, Hanoi University of Science and Technology
  (2009), official PDF
  <https://fami.hust.edu.vn/wp-content/uploads/Giai-tich-1.pdf>, SHA-256
  `54f9a6a3fabf188ce1f2b3d8819926a209c0b1f98378789a52b2291cfa7ef41c`.
  The earlier hash-bound canon records document direct inspection of printed
  pages 6–9 and 19–20. Those pages support `hàm số`, `tập xác định`,
  `tập giá trị`, `đơn ánh`, and interval-category language. They do **not**
  directly attest the rate-of-change or local-extrema terms used here.
- This sealing pass rechecked the durable canon records (`canon/README.md`,
  `terminology.csv`, and `review-A30-U032.json`) and the present module against
  the exact source. The HUST PDF bytes were not present in the recovered lane,
  so the PDF was not reopened in this pass. This limitation is stated instead
  of converting a prior inspection receipt into a false fresh-source claim.
- The previous accepted Vietnamese A30 material uses `hàm số ... đồng biến`.
  That is internal consistency evidence, not independent regional authority.
- C-VI-02 is a Vietnamese linear-algebra witness and was not used to justify
  terminology in this module. No native-speaker or subject-expert review has
  been performed.

All decisions below are **retrospective backfill**: the original translator did
not maintain this itemized log while drafting. Reasons are reconstructed from
the exact source, final translation, existing Vietnamese terminology ledger and
hash-bound canon receipts; they are not presented as contemporaneous motives.

## Decisions

### VI-M49306-D01 — rate of change

- Source locations: `term-00001`, `term-00002`, `fs-id1165137642836/title`,
  `fs-id1165137544638`, and glossary terms `fs-id1165133052921/term` and
  `fs-id1165135412050/term`.
- Choice and sense: `rate of change` → **tốc độ biến thiên**; `average rate of
  change` → **tốc độ biến thiên trung bình**. Here “rate” is a quotient of the
  output change by the input change, with units “output units per input unit”;
  it is not necessarily a derivative or an instantaneous rate.
- Checked authority: exact OpenStax definitions and formulas above. The checked
  HUST excerpts do not directly witness this Vietnamese phrase.
- Alternatives: `tốc độ thay đổi`, `suất biến thiên`, `tỉ số biến thiên`.
- Rationale: the selected wording is concise, keeps the chapter-wide
  `biến thiên` terminology coherent, and does not introduce differentiation.
- Uncertainty: **provisional, medium** because no topic-specific Vietnamese
  regional witness was available in the checked evidence set.
- Expert question: In a Vietnamese secondary-school precalculus text, is
  `tốc độ biến thiên trung bình` preferred over `tốc độ thay đổi trung bình` for
  the secant quotient before derivatives are introduced?

### VI-M49306-D02 — increasing and decreasing functions

- Source locations: learning objective `list-00001/item/2`, section
  `fs-id1165135440486`, definitions `fs-id1165134169426` and
  `fs-id1165137668624`, terms `term-00008`, `term-00009`,
  `fs-id1165135264639/term`, and `fs-id1165135639824/term`, plus their exercises.
- Choice and sense: formal labels use **hàm số đồng biến** and **hàm số nghịch
  biến**. The first explanatory definition also supplies the transparent glosses
  “tăng” and “giảm.” The strict inequalities and open-interval scope remain
  exactly those of the source.
- Checked authority: exact source definitions; prior accepted Vietnamese A30
  material supplies internal consistency for `đồng biến`. No checked external
  excerpt directly attests this pair for the present module.
- Alternatives: `hàm số tăng` / `hàm số giảm`; `hàm tăng` / `hàm giảm`.
- Rationale: `đồng biến/nghịch biến` is the more precise formal pair, while the
  parenthetical glosses keep the first encounter accessible.
- Uncertainty: **provisional, low-to-medium**; the meaning is unambiguous, but a
  topic-specific regional textbook witness would strengthen the register choice.
- Expert question: Should all exercise prompts retain only the formal pair, or
  should `tăng/giảm` remain alongside it throughout for early self-study readers?

### VI-M49306-D03 — local maxima, minima and extrema

- Source locations: explanatory paragraph `fs-id1165134272749`, terms
  `term-00005`–`term-00007`, definitions `fs-id1165135389881`, and glossary
  entries `fs-id1165135536408/term`, `fs-id1165135536416/term`, and
  `fs-id1165135412040/term`.
- Choice and sense: **cực đại địa phương**, **cực tiểu địa phương**, and
  **cực trị địa phương**. The translation explicitly distinguishes the input
  location from the function value at that input and records the English
  `local`/`relative` naming note instead of pretending the two languages share
  identical morphology.
- Checked authority: exact source prose, inequalities and graph references.
  The checked Vietnamese canon excerpts do not directly attest these terms.
- Alternatives: `cực đại tương đối`, `cực tiểu tương đối`, `cực trị tương đối`;
  or the longer `điểm cực đại/cực tiểu địa phương` when the input location is
  meant.
- Rationale: the chosen forms preserve the source's deliberate preference for
  “local,” while surrounding prose disambiguates location and output value.
- Uncertainty: **provisional, medium** because Vietnamese sources vary between
  `địa phương` and `tương đối`, and because the source glossary itself shifts
  between locations and values.
- Expert question: For the intended school-to-undergraduate register, should
  the headwords use `địa phương`, `tương đối`, or paired labels; and should the
  location headword be explicitly `điểm cực đại/cực tiểu`?

### VI-M49306-D04 — absolute maximum and minimum

- Source locations: section `fs-id1165134381626`, definitions
  `fs-id1165132939786` and `fs-id1165137932685`, terms `term-00011`,
  `term-00012`, `fs-id1165133052903/term`, and `fs-id1165133052911/term`.
- Choice and sense: **giá trị lớn nhất** and **giá trị nhỏ nhất** for the attained
  output values over the full stated domain. The surrounding prose contrasts
  them with local extrema.
- Checked authority: exact source definitions and prior checked HUST-derived
  function/range vocabulary; no checked excerpt directly attests the full pair.
- Alternatives: `cực đại tuyệt đối` / `cực tiểu tuyệt đối`; `giá trị cực đại
  toàn cục` / `giá trị cực tiểu toàn cục`.
- Rationale: the source is defining values, not merely points, and the chosen
  pair is transparent to the target self-study audience.
- Uncertainty: **provisional, low-to-medium**.
- Expert question: Is the concise school form sufficient here, or should the
  headword include `toàn cục` or `tuyệt đối` to mirror the English distinction?

### VI-M49306-D05 — endpoint and interval notation

- Source locations: `term-00003`, `term-00010`, and the worked rate-of-change
  material around `fs-id1165137762240`.
- Choice and sense: **đầu mút** and **ký hiệu khoảng**.
- Checked authority: HUST printed pages 19–20, as recorded in the hash-bound
  canon receipt, directly support interval-category and endpoint language but
  do not directly attest the exact generic heading `ký hiệu khoảng`.
- Alternatives: `điểm đầu mút`, `đầu khoảng`; `kí hiệu khoảng` (orthographic
  variant).
- Rationale: these reuse the established Vietnamese A30 ledger (`T031`) and
  avoid changing terminology between adjacent modules.
- Uncertainty: **accepted within this edition; low**, with exact-heading evidence
  still incomplete.
- Expert question: Should this edition normalize `ký` to `kí` under a specific
  Vietnamese educational orthography policy?

### VI-M49306-D06 — electrostatic force and measurement units

- Source locations: `term-00004`, example `fs-id1165137772173`, and
  `fs-id1165135443718`–`fs-id1165135543242`.
- Choice and sense: **lực tĩnh điện**, with `niutơn` and `xentimét` in prose;
  mathematical symbols and numerical values remain unchanged.
- Checked authority: exact OpenStax formula, units and source MathML only. No
  Vietnamese physics reference was checked for this module.
- Alternatives: retain SI symbols `N` and `cm` more often; use `newton` and
  `centimét` spellings in prose.
- Rationale: the transliterations are readable Vietnamese prose while the
  formula and numeric identity are preserved.
- Uncertainty: **provisional, medium** at the orthographic/register level; no
  uncertainty about the physical formula or units.
- Expert question: Which unit spellings best match current Vietnamese school
  textbooks while remaining accessible across regions?

### VI-M49306-D07 — delta notation and mathematical text

- Source location: `fs-id1165135471272` and the 254 MathML trees throughout.
- Choice and sense: translate only natural-language `mtext` such as “change in
  input/output,” while retaining every nonlinguistic MathML token, operator,
  attribute and tree structure. “Delta y trên delta x” is explained as a ratio,
  not a command to transform the function.
- Checked authority: exact source MathML and prose. No external witness was
  needed to decide token identity.
- Alternatives: read `trên` as `chia cho` only; localize the Greek-letter name.
- Rationale: the translation gives both spoken and semantic readings without
  changing the mathematics.
- Uncertainty: **low**.
- Expert question: Would a Vietnamese audio-first edition benefit from adding
  `chia cho` every time the ratio is spoken, or is the present first-use
  explanation sufficient?

### VI-M49306-D08 — accessible Table 3 correction

- Source location: `Table_01_03_03/summary` and the visible row for year 2004.
- Choice and sense: retain the frozen source and localized CNXML witness exactly;
  in the HTML accessibility description only, change the source summary's
  `(2004, 243)` to **`(2004, 249)`** and show an explicit editorial note. The
  visible source table already says 249.
- Checked authority: direct comparison of the pinned source summary and table
  cells at the exact module SHA above.
- Alternatives: preserve the erroneous summary silently; or alter the source
  witness. Both were rejected.
- Rationale: a screen-reader user should receive the same data as a sighted
  reader, while provenance remains auditable.
- Uncertainty: **none about the discrepancy**; the editorial treatment remains
  open to style review.
- Expert question: Should a future source-correction ledger also expose this
  note at book-level navigation, or is the local note sufficient?

## Open review status

All source prose blocks are translated; none of the provisional labels above is
a gap or hold. A later expert may propose changes by citing the decision ID and
exact source/target location. Any accepted change should update the editable
`translation-overrides.json`, rebuild deterministically, and preserve this
history rather than silently rewriting the rationale.
