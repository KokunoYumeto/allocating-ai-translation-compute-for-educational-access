"""Replay, validate and seal the public m49306 payload; stdlib only."""
from pathlib import Path
from collections import Counter
import hashlib, json, os, re, subprocess, sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def stat(path):
    return {"bytes": path.stat().st_size, "sha256": sha(path)}

OUTPUTS = ("translation.json", "m49306.vi.cnxml", "index.html", "QA.json")

def build_once():
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, "-X", "utf8", "-B", str(ROOT / "build.py")],
        cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr or result.stdout)
    return {name: stat(ROOT / name) for name in OUTPUTS}

first = build_once()
second = build_once()
if first != second:
    raise RuntimeError({"deterministic_replay_mismatch": {"first": first, "second": second}})

source = json.loads((ROOT / "SOURCE.json").read_text(encoding="utf-8-sig"))
if sha(ROOT / "source.cnxml") != source["full_module_sha256"]:
    raise RuntimeError("source.cnxml no longer matches SOURCE.json")
for image in source["images"]:
    path = ROOT / image["path"]
    if stat(path) != {"bytes": image["bytes"], "sha256": image["sha256"]}:
        raise RuntimeError("asset identity mismatch: " + image["path"])

def local_name(node):
    return node.tag.rsplit("}", 1)[-1]

source_xml = ET.fromstring((ROOT / "source.cnxml").read_bytes())
target_xml = ET.fromstring((ROOT / "m49306.vi.cnxml").read_bytes())
source_ids = [node.get("id") for node in source_xml.iter() if node.get("id")]
target_ids = [node.get("id") for node in target_xml.iter() if node.get("id")]
if source_ids != target_ids or source_ids != source["source_ids"]:
    raise RuntimeError("source/target identified-node order mismatch")
if Counter(local_name(node) for node in source_xml.iter()) != Counter(local_name(node) for node in target_xml.iter()):
    raise RuntimeError("source/target tag-count mismatch")

def math_fingerprint(root):
    def rec(node):
        text = None if local_name(node) == "mtext" else (node.text or "").strip()
        return [node.tag, sorted(node.attrib.items()), text, [rec(child) for child in node]]
    return [rec(node) for node in root.iter() if local_name(node) == "math"]

if math_fingerprint(source_xml) != math_fingerprint(target_xml):
    raise RuntimeError("nonlinguistic MathML identity mismatch")
source_exercises = [node.get("id") for node in source_xml.iter() if local_name(node) == "exercise"]
target_exercises = [node.get("id") for node in target_xml.iter() if local_name(node) == "exercise"]
source_solutions = [node.get("id") for node in source_xml.iter() if local_name(node) == "solution"]
target_solutions = [node.get("id") for node in target_xml.iter() if local_name(node) == "solution"]
if source_exercises != target_exercises or source_solutions != target_solutions:
    raise RuntimeError("exercise/solution identity mismatch")

translations = json.loads((ROOT / "translation.json").read_text(encoding="utf-8-sig"))["blocks"]
number_pattern = re.compile(r"(?<![A-Za-z0-9])[−–-]?\d+(?:[.,]\d+)*(?![A-Za-z0-9])")
placeholder_pattern = re.compile(r"\{\{\w+:\d+\}\}")
def prose_numbers(text):
    plain = placeholder_pattern.sub("", text)
    return Counter(token.replace("–", "−").replace("-", "−").rstrip(".,")
                   for token in number_pattern.findall(plain))
for key, original in source["source_block_templates"].items():
    if prose_numbers(original) != prose_numbers(translations[key]):
        raise RuntimeError("prose numeric-token mismatch: " + key)

rights_text = (ROOT / "original-frontmatter.cnxml").read_text(encoding="utf-8-sig")
for witness in ("id=\"eip-494\"", "id=\"para-00001\"", "Attribution-NonCommercial-ShareAlike 4.0", "CC BY-NC-SA 4.0"):
    if witness not in rights_text:
        raise RuntimeError("missing rights witness: " + witness)

source_table = next(node for node in source_xml.iter() if node.get("id") == "Table_01_03_03")
source_summary = source_table.get("summary", "")
rows = [["".join(entry.itertext()).strip() for entry in row]
        for row in source_table.iter() if local_name(row) == "row"
        for entry in [[child for child in row if local_name(child) == "entry"]]]
if "(2004, 243)" not in source_summary or ["2004", "249"] not in rows:
    raise RuntimeError("Table_01_03_03 correction witness changed")
reader_text = (ROOT / "index.html").read_text(encoding="utf-8")
if "(2004, 249)" not in reader_text or "Chú thích biên tập" not in reader_text:
    raise RuntimeError("reader lacks explicit Table_01_03_03 correction")
if "Giấy phép: CC BY-NC-SA 4.0" not in reader_text or "Giấy phép: CC BY 4.0" in reader_text:
    raise RuntimeError("reader license label mismatch")

replay = {
    "schema": "a30-deterministic-replay/1",
    "module": "m49306",
    "locale": "vi-Latn-VN",
    "passes": 2,
    "identical": True,
    "outputs": second,
    "source_sha256": source["full_module_sha256"],
    "source_ids": len(source["source_ids"]),
    "mathml_trees": source["source_statistics"]["mathml_trees"],
    "assets": len(source["images"]),
}
(ROOT / "REPLAY.json").write_text(json.dumps(replay, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

text_files = [
    "index.html", "reader.css", "README.md", "LICENSE.md",
    "CC-BY-NC-SA-4.0.txt", "TERMINOLOGY_DECISIONS.md", "SUPPORT.html",
    "source.cnxml", "original-frontmatter.cnxml", "SOURCE.json",
    "translation-overrides.json", "translation.json", "m49306.vi.cnxml",
    "build.py", "seal.py", "QA.json", "REPLAY.json",
]
for rel in text_files:
    decoded = (ROOT / rel).read_bytes().decode("utf-8-sig")
    if "\ufffd" in decoded:
        raise RuntimeError("replacement character in " + rel)

seal_qa = {
    "schema": "a30-module-seal-qa/1",
    "module": "m49306",
    "locale": "vi-Latn-VN",
    "source": {
        "repository": source["upstream_url"],
        "commit": source["commit"],
        "path": source["path"],
        "sha256": source["full_module_sha256"],
        "byte_identity_recomputed": True,
    },
    "checks": {
        "deterministic_two_pass_replay": True,
        "identified_node_order_equal": len(source_ids),
        "tag_count_multiset_equal": True,
        "mathml_nonlinguistic_tree_identity": source["source_statistics"]["mathml_trees"],
        "exercise_identity": len(source_exercises),
        "supplied_solution_identity": len(source_solutions),
        "prose_numeric_token_multiset_identity": len(source["source_block_templates"]),
        "asset_byte_hash_identity": len(source["images"]),
        "utf8_text_files_without_replacement_character": len(text_files),
        "reader_license_matches_work_license": True,
        "rights_witness_ids_present": ["eip-494", "para-00001"],
        "table_01_03_03_accessible_correction_explicit": True,
    },
    "coverage": {
        "translation_blocks": source["source_statistics"]["translation_blocks"],
        "all_exercises": source["source_statistics"]["all_exercises"],
        "all_supplied_solutions": source["source_statistics"]["all_supplied_solutions"],
        "section_exercises": source["source_statistics"]["section_exercises"],
        "section_supplied_solutions": source["source_statistics"]["section_supplied_solutions"],
        "section_exercises_without_source_solution": source["source_statistics"]["section_missing_solutions"],
        "images": source["source_statistics"]["images"],
        "glossary_definitions": source["source_statistics"]["glossary_definitions"],
    },
    "rights": {
        "license": "CC BY-NC-SA 4.0",
        "evidence": "original-frontmatter.cnxml#eip-494 and #para-00001",
        "full_license_file": "CC-BY-NC-SA-4.0.txt",
    },
    "terminology_evidence": "TERMINOLOGY_DECISIONS.md",
    "visual_qa": "reserved for the root's bounded serialized inspection",
    "next_module": source["next_module"],
}
(ROOT / "SEAL_QA.json").write_text(json.dumps(seal_qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

public_paths = [
    "index.html", "reader.css", "README.md", "LICENSE.md",
    "CC-BY-NC-SA-4.0.txt", "TERMINOLOGY_DECISIONS.md", "SUPPORT.html",
    "source.cnxml", "original-frontmatter.cnxml", "SOURCE.json",
    "translation-overrides.json", "translation.json", "m49306.vi.cnxml",
    "build.py", "seal.py", "QA.json", "REPLAY.json", "SEAL_QA.json",
] + [image["path"] for image in source["images"]]
if len(public_paths) != len(set(public_paths)):
    raise RuntimeError("duplicate public path")
rows = []
for rel in sorted(public_paths):
    path = (ROOT / rel).resolve()
    if not path.is_relative_to(ROOT) or path.is_symlink() or not path.is_file():
        raise RuntimeError("unsafe or missing public path: " + rel)
    row = {"path": Path(rel).as_posix(), **stat(path)}
    rows.append(row)

allowlist = {
    "schema": "a30-public-files/1",
    "module": "m49306",
    "locale": "vi-Latn-VN",
    "sealed": True,
    "primary_reader": "index.html",
    "reader_title": "Tốc độ biến thiên và sự biến thiên của đồ thị",
    "source_commit": source["commit"],
    "source_sha256": source["full_module_sha256"],
    "next_module": source["next_module"],
    "files": rows,
    "file_count": len(rows),
    "total_bytes": sum(row["bytes"] for row in rows),
}
(ROOT / "PUBLIC_FILES.json").write_text(
    json.dumps(allowlist, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps({
    "status": "sealed", "reader": stat(ROOT / "index.html"),
    "public_files": stat(ROOT / "PUBLIC_FILES.json"),
    "file_count": allowlist["file_count"], "total_bytes": allowlist["total_bytes"],
}, ensure_ascii=False))
