"""Build the complete Vietnamese m49306 checkpoint; Python standard library only."""
from pathlib import Path
import copy, hashlib, html, json, re, xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parent
CN = 'http://cnx.rice.edu/cnxml'
MM = 'http://www.w3.org/1998/Math/MathML'
MD = 'http://cnx.rice.edu/mdml'
ET.register_namespace('', CN)
ET.register_namespace('m', MM)
ET.register_namespace('md', MD)
TOKEN = re.compile(r'\{\{(\w+):(\d+)\}\}')

def read(name): return json.loads((ROOT / name).read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def save(name, data): (ROOT / name).write_bytes(data.encode('utf-8') if isinstance(data, str) else data)
def jsonsave(name, data): save(name, json.dumps(data, ensure_ascii=False, indent=2) + '\n')
def tag(n): return n.tag.rsplit('}', 1)[-1]
def escaped(s): return html.escape(s or '', quote=True)

manifest = read('SOURCE.json')
source_bytes = (ROOT / 'source.cnxml').read_bytes()
assert digest(source_bytes) == manifest['full_module_sha256']
source = ET.fromstring(source_bytes)
parent = {c: e for e in source.iter() for c in e}
paths = {}
def index(e, path='root'):
    paths[path] = e
    for i, c in enumerate(e): index(c, path + '/' + str(i))
index(source)

def block_index():
    result = {}
    for e in source.iter():
        name, owner, key = tag(e), parent.get(e), None
        if name == 'media': key = e.get('id') + '/alt'
        elif name == 'table': key = e.get('id') + '/summary'
        elif name == 'title':
            key = ('m49306/title' if owner is source else 'm49306/metadata/title'
                   if tag(owner) == 'metadata' else owner.get('id') + '/title')
        elif name in ('para', 'footnote', 'meaning'): key = e.get('id')
        elif name == 'term': key = e.get('id') or owner.get('id') + '/term'
        elif name == 'label' and ''.join(e.itertext()).strip(): key = owner.get('id') + '/label'
        elif name == 'item': key = owner.get('id') + '/item/' + str(list(owner).index(e) + 1)
        elif name == 'caption': key = owner.get('id') + '/caption'
        elif name == 'entry':
            table = owner
            while tag(table) != 'table': table = parent[table]
            rows = [a for a in table.iter() if tag(a) == 'row']
            key = table.get('id') + '/row/' + str(rows.index(owner) + 1) + '/entry/' + str(list(owner).index(e) + 1)
        if key: result[e] = key
    assert list(result.values()) == manifest['source_block_keys']
    return result

blocks = block_index()
overrides = read('translation-overrides.json')
assert not set(overrides) - set(manifest['source_block_keys'])
translations = {}
for key, text in manifest['source_block_templates'].items():
    target = overrides.get(key, text.replace(' on ', ' trên '))
    residue = TOKEN.sub('', target)
    if key not in overrides and re.search('[A-Za-z]', residue):
        assert residue.strip() == 'A' or residue.strip() == 'a. –3000; b. –1250' or ' trên ' in residue, (key, residue)
    assert Counter(TOKEN.findall(text)) == Counter(TOKEN.findall(target)), key
    translations[key] = target
jsonsave('translation.json', {'schema': 'a30-vi-translation/1', 'module': 'm49306', 'locale': 'vi-Latn-VN', 'blocks': translations})

MTEXT = {
    '7 years': '7 năm', 'Average rate of change': 'Tốc độ biến thiên trung bình',
    'Change in input': 'Độ thay đổi của đầu vào', 'Change in output': 'Độ thay đổi của đầu ra',
    'Combine numerator terms': 'Gộp các hạng tử ở tử số',
    'Divide by the common factor ': 'Chia cho thừa số chung ',
    'Evaluate': 'Tính giá trị', 'Simplify': 'Rút gọn',
    'Simplify and factor': 'Rút gọn và phân tích nhân tử',
    ' dollars per year': ' đô la mỗi năm', ' per year': ' mỗi năm', ' years': ' năm'
}
images = {i['media_id']: i for i in manifest['images']}
for item in images.values():
    data = (ROOT / item['path']).read_bytes()
    assert len(data) == item['bytes'] and digest(data) == item['sha256']

def em(text, italics=False):
    return '<emphasis' + (' effect="italics"' if italics else '') + '>' + text + '</emphasis>'

def restore_emphasis(key, value):
    # Source's 24 emphasis nodes and four answer-choice spans, relocated to their
    # Vietnamese equivalents. None has an ID. All original source remains frozen.
    whole = {'Table_01_03_01/row/1/entry/1', 'Table_01_03_01/row/2/entry/1',
             'fs-id1165137762240', 'Table_01_03_03/row/1/entry/1',
             'Table_01_03_03/row/1/entry/2', 'Table_01_03_04/row/1/entry/1',
             'Table_01_03_04/row/1/entry/2'}
    if key in whole: value = em(value)
    if key == 'fs-id1165133097252': value = value.replace('mỗi năm', em('mỗi năm', True), 1)
    if key == 'fs-id1165135471272':
        value = value.replace('delta y', 'delta ' + em('y', True)).replace('delta x', 'delta ' + em('x', True))
    if key == 'Table_01_03_02/row/1/entry/1': value = em(em('t', True) + ' (giờ)')
    if key == 'Table_01_03_02/row/2/entry/1': value = em(em('D', True) + '(' + em('t', True) + ') (dặm)')
    if key == 'fs-id1165134272749':
        value = value.replace('Từ local', 'Từ ' + em('local', True))
        value = value.replace('bằng relative', 'bằng ' + em('relative', True))
        value = value.replace('thuật ngữ địa phương', 'thuật ngữ ' + em('địa phương', True))
    if key == 'fs-id1165134547216': value = value.replace('địa phương', em('địa phương', True), 1)
    if key in ('fs-id1165134485672', 'fs-id1165135532371', 'fs-id1165137863670'):
        value = value.replace('tung độ', em('tung độ', True), 1)
    if key == 'fs-id1165134381632':
        for phrase in ('giá trị lớn nhất', 'giá trị nhỏ nhất'): value = value.replace(phrase, em(phrase), 1)
    for symbol in 'ⓐⓑⓒⓓ': value = value.replace(symbol, '<span class="token">' + symbol + '</span>')
    return value

consumed = Counter()
def clone(e):
    out = ET.Element(e.tag, dict(e.attrib))
    key = blocks.get(e)
    if key:
        consumed[key] += 1
        value = translations[key]
        if tag(e) in ('media', 'table'):
            out.set('alt' if tag(e) == 'media' else 'summary', value)
        else:
            value = restore_emphasis(key, escaped(value))
            slots = manifest['source_block_slots'].get(key, {})
            def insert(match):
                group, ix = match.group(1), int(match.group(2))
                node = clone(paths[slots[group][ix]])
                return ET.tostring(node, encoding='unicode')
            value = TOKEN.sub(insert, value)
            wrapper = ET.fromstring('<wrapper xmlns="' + CN + '">' + value + '</wrapper>')
            out.text = wrapper.text
            out.extend(wrapper)
            return out
    out.text = e.text
    if tag(e) == 'mtext' and e.text:
        plain = e.text.replace('\u00a0', ' ')
        if plain in MTEXT:
            out.text = MTEXT[plain].replace(' ', '\u00a0') if '\u00a0' in e.text else MTEXT[plain]
        elif re.search('[A-Za-z]', plain): raise ValueError(('untranslated mtext', plain))
    if tag(e) == 'link' and (e.text or '').strip() == 'Average Rate of Change':
        out.text = 'Tốc độ biến thiên trung bình'
    if tag(e) == 'image':
        out.set('src', images[parent[e].get('id')]['path'])
    for c in e:
        new = clone(c)
        new.tail = c.tail
        out.append(new)
    return out

translated = clone(source)
assert consumed == Counter({k: 1 for k in manifest['source_block_keys']}), consumed
xml_bytes = ET.tostring(translated, encoding='utf-8', xml_declaration=True)
save('m49306.vi.cnxml', xml_bytes)

def structural(e):
    # Child order, tag, IDs and all nonlinguistic attributes are invariant;
    # emphasis is allowed to relocate within its original translation block.
    return [(tag(n), n.get('id')) for n in e.iter() if n.get('id')]
assert structural(source) == structural(translated)
assert Counter(tag(n) for n in source.iter()) == Counter(tag(n) for n in translated.iter())
def math_identity(e):
    def rec(n):
        text = None if tag(n) == 'mtext' else (n.text or '').strip()
        return [n.tag, dict(n.attrib), text, [rec(c) for c in n]]
    return [rec(n) for n in e.iter() if tag(n) == 'math']
assert math_identity(source) == math_identity(translated)

tp = {c: e for e in translated.iter() for c in e}
id_nodes = {e.get('id'): e for e in translated.iter() if e.get('id')}
labels = {}
for kind, vn in [('figure', 'Hình'), ('table', 'Bảng'), ('example', 'Ví dụ')]:
    for i, e in enumerate((n for n in translated.iter() if tag(n) == kind), 1): labels[e.get('id')] = f'{vn} {i}'
exercise_numbers = {v: i for i, v in enumerate(manifest['section_exercise_ids'], 1)}

def attributes(e, cls=''):
    return (' id="' + escaped(e.get('id')) + '"' if e.get('id') else '') + (' class="' + cls + '"' if cls else '')

def inner(e):
    return escaped(e.text) + ''.join(render(c) + escaped(c.tail) for c in e)

def render(e):
    name = tag(e)
    attrs = attributes(e)
    if name == 'math':
        text = ET.tostring(e, encoding='unicode')
        text = re.sub(r'\s+xmlns(?::\w+)?="[^"]+"', '', text)
        text = text.replace('<m:', '<').replace('</m:', '</').replace('<math', '<math xmlns="' + MM + '"', 1)
        # ElementTree serializes the node tail; callers serialize it separately.
        if e.tail: text = text[:-len(html.escape(e.tail))] if text.endswith(html.escape(e.tail)) else text
        return '<span class="math-scroll' + (' display' if e.get('display') == 'block' else '') + '">' + text + '</span>'
    if name == 'metadata':
        title = next(c for c in e if tag(c) == 'title')
        abstract = next(c for c in e if tag(c) == 'abstract')
        return '<aside class="objectives" aria-label="Mục tiêu học tập"><span hidden>' + inner(title) + '</span>' + inner(abstract) + '</aside>'
    if name in ('content-id', 'uuid', 'colspec'): return ''
    if name == 'title':
        p = tp.get(e)
        heading = 'h1' if p is translated else 'h2' if tag(p) == 'section' and tp.get(p) is not None and tag(tp[p]) == 'content' else 'h3'
        prefix = labels.get(p.get('id'), '') if p is not None and tag(p) == 'example' else ''
        return '<' + heading + attrs + '>' + (prefix + '. ' if prefix else '') + inner(e) + '</' + heading + '>'
    if name == 'media':
        item = images[e.get('id')]
        return '<div' + attributes(e, 'media') + '><img src="' + escaped(item['path']) + '" alt="' + escaped(e.get('alt')) + '" width="' + str(item['width']) + '" height="' + str(item['height']) + '" loading="lazy"></div>'
    if name == 'link':
        target = e.get('target-id')
        if target:
            assert target in id_nodes, target
            label = inner(e).strip() or labels.get(target, 'xem mục liên quan')
            return '<a' + attrs + ' href="#' + escaped(target) + '">' + label + '</a>'
        return '<a' + attrs + ' href="' + escaped(e.get('url') or e.get('href')) + '">' + inner(e) + '</a>'
    if name == 'table':
        summary = e.get('summary') or ''
        note = ''
        if e.get('id') == 'Table_01_03_03':
            summary = summary.replace('(2004, 243)', '(2004, 249)')
            note = '<p class="editor-note">Chú thích biên tập: ô dữ liệu năm 2004 trong bảng nguồn là 249. Mô tả hỗ trợ tiếp cận của nguồn ghi nhầm 243; bản đọc hỗ trợ tiếp cận ở đây dùng 249. Các ô bảng và bản chứng nguồn không bị sửa.</p>'
        return '<div class="table-scroll"><table' + attrs + '><caption>' + labels[e.get('id')] + '</caption>' + inner(e) + '</table></div><details class="table-description"><summary>Mô tả bảng</summary><p>' + escaped(summary) + '</p></details>' + note
    if name == 'tgroup': return inner(e)
    if name == 'row': return '<tr' + attrs + '>' + inner(e) + '</tr>'
    if name == 'entry':
        row = tp[e]; body = tp[row]
        first = list(body).index(row) == 0
        cell = 'th' if first else 'td'
        return '<' + cell + attrs + (' scope="col"' if first else '') + '>' + inner(e) + '</' + cell + '>'
    if name == 'exercise':
        num = exercise_numbers.get(e.get('id'))
        return '<article' + attributes(e, 'exercise') + '>' + ('<h4>Bài ' + str(num) + '</h4>' if num else '') + inner(e) + '</article>'
    if name == 'solution':
        return '<details' + attributes(e, 'source-solution') + ' open><summary>Đáp án hoặc lời giải có trong nguồn</summary>' + inner(e) + '</details>'
    if name == 'figure':
        return '<figure' + attrs + '><div class="figure-number">' + labels[e.get('id')] + '</div>' + inner(e) + '</figure>'
    if name == 'glossary': return '<section class="glossary"><h2>Thuật ngữ</h2><dl>' + inner(e) + '</dl></section>'
    if name == 'definition': return '<div' + attrs + '>' + inner(e) + '</div>'
    if name == 'term':
        t = 'dt' if tag(tp[e]) == 'definition' else 'strong'
        return '<' + t + attrs + '>' + inner(e) + '</' + t + '>'
    if name == 'meaning': return '<dd' + attrs + '>' + inner(e) + '</dd>'
    if name == 'emphasis':
        t = 'em' if e.get('effect') == 'italics' else 'strong'
        return '<' + t + attrs + '>' + inner(e) + '</' + t + '>'
    if name == 'list':
        t = 'ol' if e.get('list-type') == 'enumerated' else 'ul'
        return '<' + t + attrs + '>' + inner(e) + '</' + t + '>'
    if name == 'newline': return '<br' + attrs + '>'
    if name == 'label': return '<h4' + attrs + '>' + inner(e) + '</h4>'
    element = {'document': 'main', 'content': 'div', 'abstract': 'div', 'section': 'section',
               'para': 'div' if any(tag(c) in ('footnote', 'math') for c in e) else 'p',
               'item': 'li', 'note': 'aside', 'example': 'section', 'commentary': 'aside',
               'problem': 'div', 'equation': 'div', 'caption': 'figcaption', 'footnote': 'aside',
               'span': 'span', 'tbody': 'tbody'}.get(name)
    if element is None: raise ValueError(('unhandled source tag', name))
    return '<' + element + attributes(e, name) + '>' + inner(e) + '</' + element + '>'

body = render(translated)
supplement = (ROOT / 'SUPPORT.html').read_text(encoding='utf-8-sig')
reader = '<!doctype html>\n<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tốc độ biến thiên và sự biến thiên của đồ thị — Precalculus 2e</title><link rel="stylesheet" href="reader.css"></head><body><header><p class="eyebrow">OpenStax · Precalculus 2e · Tiếng Việt · Mô-đun m49306</p><p>Phần 1.3 hoàn chỉnh; toàn bộ bản dịch sách vẫn đang tiếp tục.</p><nav><a href="#reader-start">Đọc phần dịch</a> · <a href="#study-support">Hỗ trợ tự học</a> · <a href="README.md">Phạm vi và nguồn</a></nav></header><div id="reader-start"></div>' + body + supplement + '<footer><p>Nguyên tác: Jay Abramson và các tác giả đóng góp, OpenStax, Rice University. Bản dịch và phần hỗ trợ được phân biệt rõ với nguyên tác. Giấy phép: CC BY-NC-SA 4.0; xem <a href="LICENSE.md">thông tin quyền</a>.</p></footer></body></html>\n'
save('index.html', reader)

class Check(HTMLParser):
    def __init__(self): super().__init__(); self.ids=[]; self.refs=[]; self.math=0; self.img=[]
    def handle_starttag(self, name, attributes):
        a=dict(attributes)
        if 'id' in a:self.ids.append(a['id'])
        if 'href' in a:self.refs.append(a['href'])
        if name=='math':self.math+=1
        if name=='img':self.img.append(a['src'])
check=Check(); check.feed(reader)
assert len(check.ids)==len(set(check.ids))
assert set(manifest['source_ids']) <= set(check.ids)
assert check.math==254 and len(check.img)==24
for ref in check.refs + check.img:
    if ref.startswith('#'): assert ref[1:] in check.ids, ref
    elif not re.match(r'https?://',ref): assert (ROOT/ref).is_file(),ref
assert '\ufffd' not in reader
outputs={name:{'bytes':(ROOT/name).stat().st_size,'sha256':digest((ROOT/name).read_bytes())} for name in ('translation.json','m49306.vi.cnxml','index.html')}
jsonsave('QA.json', {
    'schema':'a30-vietnamese-module-qa/1','module':'m49306','locale':'vi-Latn-VN',
    'source_sha256':digest(source_bytes),'source_statistics':manifest['source_statistics'],
    'checks': {'all_353_blocks_translated_once':True,'all_source_id_order_retained':True,
               'all_source_tag_counts_retained':True,'all_254_math_tree_numeric_operator_structure_identities':True,
               'all_24_asset_byte_hashes':True,'all_local_reader_references_resolve':True,
               'no_duplicate_reader_ids':True,'utf8_without_replacement_characters':True},
    'math_policy':'Only natural-language mtext is translated; all other mathematical tokens, attributes and tree structures are identical.',
    'coverage':'Complete m49306: 61 exercise objects overall; 47 end exercises with 24 source-supplied solutions, 23 without source solutions; 9 glossary definitions. No fabricated answers.',
    'presentation':'All source tag counts and identified-node order preserved. Twenty-four emphasis nodes are relocated onto their Vietnamese equivalents within the same block.',
    'known_source_dispositions':['Table_01_03_03 accessible summary says 243 for 2004, whereas the table says 249; source/translation CNXML retain witness, reader explicitly corrects the accessible summary only.','Source glossary uses local maximum/minimum for input location whereas body also names output extrema; separately labeled study note distinguishes both.'],
    'visual_status':'Not launched in this helper; root owns serialized bounded visual inspection.',
    'artifacts':outputs,'next_module':'m49308','full_book_status':'ongoing'})
print(json.dumps({'status':'built','module':'m49306','artifacts':outputs,'math':check.math,'images':len(check.img),'source_ids':len(manifest['source_ids'])},ensure_ascii=False))
