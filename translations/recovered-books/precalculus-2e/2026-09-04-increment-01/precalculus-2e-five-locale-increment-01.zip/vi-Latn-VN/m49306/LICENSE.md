# Attribution and rights

Original work: **Precalculus 2e**, Jay Abramson and OpenStax contributors,
Rice University. Chapters 1–8 build on work by David Lippman and Melonie
Rasmussen. Original full credits are preserved in `original-frontmatter.cnxml`.

The book's work-level license is **Creative Commons
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)**:
https://creativecommons.org/licenses/by-nc-sa/4.0/
The complete license is in `CC-BY-NC-SA-4.0.txt`.
Evidence: pinned original frontmatter, `eip-494` (Customization) and
`para-00001` (Art attribution). The repository license field is not used to
override this work-level evidence.

The Vietnamese translation and added study support use the same license.
Changes: translated prose and accessibility text, localized mathematical prose
inside MathML, semantic offline HTML presentation, separate self-study support,
and an explicitly documented correction to one accessible table summary.
All 24 source image files remain byte-identical. Where no individual artwork
credit appears, the source attribution rule is: Copyright Rice University,
OpenStax, under CC BY-NC-SA 4.0. Source captions and credits remain in place.
No new claim of exclusive ownership is made over mathematical facts.

Source repository: https://github.com/openstax/osbooks-college-algebra-bundle
Commit: `789b54099106b071d1d32bfcee454fed72eb4768`.
Module: `modules/m49306/index.cnxml`.
Source SHA-256: `87e3bea0a14b4f487e0a5428b8138a644b0630b692d02c5a0e348e26ae3e6806`.

Translation assistance: OpenAI Codex gpt-5.6-sol, Ultra. This is process
provenance, not replacement authorship or a claim of human/native-speaker review.
OpenStax, Rice University and the original authors do not endorse this adaptation.
Third-party Vietnamese terminology references are cited but not redistributed.
The new builder and style sheet are also offered under CC BY-NC-SA 4.0.
