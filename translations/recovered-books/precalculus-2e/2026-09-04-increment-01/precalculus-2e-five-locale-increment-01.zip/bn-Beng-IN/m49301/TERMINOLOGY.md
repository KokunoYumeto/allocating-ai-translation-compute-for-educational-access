# Indian Bengali terminology decisions

Locale: `bn-Beng-IN`, West Bengal-oriented. This is not a Bangladesh Bengali substitute. English terms remain a labelled bridge; Latin symbols and the source's numerical notation remain unchanged.

Directly consulted 2026-09-04 before/during drafting: West Bengal government's *পঠন সেতু*, Class VII, PDF page 189 / printed page 10, readable original page image and existing OCR. Actual page confirms চল, ধ্রুবক, যোগফল, গুণফল, পদ, সহগ, সদৃশ পদ and অসদৃশ পদ. OCR corrupts variables and powers; actual image, not OCR formulas, governed the decisions. Its initial `4k`/`4x` inconsistency is not copied. Original witness ledger source ID `WB-Class7-Learning-Bridge`, full PDF hash `acc0b3f3308faca853d1515c8b6eaa10dace97501dfd3f41b5c331e5e0baeef2`; page-image hash `c55d1f090e29adaf5053e21ad875b0c0e01c5d94f24afba0f9b6fad04da80c00`.

Targeted direct addition: [West Bengal, Class XII Mathematics, “সম্বন্ধ ও চিত্রণ”](https://banglarshiksha.wb.gov.in/readwrite/online_classroom/questionandanswer/Math%20Class%20XII%20Question%20%26%20Answer.pdf), sole PDF page. Acquired directly after the browsing fetch timed out; rendered and visually read with PDFium because the text layer uses legacy font encoding. Questions 1–3 witness সম্পর্ক, সেট, ক্রমযুগল, অঞ্চল, প্রসার; question 4 explicitly calls the function অপেক্ষক. The page's region/range example and f(x)=3x−1 were checked visually. This is a mathematical vocabulary witness, not permission to copy its problems or a certification of this translation.

|English|Edition wording|Evidence/decision|
|---|---|---|
|function|অপেক্ষক|Directly witnessed Class XII question 4; chosen over generic ফাংশন.|
|domain|অঞ্চল (ডোমেন)|Directly witnessed Class XII question 3; initial draft's ডোমেন refined throughout the deterministic build.|
|range|প্রসার (রেঞ্জ)|Directly witnessed Class XII question 3; distinguish actual image set from codomain.|
|relation|সম্পর্ক; সম্বন্ধ as heading synonym|সম্পর্ক appears in questions; সম্বন্ধ in the source heading.|
|ordered pair|ক্রমজোড়; ক্রমযুগল as witnessed synonym|ক্রমযুগল is witnessed; ক্রমজোড় is the edition's explicitly editorial plain-language equivalent.|
|variable / constant|চল / ধ্রুবক|Class VII image.|
|independent / dependent variable|স্বাধীন চল / নির্ভরশীল চল|Meaning-based editorial refinements of witnessed চল; no claim this exact compound was in the consulted pages.|
|one-to-one function|এক-এক অপেক্ষক|Editorial term; definition explicitly requires a unique input for each attained output.|
|vertical / horizontal line test|উল্লম্ব / অনুভূমিক সরলরেখা পরীক্ষা|Meaning-based editorial wording; not claimed directly attested in these pages.|
|input / output|ইনপুট / আউটপুট|Labelled English bridge; AX-3 explains the quantities, not just loanwords.|
|evaluate / solve|মান নির্ণয় / সমাধান|Keeps output evaluation distinct from finding input solutions.|

QA return consultation: compared the translated definition of function, domain/range, the worked substitution and AX-3 explanation against these exact witnesses. Consequence: অঞ্চল/প্রসার propagated in the build with English bridges on first definition and glossary, and চল retained rather than an unsupported regional distinction. No human regional expert review is claimed. Further advanced terms remain provisional editorial choices until better mathematical evidence is acquired; this does not prevent a useful reversible checkpoint.
