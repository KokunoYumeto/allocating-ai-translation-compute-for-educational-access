# Translation decisions for expert review — Indian Bengali

Scope: selected OpenStax Precalculus 2e module `m49301` and its separate AX-3 support. This is a traceable review queue, not an expert endorsement. Choices marked **R** are retrospective reconstructions from the completed translation, `TERMINOLOGY.md`, and `qa/EDITORIAL_DECISIONS.md`; they are not presented as the translator's original contemporaneous motives. Future entries should be marked **C** when recorded at decision time. Provisional choices remain usable and revisable; they do not create a publication or completion hold.

## Authorities actually checked

- **OpenStax source authority:** `upstream/m49301.cnxml`, 197,298 bytes, SHA-256 `81115d90dd1d9781e65844526bbbfbea638cc6fd515c623c4d535bf3bd0e37e3`. Slot numbers below follow `translations/m49301.slots.json`; CNXML IDs survive in the translated CNXML and reader.
- **West Bengal Class VII witness:** government *পঠন সেতু*, PDF page 189 / printed page 10, source ID `WB-Class7-Learning-Bridge`, full-PDF SHA-256 `acc0b3f3308faca853d1515c8b6eaa10dace97501dfd3f41b5c331e5e0baeef2`, inspected page-image SHA-256 `c55d1f090e29adaf5053e21ad875b0c0e01c5d94f24afba0f9b6fad04da80c00`. The image directly witnesses চল, ধ্রুবক, যোগফল, গুণফল, পদ, সহগ, সদৃশ পদ, and অসদৃশ পদ. Its OCR was not trusted for formulas.
- **West Bengal Class XII witness:** government *সম্বন্ধ ও চিত্রণ*, sole PDF page, [source](https://banglarshiksha.wb.gov.in/readwrite/online_classroom/questionandanswer/Math%20Class%20XII%20Question%20%26%20Answer.pdf), PDF SHA-256 `0c0a4e031c7160d9c705ba5b0b8c98c52eca452cc09e4ada7626a00e62c9a01c`, inspected rendering SHA-256 `9bc00874220b913e133eaa98b407dc7b8419140a5b43f7d30f6e04e76d11ac2b`. It directly witnesses অপেক্ষক, অঞ্চল, প্রসার, সম্পর্ক, and ক্রমযুগল. See `canon/consultation-receipt.json`.
- No regional mathematics expert or additional dictionary was consulted. Where a term is absent from the checked pages, that absence is stated below rather than filled with invented authority.

## Open decisions and difficult renderings

### BN-D01 — function and function notation **[R]**

- **Anchors:** source/target slot 0 (module title), slot 63 / `term-00006`, and glossary slot 789 / `fs-id1165137932580`; reader links `#term-00006` and `#fs-id1165137932580`.
- **Choice and sense:** `function` → **অপেক্ষক**; `function notation` → **অপেক্ষকের সংকেত**. Class XII question 4 directly supports অপেক্ষক. “সংকেত” is a meaning-based rendering, not found in the checked pages.
- **Alternatives and status:** ফাংশন is a transparent loanword; স্বরলিপি is a possible alternative for notation. অপেক্ষক is retained as the regionally witnessed headword, with English available as a bridge. **Uncertainty: low for অপেক্ষক; medium for সংকেত.**
- **Review question:** In current West Bengal secondary-to-undergraduate mathematics, is “অপেক্ষকের সংকেত” the natural heading, or is “অপেক্ষকের স্বরলিপি/ফাংশনের সংকেত” preferred?

### BN-D02 — domain and range **[R]**

- **Anchors:** slots 15 and 17 / `fs-id1165137781542`; glossary slots 787 / `fs-id1165137758552` and 801 / `fs-id1165135508573`; exercise anchor slot 744 / `fs-id1165135530586`.
- **Choice and sense:** `domain` → **অঞ্চল (ডোমেন)** at first/glossary mention and অঞ্চল thereafter; `range` → **প্রসার (রেঞ্জ)** and প্রসার thereafter. The Class XII witness directly uses অঞ্চল and প্রসার. The translation defines প্রসার as attained outputs, not a codomain.
- **Alternatives and status:** ডোমেন/রেঞ্জ are common English bridges; সংজ্ঞাক্ষেত্র/মানক্ষেত্র were not found in the checked witnesses. **Uncertainty: low-to-medium; provisional across later advanced contexts.**
- **Review question:** Are অঞ্চল and প্রসার unambiguous for this sense across present West Bengal curricula, and should the loanwords remain at every major section restart rather than only first/glossary mention?

### BN-D03 — relation and ordered pair **[R]**

- **Anchors:** slot 11 / `term-00001`, slot 13 / `term-00002`, and glossary slot 803 / `fs-id1165135315533`.
- **Choice and sense:** `relation` → **সম্পর্ক** in running prose; **সম্বন্ধ** is retained as a witnessed heading synonym. `ordered pair` → **ক্রমজোড়**; the witness has **ক্রমযুগল**.
- **Alternatives and status:** using সম্বন্ধ and ক্রমযুগল throughout would maximize witness fidelity; current words aim for plain-language readability. **Uncertainty: medium; both headwords are provisional.**
- **Review question:** Should a West Bengal edition standardize on সম্বন্ধ/ক্রমযুগল, or are সম্পর্ক/ক্রমজোড় preferable for Grades 3–8 bridge readers entering precalculus?

### BN-D04 — variables, input, and output **[R]**

- **Anchors:** slots 22 and 27 / `fs-id1165134234609`; slots 24 / `term-00003` and 29 / `term-00004`; glossary slots 793, 795, and 799.
- **Choice and sense:** `variable` → **চল**, directly witnessed in Class VII; `independent/dependent variable` → **স্বাধীন চল / নির্ভরশীল চল**; `input/output` → **ইনপুট / আউটপুট**.
- **Alternatives and status:** the compound variable terms and the loanwords were not found in the checked pages. Descriptive bridges “যে মান বসাই / যে মান পাই” are used in AX-3 explanations rather than promoted as technical headwords. **Uncertainty: medium.**
- **Review question:** Are স্বাধীন চল and নির্ভরশীল চল standard in this region, and should the learner bridge pair ইনপুট/আউটপুট with descriptive Bengali on every first encounter?

### BN-D05 — one-to-one and line tests **[R]**

- **Anchors:** glossary slot 797 / `fs-id1165135511364`; slots 791 / `fs-id1165137932588` and 805 / `fs-id1165135315542`; explanatory clarification slot 463 / `fs-id1165137628999`.
- **Choice and sense:** `one-to-one function` → **এক-এক অপেক্ষক**; tests → **অনুভূমিক/উল্লম্ব সরলরেখা পরীক্ষা**. Slot 463 explicitly states that the displayed outputs are also distinct, avoiding the source sentence's insufficient “one output per input” explanation for injectivity.
- **Alternatives and status:** একৈক/এক-একী and রেখা-পরীক্ষা variants were not found in the checked witnesses. **Uncertainty: medium for terminology; low for the mathematical clarification.**
- **Review question:** Which one-to-one headword is current in West Bengal textbooks, and does “সরলরেখা পরীক্ষা” sound more natural than “রেখা পরীক্ষা” at this level?

### BN-D06 — evaluate versus solve **[R]**

- **Anchors:** paired source/target slots 703–704 / `fs-id1165134054032`, repeated in later exercises.
- **Choice and sense:** `evaluate` → **মান নির্ণয় করো**; `solve for` → **সমাধান করো**. The distinction separates calculating an output from finding an input satisfying an equation.
- **Alternatives and status:** মূল্য নির্ণয় and “চলটির মান বের করো” were not found in the checked pages. **Uncertainty: low-to-medium.**
- **Review question:** Does মান নির্ণয় reliably signal evaluation rather than equation solving to the intended school-to-precalculus audience?

### BN-D07 — graph and graphing **[R]**

- **Anchors:** slot 744 / `fs-id1165135530586` and figure alts throughout, including slot 419 / `Figure_01_01_007`.
- **Choice and sense:** `graph` → **লেখচিত্র** and `graph the function` → অপেক্ষকের লেখচিত্র আঁকো. The checked Class XII title contains চিত্রণ, but it does not by itself prove লেখচিত্র as the regional technical headword.
- **Alternatives and status:** গ্রাফ and চিত্রলেখ are plausible alternatives not verified in the checked pages. **Uncertainty: medium; provisional.**
- **Review question:** Is লেখচিত্র the preferred mathematical noun in current West Bengal usage, or should the edition use গ্রাফ/চিত্রলেখ with a bridge?

### BN-D08 — oral reading of “f of a” inside MathML **[R]**

- **Anchors:** source/target MathML slots 124–131 / `fs-id1165135332760`; related prose slot 190 / `eip-id1165132005171`.
- **Choice and sense:** variable order and MathML structure are preserved; the display currently uses the classroom-style bridge **“f অফ a”**, while prose expresses “x-এর অপেক্ষক.” This choice avoids rearranging source MathML tokens but is not attested in the checked witnesses.
- **Alternatives and status:** “a-এর জন্য f”, “f-এ a বসালে”, or syntactic reordering outside MathML may be more natural. **Uncertainty: high; explicitly provisional.**
- **Review question:** How do West Bengal teachers naturally read `f(a)` aloud, and which written rendering is clearest without changing the formula's semantic token order?

### BN-D09 — source descriptions corrected or clarified **[R]**

- **Anchors and dispositions:** slot 419 / `Figure_01_01_007` renders “centered at (1,0)” as **শীর্ষবিন্দু (1,0)**; slot 441 / `fs-id1165137469773`, figure `Figure_01_01_009`, asset `CNX_Precalc_Figure_01_01_009-4a94.jpg`, records that the source alt says vertex `(0,1)` while the unchanged image shows `(1,0)` and labelled points `(-1,4)`, `(3,4)`; slot 463 adds the distinct-output fact needed for one-to-one reasoning; slot 685 / `fs-id1165137847091` omits the visually unsupported “increasingly steep” claim.
- **Rationale and status:** mathematics and pixels remain unchanged; Bengali prose states only what the image or definition supports. **Uncertainty: low**, except whether an accessibility description should carry the source-discrepancy note or place it in nearby editorial prose.
- **Review question:** For screen-reader users, should the explicit `(0,1)` source-error notice remain inside the alt description, or move to adjacent text while the alt simply reports the visible `(1,0)` vertex?

### BN-D10 — AX-3 learner-support vocabulary **[R]**

- **Anchors:** `adaptations/AX-3-functions.bn-IN.html`, sections 1, 3, 5, 6, and “শব্দের সেতু”. This file is labelled new support, separate from OpenStax source content.
- **Choice and sense:** AX-3 repeats অপেক্ষক, অঞ্চল, প্রসার, স্বাধীন/নির্ভরশীল চল, এক-এক, ইনপুট, আউটপুট, and ক্রমজোড় while explaining the core tests in full sentences. It distinguishes an attained range from a possible codomain and separates diagnostic answers, remediation, and recheck.
- **Alternatives and status:** a more Bengali-first bridge could lead with “যে মান বসাই / যে মান পাই” before the loanwords. No learner or classroom validation is claimed. **Uncertainty: medium; provisional for Grades 3–8 accessibility.**
- **Review question:** Which of these loanwords or advanced headwords should receive a descriptive Bengali gloss at every AX-3 use, and which can safely be taught once in the word bridge?

## Maintenance rule

For `m49324`, append substantive terminology or difficult-translation decisions here as they are made, with source/target anchors, checked authority, alternatives, uncertainty, and one answerable review question. If no authority is found, say so. Expert corrections may inform a later version, but missing responses must never leave untranslated gaps or block a coherent release.
