"""Frozen CNXML text-slot translation and deterministic semantic offline HTML."""
from pathlib import Path
import argparse, copy, hashlib, html, json, re, xml.etree.ElementTree as E
BASE=Path(__file__).resolve().parents[1]
C='http://cnx.rice.edu/cnxml'; M='http://www.w3.org/1998/Math/MathML'; MD='http://cnx.rice.edu/mdml'
E.register_namespace('', C); E.register_namespace('m',M); E.register_namespace('md',MD)
def local(e): return e.tag.split('}')[-1]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def slots(root):
    out=[]
    def walk(e, in_math=False):
        math=in_math or e.tag.startswith('{'+M+'}')
        if e.text and re.search('[A-Za-z]',e.text) and (not math or local(e)=='mtext') and local(e) not in ('content-id','uuid'):
            out.append((e,'text',e.text))
        for k in ('alt',):
            if e.get(k) and re.search('[A-Za-z]',e.get(k)): out.append((e,k,e.get(k)))
        for ch in e:
            walk(ch,math)
            if ch.tail and re.search('[A-Za-z]',ch.tail) and not math: out.append((ch,'tail',ch.tail))
    walk(root); return out
parser=argparse.ArgumentParser();parser.add_argument('--extract',action='store_true');parser.add_argument('--start',type=int,default=0);parser.add_argument('--end',type=int,default=9999)
args=parser.parse_args(); source=BASE/'upstream/m49301.cnxml'; doc=E.parse(source); ss=slots(doc.getroot())
if args.extract:
    for i,(e,k,t) in enumerate(ss):
        if args.start<=i<args.end: print(f'{i}: '+re.sub(r'\s+',' ',t).strip())
    print('TOTAL',len(ss));raise SystemExit
mapping=json.loads((BASE/'translations/m49301.slots.json').read_text(encoding='utf-8'))
# Terminology refinement after direct inspection of West Bengal Class XII p.1.
# Preserve the source slot identities while using the witnessed regional words.
mapping={k:v.replace('ডোমেন','অঞ্চল').replace('রেঞ্জ','প্রসার') for k,v in mapping.items()}
mapping['15']='অঞ্চল (domain বা ডোমেন)';mapping['17']='প্রসার (range বা রেঞ্জ)'
mapping['787']='অঞ্চল (ডোমেন)';mapping['801']='প্রসার (রেঞ্জ)'
mapping['125']='অফ';mapping['131']=' অফ '
mapping['190']=' হল এই চলের অপেক্ষক: '
missing=[i for i in range(len(ss)) if str(i) not in mapping]
if missing: raise ValueError(f'Missing {len(missing)} slots: {missing[:15]}')
for i,(e,k,t) in enumerate(ss):
    v=mapping[str(i)]
    if k in ('text','tail'): setattr(e,k,v)
    else:e.set(k,v)
translated=BASE/'translations/m49301.bn-Beng-IN.cnxml'
doc.write(translated,encoding='utf-8',xml_declaration=True)
original=E.parse(source).getroot(); root=doc.getroot()
def invariant(r):
    return [(e.tag,{k:v for k,v in e.attrib.items() if k!='alt'}) for e in r.iter()]
assert invariant(original)==invariant(root),'Structure/attribute drift'
def math_core(r):return [(e.tag,e.text) for e in r.iter() if e.tag.startswith('{'+M+'}') and local(e)!='mtext']
assert math_core(original)==math_core(root),'Mathematical token drift'
ids={e.get('id') for e in root.iter() if e.get('id')}; assets=[]; unresolved=[]; display_punctuation=[]
parents={child:parent for parent in root.iter() for child in parent}
labels={}
for tag,label in [('figure','চিত্র'),('table','সারণি'),('example','উদাহরণ'),('exercise','প্রশ্ন')]:
    for n,e in enumerate(root.iter('{'+C+'}'+tag),1):
        if e.get('id'):labels[e.get('id')]=f'{label} {n}'
for e in root.iter():
    if e.get('id') and e.get('id') not in labels:
        title=e.find('{'+C+'}title')
        if title is not None:labels[e.get('id')]=''.join(title.itertext())
def inner(e,depth):return html.escape(e.text or '')+''.join(render(ch,depth)+html.escape(ch.tail or '') for ch in e)
def render(e,depth=1):
    t=local(e); a=' id="'+html.escape(e.get('id'))+'"' if e.get('id') else ''; body=lambda:inner(e,depth)
    if e.tag.startswith('{'+M+'}'):
        c=copy.deepcopy(e);c.tail=None;c.set('dir','ltr')
        last=c
        while len(last):last=last[-1]
        if local(last)=='mo' and last.text in ('.',',','?'):
            display_punctuation.append({'source_math_index':len(display_punctuation),'punctuation':last.text,'action':'remove source sentence punctuation from mathematical display only'})
            last.text=''
        s=E.tostring(c,encoding='unicode');s=s.replace('m:','').replace('xmlns:m=', 'xmlns=');return s
    if t=='metadata':return ''.join(render(x,depth) for x in e if local(x)=='abstract')
    if t in ('uuid','content-id','colspec'):return ''
    if t=='newline':return '<br'+a+'>'
    if t in ('sup','sub'):return '<'+t+a+'>'+body()+'</'+t+'>'
    if t=='title':return f'<h{min(depth,6)}{a}>{body()}</h{min(depth,6)}>'
    if t=='glossary':return '<section'+a+'><h2>শব্দার্থ</h2>'+body()+'</section>'
    if t in ('document','content','abstract'):return body()
    if t=='section':return '<section'+a+'>'+''.join(render(x,depth+1)+html.escape(x.tail or '') for x in e)+'</section>'
    if t=='para':return '<p'+a+'>'+body()+'</p>'
    if t in ('example','note','exercise','problem','solution','definition','meaning','commentary'):
        label=labels.get(e.get('id',''),'') if t in ('example','exercise') else ('মূল উৎসের সমাধান' if t=='solution' else '')
        head='<p class="label">'+label+'</p>' if label else ''
        return '<div class="'+t+'"'+a+'>'+head+inner(e,depth+1)+'</div>'
    if t=='term':return '<dfn'+a+'>'+body()+'</dfn>'
    if t=='emphasis':return '<em'+a+'>'+body()+'</em>'
    if t=='list':
        tag='ol' if e.get('list-type')=='enumerated' else 'ul'
        typ=' type="a"' if e.get('number-style')=='lower-alpha' else ''
        return '<'+tag+a+typ+'>'+body()+'</'+tag+'>'
    if t=='item':return '<li'+a+'>'+body()+'</li>'
    if t=='equation':return '<div class="equation"'+a+'>'+body()+'</div>'
    if t=='figure':return '<figure'+a+'><p class="label">'+labels.get(e.get('id',''),'')+'</p>'+body()+'</figure>'
    if t=='caption':return '<figcaption'+a+'>'+body()+'</figcaption>'
    if t=='media':
        images=[x for x in e if local(x)=='image']; chosen=images[:1]
        return ''.join(render_image(x,e.get('alt',''),a) for x in chosen)
    if t=='image':return render_image(e,e.get('alt',''),a)
    if t=='link':
        target=e.get('target-id');url=e.get('url')
        if target:
            if target not in ids:unresolved.append(target)
            url='#'+target
        if not url:return body()
        label=body() or (labels.get(target,'উৎসের উল্লেখ') if target else url)
        return '<a'+a+' href="'+html.escape(url)+'">'+label+'</a>'
    if t=='table':return '<div class="table-scroll"><table'+a+'><caption>'+labels.get(e.get('id',''),'')+'</caption>'+body()+'</table></div>'
    if t=='tgroup':return body()
    if t in ('thead','tbody'):return '<'+t+a+'>'+body()+'</'+t+'>'
    if t=='row':return '<tr'+a+'>'+body()+'</tr>'
    if t=='entry':
        p=parents.get(e);p=parents.get(p)
        tag='th' if p is not None and local(p)=='thead' else 'td'
        span=''
        if e.get('namest') and e.get('nameend'):
            span=' colspan="'+str(int(e.get('nameend')[1:])-int(e.get('namest')[1:])+1)+'"'
        scope=' scope="col"' if tag=='th' else ''
        return '<'+tag+a+span+scope+'>'+body()+'</'+tag+'>'
    if t=='footnote':return '<small class="footnote"'+a+'>'+body()+'</small>'
    if t=='label':return '<span class="label"'+a+'>'+body()+'</span>'
    return '<span'+a+'>'+body()+'</span>'
def render_image(e,alt,a):
    name=Path(e.get('src','')).name; assets.append(name)
    assert (BASE/'assets'/name).exists(),name
    return '<img'+a+' src="../assets/'+html.escape(name)+'" alt="'+html.escape(alt)+'" loading="lazy">'
body=render(root)
page='<!doctype html><html lang="bn-IN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>অপেক্ষক ও অপেক্ষকের সংকেত</title><style>*,*::before,*::after{box-sizing:border-box}body{font:20px/1.75 "Nirmala UI","Noto Sans Bengali",sans-serif;width:100%;max-width:72rem;margin:auto;padding:2rem;color:#182335;background:#fff}p{max-width:70ch}h1,h2,h3{line-height:1.35;color:#173963}figure{margin:2rem 0}img{display:block;max-width:100%;height:auto;margin:auto}math{font-size:1.05em;direction:ltr;display:inline-block;max-width:100%;overflow-x:auto;overflow-y:hidden;vertical-align:middle}math[display=block]{display:block}math[display=block],.equation,.table-scroll{max-width:100%;overflow-x:auto;padding:.3rem}table{border-collapse:collapse;margin:1rem 0}td,th{border:1px solid #96a6b8;padding:.45rem .8rem}.example,.note,.solution{border-left:3px solid #6794b8;padding:.8rem 1.2rem;margin:1rem 0;background:#f4f8fc}.exercise{margin:1.3rem 0}.label{font-weight:600}a{color:#16548f}.footnote{display:block}figcaption{font-size:.9em}dfn{font-style:normal;font-weight:bold}@media(max-width:700px){body{padding:1rem;font-size:18px}}@media print{body{padding:0;font-size:12pt}.example,.note{break-inside:avoid}}</style><header><p>OpenStax Precalculus 2e · নির্বাচিত মডিউল m49301 · ভারতীয় বাংলা (পশ্চিমবঙ্গ)</p><p><a href="../adaptations/AX-3-functions.bn-IN.html">আলাদা AX-3 প্রস্তুতি ও ধাপে-ধাপে সহায়তা</a> · <a href="../LICENSE.md">উৎস ও স্বীকৃতি</a></p></header><main>'+body+'</main><footer><p>মূল শিক্ষণসামগ্রীর বাংলা অনুবাদ। সংযুক্ত AX-3 সহায়তা নতুন রচনা; তা OpenStax-এর মূল পাঠ নয়। চিত্রের মূল ইংরেজি লেবেল অক্ষুণ্ণ; বাংলা বিকল্প বর্ণনা সংযুক্ত।</p></footer></html>'
(BASE/'reader/m49301.bn-IN.html').write_text(page,encoding='utf-8',newline='\n')
qa={'schema':'a30-bn-selected-qa/1','module':'m49301','source_sha256':digest(source),'translated_sha256':digest(translated),'reader_sha256':digest(BASE/'reader/m49301.bn-IN.html'),'slot_count':len(ss),'mapped_slots':len(mapping),'cnxml_structure_and_ids':'pass','math_tokens_except_translated_mtext':'identical','figures':len(list(root.iter('{'+C+'}figure'))),'exercises':len(list(root.iter('{'+C+'}exercise'))),'source_solutions':len(list(root.iter('{'+C+'}solution'))),'mathml_blocks':len(list(root.iter('{'+M+'}math'))),'assets':sorted(set(assets)),'unresolved_local_refs':sorted(set(unresolved)),'display_only_sentence_punctuation_removals':len(display_punctuation),'visual_review':'owner serial review required; not claimed performed by worker'}
(BASE/'qa/m49301.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(qa,ensure_ascii=False))
