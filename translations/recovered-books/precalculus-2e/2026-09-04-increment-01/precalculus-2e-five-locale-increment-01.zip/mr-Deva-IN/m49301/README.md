# OpenStax Precalculus 2e — मराठी

Start with [फलने आणि फलनांचे संकेतलेखन](reader/m49301.mr.html). Download this folder with its `assets` directory for offline reading. The reader uses native MathML and locally available Devanagari fonts; no network font, CDN or JavaScript is required. External source links remain optional online references.

This is a **complete source-module translation checkpoint, not a completed book**. Module `m49301` includes its objectives, all teaching prose, examples, exercises, supplied answers, recap and glossary. Its source contains 805 IDs, 411 MathML expressions, 119 exercise elements, 73 supplied solution elements, 19 tables and 50 images. The original 50 image files and all mathematical markup are unchanged. Every one of the 467 non-MathML prose segments and 50 image descriptions has a Marathi rendering. Proper names, mathematical symbols and English words embedded in original MathML/images are retained with an English–Marathi bridge. Original optional video links may require internet and are not represented as Marathi videos.

The full assigned A30 Precalculus/Trigonometry book remains the end goal. This checkpoint advances the original Grade 8–first-year STEM bridge rather than substituting a short bridge for the book. The next instructional module is `m49304` (Domain and Range). Root-level owner controls track front matter and the rest of the 87-item collection. Other assigned Marathi books are maintained separately and are not included here.

## Source and comparison identities

- English authority: `openstax/osbooks-college-algebra-bundle`, commit `789b54099106b071d1d32bfcee454fed72eb4768`; tree `05b39123f698772482c0c33a43fa2d2d4ea562ae`.
- Work: *Precalculus 2e*, collection UUID `f021395f-fd63-46cd-ab95-037c6f051730`.
- Exact source: `modules/m49301/index.cnxml`, 197,298 bytes, SHA-256 `81115d90dd1d9781e65844526bbbfbea638cc6fd515c623c4d535bf3bd0e37e3`.
- The original Marathi acquisition selected Indonesian `v0.1.0-alpha.58-reader.1` as comparison material (source ZIP SHA-256 `9f8ba5e44bd4d4794c559de85a5449f3b4bd279d153801b94f3d39a471f5a0ca`). This checkpoint translates the frozen English module directly; no silent comparison-pin migration is claimed.
- The original Marathi A30 target consisted only of one function definition in a cross-book bridge. This complete module preserves its established terminology while integrating that concept in source order. The immutable recovered bridge remains unchanged.

## Distinct content layers

The body follows the source module. Expandable boxes headed “मूळ पुस्तकातील उत्तर / उकल” contain the source's supplied answers, not newly authored ones. A final clearly labelled Marathi bridge supplies three new diagnostic questions, their worked explanations and a recheck. Missing source solutions have not been invented or described as supplied; comprehensive additional worked support remains a continuing book-level obligation.

The original source-alt vertex error in Figure_01_01_009 is corrected explicitly in the Marathi alt after direct inspection: `(1,0)`, not `(0,1)`. The original CNXML witness and image remain unchanged. The historical pet-memory claims are kept as source-era contextual data, not asserted as independently validated biology. A separate note explains nonzero divisors, the difference between function and one-to-one, and the missing outside-module chapter-start image. These editorial notes are not attributed to OpenStax.

## Build and checks

Run `python -X utf8 scripts/build_m49301.py` with Python 3. It needs only this folder and the standard library. The editable Marathi CNXML and HTML are regenerated from the English source, numbered translation segments, Marathi alt text and the separate bridge fragment. Placeholder checks preserve every source child exactly once, with inline reordering only for grammatical Marathi. Structural checks compare all IDs, the multiset of exact MathML bytes, exercises/solutions/figures/tables and every asset hash. See `qa/m49301-build.json` and `qa/m49301-semantic.json` for actual checks; visual acceptance is separately recorded by the owner and is not inferred from structural pass.

Regional terminology consultations and provisional choices are summarized in [TERMINOLOGY.md](TERMINOLOGY.md). The publishable [translation decision log](TRANSLATION_DECISIONS.md) gives exact source/target anchors, actual authorities checked, retrospective rationales, alternatives, uncertainty and focused expert-review questions. Missing expert review creates no gap or publication hold; provisional choices remain explicitly open to later correction. All source author and human-contributor credits remain in `provenance/precalculus-front-matter.cnxml`.

Translation and independent reader implementation: OpenAI Codex gpt-5.6-sol, Ultra, on the user's instructions. OpenStax / Rice University and its contributors retain the original authorship. See [LICENSE.md](LICENSE.md).
