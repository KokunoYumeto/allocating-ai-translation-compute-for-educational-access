# License and attribution

OpenStax *Precalculus 2e*, Jay Abramson and contributing authors; copyright Rice University / OpenStax. Source prose, Marathi translation and separately identified original educational adaptations: **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International** — https://creativecommons.org/licenses/by-nc-sa/4.0/ .

Retain attribution, the change notice and ShareAlike terms. This is a noncommercial independent translation; no OpenStax or Rice University endorsement is implied. No logo or source cover is included. Full original contributor credits are preserved in `provenance/precalculus-front-matter.cnxml`. Image component classifications, hashes and notices are preserved in `provenance/assets.json`; they remain authoritative over any general statement. The work-level license witness is `provenance/UPSTREAM_LICENSE.txt`.

Original source and image bytes are preserved. Changes are Marathi prose and alternative text, accessible HTML presentation and separately labelled learner support. One graph-alt coordinate correction is explicit. Consulted Marathi terminology references are not relicensed or redistributed as part of this translation.
