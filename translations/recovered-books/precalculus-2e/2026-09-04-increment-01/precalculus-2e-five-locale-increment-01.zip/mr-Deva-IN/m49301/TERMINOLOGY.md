# Marathi mathematical terminology — m49301

This is the quick working register. See [TRANSLATION_DECISIONS.md](TRANSLATION_DECISIONS.md) for the complete traceable inventory and difficult-decision records, including exact anchors, evidence limits, alternatives, uncertainty and expert-review questions.

## Actual consultation, 2026-09-04

Before drafting, the writer read the original recovered Marathi canon catalogue and its function/domain/range distinctions. Fresh direct opens of the three official entries failed (timeout/502); subsequent web search-reader retrievals returned readable official prose. The writer actually read these passages, rather than merely counting saved reference metadata:

- [फलन, Marathi Vishwakosh](https://vishwakosh.marathi.gov.in/27548/): opening definition and the following domain/codomain/image-set sentences. This supports `फलन`, `प्रांत`, `सहप्रांत`, and the range synonym `कक्षा`. The witness is used for terminology, not its unrelated advanced assertions; the inverse-function paragraph's apparent unrestricted-codomain claim is not imported.
- [आलेख, Marathi Vishwakosh](https://vishwakosh.marathi.gov.in/24316/): Cartesian axes and ordered coordinate construction. Read again during revision. This supports `आलेख`, horizontal/vertical orientation and `सहनिर्देशक`. Its context-specific joining of data points is not applied to arbitrary finite relations.
- [गणितीय संकेतने, चिन्हे व संज्ञा](https://vishwakosh.marathi.gov.in/21279/): the absolute-value row was retrieved and read during revision. It directly supports `केवल मूल्य`.

Only short terms and editorial analysis are reproduced here. No unobserved PDF page or missing image-only formula is claimed as read. The older Balbharati evidence remains original-lane evidence, not a claim of a fresh full textbook inspection in this checkpoint.

## Decisions carried into the draft

| English | Marathi | Evidence / decision |
|---|---|---|
| function | फलन | Official opening definition supports the term and uniqueness condition. |
| domain | प्रांत | Attested; distinct from the visible plot window. |
| codomain | सहप्रांत | Attested; may contain values not attained. |
| range | मूल्यसंच; synonym कक्षा | Keep the existing lane's working `मूल्यसंच` consistently; exact working term remains provisional. `कक्षा` is attested. |
| coordinate | सहनिर्देशक | Attested in Cartesian coordinate construction. |
| absolute value | केवल मूल्य | Attested in the notation row. |
| input/output | आदान/प्रदान | Inherited provisional classroom choices; English equivalents shown. |
| independent/dependent variable | स्वतंत्र चल/अवलंबी चल | Inherited full compounds remain provisional; explain roles rather than imply experimental control. |
| function notation | फलनाचे संकेतलेखन | Inherited provisional term; explicitly not multiplication. |
| one-to-one function | एकास-एक फलन | Existing mathematical usage and witness wording; test injectivity over attained outputs, not surjectivity onto a declared codomain. |
| vertical/horizontal line test | उभ्या/आडव्या रेषेची कसोटी | Authored classroom compounds, not claimed verbatim canon quotations. |
| identity function | तत्सम फलन | Provisional working choice; formula `f(x)=x` is retained as the controlling definition. |
| quadratic/cubic toolkit | वर्ग/घन फलन | Descriptive local choices for exact `x²` and `x³` prototypes; not a claim all quadratics equal `x²`. |

Revision checked source numbers and labels, allowing shared outputs for a function but rejecting them for injectivity. The Marathi text uses complete instructional phrases and inline source children may be reordered for natural grammar. Every mathematical child remains unmodified. There is no claim of human review or definitive terminology authority.
