# Marathi terminology and difficult-translation decisions

This is the public, append-only decision register for the Marathi A30 lane. Its current coverage is source module `m49301` only. Later modules should add entries rather than silently replacing earlier reasoning.

## Provenance and how to read the locations

- Frozen English source: `upstream/m49301.cnxml`, 197,298 bytes, SHA-256 `81115d90dd1d9781e65844526bbbfbea638cc6fd515c623c4d535bf3bd0e37e3`.
- Marathi segment source: `translations/m49301.mr.tsv`; Marathi image descriptions: `translations/m49301-alt.mr.tsv`.
- A location such as `segment n=31 / #term-00006` means numeric key `31` in `translations/segments.json` and `translations/m49301.mr.tsv`, with the preserved CNXML/reader ID when one exists. A location without an ID is still exact because the segment key is unique and the build requires all 467 keys exactly once.
- Entries `MR-M49301-D01` through `D10` were reconstructed on 2026-09-04 after the translation was sealed. Their rationales are **retrospective reconstructions**, not claims about a contemporaneous private chain of thought. The chosen words, authorities actually checked, alternatives, uncertainty and review questions are current editorial evidence.
- No native-speaker or human-expert approval is claimed. A provisional entry remains usable and publishable while awaiting optional asynchronous correction.

## Authorities actually checked

| Code | Actual consultation and admitted scope |
|---|---|
| `E-FUNCTION` | [फलन, Marathi Vishwakosh](https://vishwakosh.marathi.gov.in/27548/): the opening definition and following domain/codomain/image-set sentences were read through a search-reader retrieval after direct official opens timed out or returned 502. Admitted for `फलन`, `प्रांत`, `सहप्रांत` and attested range synonym `कक्षा`; the entry's broader inverse-function assertion was not imported. |
| `E-GRAPH` | [आलेख, Marathi Vishwakosh](https://vishwakosh.marathi.gov.in/24316/): Cartesian axes and ordered-coordinate construction were read. Admitted for `आलेख`, horizontal/vertical orientation and `सहनिर्देशक`; its context-specific joining of data points was not generalized. |
| `E-NOTATION` | [गणितीय संकेतने, चिन्हे व संज्ञा](https://vishwakosh.marathi.gov.in/21279/): the absolute-value row was retrieved and read. Admitted for `केवल मूल्य`; it is only indirect support for compounds containing `संकेतलेखन`. |
| `E-INHERITED` | The recovered lane's prior terminology/canon records and Balbharati note were consulted during drafting. They are inherited evidence, not a claim that a complete school textbook was freshly inspected for this checkpoint. |
| `E-IMAGE-009` | `assets/CNX_Precalc_Figure_01_01_009-4a94.jpg`, 104,899 bytes, SHA-256 `cf77d80db8d2616f63ef758adbccd016eac20df35a3e1699c2d4da131820736b`, was directly inspected at original resolution. |

No other regional authority is claimed below. “Not found in checked sources” means only the three cited Vishwakosh passages did not establish that exact classroom expression; it does not claim exhaustive absence from Marathi usage.

## Complete substantive term inventory for m49301

| ID | English → current Marathi | Exact source/target anchor | Evidence and status |
|---|---|---|---|
| `T01` | relation → `संबंध` | segment `n=11` / `#term-00001` | `E-FUNCTION`; working, low uncertainty |
| `T02` | ordered pair → `क्रमित जोडी` | `n=12` / `#term-00002` | not specifically found in checked passages; working, low uncertainty |
| `T03` | independent/dependent variable → `स्वतंत्र चल` / `अवलंबी चल` | `n=18` / `#term-00003`; `n=20` / `#term-00004`; explanatory `n=80` / `#eip-id1165135256026` | `E-INHERITED`; provisional |
| `T04` | natural numbers → `नैसर्गिक संख्या` | `n=23` / `#term-00005` | not specifically found in checked passages; working, low uncertainty |
| `T05` | function → `फलन` | `n=31` / `#term-00006` | `E-FUNCTION`; established working choice |
| `T06` | input/output → `आदान` / `प्रदान` | `n=33` / `#term-00007`; `n=35` / `#term-00009` | `E-INHERITED`; provisional; see `D02` |
| `T07` | domain/range → `प्रांत` / `मूल्यसंच` | `n=34` / `#term-00008`; `n=36` / `#term-00010`; repeated domain `n=199` / `#term-00014` | domain supported by `E-FUNCTION`; range wording provisional; see `D01` |
| `T08` | function notation → `फलनाचे संकेतलेखन` | `n=72` / `#term-00011`; explanatory `n=74` / `#fs-id1165137766965` | `E-INHERITED`, with only indirect `E-NOTATION` support; provisional |
| `T09` | equation/formula → `समीकरण` / `सूत्र` | `n=164` / `#term-00012`; `n=165` / `#term-00013` | not specifically found in checked passages; working, low uncertainty |
| `T10` | evaluate a function → `फलनाचे मूल्य काढणे` | `n=130` / `#fs-id1165137470651`; `n=135` / `#fs-id1165137655584` | pedagogical paraphrase rather than a one-word calque; provisional, low uncertainty |
| `T11` | one-to-one function → `एकास-एक फलन` | `n=243` / `#term-00015`; meaning controlled at `n=230` / `#fs-id1165135245630` | `E-FUNCTION` context plus `E-INHERITED`; provisional compound; see `D04` |
| `T12` | vertical/horizontal line test → `उभ्या/आडव्या रेषेची कसोटी` | `n=265` / `#term-00016`; `n=280` / `#term-00017` | authored classroom compounds, not found verbatim in checked passages; provisional |
| `T13` | graph/coordinate → `आलेख` / `सहनिर्देशक` | `n=303` (table entry); `n=261` / `#fs-id1165137637786` | `E-GRAPH`; established working choices |
| `T14` | absolute value → `केवल मूल्य` | `n=307` (table entry) | `E-NOTATION`; directly attested |
| `T15` | identity function → `तत्सम फलन` | `n=325` (toolkit table entry) | not found in checked passages; provisional, high review value; see `D05` |
| `T16` | quadratic/cubic function → `वर्ग फलन` / `घन फलन` | `n=327` and `n=328` (toolkit table entries) | formula-controlled local labels; provisional, high review value; see `D05` |
| `T17` | toolkit functions → `मूलभूत साधनरूप फलने` | `n=298` / `#fs-id1165137698132` | explanatory classroom rendering; not found in checked passages; provisional |
| `T18` | parabola → `अन्वस्त` | image-description keys `5`, `6`, `7`, `8` in `translations/m49301-alt.mr.tsv` | not found in checked passages; provisional, high review value; see `D06` |
| `T19` | codomain → `सहप्रांत` | no occurrence in the frozen English m49301 prose; Marathi support anchor `reader/bridge.fragment.html#mr-original-bridge` | `E-FUNCTION`; added only to distinguish codomain from attained range |

## Decisions that merit expert attention

### MR-M49301-D01 — domain, range and codomain are kept distinct

- **Locations:** source/target segments `n=34` (`#term-00008`), `n=36` (`#term-00010`) and `n=199` (`#term-00014`); additional Marathi-only bridge at `reader/bridge.fragment.html#mr-original-bridge`.
- **Choice and sense:** `domain` = `प्रांत`; attained `range` = `मूल्यसंच`; `codomain` = `सहप्रांत`. `कक्षा` is recorded as an attested synonym for range but is not the running term.
- **Checked authority:** `E-FUNCTION`. The frozen m49301 source does not itself use “codomain.”
- **Retrospective rationale:** retaining the lane's `मूल्यसंच` makes “values actually obtained” transparent and avoids using one Marathi word for both range and codomain. The bridge introduces `सहप्रांत` only to state that distinction.
- **Alternatives:** use attested `कक्षा` for range; use a longer explanatory phrase such as `फलनाने प्रत्यक्ष मिळणाऱ्या मूल्यांचा संच` at first occurrence.
- **Status:** provisional; medium uncertainty about school-level convention, not about the mathematical distinction.
- **Expert-review question:** In Maharashtra Grade 8–first-year STEM materials, is `मूल्यसंच` or `कक्षा` the least ambiguous default for the attained range, while reserving `सहप्रांत` for codomain?

### MR-M49301-D02 — input/output and variable roles

- **Locations:** `n=18` (`#term-00003`), `n=20` (`#term-00004`), `n=33` (`#term-00007`), `n=35` (`#term-00009`) and full role explanation `n=80` (`#eip-id1165135256026`).
- **Choice and sense:** `input/output` = `आदान/प्रदान`; `independent/dependent variable` = `स्वतंत्र चल/अवलंबी चल`.
- **Checked authority:** inherited lane evidence only (`E-INHERITED`); these exact pairs were not established by `E-FUNCTION`, `E-GRAPH` or `E-NOTATION`.
- **Retrospective rationale:** the short native pair stays readable in tables and allows the longer variable-role compounds to remain conceptually separate. The prose explains dependence instead of implying experimental causation.
- **Alternatives now identified for review:** transliterated `इनपुट/आउटपुट`; `निविष्ट/निर्गत`; first-use bilingual labels.
- **Status:** provisional; medium uncertainty.
- **Expert-review question:** Which pair is actually most familiar and least misleading in current Marathi-medium secondary mathematics: `आदान/प्रदान`, `निविष्ट/निर्गत`, or bilingual `इनपुट/आउटपुट` on first use?

### MR-M49301-D03 — function notation is not multiplication

- **Locations:** `n=72` (`#term-00011`) and explanation `n=74` (`#fs-id1165137766965`); English–Marathi reminder in `reader/bridge.fragment.html#mr-original-bridge`.
- **Choice and sense:** `function notation` = `फलनाचे संकेतलेखन`; the text explicitly says the parentheses in `f(x)` indicate an input, not multiplication.
- **Checked authority:** inherited lane wording; `E-NOTATION` supports the general notation family but not this exact compound.
- **Retrospective rationale:** `संकेतलेखन` emphasizes a writing convention and supports the recurring instructional verb “write in function notation.”
- **Alternatives:** `फलन-संकेतन`, `फलन संकेतना`, or retaining English in parentheses at first use.
- **Status:** provisional; medium uncertainty in wording, low uncertainty in sense.
- **Expert-review question:** Which compound is normal in Marathi-medium algebra, and does `संकेतलेखन` sound like a procedure rather than the notation system itself?

### MR-M49301-D04 — injectivity and the two line tests

- **Locations:** definition `n=230` (`#fs-id1165135245630`), term `n=243` (`#term-00015`), vertical test `n=265` (`#term-00016`), horizontal test `n=280` (`#term-00017`).
- **Choice and sense:** `one-to-one function` = `एकास-एक फलन`; `vertical/horizontal line test` = `उभ्या/आडव्या रेषेची कसोटी`. The controlling sense is injectivity over attained outputs, not surjectivity onto an announced codomain.
- **Checked authority:** the function/inverse context in `E-FUNCTION` and inherited lane usage; the line-test compounds were not found verbatim in the checked passages.
- **Retrospective rationale:** the paired compounds make the graph procedures immediately interpretable, while the prose supplies the exact quantifier condition and corrects the source's later overly short explanation.
- **Alternatives:** `एक-एक फलन`, a more formal injective-function term, or retaining “vertical/horizontal line test” in parentheses.
- **Status:** provisional terminology; mathematical condition checked with low uncertainty.
- **Expert-review question:** Is `एकास-एक फलन` the preferred Maharashtra classroom term, and is `रेषेची कसोटी` idiomatic for both tests?

### MR-M49301-D05 — toolkit labels are controlled by their formulas

- **Locations:** toolkit table entries `n=325`, `n=327`, `n=328`; contextual introduction `n=298` (`#fs-id1165137698132`).
- **Choice and sense:** `identity function` = `तत्सम फलन`; the `x²` and `x³` prototypes are labelled `वर्ग फलन` and `घन फलन`. These labels describe the displayed prototypes and do not assert that every quadratic is exactly `x²` or every cubic exactly `x³`.
- **Checked authority:** no exact attestation in the checked passages; formulas and unchanged MathML are the semantic authority.
- **Retrospective rationale:** short labels fit the source's compact toolkit table, but the surrounding wording prevents an overgeneralization.
- **Alternatives now identified for review:** `एकक फलन` or `ओळख फलन` for identity; `द्विघाती फलन` and `त्रिघाती फलन` for quadratic and cubic.
- **Status:** provisional; high terminology uncertainty.
- **Expert-review question:** Should these three table labels be changed to `एकक/ओळख फलन`, `द्विघाती फलन` and `त्रिघाती फलन` even though the source row is introducing only the prototypes `f(x)=x`, `f(x)=x²`, `f(x)=x³`?

### MR-M49301-D06 — graph language and “parabola” use different evidence levels

- **Locations:** graph table entry `n=303`; coordinate explanation `n=261` (`#fs-id1165137637786`); parabola image-description keys `5`–`8` in `translations/m49301-alt.mr.tsv`.
- **Choice and sense:** `graph` = `आलेख`, coordinate = `सहनिर्देशक`, parabola = `अन्वस्त`.
- **Checked authority:** `आलेख` and `सहनिर्देशक` are supported by `E-GRAPH`. `अन्वस्त` was inherited/selected but was not found in the three checked passages.
- **Retrospective rationale:** the first two align with the checked Cartesian description. `अन्वस्त` avoids an English transliteration and is used consistently across the affected alts.
- **Alternatives for parabola:** `परवलय`, `पॅराबोला`, or a first-use bilingual form.
- **Status:** graph/coordinate low uncertainty; parabola provisional with high review value.
- **Expert-review question:** Is `अन्वस्त` recognizable in current Marathi-medium secondary mathematics, or should the reader prefer `परवलय` or a bilingual first occurrence?

### MR-M49301-D07 — Figure_01_01_009 alt corrects a source coordinate

- **Locations:** English alt witness `translations/alt-en.json` index `8`, source ID `#fs-id1165137469773`; Marathi alt key `8`; reader `#Figure_01_01_009`; unchanged asset identified by `E-IMAGE-009`.
- **Choice and sense:** target says the upward-opening parabola has vertex `(1,0)` and explicitly notes that the source alt's `(0,1)` was corrected after inspecting the image. The labelled points `(-1,4)` and `(3,4)` and line `y=4` are preserved.
- **Checked authority:** direct image inspection (`E-IMAGE-009`), corroborated by the graph's symmetry and the source's neighbouring mathematical discussion. The original CNXML and image bytes remain unchanged.
- **Retrospective rationale:** reproducing `(0,1)` would make the accessible description mathematically false; silently changing it would hide the source divergence.
- **Alternative:** reproduce the faulty source alt verbatim. Rejected because accessibility should describe the admitted image accurately.
- **Status:** high-confidence correction; open only to correction-policy review.
- **Expert-review question:** Is the explicit in-alt correction note preferable, or should the alt state only the accurate geometry while the divergence remains solely in this log?

### MR-M49301-D08 — historical animal-memory claims are translated, not revalidated

- **Locations:** source/target `n=188` (`#fs-id1165135186424`), dated citation `n=190` (`#fs-id1165135434830`), and caveat `reader/bridge.fragment.html#mr-original-bridge`.
- **Choice and sense:** the numerical claims remain as source-era contextual data; the Marathi adds `मूळ मजकुरानुसार` before the values and the bridge says no independent modern biological validation is claimed.
- **Checked authority:** only the frozen OpenStax source and its dated citation; no current biology authority was checked.
- **Retrospective rationale:** mathematics translation requires preserving the table used by the exercises, while the qualification avoids presenting old contextual claims as newly verified facts.
- **Alternatives:** silently modernize, omit, or reproduce without a caveat. Those would respectively alter the source exercise data, break coverage, or overstate validation.
- **Status:** source-faithful editorial disposition; factual currency remains unverified.
- **Expert-review question:** Is `मूळ मजकुरानुसार` sufficiently clear without interrupting the function-table lesson, or should the caveat appear as a nearby visible note as well as in the bridge?

### MR-M49301-D09 — grammatical reordering never rewrites mathematical children

- **Locations:** all 467 entries in `translations/segments.json` and `translations/m49301.mr.tsv`; representative mixed-content paragraphs `n=74` (`#fs-id1165137766965`) and `n=80` (`#eip-id1165135256026`); verifier `scripts/build_m49301.py` and `qa/m49301-build.json`.
- **Choice and sense:** placeholder-tagged inline children may be reordered to form grammatical Marathi, but each source child is inserted exactly once and the exact MathML byte multiset is preserved.
- **Checked authority:** deterministic structural comparison, not linguistic authority.
- **Retrospective rationale:** literal English constituent order would produce avoidable calques; changing MathML or dropping a child would risk changing the mathematics.
- **Alternative:** preserve English word order around formula children. Rejected as a general policy because it impairs Marathi readability.
- **Status:** structural policy verified; naturalness remains open to sentence-level expert correction.
- **Expert-review question:** Do the two representative mixed-content sentences read naturally, and are there recurring placements of formula children that should be revised without changing their bytes?

### MR-M49301-D10 — source answers and added teaching support remain separate

- **Locations:** source-supplied solution elements throughout `upstream/m49301.cnxml` (73 preserved `solution` nodes); reader solution boxes; new content only at `reader/bridge.fragment.html#mr-original-bridge`.
- **Choice and sense:** `मूळ पुस्तकातील उत्तर / उकल` labels supplied answers. Three new diagnostic questions, worked explanations, remediation and recheck are labelled independent Marathi support. The bridge also states the nonzero-divisor condition relevant to source segment `n=170`.
- **Checked authority:** frozen source structure and deterministic solution-node count; the new support is authored adaptation, not attributed to OpenStax or an external authority.
- **Retrospective rationale:** the layer distinction prevents newly written help from being mistaken for a source answer and fills a Grade 8–STEM self-study need without altering the source lesson.
- **Alternatives:** interleave the support as if it were source prose, or omit scaffolding. Rejected respectively for provenance ambiguity and reduced independent usability.
- **Status:** provenance decision verified; classroom phrasing provisional.
- **Expert-review question:** Are the labels sufficiently unmistakable to a Marathi learner, and is `उकल` the best companion word for a supplied mathematical solution at this level?

## Change discipline

When a term changes, append or amend the relevant entry with the old and new wording, exact affected segment/alt keys, authority newly checked, propagation result, and release in which it changed. Do not erase the historical source-target decision or invent an authority that was not actually consulted.
