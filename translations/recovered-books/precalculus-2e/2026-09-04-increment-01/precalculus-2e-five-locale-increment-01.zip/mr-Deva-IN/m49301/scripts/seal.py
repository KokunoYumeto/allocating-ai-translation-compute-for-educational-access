from pathlib import Path
from html.parser import HTMLParser
from collections import Counter
import json,hashlib,subprocess,sys,math
B=Path(__file__).resolve().parents[1]
class Audit(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.refs=[];self.images=[];self.math=0
 def handle_starttag(self,t,a):
  a=dict(a)
  if a.get('id'):self.ids.append(a['id'])
  if t=='a' and a.get('href','').startswith('#'):self.refs.append(a['href'][1:])
  if t=='img':self.images.append(a)
  if t=='math':self.math+=1
reader=B/'reader/m49301.mr.html';before=hashlib.sha256(reader.read_bytes()).hexdigest()
subprocess.run([sys.executable,'-X','utf8',str(B/'scripts/build_m49301.py')],check=True,capture_output=True)
after=hashlib.sha256(reader.read_bytes()).hexdigest();assert before==after
a=Audit();a.feed(reader.read_text(encoding='utf8'))
missing=[r for r in a.refs if r not in a.ids]
duplicates=[i for i,n in Counter(a.ids).items() if n>1]
assert not missing and not duplicates,(missing,duplicates)
assert len(a.images)==50 and all(x.get('alt') for x in a.images)
assert a.math==411,a.math
checks={
 'f(2)=6':2**2+3*2-4==6,
 'h(4)=24':4**2+2*4==24,
 'h(-3)=h(1)=3':(-3)**2+2*(-3)==1**2+2*1==3,
 'sqrt(5-4)=1':math.sqrt(5-4)==1,
 'sqrt(m-4)=2 gives m=8':math.sqrt(8-4)==2,
 'graph f(-1)=f(3)=4':(-1-1)**2==(3-1)**2==4,
 'graph vertex f(1)=0':(1-1)**2==0,
 'circle nonfunction witness':math.sqrt(1-0**2)==1 and -math.sqrt(1-0**2)==-1,
 'positive radius inverse':math.sqrt((math.pi*3**2)/math.pi)==3,
 'new diagnostic f(-2)=1':(-2)**2-3==1,
 'new repeated outputs not injective':len(set([4,4,9]))<3,
 'final exercise witness f(4)=f(6)':3*(4-5)**2+7==3*(6-5)**2+7
}
assert all(checks.values())
report={'schema':'a30-mr-semantic-qa/1','module':'m49301','result':'pass_checked_boundaries','deterministic_html_sha256':after,'html_id_count':len(a.ids),'duplicate_ids':duplicates,'broken_local_fragments':missing,'html_math_count':a.math,'html_images':len(a.images),'numeric_spot_checks':checks,'semantic_review':'Writer checked exactly-one input/output roles, repeated outputs, inverse on positive radii, formula substitution and source exercise instructions; all source MathML bytes separately checked. This is not an independent human review.','graph_alt_correction':{'figure':'Figure_01_01_009','source_alt_vertex':'(0,1)','target_alt_vertex':'(1,0)','evidence':'Source image directly inspected at original resolution; image bytes unchanged.'},'source_context_dispositions':['Pet-memory claims retained as historical source data, not independently validated biology.','Source one-to-one example explanation clarified with independent support note.','Division requires nonzero divisor; difference quotient h is nonzero; added note is separately credited.'],'visual_check':'Owner performs serialized reader inspection; no browser or TeX launched by this writer.'}
(B/'qa/m49301-semantic.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
files=['README.md','LICENSE.md','TERMINOLOGY.md','TRANSLATION_DECISIONS.md','CURSOR.json','upstream/m49301.cnxml','translations/segments.json','translations/m49301.mr.tsv','translations/m49301-alt.mr.tsv','translations/m49301.mr.cnxml','reader/m49301.mr.html','reader/bridge.fragment.html','scripts/build_m49301.py','scripts/seal.py','provenance/assets.json','provenance/precalculus-front-matter.cnxml','provenance/UPSTREAM_LICENSE.txt','qa/m49301-build.json','qa/m49301-semantic.json']
assets=json.loads((B/'provenance/assets.json').read_text(encoding='utf8'));files += [r['path'] for r in assets]
rows=[]
for name in sorted(set(files)):
 d=(B/name).read_bytes();rows.append({'path':name,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
manifest={'schema':'a30-mr-public-files/1','locale':'mr-Deva-IN','status':'complete_m49301_source_translation_checkpoint_not_complete_book','files':rows,'file_count':len(rows),'total_bytes':sum(r['bytes'] for r in rows)}
(B/'PUBLIC_FILES.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'public_files':len(rows),'bytes':manifest['total_bytes'],'reader_sha256':after,'manifest_sha256':hashlib.sha256((B/'PUBLIC_FILES.json').read_bytes()).hexdigest(),'qa':'pass'},ensure_ascii=False))
