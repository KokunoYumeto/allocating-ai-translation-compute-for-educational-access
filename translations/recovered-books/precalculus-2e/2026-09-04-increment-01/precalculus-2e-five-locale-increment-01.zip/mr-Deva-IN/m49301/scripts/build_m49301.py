"""Deterministic Marathi CNXML/MathML offline reader, no network or TeX."""
from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as E
import json,re,copy,html,hashlib
B=Path(__file__).resolve().parents[1]
NS='http://cnx.rice.edu/cnxml';M='http://www.w3.org/1998/Math/MathML'
E.register_namespace('',NS);E.register_namespace('m',M)
source=E.parse(B/'upstream/m49301.cnxml').getroot();target=copy.deepcopy(source)
def read_tsv(path):
 rows={}
 for line in path.read_text(encoding='utf8').splitlines():
  n,t=line.split('\t',1);assert int(n) not in rows;rows[int(n)]=t
 return rows
translations=read_tsv(B/'translations/m49301.mr.tsv')
segments=json.loads((B/'translations/segments.json').read_text(encoding='utf8'))
alts=read_tsv(B/'translations/m49301-alt.mr.tsv')
assert len(translations)==len(segments)==467
def tag(e):return e.tag.split('}')[-1]
index=0;altindex=0
def translate(e,inside=False):
 global index,altindex
 inside=inside or e.tag.startswith('{'+M+'}')
 children=list(e)
 direct=(e.text or '')+''.join(c.tail or '' for c in e)
 chosen=None
 if not inside and re.search('[A-Za-z]',direct) and tag(e) not in ['content-id','uuid']:
  chosen=translations[index];assert segments[index]['tag']==tag(e);index+=1
 for child in children:translate(child,inside)
 if chosen is not None:
  tokens=re.findall(r'⟦(\d+)⟧',chosen)
  assert sorted(map(int,tokens))==list(range(len(children))),(e.get('id'),chosen,len(children))
  chunks=re.split(r'⟦(\d+)⟧',chosen)
  e.text=chunks[0]
  for c in children:e.remove(c)
  for i in range(1,len(chunks),2):
   c=children[int(chunks[i])];c.tail=chunks[i+1];e.append(c)
 if tag(e)=='media':
  e.set('alt',alts[altindex]);altindex+=1
translate(target)
assert index==467 and altindex==50
target.set('{http://www.w3.org/XML/1998/namespace}lang','mr-IN')
data=E.tostring(target,encoding='utf-8',xml_declaration=True)
(B/'translations/m49301.mr.cnxml').write_bytes(data)
ids={e.get('id'):e for e in target.iter() if e.get('id')}
labels={}
for kind,label in [('figure','आकृती'),('table','तक्ता'),('example','उदाहरण'),('exercise','प्रश्न')]:
 for n,e in enumerate((e for e in target.iter() if tag(e)==kind),1):
  if e.get('id'):labels[e.get('id')]=f'{label} {n}'
assets=json.loads((B/'provenance/assets.json').read_text(encoding='utf8'))
asset_by_name={Path(r['path']).name:r for r in assets}
def esc(t):return html.escape(t or '',quote=True)
def inner(e):return esc(e.text)+''.join(render(c)+esc(c.tail) for c in e)
def render(e,level=2):
 t=tag(e);ident=e.get('id');a=f' id="{esc(ident)}"' if ident else ''
 if e.tag=='{'+M+'}math':
  c=copy.deepcopy(e);c.tail=None
  s=E.tostring(c,encoding='unicode').replace('<m:','<').replace('</m:','</').replace('xmlns:m=', 'xmlns=')
  return s
 if t=='metadata':
  abstract=next((n for n in e if tag(n)=='abstract'),None)
  return '<aside class="objectives"><h2>अभ्यासाची उद्दिष्टे</h2>'+inner(abstract)+'</aside>' if abstract is not None else ''
 if t=='title':return f'<h{level}{a}>'+inner(e)+f'</h{level}>'
 if t=='section':return f'<section{a}>'+''.join(render(c,min(level+1,5))+esc(c.tail) for c in e)+'</section>'
 if t=='para':return f'<div class="para"{a}>'+inner(e)+'</div>'
 if t=='list':
  k='ol' if e.get('list-type')=='enumerated' else 'ul'
  return f'<{k}{a}>'+inner(e)+f'</{k}>'
 if t=='item':return f'<li{a}>'+inner(e)+'</li>'
 if t=='emphasis':return f'<em{a}>'+inner(e)+'</em>'
 if t=='term':return f'<strong{a}>'+inner(e)+'</strong>'
 if t=='link':
  targetid=e.get('target-id');url=e.get('url')
  if targetid:
   if targetid in ids:return f'<a{a} href="#{esc(targetid)}">'+(inner(e) or labels.get(targetid,esc(targetid)))+'</a>'
   return f'<span{a} class="external-reference">'+(inner(e) or 'मूळ संदर्भ: '+esc(targetid))+'</span>'
  return f'<a{a} href="{esc(url or "#")}">'+inner(e)+'</a>'
 if t=='media':
  im=next((x for x in e if tag(x)=='image'),None)
  if im is None:return f'<span{a}>'+inner(e)+'</span>'
  name=Path(im.get('src')).name;assert name in asset_by_name
  return f'<div class="media"{a}><img src="../assets/{esc(name)}" alt="{esc(e.get("alt"))}" loading="lazy"><div class="image-note">मूळ आकृती; इंग्रजी अक्षरे व संख्याचिन्हे जशीच्या तशी.</div></div>'
 if t=='figure':return f'<figure{a}><div class="figure-label">{labels.get(ident,"")}</div>'+inner(e)+'</figure>'
 if t=='caption':return f'<figcaption{a}>'+inner(e)+'</figcaption>'
 if t=='table':return f'<div class="table-wrap"{a}><div>{labels.get(ident,"")}</div><table>'+inner(e)+'</table></div>'
 if t in ['tgroup','colspec']:return inner(e)
 if t in ['thead','tbody']:return f'<{t}{a}>'+inner(e)+f'</{t}>'
 if t=='row':return f'<tr{a}>'+inner(e)+'</tr>'
 if t=='entry':
  span=f' rowspan="{int(e.get("morerows"))+1}"' if e.get('morerows') else ''
  if e.get('namest') and e.get('nameend'):span+=f' colspan="{int(re.sub(chr(92)+"D","",e.get("nameend")))-int(re.sub(chr(92)+"D","",e.get("namest")))+1}"'
  return f'<td{a}{span}>'+inner(e)+'</td>'
 if t=='solution':return f'<details class="solution"{a}><summary>मूळ पुस्तकातील उत्तर / उकल</summary>'+inner(e)+'</details>'
 if t in ['example','exercise','note','problem']:return f'<div class="{t}"{a}>'+('<h4>'+labels[ident]+'</h4>' if ident in labels else '')+inner(e)+'</div>'
 if t=='glossary':return f'<section{a}><h2>शब्दसंग्रह</h2>'+inner(e)+'</section>'
 if t=='definition':return f'<div class="definition"{a}>'+inner(e)+'</div>'
 if t=='footnote':return f'<small class="footnote"{a}>'+inner(e)+'</small>'
 if t in ['sup','sub']:return f'<{t}{a}>'+inner(e)+f'</{t}>'
 if t=='newline':return '<br>'
 return f'<div{a}>'+inner(e)+'</div>' if t in ['content','equation'] else f'<span{a}>'+inner(e)+'</span>'
css='''body{font-family:"Nirmala UI","Noto Sans Devanagari",sans-serif;line-height:1.8;color:#142330;background:#f7f9fc;margin:0}main{max-width:1000px;margin:auto;padding:2rem;background:white}h1,h2,h3,h4{line-height:1.5;color:#163e68}h2{border-bottom:2px solid #b8ccdf;padding-bottom:.35em}h3{margin-top:2em}.para{margin:.75em 0}math{font-size:1.15em;font-family:"Cambria Math",serif}math[display="block"]{display:block;overflow-x:auto;margin:.7em 0}img{max-width:100%;height:auto;max-height:700px;object-fit:contain}.media{text-align:center}.image-note,.footnote{font-size:.8em;color:#526371}.example,.note,.objectives,.bridge{padding:1em;border:1px solid #b6cddd;border-radius:.4em;margin:1em 0}.exercise{margin:1.5em 0;padding:1em;border-left:4px solid #b8ccdf}.solution{background:#edf6ef;padding:.7em;margin:.7em 0}.table-wrap{overflow-x:auto;margin:1em 0}table{border-collapse:collapse;width:100%}td,th{border:1px solid #aab9c7;padding:.5em;vertical-align:top}figure{margin:1.3em 0}a{color:#075f9a}strong{font-weight:700}summary{cursor:pointer;font-weight:bold}li{margin:.35em 0}.figure-label{font-weight:bold;text-align:center}@media(max-width:600px){main{padding:1rem}.example,.exercise,.note{padding:.6em}td{padding:.35em}}@media print{body{background:white}main{padding:0;max-width:none}details>*{display:block}.media{break-inside:avoid}h2,h3,h4{break-after:avoid}}'''
bridge=(B/'reader/bridge.fragment.html').read_text(encoding='utf8')
body=''.join(render(c,1 if tag(c)=='title' else 2) for c in target)
doc='<!doctype html><html lang="mr-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>फलने आणि फलनांचे संकेतलेखन — मराठी</title><style>'+css+'</style></head><body><main><header><p>OpenStax Precalculus 2e · मराठी · m49301</p><p>हा संपूर्ण विभागाचा अनुवाद आहे; संपूर्ण पुस्तक अद्याप पूर्ण झालेले नाही. <a href="../README.md">व्याप्ती व स्रोत</a></p></header>'+body+bridge+'<footer><p>OpenStax / Rice University; Jay Abramson आणि सहलेखक. अनुवाद, स्वतंत्र अध्यापन-सहाय्य व बदल: 2026. CC BY-NC-SA 4.0. OpenStax चे अनुमोदन अभिप्रेत नाही. <a href="../LICENSE.md">परवाना</a></p></footer></main></body></html>'
(B/'reader/m49301.mr.html').write_text(doc,encoding='utf8',newline='\n')
def mathhash(r):
 out=[]
 for e in r.iter('{'+M+'}math'):
  c=copy.deepcopy(e);c.tail=None
  out.append(hashlib.sha256(E.tostring(c,encoding='utf8')).hexdigest())
 return Counter(out)
source_ids=Counter(e.get('id') for e in source.iter() if e.get('id'))
target_ids=Counter(e.get('id') for e in target.iter() if e.get('id'))
assert source_ids==target_ids
assert mathhash(source)==mathhash(target)
for t in ['exercise','solution','figure','table']:
 assert sum(tag(e)==t for e in source.iter())==sum(tag(e)==t for e in target.iter())
for r in assets:
 d=(B/r['path']).read_bytes();assert len(d)==r['bytes'] and hashlib.sha256(d).hexdigest()==r['sha256']
assert '\ufffd' not in doc and '⟦' not in doc
qa={'schema':'a30-mr-module-qa/1','module':'m49301','source_sha256':hashlib.sha256((B/'upstream/m49301.cnxml').read_bytes()).hexdigest(),'segments':len(translations),'source_ids':sum(source_ids.values()),'target_ids_identical':True,'math_elements':sum(mathhash(source).values()),'math_byte_multiset_identical':True,'figures':sum(tag(e)=='figure' for e in source.iter()),'images':len(assets),'exercises':sum(tag(e)=='exercise' for e in source.iter()),'supplied_solutions':sum(tag(e)=='solution' for e in source.iter()),'tables':sum(tag(e)=='table' for e in source.iter()),'all_assets_hash_verified':True,'alt_translations':50,'structural_result':'pass','reader_visual_result':'pending_owner_serialized_check','source_order':'structural units retained; inline children reordered only to form grammatical Marathi','target_cnxml_sha256':hashlib.sha256(data).hexdigest(),'html_sha256':hashlib.sha256(doc.encode()).hexdigest()}
(B/'qa/m49301-build.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(qa,ensure_ascii=False))
