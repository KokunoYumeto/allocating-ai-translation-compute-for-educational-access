# Translation decisions for expert review — m49308

Locale: `pnb-Arab-PK` (Pakistani Punjabi in native Shahmukhi). Scope: OpenStax *Precalculus 2e*, module `m49308`, “Composition of Functions.” This is a living review log, not a certification or a publication hold.

## Status and location convention

Entries `PNB-M49308-D01`–`D09` reconstruct decisions made before this log was created on 2026-09-04. Their rationales are therefore **retrospective reconstructions** from the sealed `translation.json`, `TERMINOLOGY.md`, reader bridge, and QA record—not claims about an unrecorded contemporaneous thought process. Entries `D10`–`D15` record the already-labelled source/editorial treatments. All provisional language choices remain open to correction.

Each source-addressed location gives the immutable XML path or ID from `source/m49308.cnxml`. The corresponding target can be found in `translation.json` by `slots[key=…]`, in `translated.cnxml` at the same source structure, and in `reader.html` by the stated ID or `data-source-key` selector.

## Evidence boundary and bridge policy

- **P — Shahmukhi Punjabi prose evidence:** the inherited compact prose canon `canon/examples.json` (SHA-256 `734bb92da5edb28f084ef589bbd5af7e4ac40b823036e460073266f63eb30f9c`) and the three recorded works by Jamil Ahmad Pal were checked for ordinary explanatory syntax. They support constructions such as `سکدی اے`, `چاہیدا اے`, `دی بجائے`, and `کیوں جے`; they are **not** mathematics-term authorities.
- **U — Urdu mathematics evidence:** Maulana Azad National Urdu University, *Calculus*, BNMM101DCT, first edition 2025, ISBN 978-81-994195-2-0, official PDF SHA-256 `280c82e2af33011e4b3d969c29d496503a948a25996368571f8ca0f156b9ac43`. Direct inspection of PDF page 10 found `تفاعل` beside “Function” and `جفت`/`طاق` beside their defining identities. This evidence supports only the separately labelled **Urdu bridge**; it is not treated as Punjabi attestation, and it does not attest a composition term.
- **S — Source-semantic evidence:** the pinned English source and all ten worked examples establish the intended mathematical senses and order of composition. All 543 source MathML trees remain unchanged.
- **N — Negative bounded finding:** the checked sources did not establish native Shahmukhi Punjabi specialist terminology for function composition. This means only “not found in the sources checked,” never “no such terminology exists.”
- **Reader separation:** `reader.html#bridge` has three explicitly headed columns: provisional Shahmukhi Punjabi, a separate Urdu bridge (`lang="ur-Arab-PK"`), and English (`lang="en" dir="ltr"`). English formula and graph words remain source content and are separately glossed; they are not silently presented as Punjabi. The Punjabi teaching prose uses Punjabi grammar, including a few transparently marked English-derived loans written in Shahmukhi.

## Terminology and difficult-language decisions

### PNB-M49308-D01 — composition of functions

- **Locations:** source `0/0` and `0/2/5/1/1`; target `translation.json` keys `m49308:0/0` and `term-00003`, plus `reader.html <h1>` and `[data-source-key="term-00003"]`.
- **Choice and sense:** `فنکشناں دی ترکیب` = the operation in which one function’s output becomes another function’s input.
- **Evidence actually checked:** P for Punjabi explanatory grammar; S for the mathematical sense; N for the specialist term. U did not attest composition.
- **Retrospective rationale and alternatives:** `ترکیب` is compact and pairs transparently with the repeated plain-language explanation. `فنکشن کمپوزیشن` would be heavier English code-switching; Urdu-register `تفاعلوں کی ترکیب` is retained only in the Urdu bridge, not asserted as Punjabi.
- **Status / precise review question:** provisional, medium uncertainty. Would Pakistani Punjabi mathematics educators retain `فنکشناں دی ترکیب`, prefer an attested Shahmukhi term, or normally use the English loan “composition”?

### PNB-M49308-D02 — composite function

- **Locations:** source `0/2/5/1/3` and glossary `0/3/0/0`; target keys `m49308:0/2/5/1/3` and `m49308:0/3/0/0`, selectable in the reader by matching `data-source-key`.
- **Choice and sense:** `مرکب فنکشن` = the new function formed by composition, not multiplication of two functions.
- **Evidence actually checked:** S and all ten worked examples; no native specialist attestation in P; U supplied no composition phrase.
- **Retrospective rationale and alternatives:** `مرکب` keeps the distinction between the resulting function and the operation `ترکیب`. Alternatives considered were an English loan phrase and `ترکیبی فنکشن`; neither had checked Punjabi authority.
- **Status / precise review question:** provisional, medium uncertainty. Is `مرکب فنکشن` idiomatic and unambiguous in Pakistani Punjabi, or does an established textbook term better distinguish composite from compound/complex?

### PNB-M49308-D03 — inner / outer function and evaluation order

- **Locations:** source paragraph ID `fs-id1165135161270`, XML path `0/2/5/4`; target key and `reader.html#fs-id1165135161270`. Repeated at `fs-id1165135168147` and `fs-id1165137725253`.
- **Choice and sense:** `اندرلا / باہرلا فنکشن`; `اندر توں باہر ول` means evaluate the nested function first, then feed its output to the outer function.
- **Evidence actually checked:** P for the plain Punjabi directional construction; S and preserved formulas for order. No checked Punjabi specialist attestation.
- **Retrospective rationale and alternatives:** the everyday pair is teachable and avoids falsely presenting Urdu `اندرونی / بیرونی تفاعل` as Punjabi authority. More formal Persianate pairs were reserved for the labelled Urdu bridge.
- **Status / precise review question:** provisional, low-to-medium uncertainty. Are `اندرلا` and `باہرلا` the clearest classroom forms across Pakistani Punjabi varieties, especially beside nested notation?

### PNB-M49308-D04 — input, output, domain, and range

- **Locations:** source paragraph ID `fs-id1165137531472`, XML path `0/2/5/12`; target key and `reader.html#fs-id1165137531472`. Domain rule also appears at `fs-id1165135503928`.
- **Choice and sense:** `اِن پُٹ`, `آؤٹ پُٹ`, `ڈومین`, `رینج`, always paired in the bridge with plain explanations: permissible inputs and outputs actually attained.
- **Evidence actually checked:** S establishes the concepts; P supports the surrounding Punjabi grammar. No checked source attested these four as standardized Punjabi terms. U’s separate bridge uses `دائرۂ تعریف` for domain and an explanatory phrase for range.
- **Retrospective rationale and alternatives:** the English-derived loans match common learner-facing notation and avoid inventing authoritative-sounding native terms. The reader explains them immediately rather than relying on the loans alone.
- **Status / precise review question:** provisional, medium-to-high terminology uncertainty but low semantic uncertainty. Which forms are actually used in current Shahmukhi Punjabi mathematics classrooms, and should native terms be primary with these loans parenthetical?

### PNB-M49308-D05 — commutative

- **Locations:** source XML path `0/2/5/14/0/0/1/2`; target key `term-00005` and reader selector `[data-source-key="term-00005"]`; enclosing explanation `fs-id1165135160089`.
- **Choice and sense:** `تبادلی`, immediately paraphrased as `ترتیب بدل کے وی نتیجہ اوہو` where applicable.
- **Evidence actually checked:** S and example computations establish the sense; neither P nor the inspected U page attested this term.
- **Retrospective rationale and alternatives:** the concise technical borrowing is never left unexplained. A fully explanatory phrase alone was considered but would make repeated statements cumbersome.
- **Status / precise review question:** provisional, high lexical uncertainty. Is `تبادلی` the attested Pakistani Punjabi term for commutative, or should the explanatory phrase or another technical form be primary?

### PNB-M49308-D06 — decompose / component functions

- **Locations:** source `0/2/8/0` and `0/2/8/1/0`; target keys `m49308:0/2/8/0` and `term-00007`, with identical reader `data-source-key` selectors.
- **Choice and sense:** `مرکب فنکشن نوں اوہدے جزوی فنکشناں وچ ونڈنا` = express one composite as two simpler constituent functions.
- **Evidence actually checked:** P supports ordinary `ونڈنا`; S establishes that this is decomposition into functions, not numerical division or factorization. No checked specialist Punjabi attestation.
- **Retrospective rationale and alternatives:** the verbal construction makes the action explicit. `تحلیل` was avoided because it can evoke analysis or factorization. `جزوی فنکشن` may, however, be confused with the separate concept “partial function.”
- **Status / precise review question:** provisional, high uncertainty for `جزوی`. Would `حصہ بنن والے فنکشن`, another attested constituent-term, or a loan be less ambiguous?

### PNB-M49308-D07 — binary operation

- **Locations:** source paragraph ID `fs-id1165137466004`, XML path `0/2/5/3`; target key and `reader.html#fs-id1165137466004`.
- **Choice and sense:** `دو-عملوندی عمل` = an operation taking two operands/functions to form a new function.
- **Evidence actually checked:** S establishes the formal arity and analogy with addition/multiplication. No checked Punjabi or Urdu page attested the lexical form.
- **Retrospective rationale and alternatives:** the coined compound preserves “two operands,” while the following clause supplies the full meaning. A plain paraphrase (`دو فنکشن لے کے …`) is already present and could replace the coinage.
- **Status / precise review question:** provisional, high uncertainty. Is there an attested Shahmukhi Punjabi equivalent for “binary operation,” or should the plain paraphrase be the only primary wording?

### PNB-M49308-D08 — evaluate a function

- **Locations:** learning objective `0/1/2/1/2`, target key `m49308:0/1/2/1/2`; instructional paragraph `fs-id1165135161270`; repeated source-addressed uses throughout sections `0/2/6` and `0/2/7`.
- **Choice and sense:** `قدر کڈھنا` = obtain a function’s value at a specified input, not judge its quality.
- **Evidence actually checked:** P for ordinary explanatory idiom; S, formulas, tables, and graphs for the mathematical sense. No checked specialist Punjabi source attested the exact collocation.
- **Retrospective rationale and alternatives:** this form is shorter and more conversational than Persianate `مقدار معلوم کرنا`, while the object “value” remains explicit.
- **Status / precise review question:** provisional, low-to-medium uncertainty. Is `قدر کڈھنا` suitable across secondary and undergraduate registers, or should a more formal form accompany its first occurrence?

### PNB-M49308-D09 — Urdu/English bridges and bidirectional text

- **Locations:** target-only adaptation `reader.html#bridge`, generated from `scripts/build.py`; module-wide mathematics appears in `.math-isolate[dir="ltr"]`, while the document root is `dir="rtl"`.
- **Choice and sense:** Punjabi is the teaching language. Urdu and English are comparison bridges with explicit `lang`/`dir` labels. Original English inside MathML and images is preserved and glossed rather than altered.
- **Evidence actually checked:** U only for the Urdu forms actually described above; S and hash/structure QA for preserved English and math. No bridge is treated as proof of a Punjabi term.
- **Retrospective rationale and alternatives:** explicit separation prevents visual similarity among Arabic-script Punjabi and Urdu from becoming a false language claim, while LTR isolation protects formula order.
- **Status / precise review question:** policy stable, lexical contents provisional. Do reviewers see any bridge item that a Punjabi reader could reasonably mistake for asserted native Punjabi authority?

## Source precision and accessibility decisions

These are semantic/editorial treatments, not silent changes to source mathematics. The English source and original MathML remain available beside each labelled note.

### PNB-M49308-D10 — whole-range condition is sufficient, not necessary

- **Locations:** source/target paragraph `fs-id1165137531472`; target note immediately after `reader.html#fs-id1165137531472`; generator key in `scripts/build.py` `NOTES`.
- **Decision:** preserve the translated source sentence, then label a qualification: whole inner-range containment permits composition on the whole inner domain; otherwise the composition may still exist on inputs whose inner outputs lie in the outer domain.
- **Basis / alternatives:** checked against the source’s own later domain definition and examples. Silently rewriting the source sentence was rejected.
- **Status / review question:** high-confidence mathematical correction. Is the Punjabi qualification maximally clear without introducing unnecessary formalism?

### PNB-M49308-D11 — “positive” versus “nonnegative” under a square root

- **Locations:** source/target paragraph `fs-id1165137871761`, XML path `0/2/7/5/0/1/2`; labelled target note after `reader.html#fs-id1165137871761`.
- **Decision:** preserve source wording in the translation and add a labelled correction that the radicand and principal square root may be zero, so “nonnegative” is required. Original inequalities and MathML are unchanged.
- **Basis / alternatives:** direct real-number square-root semantics. Silent correction was rejected for source fidelity.
- **Status / review question:** mathematical finding high confidence; should the Punjabi term `غیر منفی` receive a parenthetical “zero or positive” every time or only here?

### PNB-M49308-D12 — two excluded values require “and”

- **Locations:** enclosing source example `Example_01_04_08`; affected paragraph key `fs-id1165135152098`; labelled note in the same reader example.
- **Decision:** retain the original MathML/domain interval and explain that the prose must conjoin `x ≠ 2/3` and `x ≠ 2`; source `or` is a wording defect.
- **Basis / alternatives:** both denominator zeros and the source’s own correct final interval. Altering the original formula tree was rejected.
- **Status / review question:** high confidence. Does `دوہاں توں وکھ` communicate simultaneous exclusion unambiguously to the intended reader?

### PNB-M49308-D13 — reversed table dimensions in accessibility summary

- **Locations:** source table ID `Table_01_04_03`; target `reader.html#Table_01_04_03`; generated note in `scripts/build.py` `TABLE_NOTES`.
- **Decision:** preserve the source `data-source-summary`, but provide a corrected visible note and `aria-label`: the actual structure is eleven rows and three columns, not eleven columns and three rows.
- **Basis / alternatives:** deterministic count of source table rows/cells. Reproducing the wrong summary as the only accessible description was rejected.
- **Status / review question:** structural finding high confidence. Is the Punjabi row/column phrasing (`قطاراں` / `کالم`) appropriate for screen-reader users?

### PNB-M49308-D14 — empty accessibility summary

- **Locations:** source table ID `eip-id1165134118229`; same target ID in `reader.html`; generated note in `TABLE_NOTES`.
- **Decision:** retain the source summary witness (`..`), add a meaningful `aria-label`, and visibly disclose the defect.
- **Basis / alternatives:** direct source inspection. Omitting the defect or treating punctuation as meaningful alternative text was rejected.
- **Status / review question:** structural finding high confidence. Does the replacement description identify the symbolic-equation table sufficiently without over-interpreting it?

### PNB-M49308-D15 — stray “Text” token in a supplied answer

- **Locations:** source XML path and translation key `m49308:0/2/11/2/19/1/0/0`; target reader selector with the same `data-source-key`.
- **Decision:** preserve the literal source token as `متن`, then add a labelled note that it is a nonmathematical editorial remnant and not an instruction or new answer.
- **Basis / alternatives:** direct source-answer inspection. Deleting it silently or folding it into the mathematical answer was rejected.
- **Status / review question:** source finding high confidence. Would retaining the original English token in parentheses improve traceability for Punjabi readers, or only add noise?

## Maintenance rule

For later revisions, add or amend a record whenever a substantive term or difficult semantic choice changes. Preserve the prior wording and reason in version history; identify the exact source and target locations, the authority actually checked, alternatives, uncertainty, and a concrete question. Expert feedback may improve a later release but is never a gate on a truthful provisional edition.
