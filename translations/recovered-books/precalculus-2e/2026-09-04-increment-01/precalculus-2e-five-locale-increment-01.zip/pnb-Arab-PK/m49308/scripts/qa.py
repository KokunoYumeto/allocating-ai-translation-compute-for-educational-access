"""Independent source/reader checks and deterministic replay; no rendering/network."""
from pathlib import Path
from lxml import etree as E,html as H
from collections import Counter
from fractions import Fraction
import hashlib,json,re,subprocess,sys
BASE=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def tag(n):return E.QName(n).localname
def save(name,data):
    (BASE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def shape(n):
    return [tag(n),sorted((k,v) for k,v in n.attrib.items() if k!='xmlns'),n.text or '',[[shape(c),c.tail or ''] for c in n]]
def digest(n):return sha(json.dumps(shape(n),ensure_ascii=False,separators=(',',':')).encode())
def main():
    manifest=json.loads((BASE/'SOURCE_MANIFEST.json').read_text());rights=json.loads((BASE/'RIGHTS.json').read_text())
    for row in [manifest['source'],*manifest['images'],*rights['authority']]:
        data=(BASE/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
    assert rights['license']=='CC-BY-NC-SA-4.0' and len(rights['components'])==10
    src=E.parse(str(BASE/'source/m49308.cnxml')).getroot();xml=E.parse(str(BASE/'translated.cnxml')).getroot()
    reader=(BASE/'reader.html').read_bytes();dom=H.fromstring(reader.decode('utf-8'))
    source_counts=Counter(tag(n) for n in src.iter())
    paths={src:'0'}
    for n in src.iter():
        for i,c in enumerate(n):paths[c]=paths[n]+'/'+str(i)
    source_math={paths[n]:digest(n) for n in src.iter() if tag(n)=='math'}
    html_math={n.get('data-source-math-path'):digest(n[0]) for n in dom.xpath('//*[@data-source-math-path]')}
    assert source_math==html_math,'MathML identity failure'
    assert Counter(digest(n) for n in xml.iter() if tag(n)=='math')==Counter(source_math.values())
    source_ids=Counter(n.get('id') for n in src.iter() if n.get('id'))
    actual_ids=Counter(dom.xpath('//*[@id]/@id'))
    assert all(v==1 for v in actual_ids.values()),'duplicate reader IDs'
    assert all(actual_ids[k]==v for k,v in source_ids.items()),'missing source ID'
    assert source_ids==Counter(n.get('id') for n in xml.iter() if n.get('id'))
    for a in dom.xpath('//a[starts-with(@href,"#")]'):
        assert a.get('href')[1:] in actual_ids,a.get('href')
    images=dom.xpath('//img');assert len(images)==10
    for image in images:assert (BASE/image.get('src')).exists() and image.get('alt')
    assert not dom.xpath('//script|//iframe|//object')
    assert dom.get('lang')=='pnb-Arab-PK' and dom.get('dir')=='rtl'
    assert all(n.get('dir')=='ltr' for n in dom.xpath('//*[@data-source-math]'))
    assert not re.search('[\u0a00-\u0a7f\ufffd]',reader.decode('utf-8')),'encoding/script corruption'
    translation=json.loads((BASE/'translation.json').read_text(encoding='utf-8'))
    rows=translation['slots'];assert len(rows)==422 and len({r['key'] for r in rows})==422
    for r in rows:assert sorted(re.findall(r'\{\{\d+\}\}',r['source']))==sorted(re.findall(r'\{\{\d+\}\}',r['target']))
    exsrc=[n for n in src.iter() if tag(n)=='exercise'];exdom=dom.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," source-exercise ")]')
    assert [n.get('id') for n in exsrc]==[n.get('id') for n in exdom]
    assert len(dom.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," source-solution ")]'))==source_counts['solution']
    for original,rendered in zip(exsrc,exdom):
        assert sum(tag(n)=='solution' for n in original.iter())==len(rendered.xpath('.//*[contains(concat(" ",normalize-space(@class)," ")," source-solution ")]'))
    for table in [n for n in src.iter() if tag(n)=='table']:
        tr=dom.xpath('//*[@id=$id]',id=table.get('id'))[0]
        cells=[n for n in table.iter() if tag(n)=='entry']
        rendered=tr.xpath('.//td|.//th')
        assert [paths[n] for n in cells]==[n.get('data-source-node') for n in rendered]
        for original,display in zip(cells,rendered):
            assert Counter(digest(n) for n in original.iter() if tag(n)=='math')==Counter(digest(n) for n in display.iter() if tag(n)=='math')
            if not list(original):
                slot=next((r for r in rows if r['path']==paths[original] and not r['tag'].startswith('@')),None)
                expected=slot['target'] if slot else (original.text or '').strip()
                assert expected==''.join(display.itertext()).strip(),paths[original]
    # Independent numerical/algebraic spot checks support, not replace, preserved-source identity.
    f=lambda x:2*x+1;g=lambda x:3-x
    for x in [Fraction(-3),Fraction(0),Fraction(1,2),Fraction(4)]:
        assert f(g(x))==7-2*x and g(f(x))==-2*x+2
    ft={1:6,2:8,3:3,4:1};gt={1:3,2:5,3:2,4:7}
    assert ft[gt[3]]==8 and gt[ft[3]]==2
    assert (3*1+2)**2-(3*1+2)==20
    assert Fraction(4,3*2-2)==1 and 3*Fraction(2,3)-2==0
    # Source 'or' would wrongly admit both exclusions; the adjacent note states 'and'.
    for x in [Fraction(2,3),Fraction(2)]:assert (x!=Fraction(2,3) or x!=2) and not (x!=Fraction(2,3) and x!=2)
    assert len(dom.xpath('//*[@data-about="fs-id1165135152098"]'))==1
    initial={name:sha((BASE/name).read_bytes()) for name in ['reader.html','translated.cnxml']}
    subprocess.run([sys.executable,str(BASE/'scripts/build.py')],check=True,capture_output=True)
    assert initial=={name:sha((BASE/name).read_bytes()) for name in initial},'replay drift'
    hierarchy=[]
    for n in src.iter():
        if tag(n) in ('section','example','exercise','solution','definition','figure','table'):
            parents=[x.get('id') or 'm49308:'+paths[x] for x in n.iterancestors() if tag(x) in ('section','example','exercise')]
            hierarchy.append({'id':n.get('id') or 'm49308:'+paths[n],'type':tag(n),'source_path':paths[n],'parent':parents[0] if parents else 'm49308','source_order':len(hierarchy)})
    save('BACKEND.json',{'schema':'a30-module-backend-v1','work_id':'openstax-precalculus-2e','edition_commit':manifest['commit'],'unit_id':'m49308','locale':'pnb-Arab-PK','units':hierarchy,'segments':[{'segment_id':'openstax-precalculus-2e:m49308:'+r['key'],'source_key':r['key'],'source_path':r['path'],'type':r['tag'],'source_sha256':sha(r['source'].encode()),'translation_sha256':sha(r['target'].encode()),'state':r['status']} for r in rows],'assets':rights['components'],'concepts':['function-composition','inner-outer-function','domain-of-composition','noncommutativity','decomposition'],'prerequisite_modules':['m49299','m49301','m49304','m49306'],'next_module':'m49312'})
    coverage={'schema':'a30-module-coverage-v1','module':'m49308','locale':'pnb-Arab-PK','scope':'complete canonical module; full A30 book remains in progress','source_commit':manifest['commit'],'source_sha256':manifest['source']['sha256'],'counts':{'slots':415,'translated_prose_slots':sum(r['status']=='translated' for r in rows),'notation_only_slots':sum(r['status']=='source-notation-preserved' for r in rows),'math_trees':543,'source_ids':sum(source_ids.values()),'examples':10,'exercises':114,'supplied_solutions':66,'exercises_without_source_solution':sum(not any(tag(n)=='solution' for n in e.iter()) for e in exsrc),'images':10,'tables':5,'glossary_definitions':1},'artifacts':initial,'next_source_module':'m49312','source_vs_adaptation':'All original math/assets remain exact. Editorial bridge and six source-precision/accessibility notes are labelled separately. No new exercise answers.'}
    coverage['counts']['slots']=len(rows)
    save('COVERAGE.json',coverage)
    decision_log=(BASE/'TRANSLATION_DECISIONS.md').read_text(encoding='utf-8')
    assert all(marker in decision_log for marker in ['retrospective reconstruction','PNB-M49308-D01','PNB-M49308-D15','precise review question','Urdu bridge','English'])
    defects=[{'source_anchor':'fs-id1165137531472','finding':'Whole inner range containment is sufficient for full-domain composition, not necessary for a restricted composition.','treatment':'Source preserved; local editorial qualification.'},{'source_anchor':'fs-id1165137871761','finding':'Positive must be nonnegative in square-root domain discussion.','treatment':'Source preserved; local correction.'},{'source_anchor':'Example_01_04_08','finding':'Source x != 2/3 or x != 2 should conjoin both exclusions.','treatment':'MathML preserved; explicit note before interval-domain expression.'},{'source_anchor':'Table_01_04_03','finding':'Source accessibility summary reverses row/column count.','treatment':'Original summary translated in data-source-summary; corrected aria-label and visible editorial note.'},{'source_anchor':'eip-id1165134118229','finding':'Source summary is only two periods.','treatment':'Preserved source value plus meaningful aria-label and visible note.'},{'source_anchor':'m49308:0/2/11/2/19/1/0/0','finding':'Stray Text token in supplied answer.','treatment':'Literal source translation retained; explicit nonmathematical-artifact note.'}]
    save('QA.json',{'schema':'a30-pnb-m49308-qa-v1','result':'pass','checked':list(coverage['counts']),'checks':['exact source,collection,frontmatter and image hashes','all 543 MathML trees independently matched by source path','translated CNXML math multiset identity','all source IDs exact and unique in HTML','exercise order and per-exercise supplied-solution containment','five source table cell orders and math/numeric payloads','internal fragment targets and local image presence',f'{len(rows)} keyed slots and exact child placeholder multisets','no Gurmukhi/replacement characters; RTL root and isolated LTR mathematics','network-free build with no scripts/frames/objects','deterministic second build SHA-256 identity','independent numerical checks for composition, table values, evaluation and domain exclusions','publishable decision log contains retrospective labels, exact decision IDs, review questions and Urdu/English bridge distinctions'],'semantic_review':'All ten canonical worked examples read alongside the translation. Source meaning, inner-first order, currency/units, negations, domain exclusions and answer provenance checked. Numerical spot checks do not claim exhaustive independent re-solving of all exercises.','source_issues':defects,'terminology':'provisional specialist Punjabi; explicit Urdu/English bridge; canon consulted at drafting/revision','visual_review':'Not performed in this subtask; root coordinates one serial desktop/mobile sample. No human-dependent review gate.','limitations':['No native-speaker or educator certification claimed.','English source graph labels and MathML words retained and bridged.','48 exercises have no source-supplied solution; no new solutions claimed.','The full book remains in progress.'],'replay':initial})
    save('CURSOR.json',{'schema':'a30-locale-continuation-cursor-v1','locale':'pnb-Arab-PK','completed_module':'m49308','state':'complete coherent module; passed deterministic nonvisual QA','sealed_reader_sha256':initial['reader.html'],'existing_predecessors':'unchanged','next_source_module':'m49312','next_action':'Root performs the coordinated serial visual sample and publishes this module in existing lineage. Then freeze and translate complete m49312 from the same pinned Precalculus collection. Full A30 Punjabi book is not yet complete.'})
    allow=['reader.html','reader.css','translated.cnxml','translation.json','SOURCE_MANIFEST.json','RIGHTS.json','LICENSE','README.md','TERMINOLOGY.md','TRANSLATION_DECISIONS.md','BACKEND.json','COVERAGE.json','QA.json','CURSOR.json','source/m49308.cnxml','source/collection.xml','source/rights-frontmatter.cnxml','source/slots.json','scripts/build.py','scripts/qa.py','scripts/prepare.py','scripts/draft.py']+[r['path'] for r in manifest['images']]
    files=[{'path':p,'bytes':(BASE/p).stat().st_size,'sha256':sha((BASE/p).read_bytes())} for p in sorted(allow)]
    save('PUBLIC_FILES.json',{'schema':'book-module-public-files-v1','work':'OpenStax Precalculus 2e','locale':'pnb-Arab-PK','module':'m49308','entry_point':'reader.html','files':files,'file_count':len(files),'total_bytes':sum(r['bytes'] for r in files)})
    print(json.dumps({'result':'pass',**coverage['counts'],'reader_sha256':initial['reader.html'],'public_files':len(files),'public_bytes':sum(r['bytes'] for r in files)},indent=2))
if __name__=='__main__':main()
