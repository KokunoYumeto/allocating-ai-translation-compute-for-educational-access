"""Deterministic offline Punjabi m49308 reader and editable translated CNXML."""
from pathlib import Path
from lxml import etree as E
import copy,hashlib,html,json,re
from prepare import extract,tag
BASE=Path(__file__).resolve().parents[1]
MATH='http://www.w3.org/1998/Math/MathML'
def esc(x):return html.escape(str(x),quote=True)
def attrs(d):return ''.join(' '+k+'="'+esc(v)+'"' for k,v in d.items() if v is not None)
def save(name,value):
    p=BASE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value,encoding='utf-8',newline='\n')
def mathcopy(n,root=True):
    result=E.Element('{'+MATH+'}'+tag(n),dict(n.attrib),nsmap={None:MATH} if root else None)
    result.text=n.text
    for c in n:
        child=mathcopy(c,False);child.tail=c.tail;result.append(child)
    return result
NOTES={
 'fs-id1165137531472':'اصل وضاحت: پوری اندرلی رینج باہرلی ڈومین وچ ہووے تاں ترکیب پوری اندرلی ڈومین اُتے بن سکدی اے۔ جے ایہہ شرط پوری نہ ہووے، فیر وی ترکیب اوہناں اِن پُٹ اُتے بن سکدی اے جِناں لئی اندرلا آؤٹ پُٹ باہرلی ڈومین وچ آوے۔ اگلی ڈومین دی تعریف ایہو درست پابندی دیندی اے۔',
 'fs-id1165137871761':'اصل تصحیح: ماخذ دے ایس جملے وچ «مثبت» لکھیا اے؛ صحیح لفظ «غیر منفی»، یعنی صفر یا مثبت، اے۔ مربع جذر دے نشان ہیٹھلا عدد صفر وی ہو سکدا اے تے اصل مربع جذر صفر وی ہو سکدا اے۔ نال دِتیاں غیر سخت نامساواتاں تے آخری ڈومین نوں نہیں بدلیا گیا۔',
 'fs-id1165135152098':'اصل تصحیح: ایس توں اُتلی ماخذی مساوات وچ «or» لکھیا اے؛ صحیح جوڑ «and»، یعنی «تے»، اے۔ x نوں 2/3 تے 2 دوہاں توں وکھ ہونا چاہیدا اے۔ ماخذ دی اگلی وقفیاں والی ڈومین درست اے؛ اصل MathML تے وقفے محفوظ نیں۔',
 'm49308:0/2/11/2/19/1/0/0':'ماخذی نوٹ: اصل جواب وچ اکیلا انگریزی لفظ «Text» موجود اے۔ اوہدا لفظی ترجمہ «متن» اوتے محفوظ اے؛ ایہہ ریاضی دی ہدایت نہیں، ماخذ دا تدوینی بچیا ٹکڑا اے۔',
}
TABLE_NOTES={
 'Table_01_04_03':'اصل رسائی وضاحت: ماخذ دا summary گیاراں کالم تے تِن قطاراں آکھدا اے، پر اصل خانے گیاراں قطاراں تے تِن کالم نیں۔ ساری اصل قدر تے خانیاں دی ترتیب محفوظ اے۔',
 'eip-id1165134118229':'اصل رسائی وضاحت: ایہہ جدول مرکب فنکشن دی علامتی مساوات دیندا اے۔ ماخذ دا summary صرف دو نقطے اے۔',
}
class Renderer:
    def __init__(self,source,translation):
        self.source=source;self.rows={r['key']:r for r in translation['slots']};self.used=set();self.math_i=0
        self.parent={c:n for n in source.iter() for c in n}
        self.paths={source:'0'}
        for n in source.iter():
            for i,c in enumerate(n):self.paths[c]=self.paths[n]+'/'+str(i)
        self.figures={n.get('id'):i+1 for i,n in enumerate(source.xpath('//*[local-name()="figure"]'))}
        self.examples={n.get('id'):i+1 for i,n in enumerate(source.xpath('//*[local-name()="example"]'))}
        self.exercises={n.get('id'):i+1 for i,n in enumerate(source.xpath('//*[local-name()="exercise"]'))}
        self.tables={n.get('id'):i+1 for i,n in enumerate(source.xpath('//*[local-name()="table"]'))}
    def key(self,n):return n.get('id') or 'm49308:'+self.paths[n]
    def translated(self,key):
        self.used.add(key);return self.rows[key]['target']
    def mixed(self,n):
        key=self.key(n)
        if key in self.rows:
            template=self.translated(key)
            chunks=re.split(r'(\{\{\d+\}\})',template)
            return ''.join(self.render(n[int(s[2:-2])]) if re.fullmatch(r'\{\{\d+\}\}',s) else esc(s) for s in chunks)
        return esc(n.text or '')+''.join(self.render(c)+esc(c.tail or '') for c in n)
    def render(self,n):
        name=tag(n);key=self.key(n)
        if name=='metadata':
            for c in n:
                if tag(c)=='title':self.translated(self.key(c))
            return '<section class="learning-objectives"><h3>سکھن دے مقصد</h3>'+''.join(self.render(c) for c in n if tag(c)=='abstract')+'</section>'
        if name=='math':
            self.math_i+=1
            xml=E.tostring(mathcopy(n),encoding='unicode',with_tail=False)
            return '<span class="math-isolate" dir="ltr" data-source-math="'+str(self.math_i)+'" data-source-math-path="'+self.paths[n]+'">'+xml+'</span>'
        a={'id':n.get('id'),'class':'source-'+name,'data-source-node':self.paths[n],
           'data-source-attributes':json.dumps(dict(n.attrib),ensure_ascii=False,separators=(',',':'))}
        if key in self.rows:a['data-source-key']=key
        if name=='image':
            media=self.parent[n];alt=self.translated(self.key(media)+'/@alt')
            src='assets/'+Path(n.get('src')).name
            return '<img'+attrs({**a,'src':src,'alt':alt,'loading':'lazy','decoding':'async'})+' />'
        if name=='media':
            return '<div'+attrs({**a,'dir':'ltr','class':'source-media figure-scroll','tabindex':'0'})+'>'+self.mixed(n)+'</div>'
        if name=='link':
            href=n.get('url') or '#'+n.get('target-id','')
            label=self.mixed(n)
            if not label.strip():
                target=n.get('target-id')
                if target in self.figures:label='شکل '+str(self.figures[target])
                elif target in self.examples:label='مثال '+str(self.examples[target])
                elif target in self.tables:label='جدول '+str(self.tables[target])
                else:label='متعلقہ حصہ'
            return '<a'+attrs({**a,'href':href})+'>'+label+'</a>'
        if name=='table':
            summary=self.translated(key+'/@summary');a.update({'dir':'ltr','data-source-summary':summary,'aria-label':summary})
            if key=='Table_01_04_03':a['aria-label']='گیاراں قطاراں، تِن کالم: x، f(x)، g(x)۔'
            if key=='eip-id1165134118229':a['aria-label']='مرکب فنکشن دی اہم مساوات۔'
            content=self.mixed(n)
            return '<div class="table-scroll" tabindex="0"><table'+attrs(a)+'>'+content+'</table></div>'+('<aside class="adaptation" data-origin="editorial-addition">'+TABLE_NOTES[key]+'</aside>' if key in TABLE_NOTES else '')
        if name=='tgroup':
            # CALS structure is represented semantically; all attributes remain on a wrapper-free template.
            colspecs=[c for c in n if tag(c)=='colspec']
            body=('<colgroup>'+''.join(self.render(c) for c in colspecs)+'</colgroup>' if colspecs else '')
            body+=''.join(self.render(c) for c in n if tag(c)!='colspec')
            return body
        if name=='colspec':return '<col'+attrs(a)+' />'
        if name=='entry':
            row=self.parent[n];group=self.parent[row]
            first_row=list(group).index(row)==0
            has_thead=any(tag(c)=='thead' for c in self.parent[group])
            header=tag(group)=='thead' or (first_row and not has_thead)
            nameout='th' if header else 'td'
            a.update({'scope':'col' if header else None,'dir':'ltr'})
            return '<'+nameout+attrs(a)+'>'+self.mixed(n)+'</'+nameout+'>'
        if name=='newline':return '<br'+attrs(a)+' />'
        if name=='title':
            depth=sum(tag(x)=='section' for x in n.iterancestors());h='h'+str(min(6,2+depth))
            return '<'+h+attrs(a)+'>'+self.mixed(n)+'</'+h+'>'
        if name=='list':out='ol' if n.get('list-type')=='enumerated' else 'ul'
        else:out={'document':'article','content':'div','para':'div','item':'li','row':'tr','thead':'thead','tbody':'tbody','section':'section','example':'section','exercise':'section','problem':'div','solution':'div','equation':'div','note':'aside','figure':'figure','caption':'figcaption','label':'span','emphasis':'em','span':'span','term':'dfn','meaning':'dd','glossary':'dl','definition':'div','commentary':'div'}.get(name,'div')
        if name=='emphasis' and n.get('effect')=='bold':out='strong'
        if name=='equation':a['dir']='ltr'
        if name=='list' and n.get('class')=='circled':a['class']+=' circled'
        if name=='label' and not self.mixed(n).strip():return '<span'+attrs(a)+'></span>'
        content=self.mixed(n)
        if name=='example':content='<p class="ordinal">مثال '+str(self.examples[n.get('id')])+'</p>'+content
        if name=='exercise':content='<p class="ordinal">سوال '+str(self.exercises[n.get('id')])+'</p>'+content
        if name=='solution':content='<h5>ماخذ دا دِتا حل</h5>'+content
        if name=='glossary':content='<dt>اصطلاحی تعریف</dt>'+content
        result='<'+out+attrs(a)+'>'+content+'</'+out+'>'
        if key in NOTES:result+='<aside class="adaptation" data-origin="editorial-addition" data-about="'+key+'">'+NOTES[key]+'</aside>'
        return result
def translated_cnxml(root,translation):
    clone=copy.deepcopy(root);mapping={r['path']:r for r in translation['slots'] if not r['tag'].startswith('@')}
    attrmap={}
    for r in translation['slots']:
        if r['tag'].startswith('@'):attrmap.setdefault(r['path'],[]).append(r)
    def walk(n,path='0'):
        if tag(n)=='math':return
        original=list(n)
        for i,c in enumerate(original):walk(c,path+'/'+str(i))
        for r in attrmap.get(path,[]):n.set(r['tag'][1:],r['target'])
        if path not in mapping:return
        value=mapping[path]['target'];parts=re.split(r'(\{\{\d+\}\})',value)
        for c in original:n.remove(c);c.tail=None
        n.text=parts[0];last=None
        for part in parts[1:]:
            if re.fullmatch(r'\{\{\d+\}\}',part):last=original[int(part[2:-2])];n.append(last)
            elif last is not None:last.tail=(last.tail or '')+part
            else:n.text=(n.text or '')+part
    walk(clone)
    clone.set('{http://www.w3.org/XML/1998/namespace}lang','pnb-Arab-PK')
    return E.tostring(clone,encoding='unicode',xml_declaration=False)
def build():
    root,_=extract();translation=json.loads((BASE/'translation.json').read_text(encoding='utf-8'))
    render=Renderer(root,translation);body=render.render(root)
    assert render.used==set(render.rows),(set(render.rows)-render.used)
    bridge='''<section class="adaptation" id="bridge" data-origin="editorial-addition"><h2>پڑھن دی اصل کُنجی</h2><p>ایہہ مکمل ماخذی حصہ شاہ مکھی پنجابی وچ اے، پورا نصابی کتاب نہیں۔ ماخذ دے فارمولے تے شکلان دے اندرلے انگریزی ناں جیویں دے تیویں محفوظ نیں۔ ریاضی کھبے توں سجے، تے پنجابی نثر سجے توں کھبے پڑھو۔ «مرکب فنکشن» لئی سادہ خیال ایہہ اے: پہلے قاعدے توں ملی قدر نوں دوجے قاعدے وچ پاؤ۔ اندرلا پہلے، باہرلا بعد وچ؛ ایہہ ضرب نہیں۔</p><p>تکنیکی پنجابی اصطلاحاں تدوینی تے عارضی چوناں نیں؛ ایہہ کسے پنجابی ادارے دی منظور شدہ اصطلاحی فہرست ہون دا دعویٰ نہیں۔ ہِیٹھلا اردو خانہ صرف اردو دا پُل اے، پنجابی دی سند نہیں۔</p><table><thead><tr><th>شاہ مکھی پنجابی — عارضی چُون</th><th lang="ur-Arab-PK">اردو — الگ پُل</th><th lang="en" dir="ltr">English</th></tr></thead><tbody><tr><td>فنکشناں دی ترکیب؛ اک دا آؤٹ پُٹ دوجے دا اِن پُٹ</td><td lang="ur-Arab-PK">تفاعلوں کی ترکیب</td><td lang="en" dir="ltr">composition of functions</td></tr><tr><td>مرکب فنکشن</td><td lang="ur-Arab-PK">مرکب تفاعل</td><td lang="en" dir="ltr">composite function</td></tr><tr><td>اندرلا / باہرلا فنکشن</td><td lang="ur-Arab-PK">اندرونی / بیرونی تفاعل</td><td lang="en" dir="ltr">inner / outer function</td></tr><tr><td>تبادلی؛ ترتیب بدل کے وی نتیجہ اوہو</td><td lang="ur-Arab-PK">تبادلی</td><td lang="en" dir="ltr">commutative</td></tr><tr><td>ڈومین؛ قاعدے لئی جائز اِن پُٹ</td><td lang="ur-Arab-PK">دائرۂ تعریف</td><td lang="en" dir="ltr">domain</td></tr><tr><td>رینج؛ قاعدے توں واقعی ملے آؤٹ پُٹ</td><td lang="ur-Arab-PK">حاصل شدہ قدروں کا مجموعہ</td><td lang="en" dir="ltr">range</td></tr></tbody></table><p>فارمولیاں دے اندرلے اصل انگریزی لفظ: <bdi lang="en" dir="ltr">Cost</bdi> = خرچ؛ <bdi lang="en" dir="ltr">where</bdi> = جِتھے؛ <bdi lang="en" dir="ltr">and</bdi> = تے؛ <bdi lang="en" dir="ltr">or</bdi> = یا؛ <bdi lang="en" dir="ltr">number of miles / hours / gallons</bdi> = میل / گھنٹیاں / گیلن دی گنتی۔</p><p>اصل ماخذ دیاں آن لائن ویڈیو کڑیاں ضمنی نیں؛ سارا متن، فارمولے تے ضروری شکلان ایس پیکج وچ نیں۔ دوا والا سوال صرف ریاضی ماڈل دی مشق اے، علاج دی ہدایت نہیں۔</p></section>'''
    css=(BASE/'reader.css').read_text(encoding='utf-8')
    title=translation['slots'][0]['target']
    sections=[n for n in root.xpath('//*[local-name()="content"]/*[local-name()="section"]')]
    nav=' · '.join('<a href="#'+n.get('id')+'">'+esc(render.rows[render.key(n[0])]['target'])+'</a>' for n in sections)
    result='<!doctype html>\n<html lang="pnb-Arab-PK" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+title+' — A30 / m49308</title><link rel="stylesheet" href="reader.css"></head><body><header><p class="eyebrow"><bdi dir="ltr">OpenStax Precalculus 2e · m49308 · pnb-Arab-PK</bdi></p><h1>'+title+'</h1><p>اک مکمل حصہ: درس، مثالاں، مشقاں تے ماخذ دے دِتے حل۔ پورے کتاب دی پنجابی ترجمانی ہلے جاری اے۔</p><nav aria-label="حصیاں دی فہرست">'+nav+'</nav></header><main>'+bridge+body+'</main><footer lang="en" dir="ltr"><h2>Source, rights and change notice</h2><p>Adapted from <a href="https://openstax.org/details/books/precalculus-2e">OpenStax Precalculus 2e</a>, Jay Abramson et al., OpenStax / Rice University. Source module m49308 at commit 789b54099106b071d1d32bfcee454fed72eb4768. Copyright Rice University, OpenStax, under <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC BY-NC-SA 4.0</a>. This independent noncommercial ShareAlike adaptation is not endorsed by OpenStax or Rice University.</p><p>Changes: Punjabi prose translation; RTL/LTR-isolated offline HTML; translated accessibility text; separately labelled original instructional bridge and source-precision notes. All 543 source MathML trees and all 10 source image files remain unchanged in mathematical content. All 114 source exercises and 66 supplied solutions are preserved; no new answers are passed off as source answers. Remaining exercises have no supplied source solution. English text inside original mathematics/images is retained and bridged above.</p><p>Provenance: OpenAI Codex gpt-5.6-sol, Ultra. No human-review certification is claimed. Terminology is evidence-qualified; see <a href="TERMINOLOGY.md">terminology evidence</a>, <a href="TRANSLATION_DECISIONS.md">translation decisions for expert review</a>, <a href="RIGHTS.json">rights</a>, <a href="COVERAGE.json">coverage</a> and <a href="translation.json">editable translation</a>.</p></footer></body></html>\n'
    assert not any(t in result.lower() for t in ['<script','<iframe','<object'])
    save('reader.html',result)
    save('translated.cnxml',translated_cnxml(root,translation)+'\n')
    print('Built reader;',render.math_i,'MathML trees;',len(render.used),'slots')
if __name__=='__main__':build()
