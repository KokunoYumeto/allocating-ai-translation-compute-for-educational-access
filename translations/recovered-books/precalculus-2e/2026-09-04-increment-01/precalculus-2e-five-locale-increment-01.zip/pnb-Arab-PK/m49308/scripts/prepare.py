"""Extract source-addressed editable mixed-content slots without altering math."""
from pathlib import Path
from lxml import etree as E
import json,re
BASE=Path(__file__).resolve().parents[1]
def tag(n): return E.QName(n).localname
def extract():
    root=E.parse(str(BASE/'source/m49308.cnxml')).getroot()
    rows=[]
    def walk(n,path='0'):
        if tag(n) in ('metadata','math'): return
        key=n.get('id') or 'm49308:'+path
        t=(n.text or '')+''.join('{{'+str(i)+'}}'+(c.tail or '') for i,c in enumerate(n))
        plain=re.sub(r'\{\{\d+\}\}','',t).strip()
        if plain: rows.append({'key':key,'path':path,'tag':tag(n),'source':t})
        for attr in ('alt','summary'):
            if n.get(attr): rows.append({'key':key+'/@'+attr,'path':path,'tag':'@'+attr,'source':n.get(attr)})
        for i,c in enumerate(n): walk(c,path+'/'+str(i))
    walk(root)
    # OpenStax places instructional learning objectives inside metadata.
    # Append these slots to preserve already assigned body slot ordinals.
    for i,n in enumerate(root):
        if tag(n)=='metadata':
            for j,c in enumerate(n):
                if tag(c) in ('title','abstract'):walk(c,'0/'+str(i)+'/'+str(j))
    return root,rows
if __name__=='__main__':
    _,rows=extract()
    (BASE/'source/slots.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(len(rows),'slots')
    for i,r in enumerate(rows): print(str(i)+'|'+r['key']+'|'+r['tag']+'|'+re.sub(r'\s+',' ',r['source']))
