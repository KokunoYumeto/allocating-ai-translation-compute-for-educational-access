# Composition of Functions — Shahmukhi Punjabi

Open `reader.html` in a current browser. It works offline using native MathML and the ten local figures; no JavaScript, CDN, TeX, or network font is needed. Punjabi text is right-to-left; mathematics and source graph labels are left-to-right. A system font supporting Arabic script is required. Optional OpenStax video links require the internet.

This is the **complete m49308 source module**, not the complete Precalculus textbook. The full A30 Punjabi assignment continues next at **m49312**. Previous published modules remain unchanged.

Coverage: 422 source-addressed text/notation slots (including the learning objectives stored in OpenStax metadata), 543 MathML trees, 10 worked examples, 114 exercise objects, 66 source-supplied solutions, 10 unchanged source image files, five source tables, and one glossary definition. Exercises without a supplied source solution remain unanswered; no newly invented solution is represented as source content.

`translation.json` is the editable source-addressed Punjabi draft. Each slot retains its English source and structural child placeholders; placeholders can move for Punjabi syntax but cannot be added or deleted. `translated.cnxml` is a generated editable CNXML derivative. The authoritative unchanged input is `source/m49308.cnxml`, OpenStax commit `789b54099106b071d1d32bfcee454fed72eb4768`, SHA-256 `8e463e13c840a2772f75b1fc9380451bea746c1948bc5b660bb2aea677928a81`.

Rebuild with Python 3 and lxml:

```
python scripts/build.py
python scripts/qa.py
```

Normal rebuilding never needs a network. `scripts/prepare.py` extracts canonical mixed-content slots. `scripts/draft.py` holds the original Punjabi drafting map; running it deliberately regenerates `translation.json`, so preserve any later direct edits first. Acquisition scripts are not required for reading or normal rebuilding.

QA checks exact source/assets, source IDs, all canonical MathML structures, table-cell order, exercise/solution containment, internal links, placeholder coverage, Unicode/RTL markers, content categories, and deterministic reader/CNXML replay. Semantic review covered all ten source examples and the source's domain restrictions. See `QA.json` for actual results and limits. No human certification or browser visual pass is claimed by this module build; publication coordination owns the serial visual check.

Source wording problems are preserved and discussed in labelled editorial notes: the overly broad whole-range composition condition; “positive” where “nonnegative” is required; `or` where both excluded domain values require `and`; reversed row/column counts in a table accessibility summary; and a stray `Text` token in a supplied answer. No upstream contact was made. No original formula was silently changed.

`TERMINOLOGY.md` separates actual native Punjabi prose evidence, actual Urdu mathematical evidence, and provisional Punjabi specialist terms. The reader's Urdu and English bridges are explicitly labelled. `TRANSLATION_DECISIONS.md` gives expert reviewers exact source/target anchors, evidence actually checked, alternatives, uncertainty, and concrete review questions; its backfilled rationales are explicitly marked retrospective.

License: CC BY-NC-SA 4.0. Original authors and OpenStax / Rice University are credited in `LICENSE`, `RIGHTS.json`, the original frontmatter witness, and reader. Provenance: OpenAI Codex gpt-5.6-sol, Ultra.
