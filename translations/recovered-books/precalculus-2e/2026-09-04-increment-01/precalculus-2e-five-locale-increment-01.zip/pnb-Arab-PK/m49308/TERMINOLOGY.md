# Punjabi terminology and source use — m49308

Teaching locale: `pnb-Arab-PK`, native Shahmukhi Punjabi. Urdu and English are separate bridges. No Gurmukhi transliteration is used.

## Consulted evidence

The inherited compact prose canon (`canon/examples.json`, SHA-256 `734bb92da5edb28f084ef589bbd5af7e4ac40b823036e460073266f63eb30f9c`) was consulted during drafting and reread during revision. Jamil Ahmad Pal's [مہینا وار پرچاکاری](https://www.rvel.org/detail.php?id=2835), [پنجابی دے روزوار اخبار — پچھوکڑ](https://www.rvel.org/detail.php?id=1234), and [پنجابی زبان دی ونڈ کاری](https://rvel.org/detail.php?id=1283) supply ordinary explanatory constructions, not mathematics terminology. C01/C02 informed ability and obligation, C05/C06 purpose and alternatives, C11 reason-giving, and C12 transitions. Examples include `سکدی اے`, `چاہیدا اے`, `دی بجائے`, and `کیوں جے`. No prose author's views are adopted as mathematical authority.

Actual mathematical language evidence remains the directly inspected Urdu university source: Maulana Azad National Urdu University, *Calculus*, BNMM101DCT, first edition October 2025, ISBN 978-81-994195-2-0; [official PDF](https://dde.manuu.edu.in/sites/default/files/DDE/DDE-SelfLearnmaterial/NEW-SLM/49_Inner.pdf), SHA-256 `280c82e2af33011e4b3d969c29d496503a948a25996368571f8ca0f156b9ac43`. PDF page 10 uses `تفاعل` with “Function” and `جفت`/`طاق` beside their defining identities. This supports only the Urdu bridge. The full reference PDF is not redistributed. No composition-term attestation is inferred from that page.

## Decisions for this module

- `فنکشناں دی ترکیب` — composition of functions. Provisional Punjabi editorial choice, immediately explained as making one function's output the next function's input.
- `مرکب فنکشن` — composite function. Provisional, not claimed as institutionally standardized Punjabi.
- `اندرلا / باہرلا فنکشن` — inner / outer function. Punjabi explanatory pair; inside-first evaluation is repeated explicitly.
- `تبادلی` — commutative. Provisional technical borrowing, accompanied by “changing order leaves the result the same.”
- `ڈومین` / `رینج` retain prior provisional choices and distinguish permitted inputs from attained outputs.
- `جزوی فنکشناں وچ ونڈنا` — decomposition into component functions. A plain Punjabi construction; not factorization or division of numerical values.

The mathematical meanings and composition order are checked against all ten pinned OpenStax worked examples. Native Shahmukhi specialist terminology was not established by the bounded earlier search; this is a documented limitation, not a claim that no source exists or a human-dependent gate. New Urdu bridge equivalents for composition remain editorial, not newly attested claims.

All original MathML and graph pixels are retained. English MathML words (`Cost`, `where`, `and`, `or`, `number of miles/hours/gallons`) have an explicitly labelled Punjabi bridge in the reader. English source links remain optional online enrichment; they are not offline reader dependencies.
