"""Build twice and verify the public allowlist without network or shared-tree access."""
import json
from hashlib import sha256
from pathlib import Path
import build

root = Path(__file__).resolve().parent
def digest(path):
    return sha256(path.read_bytes()).hexdigest()

build.build()
first = (root / "PUBLIC_ALLOWLIST.json").read_bytes()
build.build()
second = (root / "PUBLIC_ALLOWLIST.json").read_bytes()
assert first == second, "Non-deterministic output manifest"
manifest = json.loads(second)
for entry in manifest["files"]:
    path = root / entry["path"]
    assert path.is_relative_to(root)
    assert path.stat().st_size == entry["bytes"], entry["path"]
    assert digest(path) == entry["sha256"], entry["path"]
assert digest(root / "assets/CNX_Precalc_Figure_Preface_01.jpg") == "66e71b8e2eab72b69cdb3a89691726f322f35202e3390dc0c94fa40cc6379494"
receipt = {
    "schema": "a30-preface-deterministic-replay-v1",
    "result": "pass_two_identical_builds_and_all_allowlist_bytes",
    "module": "m50919",
    "locale": "te-Telu-IN",
    "public_manifest_sha256": sha256(second).hexdigest(),
    "files_checked": len(manifest["files"]),
    "bytes_checked": sum(entry["bytes"] for entry in manifest["files"]),
    "source_figure_sha256": digest(root / "assets/CNX_Precalc_Figure_Preface_01.jpg"),
    "visual_review": "Parent-owned; not claimed by static replay"
}
(root / "REPLAY.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt))
