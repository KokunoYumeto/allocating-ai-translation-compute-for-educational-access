# OpenStax Precalculus 2e — Telugu preface

Open `reader.html` locally. It requires no server, JavaScript, remote fonts, or network-loaded images. A Telugu-capable system font is required (Noto Sans Telugu, Nirmala UI, or Gautami). Links to external publisher services need an internet connection. Browser print styles are included; no PDF page count or PDF QA is claimed.

## Actual coverage

Complete source module **m50919, Preface**, including the metadata abstract, all headings and prose, twelve chapter titles, the existing figure and its translated alternative text, all author/reviewer credits, and licensing/publication notices. This module is a checkpoint toward the full Telugu A30 assignment, **not a complete Telugu book**. The separate introduction m49299 is outside this helper package.

The source's statements about twelve chapters, 650+ examples, 2000+ figures, 5900+ exercises, answer keys, instructor accounts, other OpenStax titles, and publication plans describe the source publication. They are preserved source prose, not promises that all those materials are translated or bundled here, nor independently verified statements about current services. The biographical durations in the source are likewise preserved historical statements.

Source translations are separate from the clearly marked reader-opening editorial note, bilingual term glosses, and the caption explaining retention of English labels in the original figure. No new worked answer, diagnostic, grade test, or replacement mathematical image has been added to this preface. The wider Telugu programme's diagnostic/remediation/recheck workflow remains a requirement for instructional modules; this descriptive preface does not substitute for that workflow.

## Source and rights

- Work: OpenStax **Precalculus 2e**, not the other works sharing the source bundle.
- Authority repository: <https://github.com/openstax/osbooks-college-algebra-bundle>
- Pinned commit: `789b54099106b071d1d32bfcee454fed72eb4768`.
- Pinned tree: `05b39123f698772482c0c33a43fa2d2d4ea562ae`.
- Source path: `modules/m50919/index.cnxml`.
- Module UUID: `b3f4423d-9598-4fec-8822-df3767e33a9a`.
- Exact source SHA-256: `f6cfb6514c8b3e8cbeff7e1e81bc3ef2db53750bc91305f167af43fb70805a69`.
- Source is preserved as `source.cnxml`; all original author and institution names are retained in the reader.
- Work/component notice: source `eip-494` and `para-00001`, **CC BY-NC-SA 4.0**. See `LICENSE.md`.

The target CNXML preserves the source image reference `../../media/CNX_Precalc_Figure_Preface_01.jpg` exactly. The offline reader maps that canonical source reference to `assets/CNX_Precalc_Figure_Preface_01.jpg`, with byte identity in `qa.json`. Consumers of `translation.cnxml` can apply the same mapping or restore the canonical module/media directory layout. Embedded English labels in the source JPEG remain unchanged; the accessible alternative text is Telugu.

## Reproduce and inspect

Run `python build.py` with Python 3 and `lxml`, or `python verify_replay.py` to build twice and verify exact identity of every allowlisted file. The build is network-free and uses only files in this module directory. `translation.json` is the editable translation layer. `segments.json` exposes all 193 source slots, stable module-scoped segment IDs, full source/target text, and hashes. Source metadata IDs, credits, and the cited English book title are explicitly preserved rather than counted as untranslated prose.

Six English article/preposition fragments become empty during grammatical reordering; their content is carried by adjacent Telugu text. Source element hierarchy, all IDs, non-alt attributes, links, source figure bytes, credit strings, and all numeric tokens are checked. The preface has no MathML equations or numbered exercises. The HTML build checks local dependency resolution, internal targets, image alternatives, and absence of scripts. Parent integration performs the sequential visual check; this helper does not claim that an automated static check is visual review.

`PUBLIC_ALLOWLIST.json` lists the public payload by relative filename, byte count, and SHA-256. It excludes private task paths, credentials, operational conversations, and unrelated corpora. The allowlist does not list itself, avoiding recursive hashing. No other locale or completed Indonesian file was changed.

`TRANSLATION_DECISIONS.md` is the public expert-review queue. It identifies exact source/target locations, evidence actually checked, alternatives, uncertainty, and focused review questions. Backfilled rationales are labeled retrospective; missing regional evidence does not create a release hold.
