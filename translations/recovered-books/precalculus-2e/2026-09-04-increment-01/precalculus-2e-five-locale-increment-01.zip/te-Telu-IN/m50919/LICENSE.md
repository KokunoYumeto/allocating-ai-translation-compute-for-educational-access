# License and attribution

Original work: **OpenStax Precalculus 2e**, Rice University / OpenStax. Principal contributing author: Jay Abramson, Arizona State University. All contributing-author, institution, reviewer, and consultant credits are preserved verbatim in `source.cnxml`, `translation.cnxml`, and the reader.

The exact source preface, `m50919` at commit `789b54099106b071d1d32bfcee454fed72eb4768`, says in `eip-494` that the work is licensed under **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)**. The Telugu translation, bilingual glosses, editorial reading note, and companion build/reader files are distributed under the same license.

- License: <https://creativecommons.org/licenses/by-nc-sa/4.0/>
- Legal code: <https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode>
- Source: <https://github.com/openstax/osbooks-college-algebra-bundle/blob/789b54099106b071d1d32bfcee454fed72eb4768/modules/m50919/index.cnxml>

For the original preface illustration, the source gives no separate third-party credit in this module. The source's `para-00001` directs users of such art to retain the following notice: **Copyright Rice University, OpenStax, under CC BY-NC-SA 4.0 license.** The exact original JPEG is included unchanged; the reader's alt text is translated. No inference from the repository-level GitHub license field is used.

Changes: Telugu prose translation, translated image alternative text, bilingual chapter/feature glosses, an explicitly marked editorial scope note, and an offline HTML representation. Mathematics, source identities, author/reviewer names, and the original illustration are preserved. This is an independent translation checkpoint, not an OpenStax endorsement or an official Telugu edition. Publisher service statements and author biographies remain source statements rather than claims of present-day verification.

Regional canon materials are linguistic references only. They are not included in this public payload and are not relicensed under the OpenStax license. Their identities and the limited terminology decisions they inform are recorded in `TERMINOLOGY.md`.
