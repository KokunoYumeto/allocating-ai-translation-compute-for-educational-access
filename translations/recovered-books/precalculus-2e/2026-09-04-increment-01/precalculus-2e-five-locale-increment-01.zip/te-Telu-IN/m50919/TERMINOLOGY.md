# Telugu preface terminology consultation

## Actually consulted

The recovered Telugu canon's `TERMINOLOGY.tsv`, `examples.json`, and `B017-perimeter-witness.md` were read in full for this preface. They distinguish witnessed Telangana usage from unverified Andhra Pradesh usage. The starter examples are mainly whole-number/place-value material; they **do not attest advanced precalculus terminology**.

The B017 witness directly records Telugu mathematical prose using చుట్టుకొలత for perimeter and explaining it as the total length around a closed boundary, with worked examples and explicit unit preservation. Its effect here is stylistic and editorial: use an explicit mathematical description when an advanced label is not yet evidenced, retain the English bridge, and do not replace source counts, units, or meanings with a local adaptation.

The parent integrator also directly inspected complete page 8 of the Tamil Nadu government Telugu–English HSC 2017 mathematics paper. Q19 visibly pairs ప్రమేయానికి with “for the function”, applied to `f(x)=cos(x/2)`. This supports house singular **ప్రమేయం** and plural **ప్రమేయాలు**. The parent supplied this direct page-reading evidence; this helper did not duplicate that rendering. Document SHA-256: `eb63eb04d2b7815cc26a449e1ad6db1faca6b32fc7ba537eac318d17a5400158`, 681,500 bytes. This is **Tamil Nadu Telugu-language evidence**, not Andhra Pradesh or Telangana evidence. Legacy-font extracted text was garbled; the inspected glyphs were used, not the extraction.

## Decisions applied

- Functions → **ప్రమేయాలు**. Preserve this form across chapter headings and graph alt text; explicit English `(Functions)` bridges the first chapter title.
- Rational functions → **బహుపదాల నిష్పత్తి రూపంలోని ప్రమేయాలు (Rational Functions)**. Use this mathematically transparent descriptive phrase rather than asserting an unverified regional formal label. This is a heading gloss, not a new theorem or changed domain condition.
- Polynomial → **బహుపద**; linear → **రేఖీయ**; exponential → **ఘాతాంక**; logarithmic → **సంవర్గమాన**; periodic → **ఆవర్తన**. These are provisional house choices here, not claims of attestation by the starter canon. English chapter titles remain beside them.
- Trigonometry → **త్రికోణమితి**; analytic geometry → **విశ్లేషణాత్మక జ్యామితి**; calculus → **కలన గణితం**. Retain English heading bridges. No regional difference is inferred.
- Graph alt text uses **పరావలయం (parabola)**, **దీర్ఘవృత్తం (ellipse)**, and the descriptive “ప్రమేయం దాని విలోమంతో పాటు”. These are provisional topic choices pending a suitable specific canon witness; the figure itself is not altered.
- Worked-example prose is framed as “దశలను వివరిస్తూ పరిష్కారం”, not a claim that any grade-level test has been validated.

## Canon identities and limits

- SCERT Telangana, Class 2 Mathematics, Telugu, 2018–19 printing: <https://scert.telangana.gov.in/PDF/publication/ebooks/2TM_MAT.pdf>.
- SCERT Telangana, Class 6 Mathematics, Telugu, 2018–19 impression: <https://www.scert.telangana.gov.in/PDF/publication/ebooks/6TM_MAT.pdf>. B017 selects PDF pages 141–142 / printed pages 131–132; PDF identity recorded in the inherited witness is `3faa1f0551382ea25853d62604c63aa27034c6c07f7d56ce016c83d36b6f90ee`, 45,716,499 bytes. The original source is not copied into this package.
- Tamil Nadu supplementary paper identity and direct Q19 inspection are as stated above; parent integration maintains the acquisition URL and source receipt in the locale evidence ledger.

No source or canon is treated as training data. No Andhra Pradesh/Telangana difference is invented. Later verified topic-specific terminology can refine the reversible translation layer without changing the pinned source.
