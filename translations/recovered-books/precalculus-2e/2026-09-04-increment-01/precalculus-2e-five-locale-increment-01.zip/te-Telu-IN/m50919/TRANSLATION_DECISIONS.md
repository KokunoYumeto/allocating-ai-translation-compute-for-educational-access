# Translation decisions and expert-review queue — m50919

This is the public, traceable decision log for the Telugu translation of the complete OpenStax *Precalculus 2e* preface (`m50919`). It was backfilled on 2026-09-04 after the translation had been sealed. Unless an entry explicitly says otherwise, its rationale is a **retrospective reconstruction from the pinned source, current target, and existing `TERMINOLOGY.md`**, not a claim about the translator's unrecorded contemporaneous motive. The current wording remains usable and is open to later evidence-based correction.

Source authority: `modules/m50919/index.cnxml` at commit `789b54099106b071d1d32bfcee454fed72eb4768`, local `source.cnxml` SHA-256 `f6cfb6514c8b3e8cbeff7e1e81bc3ef2db53750bc91305f167af43fb70805a69`. Stable target locations below refer to `segments.json`, `translation.cnxml`, and the same preserved source IDs in `reader.html`.

## Evidence boundary

- The project record documents direct visual inspection of Tamil Nadu Directorate of Government Examinations, HSC Mathematics, March 2017, paper 6674, Telugu/English page 8. Question 19 visibly uses `ప్రమేయానికి` beside “for the function”; this supports the lemma `ప్రమేయం`. The PDF SHA-256 is `eb63eb04d2b7815cc26a449e1ad6db1faca6b32fc7ba537eac318d17a5400158`. This is **Tamil Nadu Telugu-language evidence, not Andhra Pradesh or Telangana evidence**. Legacy-font extraction was unusable; the page image, not extracted text, was inspected.
- The inherited Telangana starter canon (`TERMINOLOGY.tsv`, `examples.json`, and `B017-perimeter-witness.md`) was consulted. It supports elementary mathematical style and the witnessed term `చుట్టుకొలత`; it does **not** attest the advanced pre-calculus terms below. No Andhra Pradesh source was checked for this module, and no Andhra/Telangana terminology difference is claimed.
- The pinned English source controls mathematical sense. English bridges are retained where the checked Telugu evidence is narrow.

## Logged decisions

### TE50919-D01 — function

- **Source/target locations:** `A30:m50919:029`–`:033`, `:037`–`:038`, `:076`–`:077` in `segments.json`; source/target IDs `eip-id1164239746735`, `eip-id1168983371474`, `eip-id1164253943954`, `eip-id7864342`, `eip-829`, and `preface01`.
- **Chosen wording and sense:** singular `ప్రమేయం`, plural `ప్రమేయాలు`, meaning mathematical function(s), not a generic event or duty. The first chapter heading retains `(Functions)`.
- **Authority and rationale:** the Tamil Nadu page above directly attests an inflected form of `ప్రమేయం`; repeated use gives the book a consistent lemma while the English bridge prevents ambiguity.
- **Alternatives:** English/transliterated `ఫంక్షన్` alone; mixed `ప్రమేయం (function)` at every occurrence. The current target uses the Telugu lemma and limits repeated English clutter.
- **Status/uncertainty:** backfilled from a rationale already recorded in `TERMINOLOGY.md`; directly attested in Tamil Nadu but **provisional for Andhra Pradesh/Telangana convention**.
- **Expert-review question:** In Andhra Pradesh and Telangana secondary-to-undergraduate mathematics, is `ప్రమేయం` the preferred headword for *function*, and is `ప్రమేయాలు` the natural plural in these headings?

### TE50919-D02 — advanced chapter-heading terms

- **Source/target locations:** `A30:m50919:031`, `:033`, `:034`, `:037`–`:038`, and `:043`–`:046`; source/target list IDs `eip-id1168983371474`, `eip-id7864342`, and `eip-id1166690773820`.
- **Chosen wording and sense:** `రేఖీయ` (linear), `ఘాతాంక` (exponential), `సంవర్గమాన` (logarithmic), `త్రికోణమితి/త్రికోణమితీయ` (trigonometry/trigonometric), `ఆవర్తన` (periodic), `విశ్లేషణాత్మక జ్యామితి` (analytic geometry), and `కలన గణితం` (calculus). English chapter titles remain beside the most specialist forms.
- **Authority and rationale:** the pinned source fixes the concepts; the checked regional starter material does not attest these advanced labels. The choices provide concise Telugu headings while retained English anchors keep them reversible.
- **Alternatives:** English transliterations; for logarithmic, a `లఘుగణక`-based form; for calculus, bare `కాల్క్యులస్`. These alternatives are recorded now and are not represented as contemporaneously tested variants.
- **Status/uncertainty:** retrospective, **provisional**, not regionally attested in the checked sources.
- **Expert-review question:** Which forms are standard in current AP/TS intermediate and first-year STEM texts, especially `సంవర్గమాన` versus a `లఘుగణక` form and `కలన గణితం` versus `కాల్క్యులస్`?

### TE50919-D03 — rational functions as a descriptive heading

- **Source/target location:** `A30:m50919:032`, source/target list ID `eip-id1168983371474`.
- **Chosen wording and sense:** `బహుపదాల నిష్పత్తి రూపంలోని ప్రమేయాలు (Rational Functions)`, explicitly “functions in the form of a ratio of polynomials.”
- **Authority and rationale:** no checked regional source established a compact formal Telugu label. The descriptive wording preserves the mathematical type and the English heading without asserting unattested regional usage.
- **Alternatives:** a literal “rational” calque or English-only `Rational Functions`; neither was adopted as an unsupported official term.
- **Status/uncertainty:** retrospective and **provisional**; mathematically transparent but longer than a conventional textbook headword may be.
- **Expert-review question:** Is there a stable AP/TS textbook headword for *rational function* that is both more concise and equally unambiguous?

### TE50919-D04 — worked-example and pedagogical labels

- **Source/target locations:** `A30:m50919:025`, `:072`, and `:073`; IDs `eip-428`, `eip-321`, and `eip-id1166796259369`.
- **Chosen wording and sense:** `అభ్యసన లక్ష్యం` for learning objective, `పరిష్కారంతో కూడిన ఉదాహరణ` for worked example, `పరిష్కారం` for Solution, and `విశ్లేషణ` for Analysis.
- **Authority and rationale:** the source's instructional roles were preserved rather than collapsed into a generic “example.” The Telangana perimeter witness influenced the preference for explicit explanatory mathematical prose, but it does not attest these particular labels.
- **Alternatives:** transliterated labels or shorter `ఉదాహరణ`; those would obscure the source's worked-solution/analysis structure.
- **Status/uncertainty:** retrospective; low semantic uncertainty, moderate regional-terminology uncertainty.
- **Expert-review question:** Are these the most natural AP/TS labels for the recurring OpenStax Example–Solution–Analysis sequence?

### TE50919-D05 — graph, figure, conic, inverse, and geometry wording

- **Source/target locations:** `A30:m50919:076` and `:077`; IDs `eip-829` and media `preface01`; translated image alternative text is the `@alt` record `A30:m50919:077`.
- **Chosen wording and sense:** `గ్రాఫ్` (graph), `పటం` (figure), `రేఖాచిత్రం` (diagram), `పరావలయం (parabola)`, `దీర్ఘవృత్తం (ellipse)`, `విలోమం` (inverse), `నిరూపక జ్యామితి` (coordinate geometry), and `ప్రమేయ పరివర్తనం` (function transformation).
- **Authority and rationale:** the exact English source alt controls the depicted concepts. Parenthetical English is retained for the two conics because no topic-specific regional witness was checked. The source JPEG and its English embedded labels are unchanged; only accessible alt text is translated.
- **Alternatives:** English-only labels; a `నిర్దేశాంక`-based expression for coordinate geometry; transliterated `ఇన్వర్స్`. These are current review candidates, not claimed witnessed forms.
- **Status/uncertainty:** retrospective and **provisional**, especially `నిరూపక జ్యామితి` and the inverse/transformation wording.
- **Expert-review question:** What terminology do current AP/TS pre-calculus texts use for *coordinate geometry*, *inverse function*, and *function transformation*, and should either conic headword change?

### TE50919-D06 — source claims versus translation-editor additions

- **Source/target locations:** source and translated preface under `fs-id1164949285210`, including service/resource claims at `eip-219`, `eip-542`, and `eip-197`; reader-only additions at `aside.edition-note` and `figure#preface01 figcaption`.
- **Chosen treatment and sense:** source descriptions of the book, counts, web services, resources, and plans remain translated as source prose. The reader note says they are not promises about this partial Telugu package or independently verified current services. The source JPEG is retained byte-for-byte; the added Telugu figcaption only discloses that its embedded English labels remain.
- **Authority and rationale:** the pinned module is the authority for what the preface says; source IDs and credits remain intact. Editorial clarification is outside `translation.cnxml` and visibly separated in `reader.html`.
- **Alternatives:** silently update, delete, or present the claims as current translator assertions. Those would reduce source fidelity or blur provenance.
- **Status/uncertainty:** retrospective provenance record; low uncertainty. The added note is editorial, not source translation.
- **Expert-review question:** Does the reader note clearly enough separate preserved source claims and unchanged source art from the translator's limited editorial clarification?

Corrections should cite a concrete regional mathematical source and identify the decision ID. A later revision may change target wording while preserving the pinned source, stable IDs, this historical entry, and a new evidence-backed disposition.
