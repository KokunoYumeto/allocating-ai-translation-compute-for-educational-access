"""Deterministic offline Telugu preface build. Python 3 + lxml; no network."""
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
import json
import html
import re
from lxml import etree as E

ROOT = Path(__file__).resolve().parent
EXPECTED_SOURCE = "f6cfb6514c8b3e8cbeff7e1e81bc3ef2db53750bc91305f167af43fb70805a69"
EXPECTED_ASSET = "CNX_Precalc_Figure_Preface_01.jpg"
NS = {"c": "http://cnx.rice.edu/cnxml", "md": "http://cnx.rice.edu/mdml"}
UNCHANGED = {2, 5, 51, 135, *range(138, 147), *range(148, 194)}
GRAMMATICAL_EMPTY = {15, 59, 80, 83, 86, 89}
def digest(data):
    return sha256(data).hexdigest()

def jdump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def enumerate_slots(root):
    for el in root.iter():
        for kind in ("text", "tail"):
            value = getattr(el, kind)
            if value and value.strip():
                yield el, kind, value
        if el.get("alt"):
            yield el, "@alt", el.get("alt")

def build():
    source_bytes = (ROOT / "source.cnxml").read_bytes()
    assert digest(source_bytes) == EXPECTED_SOURCE, "Source identity changed"
    source = E.fromstring(source_bytes)
    translated = deepcopy(source)
    substitutions = {int(k): v for k, v in json.loads((ROOT / "translation.json").read_text(encoding="utf-8")).items()}
    source_slots, target_slots = list(enumerate_slots(source)), list(enumerate_slots(translated))
    assert len(source_slots) == 193
    assert set(substitutions) | UNCHANGED == set(range(1, 194))
    assert not set(substitutions) & UNCHANGED
    tree = E.ElementTree(source)
    records = []
    for i, ((sel, kind, sval), (tel, tkind, _)) in enumerate(zip(source_slots, target_slots), 1):
        assert kind == tkind
        tval = substitutions.get(i, sval)
        if i in GRAMMATICAL_EMPTY:
            assert tval == ""
        elif i in substitutions:
            assert any("\u0c00" <= c <= "\u0c7f" for c in tval), (i, "No Telugu text")
        assert "\ufffd" not in tval
        if kind == "@alt":
            tel.set("alt", tval)
        else:
            setattr(tel, kind, tval)
        records.append({"segment_id": f"A30:m50919:{i:03}", "xpath": tree.getpath(sel), "node": kind, "source": sval, "source_sha256": digest(sval.encode()), "target": tval, "target_sha256": digest(tval.encode()), "status": "preserved_identifier_or_credit_or_cited_title" if i in UNCHANGED else "grammatical_reordering" if i in GRAMMATICAL_EMPTY else "translated"})
    # All element names, hierarchy, IDs and attributes are immutable, except translated alt text.
    assert len(list(source.iter())) == len(list(translated.iter()))
    for s, t in zip(source.iter(), translated.iter()):
        assert s.tag == t.tag
        assert len(s) == len(t)
        assert {k: v for k, v in s.attrib.items() if k != "alt"} == {k: v for k, v in t.attrib.items() if k != "alt"}
    source_ids = source.xpath("//@id")
    assert source_ids == translated.xpath("//@id")
    assert len(source_ids) == len(set(source_ids))
    for target_id in translated.xpath("//c:link/@target-id", namespaces=NS):
        assert target_id in source_ids
    # This preface has no MathML equations or numbered exercises; every numerical token stays exact.
    snums = re.findall(r"\d+(?:[.-]\d+)*", " ".join(source.itertext()))
    tnums = re.findall(r"\d+(?:[.-]\d+)*", " ".join(translated.itertext()))
    assert snums == tnums, (snums, tnums)
    target_bytes = E.tostring(translated, encoding="UTF-8", xml_declaration=True, pretty_print=False) + b"\n"
    (ROOT / "translation.cnxml").write_bytes(target_bytes)
    jdump(ROOT / "segments.json", {"schema": "a30-cnxml-translation-segments-v1", "locale": "te-Telu-IN", "module": "m50919", "source_sha256": EXPECTED_SOURCE, "records": records})

    def render(el, level=1):
        name = E.QName(el).localname
        attrs = ' id="' + html.escape(el.get("id"), quote=True) + '"' if el.get("id") else ""
        if name == "image":
            source_src = el.get("src")
            assert source_src == "../../media/" + EXPECTED_ASSET
            alt = el.getparent().get("alt", "")
            return f'<img src="assets/{EXPECTED_ASSET}" alt="{html.escape(alt, quote=True)}" loading="lazy" decoding="async">'
        if name == "newline":
            return "<br>"
        child_level = level + 1 if name == "section" and el.find("c:title", NS) is not None else level
        body = html.escape(el.text or "")
        for child in el:
            body += render(child, child_level) + html.escape(child.tail or "")
        if name == "title":
            return f"<h{min(level,6)}{attrs}>{body}</h{min(level,6)}>"
        if name == "section":
            return f"<section{attrs}>{body}</section>"
        if name == "para":
            # CNXML allows a list inside para; HTML does not. A paragraph-role block preserves order.
            tag = "div" if el.find("c:list", NS) is not None else "p"
            return f'<{tag}{attrs} class="paragraph">{body}</{tag}>'
        if name == "list":
            return f"<ul{attrs}>{body}</ul>"
        if name == "item":
            return f"<li{attrs}>{body}</li>"
        if name == "emphasis":
            tag = "em" if el.get("effect") == "italics" else "strong"
            return f"<{tag}{attrs}>{body}</{tag}>"
        if name == "link":
            return f'<a{attrs} href="#{html.escape(el.get("target-id"), quote=True)}">{body}</a>'
        if name == "media":
            return f'<figure{attrs}>{body}<figcaption>మూలంలోని పటం; చిత్రంలో ఉన్న ఆంగ్ల లేబుళ్లు యథాతథంగా ఉంచబడ్డాయి.</figcaption></figure>'
        if name == "content":
            return body
        raise ValueError("Unhandled source element " + name)

    title = translated.find("c:title", NS).text
    abstract = translated.find("c:metadata/md:abstract", NS).text
    body = render(translated.find("c:content", NS), 1)
    page = f'''<!doctype html>
<html lang="te-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title} — OpenStax Precalculus 2e — తెలుగు</title><link rel="stylesheet" href="reader.css"></head>
<body><a class="skip" href="#source-preface">పాఠ్యానికి వెళ్లండి</a><main>
<header><p class="eyebrow">OPENSTAX PRECALCULUS 2e · A30 · m50919</p><h1>{title}</h1><p>తెలుగు అనువాదం · English terminology bridge</p></header>
<aside class="edition-note"><h2>ఈ అనువాద భాగం గురించి</h2><p>ఇది మూల పుస్తకంలోని పూర్తి ముందుమాట అనువాదం మాత్రమే; మొత్తం తెలుగు పుస్తకం పూర్తయిందని కాదు. క్రింద పేర్కొన్న అధ్యాయాలు, సమాధానాలు, వెబ్ సేవలు, అధ్యాపక వనరులు, ప్రచురణ ప్రణాళికలు మూల పుస్తకాన్ని వివరిస్తాయి. అవన్నీ ఈ అనువాద ప్యాకేజీలో ఉన్నాయని లేదా ప్రస్తుతం అదే విధంగా అందుబాటులో ఉన్నాయని ఈ ముందుమాట ప్రకటించడం లేదు.</p><p>ఈ గమనిక, ద్విభాషా పద సహాయం, పటానికి ఇచ్చిన అనువాద గమనిక మాత్రమే సంపాదకీయ చేర్పులు. రచయితలు, సమీక్షకుల పేర్లను మూలంలో ఉన్నట్లే ఉంచాము. మూల పటం మార్చలేదు; దాని ప్రత్యామ్నాయ వివరణను తెలుగులోకి అనువదించాము.</p><p><a href="README.md">పరిధి, మూలం, పునర్నిర్మాణ వివరాలు</a> · <a href="TERMINOLOGY.md">పదజాల ఆధారాలు, పరిమితులు</a> · <a href="translation.cnxml">సవరించగల CNXML</a> · <a href="segments.json">మూలం–అనువాద సరిపోలిక</a></p></aside>
<details class="abstract"><summary>మూల మెటాడేటాలోని పుస్తక సారాంశం</summary><p>{html.escape(abstract)}</p></details>
<article id="source-preface" aria-label="మూల ముందుమాట అనువాదం">{body}</article>
<footer><p>Source: OpenStax / Rice University, <a href="https://github.com/openstax/osbooks-college-algebra-bundle/blob/789b54099106b071d1d32bfcee454fed72eb4768/modules/m50919/index.cnxml">Precalculus 2e, module m50919</a>. Copyright Rice University, OpenStax, under <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC BY-NC-SA 4.0</a>. Telugu translation and identified editorial additions: the same license. <a href="LICENSE.md">License and attribution</a>.</p></footer>
</main></body></html>'''
    (ROOT / "reader.html").write_text(page + "\n", encoding="utf-8", newline="\n")
    html_tree = E.HTML(page)
    html_ids = html_tree.xpath("//@id")
    assert len(html_ids) == len(set(html_ids))
    assert all(i in html_ids for i in source_ids)
    assert not html_tree.xpath("//script")
    assert not html_tree.xpath("//img[not(@alt) or @alt='']")
    local_refs = html_tree.xpath("//link/@href | //img/@src | //a/@href")
    for href in local_refs:
        if href.startswith("#"):
            assert href[1:] in html_ids
        elif not href.startswith("https://"):
            assert (ROOT / href).is_file(), href
    asset_bytes = (ROOT / "assets" / EXPECTED_ASSET).read_bytes()
    input_hashes = {name: digest((ROOT / name).read_bytes()) for name in ("source.cnxml", "translation.json", "build.py", "reader.css", "README.md", "LICENSE.md", "TERMINOLOGY.md", "TRANSLATION_DECISIONS.md")}
    qa = {"schema": "a30-preface-source-qa-v1", "result": "pass_structural_math_encoding_offline_static_checks", "module": "m50919", "locale": "te-Telu-IN", "source_commit": "789b54099106b071d1d32bfcee454fed72eb4768", "source_sha256": EXPECTED_SOURCE, "target_sha256": digest(target_bytes), "source_slots": 193, "translated_slots_including_grammatical_reordering": len(substitutions), "unchanged_metadata_credit_cited_title_slots": len(UNCHANGED), "grammatical_empty_slots": sorted(GRAMMATICAL_EMPTY), "source_elements": len(list(source.iter())), "preserved_ids": len(source_ids), "all_non_alt_attributes_preserved": True, "all_numerical_tokens_preserved_in_order": True, "source_mathml_elements": len(source.xpath("//*[namespace-uri()='http://www.w3.org/1998/Math/MathML']")), "source_numbered_exercises": 0, "asset": {"path": "assets/" + EXPECTED_ASSET, "canonical_src": "../../media/" + EXPECTED_ASSET, "bytes": len(asset_bytes), "sha256": digest(asset_bytes), "treatment": "unchanged source JPEG with translated reader alt; inherited English image labels retained", "rights_evidence": "source m50919 para-00001: uncredited original art Copyright Rice University, OpenStax, CC BY-NC-SA 4.0"}, "offline_html_dependencies_resolved": True, "visual_qa": "not performed by helper; root owns sequential browser inspection", "source_coverage": "complete m50919 preface and metadata abstract; not a complete Telugu book", "source_cnxml_asset_resolution": "Canonical src is preserved; renderer maps it to local assets/. See canonical_src in this receipt.", "inputs": input_hashes}
    jdump(ROOT / "qa.json", qa)
    files = ["reader.html", "reader.css", "translation.cnxml", "translation.json", "segments.json", "source.cnxml", "build.py", "verify_replay.py", "README.md", "LICENSE.md", "TERMINOLOGY.md", "TRANSLATION_DECISIONS.md", "qa.json", "assets/" + EXPECTED_ASSET]
    entries = [{"path": name, "bytes": (ROOT / name).stat().st_size, "sha256": digest((ROOT / name).read_bytes())} for name in files]
    jdump(ROOT / "PUBLIC_ALLOWLIST.json", {"schema": "a30-public-allowlist-v1", "scope": "complete Telugu m50919 preface only", "files": entries})
    print(json.dumps({"result": qa["result"], "files": len(entries), "bytes": sum(x["bytes"] for x in entries), "reader_sha256": digest((ROOT / "reader.html").read_bytes()), "target_sha256": qa["target_sha256"], "public_manifest_sha256": digest((ROOT / "PUBLIC_ALLOWLIST.json").read_bytes())}))

if __name__ == "__main__":
    build()
