# Translation decisions and expert-review queue — m49299

This is the public, traceable decision log for the Telugu translation and clearly separated learner support for OpenStax *Precalculus 2e* introduction `m49299`. It was backfilled on 2026-09-04 after the reader had been sealed. Unless stated otherwise, rationales below are **retrospective reconstructions from the pinned source, current target, `TERMINOLOGY.md`, and build checks**, not claims about unrecorded contemporaneous motives. Provisional terms remain open to evidence-based correction; no missing expert response blocks use of this module.

Source authority: `modules/m49299/index.cnxml` at commit `789b54099106b071d1d32bfcee454fed72eb4768`; local `source.cnxml` SHA-256 `9539d32c4a802797ad1b350c8823bf105ece72bbffd64d8d006b3b3ef034e906`. The source and translated CNXML preserve module UUID `bc43a726-bcbf-4db7-89a0-50d97ab46818` and all four source IDs.

## Evidence boundary

- The project record documents direct visual inspection of Tamil Nadu Directorate of Government Examinations, HSC Mathematics, March 2017, paper 6674, Telugu/English page 8. Question 19 visibly uses `ప్రమేయానికి` beside “for the function”; question 20 visibly pairs `పరమ గరిష్ఠ విలువ` with “absolute maximum value.” PDF SHA-256: `eb63eb04d2b7815cc26a449e1ad6db1faca6b32fc7ba537eac318d17a5400158`. This is **Tamil Nadu Telugu-language evidence, not Andhra Pradesh or Telangana evidence**. The page image was inspected because legacy-font extraction was corrupt.
- Inherited Telangana canon records C07–C09 and C16 were consulted for smaller/larger, endpoint, and number-line style. They were not re-certified as fresh page-image inspections and do not attest specialist function terminology. No Andhra Pradesh source was checked, and no AP/TS difference is claimed.
- A university Telugu economics-mathematics candidate was not admitted because retrieval met an access challenge. It is not evidence. The pinned English source controls mathematical and historical claims.

## Logged decisions

### TE49299-D01 — function in the title and bridge

- **Source/target locations:** source document title and `md:title`; target title at the same nodes in `translated.cnxml`; `translation.json#/title`; bridge mention at `translation.json#/bridge` and `reader.html#te-original-schematic`.
- **Chosen wording and sense:** `ప్రమేయాలకు పరిచయం`; lemma `ప్రమేయం`, meaning a mathematical function/relationship with one output for each selected input.
- **Authority and rationale:** the Tamil Nadu page directly attests an inflected form of `ప్రమేయం`. English `function` is retained as a later-learning bridge rather than replacing the Telugu title.
- **Alternatives:** transliterated `ఫంక్షన్`; mixed `ప్రమేయం (function)` in the title.
- **Status/uncertainty:** backfilled from a rationale already recorded in `TERMINOLOGY.md`; directly attested in Tamil Nadu, but **provisional for Andhra Pradesh/Telangana convention**.
- **Expert-review question:** Is `ప్రమేయం` the preferred AP/TS secondary-to-undergraduate headword, and is the dative plural construction in `ప్రమేయాలకు పరిచయం` natural for a chapter introduction?

### TE49299-D02 — direction of the year–market-value relationship

- **Source/target location:** source and target paragraph `fs-id1165137911603`; related added explanation at `support.html#te-D1`.
- **Chosen wording and sense:** choose a year first, then determine/read its corresponding stock-market-average value. The target does not claim that selecting a market value determines a unique year.
- **Authority and rationale:** “For any year we choose” in the pinned source fixes this direction. The added input/output explanation follows that direction and is labeled as learner support, not source prose.
- **Alternatives:** a symmetric “relationship between two values” formulation or an inverse-function implication. Those would lose a prerequisite concept or add a false claim.
- **Status/uncertainty:** the directional rule was contemporaneously recorded in `TERMINOLOGY.md`; this structured entry is retrospective. Low mathematical uncertainty.
- **Expert-review question:** Does the Telugu paragraph preserve the one-way reading naturally without suggesting that the inverse relation is a function?

### TE49299-D03 — strict bounds, approximation, chronology, and currency

- **Source/target location:** source and target paragraph `fs-id1165137768418`; `translation.json#/paragraphs/fs-id1165137768418`; added checks `support.html#te-D2`, `#te-D3`, and recheck items 2–3.
- **Chosen wording and sense:** `కంటే కొద్దిగా తక్కువ` for “just under,” `కంటే తక్కువ` for strict “less than,” and `సుమారు`/`≈` for “about/approximately.” All years and `$100`, `$500`, `$1,100` remain source US-dollar values; no 1997 value or interpolated history is invented.
- **Authority and rationale:** the pinned source and numeric-token build checks control the distinctions. Inherited Telangana C07–C09/C16 informed elementary comparison style but do not verify this whole translation, and were not freshly page-inspected here.
- **Alternatives:** flattening all three meanings to `సుమారు`; converting dollars to rupees; inserting a value between 1995 and 2000. Each would change the source claim.
- **Status/uncertainty:** core distinctions were contemporaneously recorded in `TERMINOLOGY.md`; wording review remains **provisional for regional naturalness**.
- **Expert-review question:** Are `కంటే కొద్దిగా తక్కువ`, `కంటే తక్కువ`, and `సుమారు` the clearest AP/TS learner-facing contrasts at the intended level?

### TE49299-D04 — input/output labels are additional support

- **Source/target location:** no source counterpart; added learner-support explanation only at `support.html#te-D1`, surfaced in the reader's separately marked support section.
- **Chosen wording and sense:** `ప్రవేశ విలువ (input)` for the chosen year and `నిర్గమ విలువ (output)` for the corresponding market value.
- **Authority and rationale:** these transparent descriptive labels scaffold the source's directional relationship; the English terms remain beside them. Neither the Tamil Nadu page nor checked Telangana starter records attest these labels.
- **Alternatives:** transliterated `ఇన్‌పుట్/అవుట్‌పుట్`, English only, or another regionally attested pair if supplied later.
- **Status/uncertainty:** retrospective and explicitly **provisional/unattested**; not represented as source translation or official terminology.
- **Expert-review question:** Which input/output pair is standard and most comprehensible in current AP/TS mathematics teaching, and should the English bridge remain on first use?

### TE49299-D05 — source composite image versus original adaptation

- **Source/target locations:** source figure `Figure_01_00_001`, media `fs-id1165137810701`, source caption and alt; corresponding source-translation placeholder at `reader.html#Figure_01_00_001`; component disposition in `original-component-notice.json`; separate adaptation at `reader.html#te-original-schematic`, `translation.json#/source_reference_note`, `/adaptation_title`, `/adaptation_alt`, and `/adaptation_explanation`.
- **Chosen treatment and sense:** the unresolved third-party bull/market composite is not redistributed. Its source caption, credits, and translated alt remain evidence of the source. A separate openly licensed schematic (SHA-256 `3f78ccdb06e006e96d91d1269b562047902ca5c04703f58a0bdc007f772601a0`) illustrates only values explicitly stated in the prose and is labeled `data-origin="original-adaptation"`.
- **Authority and rationale:** the source caption identifies third-party modifications but does not supply a component license in this module. Separation avoids a false rights claim and avoids presenting the schematic as the historical graph.
- **Alternatives:** redistribute the unresolved composite, omit all reference to it, or silently substitute the schematic. All three would create a rights or provenance problem.
- **Status/uncertainty:** retrospective provenance record; source-component permission remains unresolved, so exclusion is deliberate. The adaptation is not source content.
- **Expert-review question:** Are the source-placeholder and adaptation labels sufficiently unmistakable to a Telugu reader, including one using assistive technology?

### TE49299-D06 — schematic encodes limits, not invented data

- **Source/target locations:** source paragraph `fs-id1165137768418`; `translation.json#/adaptation_alt` and `/adaptation_explanation`; `schematic.svg`; diagnostic explanations `support.html#te-D2` and `#te-D3`.
- **Chosen treatment and sense:** an open circle at `$500` means strictly below, `≈` marks approximation near `$1,100`, no line connects unknown intermediate years, and a separate descending arrow conveys direction after late 2000 without a fabricated magnitude.
- **Authority and rationale:** every mark is limited to the English prose's explicit information. The support questions make the epistemic limits examinable rather than hiding them in a caption.
- **Alternatives:** recreate a continuous stock curve, interpolate 1997, or assign a decline endpoint. Those would invent observations.
- **Status/uncertainty:** rationale was substantially contemporaneous in `TERMINOLOGY.md`; this entry is retrospective. Low source-semantic uncertainty, ordinary pedagogical-design uncertainty.
- **Expert-review question:** Could any current visual convention still imply a data point or interpolation that the prose does not warrant, and if so what equally accessible notation should replace it?

### TE49299-D07 — market vocabulary and proper names

- **Source/target location:** source and target paragraph `fs-id1165137768418`; source/target caption under `Figure_01_00_001`.
- **Chosen wording and sense:** `షేర్ల విలువలు`, `షేరు మార్కెట్ సగటు`, `పెట్టుబడి విలువ`, `డాట్-కామ్ బుడగ`, and `తీవ్ర పతనం`; Standard and Poor's, Prayitno Hadinata, and MeasuringWorth remain credited proper names.
- **Authority and rationale:** the source distinguishes individual stock values, a market average/index, an investment's value, and a later decline. No checked finance-specific Telugu authority established a regional formal vocabulary, so the target favors transparent prose and keeps identities unchanged.
- **Alternatives:** more Sanskritized finance terminology or English-heavy transliteration. Neither was evidenced during this module.
- **Status/uncertainty:** retrospective and **provisional for finance-register naturalness**; mathematical/historical quantities are fixed.
- **Expert-review question:** Are these terms natural and unambiguous for AP/TS secondary learners, particularly the distinction between `షేరు మార్కెట్ సగటు` and `పెట్టుబడి విలువ`?

The Tamil Nadu page's `పరమ గరిష్ఠ విలువ` is recorded as a future terminology lead only; “absolute maximum value” does not occur in `m49299`, so it was not inserted here. Corrections should cite a concrete mathematical source and identify the decision ID while preserving source IDs, provenance distinctions, and the historical decision record.
