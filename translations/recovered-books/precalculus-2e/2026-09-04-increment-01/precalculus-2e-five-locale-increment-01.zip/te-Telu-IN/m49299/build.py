"""Build the exact Telugu m49299 translation plus distinct original support."""
from pathlib import Path
import hashlib
import html
import json
import re
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
C='{http://cnx.rice.edu/cnxml}'
D='{http://cnx.rice.edu/mdml}'
ET.register_namespace('',C[1:-1])
ET.register_namespace('md',D[1:-1])
def sha(data):return hashlib.sha256(data).hexdigest()
def esc(value):return html.escape(value,quote=True)

def main():
    raw=(ROOT/'source.cnxml').read_bytes()
    draft=json.loads((ROOT/'translation.json').read_text(encoding='utf-8'))
    assert sha(raw)==draft['source_sha256']
    source=ET.fromstring(raw)
    target=ET.fromstring(raw)
    original_ids=[n.attrib['id'] for n in source.iter() if 'id' in n.attrib]
    target.find(C+'title').text=draft['title']
    target.find(C+'metadata').find(D+'title').text=draft['title']
    target.find('.//'+C+'caption').text=draft['source_caption']
    target.find('.//'+C+'media').set('alt',draft['source_media_alt'])
    for identity,text in draft['paragraphs'].items():
        node=target.find('.//'+C+"para[@id='"+identity+"']")
        assert node is not None and len(node)==0
        node.text=text
    assert [n.attrib['id'] for n in target.iter() if 'id' in n.attrib]==original_ids
    assert [n.tag for n in source.iter()]==[n.tag for n in target.iter()]
    translated=ET.tostring(target,encoding='utf-8',xml_declaration=True)
    (ROOT/'translated.cnxml').write_bytes(translated)
    paragraphs=''.join('<p id="'+identity+'">'+esc(text)+'</p>' for identity,text in draft['paragraphs'].items())
    body=f'''<!doctype html><html lang="te-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(draft['title'])}</title><link rel="stylesheet" href="style.css"></head><body>
<header><p>OpenStax Precalculus 2e · తెలుగు–ఆంగ్ల అభ్యాస మార్గం · m49299</p><h1>{esc(draft['title'])}</h1><p>ఇది ఒక పరిచయ విభాగం మాత్రమే. మొత్తం తెలుగు పుస్తకం ఇంకా పూర్తికాలేదు.</p></header>
<aside class="notice" aria-label="చిత్రం గురించి సంచిక గమనిక">{esc(draft['source_reference_note'])}</aside>
<section data-origin="source-translation"><h2>మూలపాఠ్య అనువాదం</h2>
<figure id="Figure_01_00_001"><p id="fs-id1165137810701">అసలు చిత్రం పునర్ముద్రించబడలేదు. మూల ప్రత్యామ్నాయ వివరణ: {esc(draft['source_media_alt'])}</p><figcaption class="source-caption">{esc(draft['source_caption'])}</figcaption></figure>{paragraphs}</section>
<section id="te-original-schematic" class="adaptation" data-origin="original-adaptation"><h2>{esc(draft['adaptation_title'])}</h2><p>చిన్న తెరపై చిత్రంలో అడ్డంగా స్క్రోల్ చేసి అన్ని లేబుళ్లు చదవవచ్చు. <a href="schematic.svg">చిత్రాన్ని వేరుగా తెరవండి</a>.</p><figure><div class="diagram" tabindex="0" role="region" aria-label="అడ్డంగా స్క్రోల్ చేయగల సంకేత చిత్రం"><img src="schematic.svg" width="820" height="430" alt="{esc(draft['adaptation_alt'])}"></div><figcaption>{esc(draft['adaptation_explanation'])}</figcaption></figure><p>{esc(draft['bridge'])}</p></section>
{(ROOT/'support.html').read_text(encoding='utf-8')}
<footer><p>మూల రచన: Jay Abramson మరియు OpenStax సహరచయితలు, Rice University. మూల వచనం, అనువాదం, వేరుగా గుర్తించిన అదనపు సహాయం: <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC BY-NC-SA 4.0</a>. ఇది స్వతంత్ర అనువాదం; మూల రచయితల ఆమోదం ఉన్నట్లు ప్రకటించడం లేదు.</p><p><a href="README.md">పరిధి, మూలం, మళ్లీ నిర్మించే విధానం</a> · <a href="LICENSE.md">హక్కులు</a> · <a href="TERMINOLOGY.md">పదజాల ఆధారాలు</a></p></footer></body></html>'''
    reader=body.encode('utf-8')
    (ROOT/'reader.html').write_bytes(reader)
    ids=re.findall(r'\bid="([^"]+)"',body)
    assert len(ids)==len(set(ids)) and set(original_ids)<=set(ids)
    assert all(x in draft['paragraphs']['fs-id1165137768418'] for x in ['$100','$500','$1,100','40','1995','2000'])
    assert not re.search(r'\{\{[^}]+\}\}|\ufffd',body)
    assert 480<500 and not 500<500 and not 520<500 and 699<700
    assert ET.fromstring((ROOT/'schematic.svg').read_bytes()).tag.endswith('svg')
    qa={'schema':'a30-te-module-qa/1','module':'m49299','status':'source_text_complete_with_explicit_image_adaptation','source_sha256':sha(raw),'translated_cnxml_sha256':sha(translated),'reader_sha256':sha(reader),'reader_bytes':len(reader),'source_ids_preserved':original_ids,'source_paragraphs':len(draft['paragraphs']),'source_mathml_trees':0,'source_exercises':0,'added_diagnostics':3,'added_rechecks':3,'original_excluded_image':'CNX_Precalc_Figure_01_00_001n.jpg','original_schematic_sha256':sha((ROOT/'schematic.svg').read_bytes()),'next_source_anchor':'m49301','checks':['source byte identity','CNXML element order and source IDs','all stated source numeric anchors','UTF-8 and no unresolved placeholders','diagnostic arithmetic','explicit source/adaptation/answer distinctions'],'visual_check':'separately recorded after targeted inspection; not claimed here','scope':'One introduction, not complete A30'}
    (ROOT/'QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    names=['translation.json','support.html','style.css','README.md','LICENSE.md','TERMINOLOGY.md','TRANSLATION_DECISIONS.md','build.py','source.cnxml','translated.cnxml','schematic.svg','original-component-notice.json','reader.html','QA.json']
    if (ROOT/'VISUAL_QA.json').exists():
        visual=json.loads((ROOT/'VISUAL_QA.json').read_text(encoding='utf-8'))
        assert visual['reader_sha256']==sha(reader), 'Visual review is stale for this reader'
        names.append('VISUAL_QA.json')
    manifest={'schema':'public-files/1','files':[{'path':n,'bytes':(ROOT/n).stat().st_size,'sha256':sha((ROOT/n).read_bytes())} for n in sorted(names)]}
    (ROOT/'PUBLIC_FILES.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(qa,ensure_ascii=False))

if __name__=='__main__':main()
