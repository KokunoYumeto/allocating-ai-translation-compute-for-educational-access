# License and attribution

Original text: OpenStax *Precalculus 2e*, Jay Abramson and contributing authors, copyright Rice University / OpenStax. Source prose, Telugu translation and clearly identified original learning support: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International, https://creativecommons.org/licenses/by-nc-sa/4.0/ . This independent edition is not endorsed by OpenStax or Rice University.

The original composite image `CNX_Precalc_Figure_01_00_001n.jpg` is not included. Original source credits: bull — modification of work by Prayitno Hadinata; graph — modification of work by MeasuringWorth. Those credits do not describe the new schematic. The exact inherited component notice is included.

The separately authored prose-based schematic is reused from the published recovered Precalculus package, commit `d59087b930e43cc31130e59005a2f09f552d11d4`, under CC BY-NC-SA 4.0. This Telugu continuation adds explanation, alternative text and independently authored diagnostic/remediation/recheck questions and answers. It does not supply historical values absent from the source.

Consulted Telugu references are not relicensed or redistributed. The compact terminology observations are commentary, not a full reference-text reproduction. Human source author and contributor credits are preserved; OpenAI Codex gpt-5.6-sol, Ultra assisted the translation workflow.
