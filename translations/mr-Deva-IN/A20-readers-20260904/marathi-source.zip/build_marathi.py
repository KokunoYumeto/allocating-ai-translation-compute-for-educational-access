"""Bounded deterministic reader recovery; original intake is read-only."""
from pathlib import Path
import argparse, base64, hashlib, json, mimetypes, shutil, sys
import xml.etree.ElementTree as ET
sys.path.insert(0,str(Path(__file__).resolve().parent/'runtime'))
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent
INTAKE = ROOT/'source' if (ROOT/'source').exists() else Path('C:/interlanguage-production/laptop-mathematics-review/translations/mr-Deva-IN/workspace/mr-Deva-IN')
OUT = ROOT if (ROOT/'source').exists() else ROOT / 'mr-Deva-IN'
PINNED = {'m81373':'4a47646ee5129394213e7576d23356dbfc603c6a956dcbfaf45d90e3a1fe82fa', 'm81374':'c629adb12dd6381b9d219d783f4af055aa1a8c060a9b36dce3bfcb5a39c1172d'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw if isinstance(raw, bytes) else raw.encode('utf-8'))
def record(path):
    raw=path.read_bytes()
    return {'path':path.relative_to(OUT).as_posix(),'bytes':len(raw),'sha256':sha(raw)}
def copy(relative, expected=None):
    src=(INTAKE/relative).resolve()
    assert src.is_relative_to(INTAKE.resolve()), relative
    raw=src.read_bytes()
    if expected:
        assert sha(raw)==expected['sha256'] and len(raw)==expected['bytes'], relative
    write(OUT/'source'/relative,raw)
    return raw

def main():
    css=(ROOT/'reader.css').read_text('utf-8')
    receipts={}; inputs={}; pages=[]; changes=[]
    for module,pin in PINNED.items():
        unit='A20-'+module
        source=copy('translations/'+unit+'.xml')
        assert sha(source)==pin
        r=json.loads(copy('qa/'+unit+'-assembly-receipt.json'))
        receipts[module]=r
        for path,expected in r['inputs'].items():
            copy(path,expected); inputs[path]=expected
        xml=ET.fromstring(source)
        title=xml.findtext('header/h1')
        ids=[n.get('id') for n in xml.iter() if n.get('id')]
        checks={n.get('data-check'):''.join(n.itertext()) for n in xml.iter() if n.get('data-check')}
        root=BeautifulSoup(ET.tostring(xml,encoding='unicode',method='html'),'html.parser')
        article=root.article
        article['data-status']='recovered-bounded-reader-20260904'
        article.attrs.pop('data-reader-accepted',None)
        framing=article.header.find('p',attrs={'data-kind':'original'})
        previous=framing.get_text()
        framing.string='हा इयत्ता आठवीपासून प्रथम वर्षाच्या STEM अभ्यासाकडे नेणारा मराठी वाचनभाग आहे. येथे मूळ शिकवणी, उदाहरणे, सराव आणि स्रोतात दिलेली उत्तरे जतन केली आहेत. नव्याने जोडलेली उत्तरे, दुरुस्त्या व स्पष्टीकरणे स्वतंत्रपणे चिन्हांकित आहेत. हा दोन विभागांच्या मर्यादित संचातील एक विभाग आहे; संपूर्ण पुस्तकाचा अनुवाद नाही.'
        changes.append({'module':module,'kind':'reader-framing-only','prior_sha256':sha(previous.encode()),'replacement':framing.get_text()})
        for p in article.find_all('p'):
            text=p.get_text()
            if 'वाचकाचे HTML/PDF दृश्य-परीक्षण' in text:
                p.string=text.replace('मातृभाषिक गणित-शिक्षकाचे पुनरावलोकन, वाचकाचे HTML/PDF दृश्य-परीक्षण आणि पूर्ण कार्यप्रवाह-स्वीकृती अद्याप स्वतंत्र आहेत.','शब्दसंग्रहातील तात्पुरते पर्याय स्पष्ट ठेवले आहेत. ही मर्यादित वाचन-आवृत्ती आहे; PDF/UA प्रमाणन किंवा मातृभाषिक तज्ज्ञांचे प्रमाणपत्र असल्याचा दावा नाही.')
        for img in article.find_all('img'):
            ref=img['src']; image_path=(INTAKE/'translations'/ref).resolve()
            assert image_path.is_relative_to(INTAKE.resolve()) and image_path.is_file()
            data=image_path.read_bytes(); mime=mimetypes.guess_type(image_path.name)[0]
            assert mime and mime.startswith('image/') and img.get('alt','').strip()
            img['src']='data:'+mime+';base64,'+base64.b64encode(data).decode('ascii')
            img['data-source-asset']=ref
        for table in article.find_all('table'):
            table.wrap(root.new_tag('div',attrs={'class':'table-scroll','tabindex':'0','role':'region','aria-label':'तक्ता'}))
        nav=root.new_tag('nav',attrs={'aria-label':'विभागातील दुवे'})
        start=root.new_tag('a',href='../index.html'); start.string='वाचनसंच'; nav.append(start)
        for h in article.select('h2'):
            parent=h.find_parent(id=True)
            if parent and (parent.get('data-kind')=='source-context' or parent.get('id') in ('assembly-credits','credits')):
                nav.append(' · '); link=root.new_tag('a',href='#'+parent['id']); link.string=h.get_text(); nav.append(link)
        article.header.append(nav)
        prov=root.new_tag('p',attrs={'class':'edition-note','data-kind':'original'})
        prov.string="2026-09-04: recovered reader edition. OpenAI Codex gpt-5.6-sol, Ultra; Codex, acting on the user's request. Source, author and prior translation credits retained."
        article.append(prov)
        html='<!doctype html>\n<html lang="mr-Deva-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'"><title>'+title+'</title><style>'+css+'</style></head><body>'+str(article)+'</body></html>\n'
        parsed=BeautifulSoup(html,'html.parser')
        assert ids==[n['id'] for n in parsed.select('[id]')]
        assert checks=={n['data-check']:n.get_text() for n in parsed.select('[data-check]')}
        targets=set(ids)
        assert all(a['href'][1:] in targets for a in parsed.select('a[href^="#"]'))
        path=OUT/'reader'/(unit+'.html'); write(path,html)
        pages.append({**record(path),'module':module,'kind':'full-module','source_sha256':pin,'canonical_ids':r['counts']['canonical_ids'],'math_checks':len(checks),'images':len(parsed.select('img'))})
    # Selected smaller units remain optional overlapping study chunks, never extra module credit.
    for number in range(2,23):
        unit=f'MR-BRIDGE-{number:03d}'
        old=INTAKE/'output'/(unit+'.html')
        original=copy('output/'+unit+'.html'); parsed=BeautifulSoup(original,'html.parser')
        old_text=parsed.body.get_text()
        style=parsed.find('style'); assert style
        style.string=css
        for table in parsed.select('table'):
            table.wrap(parsed.new_tag('div',attrs={'class':'table-scroll','tabindex':'0','role':'region','aria-label':'तक्ता'}))
        assert old_text==parsed.body.get_text()
        assert all(im.get('src','').startswith('data:image/') for im in parsed.select('img'))
        path=OUT/'reader'/(unit+'.html'); write(path,str(parsed)+'\n')
        pages.append({**record(path),'kind':'overlapping-study-unit','source_html_sha256':sha(original),'images':len(parsed.select('img'))})
    # Pin only the source assembly tooling and its needed helpers/tests, not broad programme history.
    for name in ('assemble_m81373.py','assemble_m81374.py','build_pdf.py','build_unit.py','freeze_unit.py','build.py','test_assemble_m81373.py','test_assemble_m81374.py','test_m81374_primary_source.py'):
        copy('tools/'+name)
    for name in ('README.md','witnesses.lock.json'):
        copy('canon/'+name)
    copy('terminology.csv')
    copy('provenance/notices/A20-en/LICENSE')
    copy('provenance/notices/A20-id/LICENSE.txt')
    # Original accepted m81373 PDF retained, no re-export or translation change.
    old_pdf=INTAKE/'output/pdf/A20-m81373.pdf'
    write(OUT/'output/pdf/A20-m81373.pdf',copy('output/pdf/A20-m81373.pdf'))
    facts={'schema':'a20-recovered-marathi-build/1','date':'2026-09-04','source_commit':'ed6f2e2020118723c2a12fe3377d2273c3d8ec50','source_modules':['m81373','m81374'],'unique_modules':2,'source_canonical_ids':1991,'source_exercises':339,'source_supplied_answers':196,'new_answers_to_source_omissions_in_recovered_m81373':29,'explicit_source_answer_omissions_in_m81374':114,'additional_credit_for_overlapping_readers':0,'input_files_hash_replayed':len(inputs),'readers':pages,'render_only_changes':changes,'retained_pdf':record(OUT/'output/pdf/A20-m81373.pdf'),'limits':['Not a complete textbook','No PDF/UA or native-teacher certification','Terminology provisional where marked','Historical Indonesian v0.3.0 comparison stays pinned; completed v1.0.0 is not substituted silently']}
    write(OUT/'qa/BUILD.json',json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
    links=''.join('<li><a href="reader/'+p['path'].split('/')[-1]+'">'+p['path'].split('/')[-1].replace('.html','')+'</a></li>' for p in pages if p['kind']=='overlapping-study-unit')
    index='<!doctype html><html lang="mr-Deva-IN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>मराठी बीजगणित वाचनसंच</title><style>'+css+'</style><body><article><h1>मराठी बीजगणित वाचनसंच</h1><p>इयत्ता आठवीपासून प्रथम वर्षाच्या STEM अभ्यासाकडे. OpenStax Intermediate Algebra 2e मधील दोन पूर्ण स्रोत-विभाग; संपूर्ण पुस्तक नाही.</p><h2>मुख्य वाचनक्रम</h2><ol><li>संबंध आणि फलने: <a href="reader/A20-m81373.html">HTML</a> · <a href="output/pdf/A20-m81373.pdf">PDF (64 पाने)</a></li><li>फलनांचे आलेख: <a href="reader/A20-m81374.html">HTML</a> · <a href="output/pdf/A20-m81374.pdf">PDF</a></li></ol><p>मूळ स्रोत-उत्तरे, नव्याने जोडलेली उत्तरे आणि स्रोतात उत्तर नसलेले प्रश्न स्वतंत्रपणे चिन्हांकित आहेत. मूळ चित्रांतील इंग्रजी शब्दांसाठी मराठी वर्णने दिली आहेत.</p><h2>लहान अभ्यासभाग</h2><p>खालील भाग मुख्य विभागांशी आच्छादित आहेत; ते अतिरिक्त अनुवादित विभाग म्हणून मोजलेले नाहीत.</p><ul>'+links+'</ul><h2>स्रोत व पुनर्वापर</h2><p><a href="README.md">व्याप्ती, श्रेय आणि पुढील अभ्यास</a> · <a href="LICENSE">CC BY-NC-SA 4.0 व घटक-परवाने</a> · <a href="SHA256SUMS.txt">SHA-256</a></p><p>पुढील स्रोत: m81375. पाच-पुस्तकांचा विस्तृत अभ्यासक्रम अजून पूर्ण झालेला नाही.</p></article></body></html>\n'
    write(OUT/'index.html',index)
    print(json.dumps({k:facts[k] for k in ('unique_modules','source_canonical_ids','source_exercises','input_files_hash_replayed')},ensure_ascii=False))

if __name__=='__main__': main()
