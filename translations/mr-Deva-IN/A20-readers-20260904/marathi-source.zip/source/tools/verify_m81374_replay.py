"""Two fresh-process PDF replays, source oracle, and font-run regression."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parents[1]
QA = BASE/'qa/recovery'

def h(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args):
    result = subprocess.run([sys.executable, '-X', 'utf8', '-B', *args], cwd=BASE,
                            text=True, encoding='utf8', capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout+'\n'+result.stderr)
    return result.stdout+result.stderr

replays=[]
for _ in range(2):
    run(['tools/build_m81374_pdf.py'])
    replays.append({'pdf_sha256':h(BASE/'output/pdf/A20-m81374.pdf'),
                    'receipt_sha256':h(BASE/'qa/A20-m81374-pdf-build-receipt.json')})
assert replays[0] == replays[1]
font_log = run(['tools/audit_symbol_runs.py'])
source_log = run(['-m','unittest','discover','-s','tools','-p','test_m81374_primary_source.py','-v'])
assert 'Ran 20 tests' in source_log and source_log.rstrip().endswith('OK')
qa_log = run(['tools/qa_m81374_pdf_recovery.py'])
receipt = {'schema':1,'status':'PASS','fresh_process_replays':replays,
           'deterministic_pdf_and_build_receipt':True,'source_oracle_tests':20,
           'mixed_font_shaping_words':0,'font_audit':json.loads(font_log),
           'source_oracle_output':source_log,'automated_qa_sha256':h(QA/'AUTOMATED_QA.json')}
(QA/'REPLAY_QA.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:receipt[k] for k in ['status','fresh_process_replays','source_oracle_tests','mixed_font_shaping_words']},indent=2))
