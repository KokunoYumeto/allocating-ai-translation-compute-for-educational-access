"""Report unsupported mixed-font shaping words before drawing."""
from collections import Counter
import json
import re
import build_m81374_pdf as b

found=[]
original=b.core.ReadingParagraph
class AuditParagraph(original):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        word=[]
        def flush():
            if len({font for text,font in word})>1:
                found.append(word.copy())
            word.clear()
        for frag in self.frags:
            if getattr(frag,'lineBreak',False):
                flush()
            for token in re.findall(r'\s+|\S+',getattr(frag,'text','')):
                if token.isspace():
                    flush()
                else:
                    word.append((token,frag.fontName))
        flush()
b.core.ReadingParagraph=AuditParagraph
b.register_fonts()
story=b.ModuleStory(b.load_inputs())
story.styles=b.module_styles()
story.compose()
print(json.dumps({'mixed_font_words':len(found),'unique_words':list(dict.fromkeys(json.dumps(x,ensure_ascii=False) for x in found))},ensure_ascii=False,indent=2))
assert not found, 'Mixed-font shaping word remains'
