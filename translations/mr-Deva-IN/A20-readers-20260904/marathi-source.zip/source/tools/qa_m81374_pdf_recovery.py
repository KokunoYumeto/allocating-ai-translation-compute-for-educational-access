"""Independent bounded recovery PDF checks and Poppler visual contact sheets."""
from collections import Counter
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

from PIL import Image, ImageDraw
import pdfplumber
import pypdf

BASE = Path(__file__).resolve().parents[1]
PDF = BASE / 'output/pdf/A20-m81374.pdf'
QA = BASE / 'qa/recovery'
TMP = BASE / 'tmp/pdfs/rendered'

def digest(raw):
    return sha256(raw).hexdigest()

def main():
    QA.mkdir(parents=True, exist_ok=True)
    TMP.mkdir(parents=True, exist_ok=True)
    raw = PDF.read_bytes()
    source = (BASE / 'translations/A20-m81374.xml').read_bytes()
    assert digest(source) == 'c629adb12dd6381b9d219d783f4af055aa1a8c060a9b36dce3bfcb5a39c1172d'
    xml = ET.fromstring(source)
    ids = [e.get('id') for e in xml.iter() if e.get('id')]
    reader = pypdf.PdfReader(BytesIO(raw))
    assert set(ids) == set(reader.named_destinations)
    assert reader.attachments['A20-m81374.xml'] == [source]
    assert reader.trailer['/Root']['/Lang'] == 'mr-Deva-IN'
    assert len([e for e in xml.iter() if e.get('class') == 'problem']) == 255
    assert len([e for e in xml.iter() if e.get('class') == 'solution']) == 141
    spans = []
    pages = []
    all_boxes = []
    orphaned_labels = []
    for pageno, page in enumerate(reader.pages, 1):
        content = page.get_contents().get_data()
        text = [bytes.fromhex(s.decode('ascii')).decode('utf-16-be').lstrip('\ufeff')
                for s in re.findall(rb'/ActualText\s*<([0-9A-Fa-f]+)>', content)]
        spans.extend(text)
        assert text, f'Empty body page {pageno}'
        assert all('\ufffd' not in t and '\x00' not in t for t in text)
        if re.fullmatch(r'(?:[ⓐ-ⓗ]|\([a-z]\))', text[-1].strip()):
            orphaned_labels.append(pageno)
        pages.append({'page': pageno, 'actual_text_spans': len(text),
                      'logical_characters': sum(map(len, text))})
    source_checks = [e for e in xml.iter() if e.get('data-check')]
    joined = '\n'.join(spans)
    absent = []
    for e in source_checks:
        needle = re.sub(r'\s+', ' ', ''.join(e.itertext())).strip()
        if needle not in re.sub(r'\s+', ' ', joined):
            absent.append({'id': e.get('data-check'), 'text': needle})
    assert not absent, f'Math strings absent: {absent}'
    assert not orphaned_labels, f'Orphaned subpart labels: {orphaned_labels}'
    import build_m81374_pdf as builder
    render_root = builder.load_inputs()['root']
    logical_surface = re.sub(r'\s+', ' ', joined)
    leaf_count = 0
    for element in render_root.iter():
        if element.tag in builder.LEAVES and all(c.tag in builder.core.INLINE for c in element):
            text = re.sub(r'\s+', ' ', builder.core.logical(element)).strip()
            if text:
                assert text in logical_surface, f'Unrendered leaf: {element.get("id")} {text[:100]}'
                leaf_count += 1
        if element.tag == 'img':
            assert re.sub(r'\s+', ' ', element.get('alt')).strip() in logical_surface
    with pdfplumber.open(PDF) as document:
        for pageno, page in enumerate(document.pages, 1):
            bad = [c for c in page.chars if c['x0'] < 1 or c['x1'] > page.width - 1
                   or c['top'] < 1 or c['bottom'] > page.height - 1]
            assert not bad, f'Off-page glyphs: {pageno}'
            bad_images = [i for i in page.images if i['x0'] < 1 or i['x1'] > page.width - 1
                          or i['top'] < 1 or i['bottom'] > page.height - 1]
            assert not bad_images, f'Off-page image: {pageno}'
            box = {'page': pageno, 'characters': len(page.chars), 'images': len(page.images),
                   'x0': min(c['x0'] for c in page.chars), 'x1': max(c['x1'] for c in page.chars),
                   'top': min(c['top'] for c in page.chars), 'bottom': max(c['bottom'] for c in page.chars)}
            all_boxes.append(box)
            page.close()
    poppler = shutil.which('pdftoppm')
    assert poppler
    subprocess.run([poppler, '-png', '-scale-to', '650', str(PDF), str(TMP/'page')], check=True)
    files = sorted(TMP.glob('page-*.png'))
    assert len(files) == len(reader.pages)
    contacts = []
    for start in range(0, len(files), 16):
        selected = files[start:start+16]
        sheet = Image.new('RGB', (1600, 2352), 'white')
        draw = ImageDraw.Draw(sheet)
        for index, path in enumerate(selected):
            im = Image.open(path).convert('RGB')
            im.thumbnail((380, 548))
            left, top = (index%4)*400+(400-im.width)//2, (index//4)*588+28
            sheet.paste(im, (left, top))
            draw.text(((index%4)*400+10, (index//4)*588+8), f'Page {start+index+1}', fill='black')
        out = QA / f'contact-{start+1:03d}-{start+len(selected):03d}.jpg'
        sheet.save(out, quality=88)
        contacts.append({'path': out.relative_to(BASE).as_posix(), 'sha256': digest(out.read_bytes())})
    build = json.loads((BASE/'qa/A20-m81374-pdf-build-receipt.json').read_text(encoding='utf8'))
    receipt = {'schema': 1, 'status': 'PASS automated; visual inspection recorded separately',
               'source_sha256': digest(source), 'pdf_sha256': digest(raw), 'pdf_bytes': len(raw),
               'pages': len(reader.pages), 'stable_ids': len(ids), 'math_checks_found': len(source_checks),
               'source_exercises': 255, 'source_supplied_answers': 141, 'explicit_omissions': 114,
               'complete_leaf_text_surfaces_checked': leaf_count, 'image_alt_texts_checked': 149,
               'orphaned_subpart_labels': orphaned_labels,
               'actual_text_spans': len(spans), 'figures': sum(b['images'] for b in all_boxes),
               'off_page_glyphs': 0, 'off_page_images': 0, 'pages_checks': pages, 'geometry': all_boxes,
               'fonts': build['fonts'], 'contact_sheets': contacts,
               'python': platform.python_version(), 'pypdf': pypdf.__version__,
               'pdfplumber': pdfplumber.__version__, 'poppler_sha256': digest(Path(poppler).read_bytes()),
               'qa_builder_sha256': digest(Path(__file__).read_bytes())}
    (QA/'AUTOMATED_QA.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps({k:receipt[k] for k in ['status','pages','pdf_sha256','math_checks_found','figures','off_page_glyphs']},indent=2))

if __name__ == '__main__':
    main()
