"""Sanitized, artifact-bound handoff for the independent PDF recovery helper."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform

BASE=Path(__file__).resolve().parents[1]
QA=BASE/'qa/recovery'
def record(relative):
    raw=(BASE/relative).read_bytes()
    return {'path':relative,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(path,obj):
    (BASE/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
receipt=json.loads((BASE/'qa/A20-m81374-pdf-build-receipt.json').read_text(encoding='utf8'))
for binary in receipt['shaping_binaries']:
    binary['path']='dependency:uharfbuzz/'+Path(binary['path']).name
receipt['visual_review']='See qa/recovery/REVIEW.md and qa/recovery/AUTOMATED_QA.json'
receipt['status']='PASS structural, text-coverage, deterministic replay and sampled visual checks'
receipt['not_claimed']=[item for item in receipt['not_claimed'] if 'browser policy' not in item]
receipt['not_claimed'].append('HTML QA is handled separately by the owner, not claimed by this PDF helper')
save('qa/recovery/BUILD_RECEIPT_PUBLIC.json',receipt)
versions={p:importlib.metadata.version(p) for p in ['reportlab','pypdf','Pillow','pdfplumber']}
versions['uharfbuzz']=receipt['uharfbuzz']
save('qa/recovery/DEPENDENCIES.json',{'python':platform.python_version(),'packages':versions,
     'fonts':receipt['fonts'],'shaping_binaries':receipt['shaping_binaries'],
     'note':'Fonts and environment packages are dependencies, not redistribution payload.'})
files=['output/pdf/A20-m81374.pdf','tools/build_m81374_pdf.py','tools/audit_symbol_runs.py',
       'tools/qa_m81374_pdf_recovery.py','tools/verify_m81374_replay.py','tools/seal_m81374_handoff.py',
       'requirements-pdf.txt','qa/recovery/BUILD_RECEIPT_PUBLIC.json','qa/recovery/DEPENDENCIES.json',
       'qa/recovery/REVIEW.md','qa/recovery/AUTOMATED_QA.json','qa/recovery/REPLAY_QA.json']
save('HANDOFF.json',{'schema':1,'task':'Marathi A20:m81374 readable PDF recovery',
    'status':'COMPLETE bounded helper; owner integration/publication remains separate',
    'pdf_pages':178,'learning_content_pages':164,'credits_pages':1,'identity_index_pages':13,
    'source_sha256':receipt['source_sha256'],'pdf_sha256':receipt['pdf_sha256'],
    'source_exercises':255,'source_supplied_answers':141,'explicit_answer_omissions':114,
    'render_fixes':['keep plain subpart labels with next graph','correct mixed-font punctuation runs',
                    'refresh render-only closing status and preserve exact source attachment'],
    'source_or_math_edits':False,'figures':149,'math_checks':685,'named_destinations':1371,
    'fresh_process_replays_identical':True,'source_oracle_tests_passed':20,
    'visual_samples':[1,4,39,50,81,120,149,164,165,178],
    'next_action':'Owner copies these helper changes into existing m81374 closure and integrates final PDF.',
    'required_unchanged_builder_files':[record(f) for f in ['tools/build_pdf.py','tools/build_unit.py',
        'tools/assemble_m81374.py','tools/test_m81374_primary_source.py']],
    'files':[record(f) for f in files]})
print(json.dumps(record('HANDOFF.json'),indent=2))
