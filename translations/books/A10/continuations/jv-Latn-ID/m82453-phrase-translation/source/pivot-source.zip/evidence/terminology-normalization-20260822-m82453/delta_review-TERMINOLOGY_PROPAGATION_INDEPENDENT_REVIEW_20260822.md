# Independent review of terminology propagation — 2026-08-22

## Verdict

**PASS for completeness, isolation, contextual grammar, and semantic
precision.** All 60 old case-aware occurrences of `ekspresi aljabar` are
eliminated in the five reviewed admitted modules, the requested per-module
source-occurrence counts are exact, and no case-insensitive residue remains.
Fifty-eight occurrences now use the natural school-mathematics term `bentuk
aljabar`; the two relation-specific accessibility occurrences identified in
the first review now correctly use `notasi pertidaksamaan` and `persamaan`.
Every changed site was re-inspected in context. No unrelated change occurred.

## Scope and immutable old-byte witness

Only these targets were read:

- `work/translated-modules/m82453/index.cnxml`
- `work/translated-modules/m82455/index.cnxml`
- `work/translated-modules/m82456/index.cnxml`
- `work/translated-modules/m82460/index.cnxml`
- `work/translated-modules/m82461/index.cnxml`

The old-byte witness was the published source package
`publication/zenodo/0.2.0-wip/elementary-algebra-2e-id-ID-0.2.0-wip-source.zip`,
1,010,310 bytes, SHA-256
`3053208401c759af41e5fc31b8380ad63db3bb47b106557a9557acb34e6acdac`.
The sanitized Zenodo receipt records an anonymous byte-for-byte readback pass
for that exact package at DOI `10.5281/zenodo.22061603`. The ZIP CRC test also
passed locally. The five old target hashes below agree with the release
manifest inside that public checkpoint.

## Exact replacement and hash verification

| Module | Old public SHA-256 | Current SHA-256 | Intended replacements | Old/current bytes | Exact transformed-byte identity |
|---|---|---|---:|---:|---|
| `m82453` | `b231469f1fc5231e01c16b0f991e6e7aec228247ef0d88676034fd6623d950df` | `2c0b688d569044b128d589579e9ba7d871a0fb9ac7a670ac6f22d0ef2b66e635` | 29 | 186,275 / 186,219 | PASS |
| `m82455` | `8fc19ef25195fbfa6f1e0b98189e0c92215da446fdf23c54eb82b747d3eb5734` | `8f9c14d949ffc9064f75456dd0168569ed2934a42c4589e78a36c469262a62cd` | 12 | 119,913 / 119,889 | PASS |
| `m82456` | `953b0ced9cf9b32eeef5894997d333973108f9c3240c8afdbd5ea4e3263b0101` | `8bd2e199b0062862a10416cb939a2ce4bde2365b081341bd1f5c2f10e9467473` | 4 | 121,466 / 121,458 | PASS |
| `m82460` | `1d76157dfa51bde7d1e7379034dfd8887133f7218be5b6ec6f31e75bb8c02ec5` | `d50d5882be8ea244e68914070a8a4e1cd2d2533927648a001338e155d3ad0739` | 9 | 166,085 / 166,067 | PASS |
| `m82461` | `99d4f404d3bd55a583fd3a381072a4fc7e098f9226448bebfa0c8b7cf0a0def5` | `65bcf3ab72308630bae922bc572a8e5e4bb82f11a80670a7e47c04b74004a503` | 6 | 284,569 / 284,557 | PASS |

For `m82455`, `m82456`, `m82460`, and `m82461`, applying only these observed
case-preserving mappings to the old UTF-8 text produces the current file byte
for byte:

- `ekspresi aljabar` → `bentuk aljabar`
- `Ekspresi aljabar` → `Bentuk aljabar`
- `Ekspresi Aljabar` → `Bentuk Aljabar`

For `m82453`, applying the two unique context-anchored mappings first, followed
by the same case-preserving normalization for the other 27 occurrences,
produces the current file byte for byte:

- under table `fs-id1170655178120`, `ekspresi aljabar` →
  `notasi pertidaksamaan`
- under table `fs-id1170655090988`, `ekspresi aljabar` → `persamaan`

The aggregate byte decrease is 118 bytes: 58 normalizations shorten the phrase
by two bytes each, the inequality-specific correction adds five bytes, and the
equation-specific correction removes seven bytes. No other byte differs.
`m82453` and `m82461` each already contained one lower-case `bentuk aljabar` in
the old public target; those pre-existing occurrences were not miscounted as
propagation changes. The five current files contain 60 total occurrences of
`bentuk aljabar`: 58 propagated occurrences plus those two pre-existing ones.

## Complete contextual review

All 60 changed occurrences were inspected on their actual XML surface. Their
distribution is:

| Module | Reader text | Accessibility attributes | Total reviewed |
|---|---:|---:|---:|
| `m82453` | 16 (`item` 1, `para` 13, `title` 1, `emphasis` 1) | 13 (`aria-label` 6, `alt` 5, `summary` 2) | 29 |
| `m82455` | 11 (`item` 1, `para` 9, `emphasis` 1) | 1 (`alt` 1) | 12 |
| `m82456` | 4 (`para` 4) | 0 | 4 |
| `m82460` | 0 | 9 (`summary` 6, `alt` 3) | 9 |
| `m82461` | 6 (`para` 4, `emphasis` 2) | 0 | 6 |
| **Total** | **37** | **23** | **60** |

The reader-text uses cover learning objectives and headings, explanations of
algebraic forms and terms, and exercise directions that ask the learner to
translate a phrase into a symbolic algebraic form. The accessibility uses
describe tables, figures, and worked simplifications of such forms. In these
contexts `bentuk aljabar` is the natural Indonesian school-mathematics term and
fits the surrounding syntax without agreement, capitalization, or collocation
damage.

The two refined `m82453` accessibility descriptions are now contextually
correct:

1. Table `fs-id1170655178120` (`aria-label`, current source line 133) now says
   that the “Simbol Pertidaksamaan” column contains `notasi pertidaksamaan`
   such as `a ≠ b`, `a < b`, and `a ≥ b`. This precisely identifies the
   displayed inequality relations.
2. Table `fs-id1170655090988` (`aria-label`, current source line 265) now says
   that the “Persamaan” column contains `persamaan` such as `3 + 5 = 8` and
   `x = 53`. This correctly distinguishes equations containing equality from
   algebraic expressions.

Both replacements are grammatical, natural, and aligned with the objects
enumerated in their respective aria-labels. No other reviewed occurrence
requires a contextual exception.

## Structure, identifiers, mathematics, and references

All five current files are well-formed XML. Old versus current comparisons
passed for the ordered identifier sequence, canonical MathML roots, ordered
reference/asset targets, and the full element/attribute-name skeleton:

| Module | Elements | IDs | MathML roots | Reference/asset targets | All ordered identities exact |
|---|---:|---:|---:|---:|---|
| `m82453` | 5,668 | 1,001 | 409 | 55 | PASS |
| `m82455` | 4,064 | 754 | 329 | 29 | PASS |
| `m82456` | 4,344 | 740 | 317 | 24 | PASS |
| `m82460` | 6,435 | 925 | 480 | 22 | PASS |
| `m82461` | 8,697 | 2,644 | 621 | 64 | PASS |

Because the complete current bytes equal the old public bytes after only the
three case-preserving normalization mappings and the two exact table-specific
mappings above, this also proves that no unrelated reader text, mathematical
notation, ID, hierarchy, exercise, solution, cross-reference, asset path, or
credit changed in this propagation and precision correction.

## Independent conclusion

The focused terminology propagation is complete, reproducible, and isolated.
The two named `m82453` semantic corrections are correct and equally isolated.
It is safe to retain all five current targets; no terminology follow-up remains
from this review.
