# m82455 Source Semantic and Accessibility Audit

Recorded: 2026-08-21T13:01:29+02:00  
Status: source review complete; final target dispositions independently verified

## Authority and bounded closure

- Source: `authority/source/modules/m82455/index.cnxml`
- Bytes: 118,967
- SHA-256:
  `794635f93249017847f2646910d007e9de53b00ee6037133aa5c3edb7c2b88ec`
- XML parses: yes; 4,068 elements; 754 unique IDs; zero duplicate IDs or
  replacement characters.
- Exercises/problems/solutions: 132 / 132 / 93. Every exercise contains one
  problem; all embedded solutions are attached correctly. No supplied-answer
  arithmetic error was found.
- Media: 29 unique directly referenced assets, all present and decodable;
  2,140,993 bytes total.
- Tables: 24; row/column coverage, including spans, is coherent.
- Links/xrefs: none.

## Determined source corrections

1. Media `eip-id1169751035249` has the empty description “The text”; the raster
   says “Substitute 12 for z.” The Indonesian alt must describe that exact text.
2. Media `eip-id1169752818172` misreads the visible expression `20−z` as
   `2Q-Z`; the target description must use `20−z`.
3. Table `eip-id1169752967487` incorrectly describes `2(16)+3(4)+8` as “two
   times 16 squared plus …” and has malformed quotation around `x`; the target
   ARIA must state the displayed substitution exactly.
4. Lists `fs-id1170654239367` and `fs-id1170653881237`, under multiplication
   and division of signed numbers, say only “Product is …”; the rule applies to
   the product or quotient/result.
5. Self-check media `fs-id1170652631573` says “multiple integers”; the raster
   says “multiply integers.”
6. Media `fs-id1171792706468` says “Step five”; the raster says “Step 6.”
7. Solution `fs-id1170654237484` encodes ASCII `-16` inside MathML; normalize
   it to the mathematical minus sign `−` under an exact protected-text exception.
8. The source accessibility prose for media `fs-id1170652629325` has broken
   spacing and quotation (`thisis`, `equation“`, `reads” “`). Media
   `fs-id1170654116877` twice uses the ungrammatical “What are left are …”. The
   Indonesian descriptions must state the visible content cleanly.
9. Minor source copyedits to normalize in translation: “Add inside parenthesis”
   (use the plural concept), doubled spacing in the morning/afternoon problem,
   a missing terminal period in the application-strategy list, and missing
   spaces before circled part labels in `fs-id1170652630251`.
10. Para `fs-id1170654027710` says without qualification that `a·b` means
    adding `a`, `b` times. Repeated
    addition in this form requires a nonnegative whole-number multiplier.
    The target therefore adds the topology-neutral qualifier
    `Jika b bilangan cacah`.

## Preserved interoperability and assembly defects

- Twenty `.jpg` assets are valid JPEG files but their image elements declare
  `image/png`: figures `003a–003c`, `004a–004d`, `005a–005c`, `006a–006c`,
  `007a–007c`, and `008a–008d` (source lines 636, 639–640, 654, 657–658,
  662, 707, 710–711, 758, 761–762, 776, 779–780, 825, 829, 833, 837).
  Preserve source attributes in the localized CNXML; normalize MIME only in a
  systematic derivative-assembly policy unless an exact exception is approved.
- Currency signs are embedded in `<m:mn>` at source lines 1693 (`$28`), 1703
  (`$38`), 1711 (`$49`), and 1722 (`$3600`). Separating currency into MathML
  text/operator tokens would improve semantics but changes topology; preserve
  it unless a later exact exception is deliberately admitted.
- The key-concepts strategy at lines 1221–1227 omits “Read the problem,” even
  though the canonical six-step strategy at lines 1146–1152 includes it. This
  is recorded as an editorial omission requiring a topology-neutral wording
  repair or later explicit topology decision.

## Final target dispositions

- Determined corrections 1–10 are present in the final Indonesian target.
  The missing first strategy step is restored by topology-neutral wording in
  the existing first list item.
- The two English ordinal constructions `4th` are replaced by locale-neutral
  `4` under the exact structural declaration in
  `qa/modules/m82455/STRUCTURAL_EXCEPTIONS.json`.
- Four English MathML function words with no Indonesian token equivalent and
  the ASCII-minus repair are exact, hash-bound protected-text exceptions.
- The 20 inherited MIME declarations, four tables without source
  accessibility attributes, and four currency strings embedded in `mn` remain
  explicitly deferred; no undeclared target structure or attribute was added.
- Independent structural, mathematical, language, and accessibility replays
  on target SHA-256
  `8fc19ef25195fbfa6f1e0b98189e0c92215da446fdf23c54eb82b747d3eb5734`
  report `P1=0`, `P2=0`, and `P3=0`.

## Admission rule

No item above is silently changed in authority. Final target dispositions must
be recorded in `05_CORRECTIONS.csv`; any non-reader attribute or non-`mtext`
MathML delta must be exact and hash-bound. This audit alone does not admit the
translation.
