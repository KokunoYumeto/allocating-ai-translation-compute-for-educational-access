# m82461 Final Admission Review

Boundary: `EA2-B0012-m82461`  
Reviewed: 2026-08-22  
Verdict: **PASS** (`P1=0`, `P2=0`, `P3=0`)

## Frozen identity

- Authority: 284,041 bytes; SHA-256
  `df82cee2f1a278bb88f392572457ee679bc09d108962a9b6c72ba5bb0084655e`.
- Indonesian target: 284,569 bytes; SHA-256
  `99d4f404d3bd55a583fd3a381072a4fc7e098f9226448bebfa0c8b7cf0a0def5`.
- Deterministic builder: 95,250 bytes; SHA-256
  `3649b0af298b0b9f4a27a31f66e27bdf7f3366c792d1460b62aeb6fc7fd784e1`.
- Translation map: 107,758 bytes; SHA-256
  `ba29fb53a377ff655f9c8bcfe29ef2d2bcc6cc95d53159185c9edb2ade64a11b`.
- Machine audit: 1,698 bytes; SHA-256
  `ee86ae5c86567145c081dc2934019257f5cd787d48a06cded379e5fcd9e0230a`.
- Target manifest: 102 bytes; SHA-256
  `6abda06f2e72d8d025037fdcb5f9e616b31c4e48437a7837379f6be21543c868`.
- Structural exception declaration: none required.
- Source semantic audit: 27,737 bytes; SHA-256
  `5f4befeb2f797b384a92b65563a3af0982fffb6c030bd39c1b350ad80f96362d`.
- Terminology/accessibility plan: 33,021 bytes; SHA-256
  `e52f4e2211084d6f030cad8952a219d884bfe552b9306076e94d5e05a3fa0e3c`.
- Independent mathematics review: 12,971 bytes; SHA-256
  `bd04fb767fd607f9c150143d9771771969eb8ea4e62ee08efcb90c3f24e393be`.
- Independent language/accessibility review: 9,808 bytes; SHA-256
  `caeb41fcd635fdcebb91cfb0ccaed9087feaaed876deb7fcb45cbd235a253059`.

Two clean executions of the deterministic builder reproduced the frozen target
byte for byte. A final root audit then reproduced the same target hash and the
same 29 controlled direct numeric-slot differences.

## Structure, mathematics, and assets

The strict auditor and both independent reviewers reconcile all 8,697 source
elements to all 8,697 target elements without a structural exception. All 2,644
IDs retain exact order and uniqueness. The expanded-tag sequence, non-reader
attributes, 11 resolving target-ID references, nine document references, 44
media references, and declared MIME values retain source identity. The target
contains 23 sections, 15 worked examples, 566 exercises/problems, 306 supplied
solutions, 18 tables, four figures, 44 image references, and 20 links.

Independent mathematical review covered every one of the 566 problem
statements and 306 supplied solutions, plus all 260 intentionally unsupplied
problems and all 15 worked examples. It recomputed and reconciled the exact 16
allowed problem/solution numeric differences, four allowed mathematical-symbol
differences, and 29 direct numeric-slot differences. Every difference is bound
to a localized raster transcription or one of the recorded target corrections;
no unclassified quantity, unit, variable, operation, premise, result, or
exercise/solution correspondence remains.

All 621 MathML roots and 5,234 MathML elements retain topology and protected
mathematical content. The 331 `mtext` nodes split exactly into 131 lexical and
200 protected nodes: 111 lexical nodes are translated, 20 are valid
identity-localizations, and all 200 protected nodes retain source values. No
protected-text or protected-attribute exception is needed.

All 44 referenced assets exist, decode as JPEG, total 2,422,030 bytes, and have
ordered asset-manifest SHA-256
`9c19378fb516fb18419df345b313ed4a5e4a4b85646690a944b32ab1fc4a9865`.
The 15 truthful JPEG declarations and 29 inherited PNG declarations over JPEG
bytes remain explicitly recorded. No authority byte or component relationship
was silently changed.

## Language and accessibility

The independent language review inspected all 1,290 planned reader blocks: 44
titles, 1,055 paragraphs, 23 list items, 164 table entries, and four captions.
All 1,233 source text-bearing blocks and all 57 structural empty/media-only
slots were reconciled in order. The target's 1,249 text-bearing blocks and 41
empty blocks differ only because required Indonesian raster fallback text was
added inside existing containers. No active English prose, rejected term,
placeholder, replacement character, or within-surface duplicated-word finding
remains.

Exactly 62 reader-facing attributes are nonempty and localized: 44 `alt`, 14
`aria-label`, and four `summary` values. The 25 English-labelled source rasters
each have a complete Indonesian alt, a matching visible Indonesian
transcription/key, and explicit disclosure that the retained source raster is
English. All 19 notation-only rasters have accurate localized alternatives and
no false source-language disclosure. The protected `8 lbs` and `15 oz` MathML
tokens remain exact as required; expanded generated-reader voicing remains an
assembly obligation, not a target defect.

The target applies and verifies exactly `EA2-C0176` through `EA2-C0199`.
`EA2-C0200` through `EA2-C0203` remain explicit downstream obligations for
empty-block suppression, truthful MIME treatment, localized semantic raster
derivatives, and responsive reflow of cramped math rasters. In particular, the
final readers must replace or reflow non-centered and undersized source-image
layouts so content is centered, width-responsive, uncropped, and readable.

Both independent reviews were rerun against the exact frozen target above and
report no open P1, P2, or P3 finding. This admission establishes a structurally,
mathematically, linguistically, and accessibly reviewed CNXML module. It does
not claim a rendered reader build, full-page visual QA, or publication; those
remain book-level gates.
