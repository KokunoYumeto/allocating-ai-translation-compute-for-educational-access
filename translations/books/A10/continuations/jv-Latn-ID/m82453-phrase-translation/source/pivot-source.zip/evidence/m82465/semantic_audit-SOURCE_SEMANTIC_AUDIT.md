# m82465 Source Semantic Audit

Status: complete read-only pretranslation control. No target module was created, and no source, live ledger, backend, reader, admission, sibling-module, or publication state was changed.

## Scope proof: fail-closed gate passed

The lane's active scope lock maps catalog ID `col31130` to the immutable witness `authority/source/collections/elementary-algebra-2e.collection.xml`. The mapping file `11_SCOPE_LOCK.md` is 1,611 bytes, SHA-256 `218e247b62530dbf218c600bd57bc6785c78968062027fe87d4653c95a422041`; the collection witness is 5,256 bytes, SHA-256 `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72`.

The frozen collection XML itself was parsed under the CollXML namespace and gives:

- title `Elementary Algebra 2e`;
- UUID `55931856-c627-418b-a56f-1dd0007683a8`;
- slug `elementary-algebra-2e`;
- exactly 82 `col:module` nodes;
- exactly 82 unique `document` values (zero duplicate groups);
- ordinal 15 `m82464`, with predecessor `m82463` and successor `m82465`;
- ordinal 16 `m82465`, with predecessor `m82464` and successor `m82467`;
- both nodes in the same direct subcollection, **Solving Linear Equations and Inequalities**.

Thus `m82465` is inside the exact 82-member closure and immediately follows `m82464`. If either witness hash, the count, uniqueness, or adjacency changes, this audit is closed and must not be used.

## Frozen module identity

| Field | Exact value |
|---|---|
| path | `authority/source/modules/m82465/index.cnxml` |
| bytes | 102,020 |
| SHA-256 | `320496fe179611ea5e34e8bbf62a28317385e19a2c8038f304183a9dd5847692` |
| XML root / namespace | `document` / `http://cnx.rice.edu/cnxml` |
| source root `xml:lang` | absent |
| document title | Solve Equations with Variables and Constants on Both Sides |
| metadata content ID | `m82465` |
| metadata title | Solve Equations with Variables and Constants on Both Sides |
| metadata UUID | `0a4b0d7e-4ba8-4238-a334-a318d1fb868f` |
| abstract objectives | 3 |
| parse result | well-formed XML |

## Exhaustive topology and ID inventory

All 548 `id` attributes are nonempty and unique. Every section, paragraph, note, exercise, problem, solution, example, table, list, and media node has an ID; no key structural node in those classes lacks one. Every exercise has exactly one direct problem; none has more than one solution. Every media node has exactly one direct image, a nonempty unique alt, and a nonempty source.

Element counts:

```text
abstract=1  colspec=24  content=1  content-id=1  document=1
emphasis=9  entry=185  example=10  exercise=89  image=83
item=14  label=9  link=1  list=4  math=172  media=83
metadata=1  mfrac=37  mi=235  mn=437  mo=341  mover=2
mrow=144  mspace=1  mtable=1  mtd=24  mtext=4  mtr=4
newline=4  note=22  para=172  problem=89  row=80
section=9  solution=60  span=2  table=9  tbody=9
term=1  tgroup=9  title=22  uuid=1
```

Attribute counts:

```text
alt=83  aria-label=9  bullet-style=1  class=41
colname=24  colnum=24  cols=9  columnalign=14  document=1
effect=9  id=548  list-type=3  mime-type=83
nameend=47  namest=47  number-style=2  src=83
stretchy=4  target-id=1  valign=2  width=1
```

The sole `width` is `m:mspace width="0.2em"`; no image carries a requested display width. All 47 `namest` and 47 `nameend` references resolve to a `colspec` in their own table. There are zero broken table-span references.

### Section tree

| Depth | ID | Title / role | Direct-child outline |
|---:|---|---|---|
| 0 | `fs-id1168343000919` | Solve Equations with Constants on Both Sides | title, 3 prose paras, 2 examples, 4 try notes |
| 0 | `fs-id1168344071798` | Solve Equations with Variables on Both Sides | title, prose, 3 examples, 6 try notes |
| 0 | `fs-id1168344441727` | Solve Equations with Variables and Constants on Both Sides | title, 6 prose paras, 5 examples, 10 try notes, 1 how-to note |
| 0 | `fs-id1168344334793` | Key Concepts | title and one wrapper list |
| 0 | `fs-id1168343059733` | empty title; class `section-exercises` | four titled child sections |
| 1 | `fs-id1168344336037` | Practice Makes Perfect | 52 exercises plus 6 organizer/instruction paras |
| 1 | `fs-id1168344457772` | Everyday Math | 2 exercises |
| 1 | `fs-id1168343054040` | Writing Exercises | 4 exercises |
| 1 | `fs-id1166503588340` | Self Check | 2 paras and 1 media table |

### Reader blocks, lists, and tables

- Notes: 22 total — `be-prepared` 1 (`fs-id1168344623944`), `try` 20, and `howto` 1 (`fs-id1168344162059`, title **Beginning Strategy for Solving Equations with Variables and Constants on Both Sides of the Equation.**).
- Examples: 10, each containing one exercise/problem/solution. Example IDs in source order are `fs-id1168344197880`, `fs-id1168343222232`, `fs-id1168344198560`, `fs-id1168344478005`, `fs-id1168342989172`, `fs-id1168343051441`, `fs-id1168344193073`, `fs-id1168344315853`, `fs-id1168344286844`, `fs-id1168344081026`.
- Lists: 4 — the 3-item abstract objective list; one 5-item enumerated `stepwise` strategy list; one 1-item bulleted Key Concepts wrapper; and its nested 5-item enumerated `stepwise` list.
- Tables: 9, totaling 80 rows, 185 entries, 24 colspecs. Source-order row/media counts are `9/8`, `10/9`, `8/7`, `9/9`, `5/5`, `11/11`, `11/11`, `6/5`, `11/11`. All have empty labels because they are `unnumbered unstyled`; 6 also have `can-break`.
- The five-step Beginning Strategy example is not a CNXML table: its five 750-pixel row slices are five media nodes in sequence. That source topology is assembly debt.
- Class values: `note|be-prepared=1`, `note|try=20`, `note|howto=1`, `list|stepwise=2`, `section|everyday=1`, `section|key-concepts=1`, `section|practice-perfect=1`, `section|section-exercises=1`, `section|writing=1`, `span|token=2`, `term|no-emphasis=1`, `table|unnumbered unstyled=3`, `table|unnumbered unstyled can-break=6`.
- Emphasis effects: 6 bold and 3 italics. These are reader-facing presentation semantics; values must remain structural tokens.

### Links and references

There is one cross-module link, with no literal inline text:
`document="m82460" target-id="fs-id1170654036044"`, in readiness problem
`fs-idm610730592`. `m82460` is a member of the frozen 82-module collection.
The exact frozen witness
`authority/source/modules/m82460/index.cnxml` is 164,724 bytes, SHA-256
`ee089e74a6609868c94808e624d57016de348a791b577458c539c93584bba9a5`,
and contains exactly one element with that target ID (an `example`). The link
therefore resolves in the frozen collection. Preserve both attributes exactly
and recheck assembled-scope resolution before release.

## Formula and solution audit

The 172 MathML blocks divide into 90 in problems, 81 in solutions, and one explanatory `ax=b` block. Twenty-one math blocks contain the 37 fractions. One solution contains a native 4-row `m:mtable`, two `mover` question-over-equals signs, and the single `mspace`; its check for `x=-8` is correct. Two problem formulas use `m:mtext` for unary minus instead of `m:mo` (`fs-id1168343007643`, `fs-id1168343052677`); that semantic repair is proposed as `EA2-C0250`, without changing the displayed equations.

Independent algebra verified all 89 problems. All 60 supplied final answers are correct. The 29 source-unsupplied answers below are QA expectations only and must not be inserted into a translation. Three worked-presentation defects survive despite correct final answers: `EA2-C0243`, `EA2-C0244`, and `EA2-C0245`.

IDs below are `exercise / problem / solution`; `—` means the frozen source supplies no solution.

| # | Surface | IDs | Problem | Frozen source result | Independent check |
|---:|---|---|---|---|---|
| 1 | Prepare | `fs-idm339026640` / `fs-idm610730592` / `fs-idm617570784` | simplify `4y-9+9` | `4y` | correct |
| 2 | Example | `fs-id1168344534035` / `fs-id1168344520817` / `fs-id1168344517582` | `7x+8=-13` | `x=-3` (worked) | correct; table aria is unrelated (`EA2-C0242`) |
| 3 | Try | `fs-id1168344246431` / `fs-id1168344321897` / `fs-id1168344148946` | `3x+4=-8` | `x=-4` | correct |
| 4 | Try | `fs-id1168344301536` / `fs-id1168344309222` / `fs-id1168343007231` | `5a+3=-37` | `a=-8` | correct |
| 5 | Example | `fs-id1168344328456` / `fs-id1168344341915` / `fs-id1168344394992` | `8y-9=31` | `y=5` (worked) | correct |
| 6 | Try | `fs-id1168343140153` / `fs-id1168344525168` / `fs-id1168344475410` | `5y-9=16` | `y=5` | correct |
| 7 | Try | `fs-id1168344287595` / `fs-id1168344148934` / `fs-id1168343139848` | `3m-8=19` | `m=9` | correct |
| 8 | Example | `fs-id1168344187326` / `fs-id1168344208617` / `fs-id1168344282124` | `9x=8x-6` | `x=-6` (worked) | correct |
| 9 | Try | `fs-id1168344313317` / `fs-id1168343238132` / `fs-id1168344592950` | `6n=5n-10` | `n=-10` | correct |
| 10 | Try | `fs-id1168342980814` / `fs-id1168344600408` / `fs-id1168344505212` | `-6c=-7c-1` | `c=-1` | correct |
| 11 | Example | `fs-id1168342968262` / `fs-id1168344198024` / `fs-id1168344363684` | `5y-9=8y` | `y=-3` (worked) | correct |
| 12 | Try | `fs-id1168343003381` / `fs-id1168344156204` / `fs-id1168343054322` | `3p-14=5p` | `p=-7` | correct |
| 13 | Try | `fs-id1168344073172` / `fs-id1168344186237` / `fs-id1168344449054` | `8m+9=5m` | `m=-3` | correct |
| 14 | Example | `fs-id1168343173478` / `fs-id1168344248585` / `fs-id1168344075824` | `12x=-x+26` | `x=2` (worked) | correct; unary minus token debt `EA2-C0250` |
| 15 | Try | `fs-id1168344083027` / `fs-id1168343053622` / `fs-id1168344335736` | `12j=-4j+32` | `j=2` | correct |
| 16 | Try | `fs-id1168344299331` / `fs-id1168343160986` / `fs-id1168344281884` | `8h=-4h+12` | `h=1` | correct |
| 17 | Example | `fs-id1168344186545` / `fs-id1168344198759` / `fs-id1168344082079` | `7x+5=6x+2` | `x=-3` (worked raster) | final answer correct; step-5 raster wrong (`EA2-C0243`) |
| 18 | Try | `fs-id1168344514524` / `fs-id1168343007558` / `fs-id1168344084568` | `12x+8=6x+2` | `x=-1` | correct |
| 19 | Try | `fs-id1168344155151` / `fs-id1168344619809` / `fs-id1168344330594` | `9y+4=7y+12` | `y=4` | correct |
| 20 | Example | `fs-id1168344116235` / `fs-id1168344106681` / `fs-id1168343222622` | `8n-4=-2n+6` | `n=1` (worked) | correct |
| 21 | Try | `fs-id1168344439867` / `fs-id1168344103574` / `fs-id1168343186886` | `8q-5=-4q+7` | `q=1` | correct |
| 22 | Try | `fs-id1168344227238` / `fs-id1168344316999` / `fs-id1168343061173` | `7n-3=n+3` | `n=1` | correct |
| 23 | Example | `fs-id1168344072640` / `fs-id1168343008854` / `fs-id1168344499016` | `7a-3=13a+7` | `a=-5/3` (worked) | correct; parent aria misvoices check (`EA2-C0244`) |
| 24 | Try | `fs-id1168344192020` / `fs-id1168344509721` / `fs-id1168344215124` | `2a-2=6a+18` | `a=-5` | correct |
| 25 | Try | `fs-id1168344298356` / `fs-id1168344302388` / `fs-id1168344441119` | `4k-1=7k+17` | `k=-6` | correct |
| 26 | Example | `fs-id1168344108706` / `fs-id1168342992147` / `fs-id1168344504486` | `(5/4)x+6=(1/4)x-2` | `x=-8` (worked) | correct |
| 27 | Try | `fs-id1168344285089` / `fs-id1168343001184` / `fs-id1168343186830` | `(7/8)x-12=-(1/8)x-2` | `x=10` | correct |
| 28 | Try | `fs-id1168344502608` / `fs-id1168344418796` / `fs-id1168343070407` | `(7/6)y+11=(1/6)y+8` | `y=-3` | correct |
| 29 | Example | `fs-id1168343045501` / `fs-id1168343021370` / `fs-id1168343001168` | `7.8x+4=5.4x-8` | `x=-5` (worked) | final answer correct; check raster uses `-5` (`EA2-C0245`) |
| 30 | Try | `fs-id1168344219079` / `fs-id1168344600521` / `fs-id1168344124234` | `2.8x+12=-1.4x-9` | `x=-5` | correct |
| 31 | Try | `fs-id1168344601791` / `fs-id1168344084648` / `fs-id1168344185777` | `3.6y+8=1.2y-4` | `y=-5` | correct |
| 32 | Practice | `fs-id1168344331185` / `fs-id1168343060009` / — | `9x-3=60` | — | `x=7` |
| 33 | Practice | `fs-id1168344505411` / `fs-id1168344216203` / `fs-id1168344523991` | `12x-8=64` | `x=6` | correct |
| 34 | Practice | `fs-id1168344118249` / `fs-id1168344462653` / — | `14w+5=117` | — | `w=8` |
| 35 | Practice | `fs-id1168344500224` / `fs-id1168344335607` / `fs-id1168344342129` | `15y+7=97` | `y=6` | correct |
| 36 | Practice | `fs-id1168343129283` / `fs-id1168343062211` / — | `2a+8=-28` | — | `a=-18` |
| 37 | Practice | `fs-id1168343069887` / `fs-id1168343003041` / `fs-id1168343064548` | `3m+9=-15` | `m=-8` | correct |
| 38 | Practice | `fs-id1168344199993` / `fs-id1168343070631` / — | `-62=8n-6` | — | `n=-7` |
| 39 | Practice | `fs-id1168344088515` / `fs-id1168344088518` / `fs-id1168343246529` | `-77=9b-5` | `b=-8` | correct |
| 40 | Practice | `fs-id1168343096832` / `fs-id1168343008773` / — | `35=-13y+9` | — | `y=-2` |
| 41 | Practice | `fs-id1168344591658` / `fs-id1168342982413` / `fs-id1168344343443` | `60=-21x-24` | `x=-4` | correct |
| 42 | Practice | `fs-id1168343195077` / `fs-id1168343195079` / — | `-12p-9=9` | — | `p=-3/2` |
| 43 | Practice | `fs-id1168344394658` / `fs-id1168344394660` / `fs-id1168342996704` | `-14q-2=16` | `q=-9/7` | correct |
| 44 | Practice | `fs-id1168344456958` / `fs-id1168342982390` / — | `19z=18z-7` | — | `z=-7` |
| 45 | Practice | `fs-id1168343181576` / `fs-id1168343181579` / `fs-id1168344197923` | `21k=20k-11` | `k=-11` | correct |
| 46 | Practice | `fs-id1168342983872` / `fs-id1168342983875` / — | `9x+36=15x` | — | `x=6` |
| 47 | Practice | `fs-id1168344503668` / `fs-id1168344108850` / `fs-id1168344336692` | `8x+27=11x` | `x=9` | correct |
| 48 | Practice | `fs-id1168344073119` / `fs-id1168344123401` / — | `c=-3c-20` | — | `c=-5` |
| 49 | Practice | `fs-id1168344441056` / `fs-id1168344150072` / `fs-id1168344335742` | `b=-4b-15` | `b=-3` | correct |
| 50 | Practice | `fs-id1168343070072` / `fs-id1168343070074` / — | `9q=44-2q` | — | `q=4` |
| 51 | Practice | `fs-id1168344149599` / `fs-id1168344514968` / `fs-id1168344310432` | `5z=39-8z` | `z=3` | correct |
| 52 | Practice | `fs-id1168344087044` / `fs-id1168344198688` / — | `6y+1/2=5y` | — | `y=-1/2` |
| 53 | Practice | `fs-id1168343190208` / `fs-id1168343190211` / `fs-id1168344294644` | `4x+3/4=3x` | `x=-3/4` | correct |
| 54 | Practice | `fs-id1168343006176` / `fs-id1168343006178` / — | `-18a-8=-22a` | — | `a=2` |
| 55 | Practice | `fs-id1168342982984` / `fs-id1168343008544` / `fs-id1168344503002` | `-11r-8=-7r` | `r=-2` | correct |
| 56 | Practice | `fs-id1168344513016` / `fs-id1168344513019` / — | `8x-15=7x+3` | — | `x=18` |
| 57 | Practice | `fs-id1168344106595` / `fs-id1168344106598` / `fs-id1168343140939` | `6x-17=5x+2` | `x=19` | correct |
| 58 | Practice | `fs-id1168344295452` / `fs-id1168344295454` / — | `26+13d=14d+11` | — | `d=15` |
| 59 | Practice | `fs-id1168343244759` / `fs-id1168343244761` / `fs-id1168344456927` | `21+18f=19f+14` | `f=7` | correct |
| 60 | Practice | `fs-id1168344322185` / `fs-id1168344322187` / — | `2p-1=4p-33` | — | `p=16` |
| 61 | Practice | `fs-id1168344245751` / `fs-id1168344245753` / `fs-id1168343128821` | `12q-5=9q-20` | `q=-5` | correct |
| 62 | Practice | `fs-id1168343008578` / `fs-id1168343052674` / — | `4a+5=-a-40` | — | `a=-9`; unary minus token debt `EA2-C0250` |
| 63 | Practice | `fs-id1168344075297` / `fs-id1168344600260` / `fs-id1168344394371` | `8c+7=-3c-37` | `c=-4` | correct |
| 64 | Practice | `fs-id1168343063978` / `fs-id1168343063980` / — | `5y-30=-5y+30` | — | `y=6` |
| 65 | Practice | `fs-id1168344601946` / `fs-id1168344601949` / `fs-id1168344603333` | `7x-17=-8x+13` | `x=2` | correct |
| 66 | Practice | `fs-id1168344302780` / `fs-id1168344302782` / — | `7s+12=5+4s` | — | `s=-7/3` |
| 67 | Practice | `fs-id1168342981488` / `fs-id1168343175118` / `fs-id1168344311960` | `9p+14=6+4p` | `p=-8/5` | correct |
| 68 | Practice | `fs-id1168344449309` / `fs-id1168344449311` / — | `2z-6=23-z` | — | `z=29/3` |
| 69 | Practice | `fs-id1168344489885` / `fs-id1168343023580` / `fs-id1168343062439` | `3y-4=12-y` | `y=4` | correct |
| 70 | Practice | `fs-id1168344503735` / `fs-id1168344503738` / — | `(5/3)c-3=(2/3)c-16` | — | `c=-13` |
| 71 | Practice | `fs-id1168344312771` / `fs-id1168344312773` / `fs-id1168343060706` | `(7/4)m-7=(3/4)m-13` | `m=-6` | correct |
| 72 | Practice | `fs-id1168344298675` / `fs-id1168344107338` / — | `8-(2/5)q=(3/5)q+6` | — | `q=2` |
| 73 | Practice | `fs-id1168344254586` / `fs-id1168343006879` / `fs-id1168344293240` | `11-(1/5)a=(4/5)a+4` | `a=7` | correct |
| 74 | Practice | `fs-id1168344478053` / `fs-id1168344478055` / — | `(4/3)n+9=(1/3)n-9` | — | `n=-18` |
| 75 | Practice | `fs-id1168344213458` / `fs-id1168344213460` / `fs-id1168344461100` | `(5/4)a+15=(3/4)a-5` | `a=-40` | correct |
| 76 | Practice | `fs-id1168344315747` / `fs-id1168344315749` / — | `(1/4)y+7=(3/4)y-3` | — | `y=20` |
| 77 | Practice | `fs-id1168344149912` / `fs-id1168344149914` / `fs-id1168343061223` | `(3/5)p+2=(4/5)p-1` | `p=15` | correct |
| 78 | Practice | `fs-id1168344315806` / `fs-id1168344082963` / — | `14n+8.25=9n+19.60` | — | `n=2.27` |
| 79 | Practice | `fs-id1168343059637` / `fs-id1168344309965` / `fs-id1168344513330` | `13z+6.45=8z+23.75` | `z=3.46` | correct |
| 80 | Practice | `fs-id1168344440652` / `fs-id1168344440654` / — | `2.4w-100=0.8w+28` | — | `w=80` |
| 81 | Practice | `fs-id1168344317854` / `fs-id1168344317856` / `fs-id1168343046742` | `2.7w-80=1.2w+10` | `w=60` | correct |
| 82 | Practice | `fs-id1168343054509` / `fs-id1168343054511` / — | `5.6r+13.1=3.5r+57.2` | — | `r=21` |
| 83 | Practice | `fs-id1168343051373` / `fs-id1168343051375` / `fs-id1168344249316` | `6.6x-18.9=3.4x+54.7` | `x=23` | correct |
| 84 | Everyday | `fs-id1168344457778` / `fs-id1168344216517` / — | tickets: `6s+27s-45=1506` | — | `s=47`; adult tickets `3s-5=136`; value check `$282+$1224=$1506` |
| 85 | Everyday | `fs-id1168344087365` / `fs-id1168344087367` / `fs-id1168343139775` | fence: `150=2w+30+2w` | `30 feet` | correct; length `45 feet`, perimeter `150 feet` |
| 86 | Writing | `fs-id1168343054046` / `fs-id1168344501755` / — | `(6/5)y-8=(1/5)y+7` with explanations | — | `y=15` |
| 87 | Writing | `fs-id1168344298458` / `fs-id1168344298460` / `fs-id1168343188471` | `10x+14=-2x+38` with explanations | `x=2`; justifications vary | correct |
| 88 | Writing | `fs-id1168344478386` / `fs-id1168344478388` / — | why choose larger coefficient? | — | it usually avoids a negative coefficient; it is convenient, not required |
| 89 | Writing | `fs-id1168344389722` / `fs-id1168343113683` / `fs-id1168344192774` | is `x=-2` a solution of `5-2x=-4x+1`? | Yes; justifications vary | correct: both sides equal `9` |

## Direct asset inventory

The 83 image uses resolve to 83 unique existing files under `authority/source/media`; there are zero missing files and zero duplicate source references. Every file has JPEG `FF D8 FF` signature and reports 150x150 DPI. Sixteen declarations are truthful `image/jpeg`; 67 declare `image/png` despite JPEG bytes and `.jpg` names. Total referenced bytes are 2,237,067, of which 1,677,963 belong to the 67 declaration/signature mismatches.

Dimensions range from 118x39 to 750x205. Seventy-three files are below 40 pixels high, 44 are below 20 pixels high, 77 are below 100 pixels high, and 75 have fewer than 10,000 pixels. One 197x51 asset is 580,996 bytes because embedded profiles dominate it. The canonical inventory digest is SHA-256 `29b3a491955b51d943d86d9b84e7649349de8a472a95eba5067b860d60b233db`, computed over UTF-8 lines joined by LF in the form `ordinal|filename|declared=...|actual=...|bytes=...|px=...|dpi=...|sha256=...`.

| # | File | Declared / actual MIME | Bytes | Pixels | SHA-256 |
|---:|---|---|---:|---:|---|
| 1 | `CNX_ElemAlg_Figure_02_03_001_img_new.jpg` | jpeg / jpeg | 45,839 | 118x39 | `1f7204fa0faf403dd6e934da6e84a5bff1e4021a9f20b9cf81173c420dea372a` |
| 2 | `CNX_ElemAlg_Figure_02_03_002d_img_new.jpg` | png / jpeg | 24,492 | 162x52 | `b7cf443582edec37e14e305d55d00f350c62a686aef165ea8ed5d18b9246da05` |
| 3 | `CNX_ElemAlg_Figure_02_03_002e_img_new.jpg` | png / jpeg | 15,926 | 162x13 | `af39f012dcc392046284d21c969717f9e14e9808debdbd722afc17ed692e7f8e` |
| 4 | `CNX_ElemAlg_Figure_02_03_002f_img_new.jpg` | png / jpeg | 12,749 | 162x13 | `cbf7be3afd2077e3e6eba3450c235e863493399188d9e3d7b68c3351f3cb0ca0` |
| 5 | `CNX_ElemAlg_Figure_02_03_002g_img_new.jpg` | png / jpeg | 15,714 | 162x32 | `31c35ea19e3d6689ff289d858c5117c92cf0811c310a903c831091b1bebee463` |
| 6 | `CNX_ElemAlg_Figure_02_03_002h_img_new.jpg` | png / jpeg | 13,108 | 162x13 | `87496eb50c639531a05cf0c4eb915b738abe8c61de99bef32a13ab3dfe175bd5` |
| 7 | `CNX_ElemAlg_Figure_02_03_002a_img_new.jpg` | png / jpeg | 11,482 | 162x13 | `241b92972492fc32ee429d65bbef47d59f9339145543a946afdae884c3bf6d5a` |
| 8 | `CNX_ElemAlg_Figure_02_03_002b_img_new.jpg` | png / jpeg | 13,969 | 162x23 | `06aad611f4042598138c71c58b51d5e69176fc6749934087ae3f73553503f795` |
| 9 | `CNX_ElemAlg_Figure_02_03_002c_img_new.jpg` | png / jpeg | 16,241 | 162x60 | `7b5790a5e420199b82a2b05f70f763da4f368c9a380894bba7926b40de876ebb` |
| 10 | `CNX_ElemAlg_Figure_02_03_004e_img_new.jpg` | png / jpeg | 21,105 | 164x39 | `b546666dbcbc26953d66b211f2e792527bccaf46e53fd30abac3ca7709ebbb24` |
| 11 | `CNX_ElemAlg_Figure_02_03_004f_img_new.jpg` | png / jpeg | 16,949 | 164x18 | `12e52686f9e0fd3c4ac128085a7c20b3669d08592d15ef830d4ea7af2ad2bbb2` |
| 12 | `CNX_ElemAlg_Figure_02_03_004g_img_new.jpg` | png / jpeg | 13,586 | 164x17 | `013ee603254b9133f5d2defdbd60b16beb4a40f528bf4656aff8d6918cddf28d` |
| 13 | `CNX_ElemAlg_Figure_02_03_004h_img_new.jpg` | png / jpeg | 17,388 | 164x35 | `3dbfb77d858568d96820fcc65c932376234d4c88111146b1a4306615b7c419b8` |
| 14 | `CNX_ElemAlg_Figure_02_03_004i_img_new.jpg` | png / jpeg | 13,726 | 164x17 | `3a8ef87f786a435ef1c7198c58707535cf3a0baff7e24649c9a0c9e1875352af` |
| 15 | `CNX_ElemAlg_Figure_02_03_004a_img_new.jpg` | png / jpeg | 11,356 | 164x17 | `33a52e7e7cfebe043920a527e3f2b5b1b683429edb7c6fd2452b32997d0f82fe` |
| 16 | `CNX_ElemAlg_Figure_02_03_004b_img_new.jpg` | png / jpeg | 12,901 | 164x21 | `7aa547e06608e2a56551449eb34cde30a851d35a8b2c0fa5e2af9590f8cbbb41` |
| 17 | `CNX_ElemAlg_Figure_02_03_004c_img_new.jpg` | png / jpeg | 12,539 | 164x21 | `a082740642ad59ca2bc6d9eac4569081993110d3464e17e6bba6d8f42e4491bf` |
| 18 | `CNX_ElemAlg_Figure_02_03_004d_img_new.jpg` | png / jpeg | 12,656 | 164x13 | `85a1719c1606f7f79e571571f24c1f55445834f09b443ec16359cb6561b05986` |
| 19 | `CNX_ElemAlg_Figure_02_03_006e_img_new.jpg` | png / jpeg | 22,039 | 160x36 | `214d143c3834fd2cf4895420fffd81c666161022de15112aa53468d72cfc0228` |
| 20 | `CNX_ElemAlg_Figure_02_03_006f_img_new.jpg` | png / jpeg | 19,043 | 160x13 | `582566061c1f7c0efedac8e391fc58526453a6fd5bae28605c9742f4138ba142` |
| 21 | `CNX_ElemAlg_Figure_02_03_006g_img_new.jpg` | png / jpeg | 14,607 | 160x13 | `1267d0185672db2a8c7bf709405f96093380e3d852a840dbcfef154362191235` |
| 22 | `CNX_ElemAlg_Figure_02_03_006a_img_new.jpg` | png / jpeg | 12,969 | 160x13 | `42510bda8784f0021d83b96c3fe5260c70edde819817de35922011b570d1aa9c` |
| 23 | `CNX_ElemAlg_Figure_02_03_006b_img_new.jpg` | png / jpeg | 16,282 | 160x23 | `afe5f4c966cda97ad89a182b0baaf4473bd7b7ecdcbc4904dc5a500b681141c1` |
| 24 | `CNX_ElemAlg_Figure_02_03_006c_img_new.jpg` | png / jpeg | 14,887 | 160x21 | `91570265c1745b2030216392ceb7fbaa3ad2793082a13c4b8be0580239a3115a` |
| 25 | `CNX_ElemAlg_Figure_02_03_006d_img_new.jpg` | png / jpeg | 14,322 | 160x13 | `c8612d2f7946892437316e077209be9adf91a485617acd6bafc83a72883d36ad` |
| 26 | `CNX_ElemAlg_Figure_02_03_008e_img_new.jpg` | jpeg / jpeg | 22,946 | 151x36 | `cbf2390a961a08863ee0261f5042dde7d1367985da097f3a9a40e7415c18b973` |
| 27 | `CNX_ElemAlg_Figure_02_03_008f_img_new.jpg` | jpeg / jpeg | 19,210 | 151x18 | `9a73b97ca8285bd3d820588144494443009b35867dd71be6fbddfd8e19aa51a6` |
| 28 | `CNX_ElemAlg_Figure_02_03_008g_img_new.jpg` | jpeg / jpeg | 14,467 | 151x18 | `bb76e52fa07671c391aeadc0a6803e5156b32a49c2e8067585cde23f358dc45d` |
| 29 | `CNX_ElemAlg_Figure_02_03_008h_img_new.jpg` | jpeg / jpeg | 16,998 | 151x35 | `10e8298d78276415b5e08f45736aeaf10ba996fed53bb654c4b6934f2ee607b2` |
| 30 | `CNX_ElemAlg_Figure_02_03_008i_img_new.jpg` | jpeg / jpeg | 14,000 | 151x18 | `6c5fcb00e8b8cd0757a6bc2713a0fdb638273e97ba6d2d82e5ebb5cb03c17ba3` |
| 31 | `CNX_ElemAlg_Figure_02_03_008a_img_new.jpg` | jpeg / jpeg | 15,423 | 130x18 | `2a4597c670aa1e0a127e5c41d09ed75e43c587ff1ce3594d40e1a117627bf529` |
| 32 | `CNX_ElemAlg_Figure_02_03_008b_img_new.jpg` | jpeg / jpeg | 19,033 | 130x25 | `50a7246f392453743253ee87777ac9308c5c2618188cd1c0d71421b6d446d72f` |
| 33 | `CNX_ElemAlg_Figure_02_03_008c_img_new.jpg` | jpeg / jpeg | 16,110 | 130x21 | `4619d66b499da6ab779ec077ef895d96b2ad6f498496073ad61972f7684455a2` |
| 34 | `CNX_ElemAlg_Figure_02_03_008d_img_new.jpg` | jpeg / jpeg | 15,357 | 130x16 | `c1552f5ad7d301bfdff95ef8523aed540e6c93669124d0092fb8a729b76e5afb` |
| 35 | `CNX_ElemAlg_Figure_02_03_009a_img_new.jpg` | png / jpeg | 20,799 | 164x37 | `345dc7712c1cd0016da691ce7c0db14aecb241f34a885bcdaaaf06a0410fb8cf` |
| 36 | `CNX_ElemAlg_Figure_02_03_009b_img_new.jpg` | png / jpeg | 16,475 | 164x14 | `2dc07e884c89356581c495db3e86f8884f4f9656f753c52fc46b8427f6466de0` |
| 37 | `CNX_ElemAlg_Figure_02_03_009c_img_new.jpg` | png / jpeg | 13,497 | 164x14 | `a3b15bad8c7ce42cdbc101c02764dc870bf25bf624b7f303c36edf19a59672ab` |
| 38 | `CNX_ElemAlg_Figure_02_03_009d_img_new.jpg` | png / jpeg | 17,339 | 164x34 | `5fa1aa7a3ed81a9169c04ab25088a38b4c46f71da3f22827e53f7008f1c70561` |
| 39 | `CNX_ElemAlg_Figure_02_03_009e_img_new.jpg` | png / jpeg | 13,022 | 164x13 | `97ccc692cd2a6d66344e14800380e14789fc89df08395029cff3c6a25e31059f` |
| 40 | `CNX_ElemAlg_Figure_02_03_010a_img_new.jpg` | jpeg / jpeg | 61,756 | 750x124 | `2d6d215c85baefab9ec5eac87f0dfd9fa94555d7d93a1d0a6704928d818b306a` |
| 41 | `CNX_ElemAlg_Figure_02_03_010b_img_new.jpg` | jpeg / jpeg | 74,991 | 750x205 | `09cca8efdf5a2a7febf946df4fc514006d3713e7209ca101510181939dd59e50` |
| 42 | `CNX_ElemAlg_Figure_02_03_010c_img_new.jpg` | jpeg / jpeg | 61,909 | 750x122 | `b2270ac4f49e3087d155d6065420a4f57e914831c91e3e17c325138671534c1d` |
| 43 | `CNX_ElemAlg_Figure_02_03_010d_img_new.jpg` | jpeg / jpeg | 51,250 | 750x121 | `b56dde1823cde82c1d3926a6c144e10e35dd33de02682e5fe2eccdf1bea6b5d1` |
| 44 | `CNX_ElemAlg_Figure_02_03_010e_img_new.jpg` | jpeg / jpeg | 39,628 | 750x174 | `53ce8d72111efe7e57b9a623a65317fc419312a90b6e64079d57fe162ac9abcf` |
| 45 | `CNX_ElemAlg_Figure_02_03_011e_img_new.jpg` | png / jpeg | 21,481 | 200x36 | `f7e1c18c119d46333369eda09f08673109020fd2c8ee34ffa864f5d6313bf7f3` |
| 46 | `CNX_ElemAlg_Figure_02_03_011f_img_new.jpg` | png / jpeg | 19,815 | 200x14 | `9dcfdaa051c59ad21f327a5fa386ffe7789ec97e76ec231cc59f13c6a6e38792` |
| 47 | `CNX_ElemAlg_Figure_02_03_011g_img_new.jpg` | png / jpeg | 15,436 | 200x14 | `48223fb9a678870d3d45795a5ce9a8250b51f4315334a91ce78d01c781a7775a` |
| 48 | `CNX_ElemAlg_Figure_02_03_011h_img_new.jpg` | png / jpeg | 18,422 | 200x14 | `da9fb4e337ba12770a8515499af7f03bbf8a443774b05a879d931219c3827800` |
| 49 | `CNX_ElemAlg_Figure_02_03_011i_img_new.jpg` | png / jpeg | 15,922 | 200x13 | `667d3f8fc4b01ba8f1ac00b8b4ebdaca5dc5bd841c5bc3b499029c54e284aebd` |
| 50 | `CNX_ElemAlg_Figure_02_03_011j_img_new.jpg` | png / jpeg | 19,378 | 200x34 | `4be070c5177b4caf3bfdebadccabba2f56ceedab6612a8ca30e60ebb8eeacab9` |
| 51 | `CNX_ElemAlg_Figure_02_03_011k_img_new.jpg` | png / jpeg | 15,656 | 200x13 | `aafadcd7d0c80263e72e43aacbce3a8153c9aff372361d12c30a309c35df1dea` |
| 52 | `CNX_ElemAlg_Figure_02_03_011a_img_new.jpg` | png / jpeg | 16,995 | 200x14 | `210cbb59c3c510a569bb6d38b66dcaf284f3a031a6d4c2f09a6b31c6e42ec9cb` |
| 53 | `CNX_ElemAlg_Figure_02_03_011b_img_new.jpg` | png / jpeg | 18,088 | 200x23 | `2dacb0dec3d230c1cd86dd096e3e39af38cc236b86431518a9a95f43f398098d` |
| 54 | `CNX_ElemAlg_Figure_02_03_011c_img_new.jpg` | png / jpeg | 17,237 | 200x23 | `2dba4ab2aa880b445e7e07dea16021275781b0b18579cd73e7a89a4bd73e3658` |
| 55 | `CNX_ElemAlg_Figure_02_03_011d_img_new.jpg` | png / jpeg | 16,098 | 200x13 | `b4e5c3ba95f61850fcc5690ee120a520490eb60d0b40d6238384d3cf1e6553fd` |
| 56 | `CNX_ElemAlg_Figure_02_03_012e_img_new.jpg` | png / jpeg | 23,649 | 197x37 | `10eecb80eb72f4b5438531cd6344e98d0e78042f1f1e0eba9b07d6a050468543` |
| 57 | `CNX_ElemAlg_Figure_02_03_012f_img_new.jpg` | png / jpeg | 21,096 | 197x15 | `39b2647347e4e342a81e36c28d25acafb331447bfcf988d9460bc77f55fd6362` |
| 58 | `CNX_ElemAlg_Figure_02_03_012g_img_new.jpg` | png / jpeg | 17,328 | 197x14 | `62fca7fd5d0da377e55bbfdb823fd588fa0fe5ff04ad0ae597f03c18c61eb1ac` |
| 59 | `CNX_ElemAlg_Figure_02_03_012h_img_new.jpg` | png / jpeg | 19,668 | 197x14 | `cec2120db4da941811e69ef7a0c95bab0d92b03c86b78b7a9c9f01d9ca9dc0e1` |
| 60 | `CNX_ElemAlg_Figure_02_03_012i_img_new.jpg` | png / jpeg | 17,720 | 197x14 | `dc802b30b224b61d21721e9e1fbba7721f070eee6cd3491bc2cbfe5d43cb0679` |
| 61 | `CNX_ElemAlg_Figure_02_03_012j_img_new.jpg` | png / jpeg | 20,578 | 197x35 | `1a64b153a20532b9bfa19356155f37588f3bb57a6b3059c4a02abe9327c49122` |
| 62 | `CNX_ElemAlg_Figure_02_03_012l_img_new.jpg` | png / jpeg | 19,121 | 197x32 | `90ba0fc0c2fde7074ad954993bc0c873415c019d98e8c36450a11daf0babd8e1` |
| 63 | `CNX_ElemAlg_Figure_02_03_012a_img_new.jpg` | png / jpeg | 15,459 | 197x15 | `0c8efca3bd09b0fde3a52ab87f37d6bdc1b6dd43c4f2e1b7dc8cdc098f3c1e58` |
| 64 | `CNX_ElemAlg_Figure_02_03_012b_img_new.jpg` | png / jpeg | 22,027 | 197x36 | `880a93c8db3bfa42459c50dc1e4fcbdf5ced810d2d3fa19a6bfa6eca9676ee37` |
| 65 | `CNX_ElemAlg_Figure_02_03_012c_img_new.jpg` | png / jpeg | 19,878 | 197x33 | `9f56e67822855237cbd832b311e312fe49485bf123499b793bf9fef98fe33323` |
| 66 | `CNX_ElemAlg_Figure_02_03_012d_img_new.jpg` | png / jpeg | 580,996 | 197x51 | `cfbfdae220fe0a4de38a46706ae789b87cb77564cfcc1ebf7da09563f8f5f5d7` |
| 67 | `CNX_ElemAlg_Figure_02_03_013a_img_new.jpg` | png / jpeg | 22,816 | 235x58 | `38c937443fd3f54676185235b03ceab67aad70d9f7eb339c21240228c9fd7cda` |
| 68 | `CNX_ElemAlg_Figure_02_03_013b_img_new.jpg` | png / jpeg | 22,094 | 235x35 | `f26c3aab4b7d5ef8a04e4fde2b5512b5e956b28a0bb9f4d1aec956c9b8763fc4` |
| 69 | `CNX_ElemAlg_Figure_02_03_013c_img_new.jpg` | png / jpeg | 15,696 | 235x13 | `3acd90690861eb07e3acabc0ce4edab44d305c512347089a39c4915fb4d630a0` |
| 70 | `CNX_ElemAlg_Figure_02_03_013d_img_new.jpg` | png / jpeg | 17,652 | 235x15 | `b31eb48523f09cea5ec8c95c4ecdc82ac5c023457b51c0e51ce800390105028e` |
| 71 | `CNX_ElemAlg_Figure_02_03_013e_img_new.jpg` | png / jpeg | 15,862 | 235x13 | `74e787e4cfe2ec6949850bf88d7419ffb27eb5db146e3f2ec0481fba15a22c38` |
| 72 | `CNX_ElemAlg_Figure_02_03_014e_img_new.jpg` | png / jpeg | 21,580 | 236x37 | `5a574e464b801454b8c2ea1a1dd3666d88207335bf75b654f626f9881dc9bc4c` |
| 73 | `CNX_ElemAlg_Figure_02_03_014f_img_new.jpg` | png / jpeg | 17,357 | 236x15 | `627f9b1886d65f337831f0e51506429053505450a789387231d406399778bce3` |
| 74 | `CNX_ElemAlg_Figure_02_03_014g_img_new.jpg` | png / jpeg | 12,974 | 236x14 | `d81912ba3d72ca6ce778e90cce0989b7349c89ba8ed792b20de841dbaccc7fed` |
| 75 | `CNX_ElemAlg_Figure_02_03_014h_img_new.jpg` | png / jpeg | 15,269 | 236x14 | `f432fff066aebf0bf7ee3dabc0545a7618f7d4c4a30270170eb64443a97f341f` |
| 76 | `CNX_ElemAlg_Figure_02_03_014i_img_new.jpg` | png / jpeg | 13,461 | 236x14 | `6f6839007e6c137c9d2ec26a3f2043c96df07a655bc6ad4bb301f7eebbf0ca21` |
| 77 | `CNX_ElemAlg_Figure_02_03_014j_img_new.jpg` | png / jpeg | 17,339 | 236x35 | `22e5ea2a13d86b6662d795e6a7f238977c98c28395db2d263269af793e95879a` |
| 78 | `CNX_ElemAlg_Figure_02_03_014k_img_new.jpg` | png / jpeg | 13,203 | 236x13 | `fe615bab1d0facc8c0b68044eac6b68aca0865de409470db40291057658d56eb` |
| 79 | `CNX_ElemAlg_Figure_02_03_014a_img_new.jpg` | png / jpeg | 11,265 | 236x13 | `e14d588b8f1eb5d8e1e4efa4185e3829c1a0d7c6a7da36a7e8edf8b61056c793` |
| 80 | `CNX_ElemAlg_Figure_02_03_014b_img_new.jpg` | png / jpeg | 14,658 | 236x16 | `599fe438d22a9f1e0d0371317367ed7dc26f5d5f132d3a04c88cffb9e5158888` |
| 81 | `CNX_ElemAlg_Figure_02_03_014c_img_new.jpg` | png / jpeg | 12,159 | 236x21 | `70e55a051a750e788164b102ac58b5b7d4ab4b6ee3a805814cbbc4cdc90f0f04` |
| 82 | `CNX_ElemAlg_Figure_02_03_014d_img_new.jpg` | png / jpeg | 11,362 | 236x14 | `7dc3871869f7a7e0b8c29c4ebf42e03cdc496f3d6ade99cf2bc73aa8d1407375` |
| 83 | `CNX_ElemAlg_Figure_02_03_201_img_new.jpg` | jpeg / jpeg | 70,187 | 658x172 | `e67a8fbc6db9a8ff2d01ac0e72c5a763b7736d3328317f3d150662c7a427d10b` |

## Reader-facing attribute and raster audit

- All 83 alts are nonempty and distinct; length range is 51–801 characters. All 9 table aria-labels are nonempty.
- Three aria-labels carry material wrong content: the copied fraction problem (`EA2-C0242`), the wrong sign/final numerator in the `a=-5/3` check (`EA2-C0244`), and the wrong `-5` constant in the decimal check (`EA2-C0245`).
- Two individual alts make false color claims: ordinal 58 says white on black although the raster is dark on white; ordinal 69 says white on white although the equation is dark on white (`EA2-C0247`).
- The Beginning Strategy alts incorrectly call the five-step sequence a four-row table and contain `paretheses`; the step-5 alt otherwise states the intended correct math even though its raster is wrong (`EA2-C0248`, `EA2-C0243`).
- The decimal check at ordinal 79 is not merely an alt error: direct visual inspection confirms the source raster itself reads `7.8x+4=5.4x-5`. The next three check rasters return to the correct `-8` and validate `x=-5`.
- Direct visual inspection of ordinal 44 confirms two visible errors: `7x+6=6x+2` and `(-3)+5` without coefficient 7. The later lines `-21+5=-18+2` and `-16=-16` reveal the intended correct substitution.
- The self-check raster and alt faithfully expose the source's malformed English header `No-I don't get it!`. It is a real pixel-level copy defect, not a translation choice.
- Reader-visible English remains inside 16 rasters: ordinals `1, 2, 10, 19, 26, 35, 40, 41, 42, 43, 44, 45, 56, 67, 72, 83`. The first six plus 45, 56, 67, and 72 label variable/constant roles; 40–44 contain the five English strategy steps; 83 is the English self-check.
- Worked-math rasters occupy ordinals `1–39` and `45–82` (77 files). Their tiny intrinsic dimensions are not suitable for page-width scaling, high zoom, narrow-screen reflow, or selectable mathematical content. Native semantic reconstruction is required; enlarging the JPEGs is not remediation.
- Ordinal 66 is 580,996 bytes at 197x51 pixels. Image metadata reports an ICC profile of 557,168 bytes and XMP of 20,755 bytes; this profile bloat is preserved in the frozen source and logged for deterministic derivative handling.

## Exact defect and assembly-debt register

The source remains immutable. Each proposed delta is separately recorded in `PROPOSED_CORRECTIONS.csv`; nothing in this audit authorizes an unlogged repair.

| ID | Priority / locator | Finding | Disposition |
|---|---|---|---|
| `EA2-C0242` | P2 `eip-id1168186226630` | aria describes unrelated `3/8+x=1/2`, not `7x+8=-13` | rebuild narration from actual table |
| `EA2-C0243` | P2 `fs-id1168344149090` | step-5 raster changes `+5` to `+6` and drops coefficient 7 in substitution | reconstruct exact check; align alt |
| `EA2-C0244` | P2 `eip-id1168184909198` | aria drops the minus from `-65/3` and says `-54/3=-54/3` instead of `-44/3=-44/3` | correct accessible arithmetic |
| `EA2-C0245` | P2 `eip-id1168181949822` | raster, alt, and aria say `5.4x-5`; problem is `5.4x-8` | replace exact check equation |
| `EA2-C0246` | P3 `eip-id1168181949602` | visible `Division Propery` typo | copyedit to `Property` |
| `EA2-C0247` | P3 media `eip-id1168184877314`, `eip-id1168186252297` | false or impossible foreground/background claims | remove false visual boilerplate |
| `EA2-C0248` | P3 `fs-id1168344202405` sequence | wrong four-row topology and `paretheses` typo | describe one five-step table accurately |
| `EA2-C0249` | P3 `fs-id1168343160732` | malformed raster/alt header `No-I don't get it!` | correct and localize header |
| `EA2-C0250` | P3 paras `fs-id1168343007643`, `fs-id1168343052677` | unary minus encoded as `m:mtext` | use `m:mo` in derivative MathML |
| `EA2-C0251` | P3 module asset closure | 67 `image/png` declarations point to JPEG streams | make MIME truthful or transcode deterministically |
| `EA2-C0252` | P3 ordinals 1,2,10,19,26,35,40–45,56,67,72,83 | 16 rasters retain English pixels | native localization or disclosed transcription fallback |
| `EA2-C0253` | P3 ordinals 1–39,45–82 | 77 tiny worked-math rasters; 73 below 40px high | responsive semantic reflow |
| `EA2-C0254` | P3 `fs-id1168343160732` | Self Check is a flattened 4x4 raster table | semantic table and accessible controls |
| `EA2-C0255` | P3 `eip-id1168184833975` | 580,996-byte 197x51 JPEG dominated by profiles | native reflow or verified profile stripping in derivative |
| `EA2-C0256` | P3 document root | standalone CNXML lacks `xml:lang` | target root must declare `id-ID` |

## Ledger collision proof

| Exact input | Rows | ID interval | Bytes | SHA-256 |
|---|---:|---|---:|---|
| `04_TERMINOLOGY.csv` | 257 | `EA2-T0001`–`EA2-T0257` | 49,172 | `f8dab6e21c29fbe2cdc636424852dad10c2406da7727c655d4864baf0a4a5c43` |
| `qa/m82463/PROPOSED_TERMINOLOGY.csv` | 35 | `EA2-T0258`–`EA2-T0292` | 9,604 | `bd29ca51c45a349bbfbe57654d16328a32f2aa81e5c9f4cb68546184ec01cc9f` |
| `qa/m82464/PROPOSED_TERMINOLOGY.csv` | 30 | `EA2-T0293`–`EA2-T0322` | 8,622 | `984a33e132193033fa78ef6dad1a38cd1b82ca197e732704c5b849e904383ede` |
| `05_CORRECTIONS.csv` | 205 | `EA2-C0001`–`EA2-C0205` | 113,452 | `46a77741bfac0fb64ff7b0368e37f7f593599edb2d18704a122cbd450348aca2` |
| `qa/m82463/PROPOSED_CORRECTIONS.csv` | 17 | `EA2-C0206`–`EA2-C0222` | 12,216 | `458b1183686964aed6af31b93b2c37fdc0f5988a47a4e66651f4a108871cd8d0` |
| `qa/m82464/PROPOSED_CORRECTIONS.csv` | 19 | `EA2-C0223`–`EA2-C0241` | 13,402 | `5bcc615479918cf695e3cdfe54aa53a5652854f9d1d98802f9d088d27a3f2a9a` |

Across those exact inputs there are zero duplicate terminology IDs and zero duplicate correction IDs. The maximum staged IDs are `EA2-T0322` and `EA2-C0241`; this audit therefore allocates contiguous, collision-free proposal ranges `EA2-T0323`–`EA2-T0354` (32 rows) and `EA2-C0242`–`EA2-C0256` (15 rows).

## Blockers and terminal boundary

This pretranslation audit itself has no blocker: scope, source, math, IDs, media closure, and proposal allocation are complete.

A later target remains blocked from admission or release until all of the following are true:

1. the live/staged ID ledgers are re-read and the proposed ranges remain collision-free;
2. every accepted correction is applied by ID with a recorded source-to-target delta;
3. all 83 alts and 9 aria-labels are translated and the P2 accessibility/math defects are removed;
4. the English and low-resolution rasters are localized/reflowed or have an explicitly approved accessible fallback;
5. `m82460#fs-id1170654036044` resolves in assembled scope;
6. 548 IDs, 89 exercises/problems, 60 supplied solutions, 29 unsupplied solutions, 172 MathML blocks, 83 direct asset associations, and source ordering all survive validation;
7. a separately authorized target/build/admission workflow is run.

No target, live-ledger update, source edit, build, admission, publication, or sibling-content read is part of this control.
