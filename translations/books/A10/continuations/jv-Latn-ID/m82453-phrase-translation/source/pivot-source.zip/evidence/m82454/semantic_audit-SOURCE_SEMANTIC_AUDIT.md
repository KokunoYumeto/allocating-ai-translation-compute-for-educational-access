# m82454 Frozen-Source Semantic Audit

Source: `authority/source/modules/m82454/index.cnxml`  
Bytes: 184,899  
SHA-256: `4483b9df8736598af20287450b89cf367728da04c697f85f1abb64bbeffb092f`  
Scope: frozen-source audit and final target disposition

## Closure

- 5,794 XML elements and 875 unique IDs.
- 10 sections, 16 examples, 32 try notes, 128 exercises/problems, and 88
  solutions. All 48 instructional/example exercises are solved; 80 end
  exercises provide the 40 odd-item solutions and intentionally omit the 40
  even-item solutions. Multipart problem/solution part counts match.
- 7 internal target links, all resolved. Two external URLs were inventoried but
  not opened in this source-only audit.
- 5 figures and 65 unique media/image references; all 65 assets exist and have
  nonempty alt text.
- 32 tables: 23 with `aria-label`, 9 with `summary`; one column-count defect is
  listed below.
- 14 equations and 12 term nodes.
- Checked final numerical results are arithmetically sound except for the
  misleading source statements explicitly listed below.

## Material meaning defects

1. Exercise `fs-id1170655000342`, table `eip-id1169750893702`, near source
   line 199 says “The opposite of −(−6) is 6,” which is false because
   `−(−6)=6` and its opposite is `−6`. The intended worked sentence is “The
   opposite of −6 is 6.”
2. Caption `CNX_ElemAlg_Figure_01_03_009_new/caption`, near line 330, omits
   the first integer and renders essentially “The integers 5 and are 5 units
   away from 0.” The image shows `−5` and `5`; state both.
3. Media `fs-id1169754375291`, asset
   `CNX_ElemAlg_Figure_01_03_008a_img_new.jpg`, visibly says “substitute −8
   for −x,” although the enclosing table correctly substitutes `−8` for `x`.
   The target alt must remain honest until a separately bound derivative
   overlay corrects the bitmap.
4. Paragraph `fs-id1170654928184`, near line 1137, models `−5−3` but says
   adding 0 to 5 leaves 5. It must say that adding 0 to `−5` leaves `−5`.

## Structural and accessibility defects

- Exactly 50 `<image mime-type="image/png">` nodes reference `.jpg` files
  whose signatures are JPEG. The remaining 15 image declarations are correct.
  Record the inherited defect; do not silently normalize it in only one module
  without an explicit systematic policy.
- Table `fs-id1167824767322` has `tgroup cols="2"` but three cells. This is a
  real structural defect, to be corrected only with an explicit documented
  topology/attribute exception.
- Table `eip-id1169750893702` describes both part-a brackets as 10 units; the
  inspected `006a` asset shows 7 and 7.
- Table `eip-id1169754030168` describes `5+(−3)` as negative 5 plus 3 rather
  than 5 plus negative 3.
- Media `eip-id1169749467098` shows `|−(−20)|`, not an outer negative before
  `|−20|`. Media `eip-id1169754130713` shows `−|−14|`; its alt omits the outer
  negative.
- Table `eip-id1169749482384` part-a aria text spills into part b; remove the
  part-b sentences because `fs-id1167824767322` describes that part.
- `fs-id1170655204215` and `fs-id1170655226595` each say two rows by five
  columns although the tables have five rows by two columns.
- Glossary meaning `fs-id1166422694262` says “−a means the opposite of the
  number” and omits `a`.
- Paragraph `fs-id1170655091191` instructs readers to enable Java in a browser.
  It is obsolete and requires separate link/runtime verification before final
  reader admission.
- Four source image descriptions miscount visible counters:
  `eip-id1169754016113` and `eip-id1169754016122` describe seven red counters
  although the assets show eight; `eip-id1169753968375` describes six blue
  counters although the asset shows eight; and `eip-id1169749482408` describes
  five red counters although the asset shows four.
- The two stock-market application paragraphs `fs-id1170655219720` and
  `fs-id1170655232454` call signed daily point changes “closing numbers.” The
  listed signed values and the total-change questions show that these are daily
  changes measured at the close, not index closing levels.

## Consistency and copyediting corrections

- Normalize four mathematical en dashes to the true minus sign: one near line
  198, two in `fs-id1170654936713`, and one in `fs-id1170655121542`.
- Definitions `fs-id1170655000824` and `fs-id1166422694262` say an opposite is
  on the opposite side of zero, omitting zero. Add that zero is its own
  opposite.
- Solution `fs-id1170655355458` / paragraph `fs-id1170655355460` phrases the
  weekly total as “32, negative”; state `−32; negative` unambiguously.
- Copy errors: `fs-id1170655201463` (“ticks marks,” “at points”);
  `eip-id1169750893702` (“a ,” and “is is”); `fs-id1170654920902` missing a
  post-period space; `eip-id1169752110168` (“partenthesis” and missing space);
  `fs-id1166424759040` unmatched closing quote; `fs-id1170655040356`
  (“labled”); `eip-id1169752192784` and `eip-id1169754361484` (“3equals”);
  `eip-id1169749482384` malformed `reads,”Take` punctuation/spacing.
- `fs-id1170654982815` says the counter model covers addition and subtraction
  “of negatives,” although the section models both positive and negative
  integers. `fs-id1170654962468` and `fs-id1166424866338` contain malformed
  counter-removal conditionals; the latter must explicitly direct the reader
  to add neutral pairs when too few counters are available.

## Canonical id-ID choices

`negative numbers` → `bilangan negatif`; `number line` → `garis bilangan`;
`opposite` → `lawan (bilangan)`, never `kebalikan`; `integers` → `bilangan
bulat`; `whole numbers` → `bilangan cacah`; `counting numbers` → `bilangan
asli`; `absolute value` → `nilai mutlak`; `neutral pair` → `pasangan netral`;
`subtraction property` → `sifat pengurangan`; `positive/negative counter` →
`keping positif/negatif`. Distinguish `tanda negatif`, `tanda kurang`, and
`lawan dari`; use `sederhanakan` for simplify and `tentukan nilainya` for
evaluate.

## Final target disposition

The admitted target is 171,565 bytes, SHA-256
`dcfecfa37b1b6b77d826c16612cc14dfe127dea5720cb6cc0d71029b65f73c40`.
Every issue above is corrected in reader-facing Indonesian except the 50
inherited JPEG/`image/png` declaration mismatches, which remain source-exact
and are explicitly deferred to derivative assembly. The obsolete Java links
are retained with a truthful legacy-browser caveat rather than being claimed
operational. The bad `008a` bitmap is corrected by a separately hashed
derivative overlay. The three-cell table now declares `cols="3"` under one
hash-bound protected-attribute exception. The caption and three en-dash minus
repairs are the only four protected non-`mtext` mathematical token changes.
