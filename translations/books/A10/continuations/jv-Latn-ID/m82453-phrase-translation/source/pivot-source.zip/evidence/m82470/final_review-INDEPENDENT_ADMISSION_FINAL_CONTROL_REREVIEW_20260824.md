# Independent Final Admission-Control Rereview — m82470 — 2026-08-24

## Verdict and independence

**PASS.** The unchanged OpenStax *Elementary Algebra 2e* m82470 sixth candidate passes this fresh, complete, independent final admission-control rereview with **P1=0, P2=0, P3=0, and unresolved=0**. I am not the candidate builder, either content reviewer, or the admission-control author. I independently rehashed the live evidence, read the repaired control implementation and reports, reproduced the exception surface from the bound XML, executed the read-only control checks, and reran the adversarial suite before reaching this verdict.

This report **supersedes** the rejected `qa/m82470/INDEPENDENT_ADMISSION_FINAL_REVIEW_20260824.md`, 13,353 bytes, SHA-256 `7c90dd7384ac59d8857e8f40b16d3b5d7de4e86fc3e5fa277209d5414eb70467`. That old final report is not evidence for this verdict. Its control boundary was invalid because the old exception preparer omitted seven source U+200B-to-empty target MathML `mtext` allowances. The candidate itself did not change.

## Exact candidate and review bindings

| Role | Path | Bytes | SHA-256 |
|---|---|---:|---|
| Frozen source | `authority/source/modules/m82470/index.cnxml` | 280,643 | `e0c457e6b1fb1da6d93a1ffca68347b7afb1bd73683ed9575a10672b4aef13c9` |
| Live unadmitted target | `work/translated-modules/m82470/index.cnxml` | 238,245 | `9397da714e6d4925d60d2dc8b4a7b0b9c6d3e69b69671bfb6684a6797187001b` |
| Candidate builder | `qa/m82470/build_m82470_candidate.py` | 159,510 | `e5de4de89abb19c797b05d6427ac827de7cafdf95b71e684eb2d2ba3dbb1eae8` |
| Construction map | `qa/m82470/CANDIDATE_CONSTRUCTION_MAP.json` | 18,075 | `9f2231dd170d9e332aeb66cea4dd669d15b0cfbe368971ad8a1963281582b411` |
| Mathematics sixth review | `qa/m82470/INDEPENDENT_MATHEMATICS_SIXTH_REVIEW_20260824.md` | 10,788 | `996cd851e2cf062cb1014c0cd0029744284825edcc49e33522706ac65b810ab4` |
| Language/accessibility sixth review | `qa/m82470/INDEPENDENT_LANGUAGE_ACCESSIBILITY_SIXTH_REVIEW_20260824.md` | 14,461 | `3e2fb4202d89c113281a9b84606abfcc77474af954e2aca2c1476b64b45f84a9` |

The map parses as `ea2.m82470.candidate_construction_map` version `1.5.0`, has status `unadmitted_fifth_repaired_successor_ready_for_independent_review`, has no admission object, and records all 24 corrections `EA2-C0304` through `EA2-C0327` as applied and validated in the unadmitted candidate.

The live candidate differs from the last rejected content candidate `qa/m82470/rejected_155fa7d1/index.cnxml` at exactly two primitive surfaces: direct paragraph text `Gunakan rumus. ` becomes `Gunakan rumus ` at owners `fs-id1168345439695` and `fs-id1168341926220`. Element names, attributes, MathML, children, tails, and all other primitive surfaces are unchanged. This confirms that the candidate reviewed by both sixth content reviewers is the exact candidate bound here.

## Rejected control boundary and repaired controls

The failed control run is preserved by rejected-control manifest `qa/m82470/rejected_control_50db4d5e/MANIFEST.json`, 2,543 bytes, SHA-256 `15e3d89831cbda8c73e7517205a2ed8fe0ea8baaeb8f9b5e535044c06aaef060`. I independently verified its exact ordered inventory of seven payloads and aggregate 118,408 bytes, including the old final report above. Its status is `permanently_rejected_incomplete_protected_text_allowances`, its candidate hash is the unchanged live target hash, `admission_performed` is false, and its recorded failure is `RuntimeError: MathML mtext emptied in m82470 at node 1419`.

The repaired control surface rehashes as follows:

| Role | Path | Bytes | SHA-256 |
|---|---|---:|---|
| Common verifier | `scripts/m82470_admission_common.py` | 92,252 | `672141c76be9dfc2badff6cb11679f531875e44899ba1dda8067126a1856c640` |
| Repaired preparer | `scripts/prepare_m82470_structural_exceptions.py` | 14,660 | `c486f3c1b7962d8f637957ea7fcbffcc21355314b503817e01ecd2b11aafd6a8` |
| Admission-evidence finalizer | `scripts/finalize_m82470_admission_evidence.py` | 5,090 | `e93428172af769829585bc97bbc2be537dde5887360777cb7dd5fbd568bfbebb` |
| Ledger admission script | `scripts/admit_m82470_ledgers.py` | 20,802 | `f542d90cbc3a97e8789905f9f790116251f719849b13eb1cbd7fb0bd38c11742` |
| Registry script | `scripts/register_m82470_translation_input.py` | 5,239 | `0eb50632374cf9134a59e84b655e63696fbb0b479315c18ba3ecccd12d766b1c` |
| Binding creator | `scripts/create_m82470_admission_bindings.py` | 2,090 | `4fbcddd0c281e7776700145bc7b2eb39e9fdc1064221eeb4c1965033649a81c7` |
| Binding template | `qa/m82470/ADMISSION_BINDINGS_TEMPLATE.json` | 6,423 | `7c9a7c7570432a828e5f49e93515c9da0edd2e74dd49cb450805b535d5fed585` |
| Adversarial tests | `qa/m82470/test_m82470_admission_hardening.py` | 30,843 | `4fdef91a98e9ab0c0656d3d24558ddbc3416ce2d24c9f8519e81bf689bced189` |
| Superseding hardening report | `qa/m82470/ADMISSION_CONTROL_HARDENING_20260824.md` | 11,148 | `a57221696909e06225dba2e5a36ddb762c6c799a430dc6c51b8a39a9b69faba8` |
| Fixed exceptions | `qa/modules/m82470/STRUCTURAL_EXCEPTIONS.json` | 38,189 | `e3d209cbed6482a193028b38874d44bbe4b343e03a8f5c82599e38faaf2d7c97` |
| Generic audit | `qa/modules/m82470/TRANSLATION_AUDIT.json` | 2,756 | `66bca9cde94fbbb75990bc49436e3d4f32cba2fb0dc791de6db00a2472e8bf17` |
| Target manifest | `qa/modules/m82470/TARGET_MANIFEST.csv` | 102 | `4c524d823fce53632af17c8d996bb742527d2d5f6be09ea6c3d607cf39d8800f` |

The common verifier now permanently binds the rejected-control packet and rejects both the old final-review path and SHA. It requires exception schema `1.1.0`, the exact 1 structural / 86 protected-attribute / 1 attribute-presence / 9 protected-text-record surface, a protected-text count of 10, the exact generic-audit and target-manifest identities, and a distinct fresh final-review identity. The finalizer consumes the verified structural exceptions and requires the real generic audit to have used all ten text allowances before it can produce any admission receipt.

## Independent XML-delta reproduction

I parsed the exact source and target with entity resolution and network access disabled. I normalized only the registered EA2-C0305 structural replacement by substituting the target's bound fourth MathML fragment at owner `fs-id1168345445955` into a working copy of the source while preserving its tail. After that normalization:

- source and target each have 6,936 ordered elements and the same ordered QName topology;
- there are exactly 86 protected attribute changes, one root `xml:lang="id-ID"` presence addition, and three distinct local SVG `src` replacements;
- protected mathematical text has exactly ten occurrences aggregated into nine records;
- seven source U+200B `mtext` values become empty target values at node indices 1419, 1420, 1490, 1581, 2327, 2435, and 3601, aggregated as six keys because indices 1419 and 1420 share owner `fs-id1168345284577`;
- the remaining three protected text changes are node 2706 `mo` `>` to `<` (EA2-C0304), node 5805 `mi` `D` to `d` (EA2-C0320), and node 6812 `mn` `4` to `−4` (EA2-C0305).

Running the repaired preparer's `build_exception_data` in memory against the frozen rejected binding reproduced the live fixed exceptions byte-for-byte: 38,189 bytes and SHA-256 `e3d209cbed6482a193028b38874d44bbe4b343e03a8f5c82599e38faaf2d7c97`. The result has six U+200B records representing seven occurrences, three non-`mtext` records, nine records total, and count 10. Removing an allowance or drifting its owner makes the real generic comparison fail at the emptied MathML `mtext`, so this surface is fail-closed rather than a cardinality-only bypass.

## Generic audit and candidate semantics

I preserved the bound audit bytes and did not rerun its writing mode. The immutable generic audit reports `structural_pass` and `protected_text_exceptions_applied` = 10. Its other independently reproduced values are 86 protected-attribute exceptions, one protected-attribute-presence exception, 6,936 elements, 1,537 IDs, 4,372 MathML nodes, 204 translated accessibility attributes, and 185 image references. Its source/target descriptors, fixed-exception path, and target manifest all match the exact bindings above. A separate read-only call to the generic auditor's `compare_module` reproduced those control counts.

The bound builder's read-only `validate(source_root, target_root)` passes. It reports equal source/target inventories and ordered IDs/link bindings, protected mathematics equal outside the registered overlays, zero empty accessibility values, zero bounded English residue, 182 JPEG plus three SVG references, and all 24 correction assertions true.

I separately verified the high-risk repairs:

- EA2-C0325 changes only owner `fs-id1168345667902` from the wrong source JPEG to `assets/EA2-C0325_all_real_numbers.svg` with MIME `image/svg+xml`. The problem reduces to `0 < 3/5`, so all real numbers and interval `(−∞, ∞)` are correct. The SVG is 2,783 bytes, SHA-256 `5cab3afbb33159d0877d0553a416e848cf662587b79e98ba63b9a0b5f7b92d97`, and its 1200×500 viewBox, title, and description express that result.
- EA2-C0326 preserves the retained JPEG while owner `eip-id1168463870368` has the exact Indonesian alternative for `x < 2.5`: excluded endpoint at 2.5 and a ray to the left.
- EA2-C0327 preserves both `d=rt` MathML formulas and repairs the two surrounding prompts to continuous `Gunakan rumus d=rt untuk menentukan ...` text at owners `fs-id1168345439695` and `fs-id1168341926220`.
- The other two corrected SVGs are independently bound: `EA2-C0306_x_ge_neg1.svg`, 2,423 bytes, SHA-256 `0f1a0b43d7f46d368e2017afa492fad80aebd8d4ec61b138d39b07499b729e10`, shows `x ≥ −1`; `EA2-C0307_k_le_7.svg`, 1,495 bytes, SHA-256 `a735fdfebf49ba736c9ebf926d5562b51acdfe3615e9c315dc8dd89adfa4430d`, shows `k ≤ 7`.

## Rejected candidate packets

All five prior candidate packets were independently verified against their exact manifests, ordered payload inventories, candidate bytes, unchanged assets/evidence, and aggregate byte counts:

| Packet | Manifest SHA-256 | Files | Aggregate bytes | Candidate SHA-256 |
|---|---|---:|---:|---|
| `rejected_621ecf1e` | `2a4777fa5e9bd6eda35e7a543072e2155c3dc62c042f66bbbb5366ed8af8e04f` | 6 | 353,120 | `621ecf1e9434ee52173afb8b2888bb12967055d7f544b773cba9a78c68581938` |
| `rejected_2e799b86` | `1081adf99b104a860dfade5cdb86ed165281b75a12e38686032af9ded0508a76` | 7 | 392,277 | `2e799b868f377ef1dbf7c191f218af5f1ec0b39e963670f36bf0aaae5cbdfe6a` |
| `rejected_5825a8bc` | `a601e80686a8821f3832d4b55715171e8360bd591a31bc286bdf01d7870f0df8` | 8 | 422,470 | `5825a8bc791d025bea6c70547ec4a6e52035a4f15a83c32a5e1fc9bcb5f07e38` |
| `rejected_ef9a1254` | `d3196bc3460c6c784d21f47d601703dc0c1033ec2fe4cf3b6cb4fb57f444fdf7` | 8 | 431,705 | `ef9a1254030ba1c682fcd156652681ef5ffe340343b8ee259156427a24f9cbdb` |
| `rejected_155fa7d1` | `843519b8c120de4cd37ae107db22c30597be7625f265f2f3a49d5e6237dcc7f6` | 16 | 592,291 | `155fa7d1fa2701c984854f61e5852902364a61f6c178a77c2a7b8a30c03c7cef` |

Every rejected candidate hash remains in the admission denylist. Exact manifest tampering, missing packets, unsafe or duplicate payload names, altered inventories, and fail-open construction-map states are rejected.

## Review receipts, parser hardening, and adversarial execution

Both fresh content reports were read in full and independently descriptor-verified. Each contains exactly one canonical receipt, complete module scope, distinct reviewer identity, `independent: true`, exact embedded source/target/builder/map descriptors, `coverage_complete: true`, result `pass`, and integer zero values for all four finding fields. The mathematics identity is `codex-m82470-mathematics-sixth-20260824`; the language/accessibility identity is `codex-m82470-language-accessibility-sixth-20260824`. Neither report relies on the rejected old final-control receipt.

The receipt parser requires UTF-8, exactly one marker pair, duplicate-key-free JSON, an exact 17-key receipt set, the exact evidence descriptors, Boolean independence, and true integer zeros rather than Boolean lookalikes. Direct probes rejected duplicate JSON keys, parent-path escape, backslash paths, the lane root as a descriptor, and Boolean descriptor byte counts. Review paths must remain inside `qa/m82470`, cannot be in a rejected directory, and cannot use any known rejected path or hash.

Exact-file `py_compile` passed for the common verifier, repaired preparer, finalizer, ledger script, registry script, binding creator, and adversarial test module. The full bounded suite then passed **16/16** tests. It covered the live construction chain and all rejection packets; fail-open map mutations; synthetic complete bindings and canonical receipts; rejected hashes and the rejected-control boundary; duplicate JSON and forged review claims; exact pre-boundary byte tampering; ledger prefix/tail projections; injected multi-file write failure rollback; interrupted and committed transaction recovery; EA2-C0325/C0326/C0327 drift; and missing or owner-drifted U+200B allowances.

## Exact pre-admission boundary and no-mutation result

The pre-admission boundary still matches exactly:

| Surface | Rows/blocks and tail | Bytes | SHA-256 |
|---|---|---:|---|
| `04_TERMINOLOGY.csv` | 402 rows; `EA2-T0402` | 89,897 | `0f7f6b3bcbe689db67111b4189b25216e5e7e2ab5f2c64382894ddd6b371b3c1` |
| `05_CORRECTIONS.csv` | 303 rows; `EA2-C0303` | 180,631 | `f1d4f0d9a846dbfe1899b6b12ade506f676f6d62a9f6e09683bf986c1df10afb` |
| `06_QA_BUILD_LEDGER.csv` | 48 rows; `EA2-QA0048` | 22,037 | `f4d381dd8ded7328e3b4a4b105f71302f8a9d2111c66372dbf8398f0fe7ccd37` |
| `backend/registry/translation-inputs.json` | 17 blocks; `m82469` | 57,147 | `01fe9d731eb990786b7a13fb38401cfe43b2d847b90b490e4575add2cd9e6a60` |

The registry contains zero `m82470` blocks. The live binding, translation-admission receipt, ledger-admission receipt, registry-admission receipt, ledger transaction journal, m82470 milestone directory, and all six ledger transaction sidecars are absent. This rereview did not run the preparer in writing mode, create `ADMISSION_BINDINGS.json`, finalize admission evidence, admit ledgers, register the backend, build a reader, or mutate source, target, builder, construction map, reviews, ledgers, registry, or publication state.

## Final finding totals

- P1=0
- P2=0
- P3=0
- unresolved=0
- Coverage: complete m82470 module and complete repaired admission-control boundary
- Result: PASS

<!-- BEGIN EA2_M82470_ADMISSION_REVIEW_RECEIPT -->
{
  "schema": "ea2.m82470.admission_review_receipt",
  "schema_version": "1.0.0",
  "module_id": "m82470",
  "review_type": "final_review",
  "scope": "complete_m82470_module",
  "coverage_complete": true,
  "result": "pass",
  "p1": 0,
  "p2": 0,
  "p3": 0,
  "unresolved": 0,
  "source": {
    "path": "authority/source/modules/m82470/index.cnxml",
    "bytes": 280643,
    "sha256": "e0c457e6b1fb1da6d93a1ffca68347b7afb1bd73683ed9575a10672b4aef13c9"
  },
  "target": {
    "path": "work/translated-modules/m82470/index.cnxml",
    "bytes": 238245,
    "sha256": "9397da714e6d4925d60d2dc8b4a7b0b9c6d3e69b69671bfb6684a6797187001b"
  },
  "builder": {
    "path": "qa/m82470/build_m82470_candidate.py",
    "bytes": 159510,
    "sha256": "e5de4de89abb19c797b05d6427ac827de7cafdf95b71e684eb2d2ba3dbb1eae8"
  },
  "construction_map": {
    "path": "qa/m82470/CANDIDATE_CONSTRUCTION_MAP.json",
    "bytes": 18075,
    "sha256": "9f2231dd170d9e332aeb66cea4dd669d15b0cfbe368971ad8a1963281582b411"
  },
  "reviewer": {
    "identity": "codex-m82470-final-admission-control-rereview-20260824",
    "independent": true
  },
  "model": "OpenAI Codex gpt-5.6-sol, Ultra"
}
<!-- END EA2_M82470_ADMISSION_REVIEW_RECEIPT -->
