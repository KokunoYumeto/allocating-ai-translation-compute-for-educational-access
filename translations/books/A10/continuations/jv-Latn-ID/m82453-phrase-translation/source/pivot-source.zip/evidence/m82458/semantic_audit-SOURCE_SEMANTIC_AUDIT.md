# m82458 Source Semantic and Accessibility Audit

Recorded: 2026-08-21  
Status: source review complete; target dispositions pending final review

## Authority and bounded closure

- Source: `authority/source/modules/m82458/index.cnxml`
- Bytes: 130,960
- SHA-256:
  `678dc0c3ae2aad0192c0314395541720d6c6eb97f56d2f4d169f056fe1e630cb`
- XML parses: yes; 2,989 elements; 1,013 unique IDs; zero duplicate IDs.
- Structural inventory: 11 sections, 17 examples, 179 exercises, 179
  problems, 115 supplied solutions, 22 tables, 49 media, 182 MathML
  expression roots / 1,293 MathML elements, and 2 local links.
- Every exercise has exactly one problem. The 64 exercises without a supplied
  solution are the intentional unkeyed members of the practice/writing sets.
- Both local links resolve: `CNX_ElemAlg_Figure_01_07_001_new` and
  `fs-id1170655126266`.
- All 49 directly referenced media are present, unique, decodable JPEG files;
  total media bytes: 3,002,999.
- Ordered closure-manifest SHA-256:
  `189e04c9cd3fa0075018bfba608a7db4264fc73e8381d61111cdf3cfd4a21a11`.
  The manifest input is one UTF-8 line per image in CNXML order:
  `relative-ref<TAB>byte-count<TAB>sha256<LF>`.
- Ordered raw-media-concatenation SHA-256:
  `be51f51905f6824f67ad714ad07489f1386f9ba4c588d577582866d5d308fcf6`.

## Supplied-solution review

All 115 supplied solutions were independently checked: the 51 worked/try
solutions, 59 keyed practice solutions, 3 keyed everyday-math solutions, and 2
open-response keys. Arithmetic, signs, rounding precision, decimal/fraction/
percent conversions, currency rounding, repeating blocks, and the two
“answers may vary” dispositions were checked. No visible answer-key arithmetic
error was found.

One accessibility path is mathematically wrong even though the visible raster
answer is correct: in exercise `fs-id1170654983810`, the problem is `−5/8` and
the raster correctly ends at `−0.625`, but the surrounding prose and source alt
drop both negative signs. This is priority P1 below and must not be counted as a
clean accessible solution until repaired.

## Priority P1 — meaning-changing corrections

These should be corrected in reader-facing Indonesian and recorded in
`05_CORRECTIONS.csv`; authority bytes remain unchanged.

1. Paragraph `fs-id1170655062737` (source line 483) says to count the number of
   decimal **points** in the factors. The placement rule requires the total
   number of decimal **places** in the factors. Translate the correct rule.
2. Equation `fs-id1170655111307` (line 777) begins with a stray
   `<mn>0</mn><mspace/>`, rendering the false/malformed sequence
   `0 0.03 = 3/100`. Remove or neutralize the stray leading zero in the target;
   treat the protected MathML delta as an exact, hash-bound correction.
3. Exercise `fs-id1170654983810`, solution `fs-id1170655124919`, paragraph
   `fs-id1170655124777`, and media `fs-id1170654966693` (lines 855–865): the
   problem is `−5/8`. The raster correctly shows `−5/8 = −0.625`, while the
   prose begins with positive `5/8` and the alt concludes positive
   `5/8 = 0.625`. Retain the negative sign in prose and alt and state the result
   `−0.625`.
4. Table `eip-id1169753348487` (line 506) describes
   `(−3.9)(4.075)` as positive `3.9(4.075)`, says the signs are the same, and
   says the product is positive. The body correctly says the signs differ and
   the result is `−15.8925`. Replace the ARIA description with the correct
   signs and result.
5. Table `eip-id1169754137615` (line 730) corrupts `$3.99` as `>.99` in two
   places. Restore `$3.99` in the localized ARIA description.
6. Table `fs-id1167835297201` (line 1064) describes part (c) as
   `5.7% → 0.057`; the problem and visible result are
   `35.7% → 0.357`. Correct both values and the two-place leftward shift.

## Priority P2 — accessibility corrections

7. Media `fs-id1170655218662` (line 210) says “hundreds place”; the raster and
   problem use the **hundredths** place.
8. Media `fs-id1170653901496` (line 216) ends “9 is greater than or equal to”
   without the comparison value. Restore `5`.
9. Media `eip-id1169752799574` (line 278) only reports the arrow to tenths
   digit 3 and omits the operative underline beneath comparison digit 7.
10. Media `eip-id1169750840488` (line 282) incorrectly says to add 1 to the
    integer part if tenths digit 3 is at least 5. The hundredths digit 7 is at
    least 5, so 1 is added to tenths digit 3.
11. Media `eip-id1169754058811` (line 306) repeats the arrow-to-8 description
    but omits the operative underline beneath tenths digit 3.
12. Media `fs-id1170654903748` (line 150) says “Look for the **work** ‘and’.”
    The raster and procedure say “word ‘and’.”
13. Media `eip-id1169752926445` (line 806) calls `0.3` the tenths-place item;
    the raster labels the digits 3, 7, and 4 as tenths, hundredths, and
    thousandths. Describe digits, not `0.3` as a place-value digit.
14. Seven generic arrow alts invent unrelated trend/flow semantics or fail to
    convey the mathematical motion: `eip-id1169749465627` (line 616),
    `eip-id1169750795982` (1038), `eip-id1169750875596` (1055),
    `eip-id1169753258746` (1072), `eip-id1169750875648` (1151),
    `eip-id1169753320625` (1168), and `eip-id1169753184552` (1185). Replace
    each with the exact starting value, decimal-point direction/distance, and
    result supplied by its enclosing table.
15. Table `fs-id1167835311022` (line 1030) says the displayed result is `.62`;
    the table result is `0.62`. Retain the leading zero.
16. Table `fs-id1167831040263` (line 1160), which owns part (b), appends the
    complete description of part (c); the next table
    `fs-id1167835167385` already and correctly owns part (c). Trim the part (b)
    ARIA label to `1.25 → 125%` only.

All 49 media have nonempty source alt text. All 22 tables have an accessibility
attribute (17 `aria-label`, 5 `summary`). Those counts do not supersede the
semantic corrections above.

## Priority P3 — source copyedits and pedagogy note

- Figure `CNX_ElemAlg_Figure_01_07_001_new` caption (line 32): normalize
  “Place value of decimal numbers are shown” to “Place values of decimal
  numbers are shown.”
- Paragraph `fs-id1170655107014` (line 559): insert “the” in “relating the
  number of zeros ... to **the** number of decimal places.”
- Table `eip-id1169754137615`, entry at line 741: normalize the punctuation in
  “nearest cent (hundredth.)”.
- Practice problem `fs-id1170655059945`, paragraph `fs-id1170655059948`
  (line 1307): “Twenty-nine thousandth” → “Twenty-nine thousandths.”
- Key-concepts list `fs-id1170655106869` (line 1223): normalize the mismatched
  opening quotation mark in `”and”`.
- Pedagogy note, no silent content expansion: procedure
  `fs-id1170655206712` and the corresponding key concept explicitly teach
  conversion to a **proper** fraction by taking the digits right of the decimal
  point. Later practice includes `1.25` and `1.35`, whose keyed answers are the
  improper fractions `5/4` and `27/20`. The answers are correct, but the stated
  procedure does not cover a nonzero whole-number part. Phrase the procedure’s
  scope precisely; any added general algorithm is an editorial addition, not a
  source correction.

## English-labelled raster inventory (28/49)

These exact source rasters contain English lexical content. Until localized
overlays exist, the Indonesian target description must identify that the
raster is English-labelled, quote only the relevant visible wording, and give
its Indonesian meaning. Numeric/symbol-only rasters are not included.

| Media owner | Source raster |
|---|---|
| `fs-id1170654939786` | `CNX_ElemAlg_Figure_01_07_001_new.jpg` |
| `fs-id1170655232620` | `CNX_ElemAlg_Figure_01_07_002a_new.jpg` |
| `fs-id1170654238417` | `CNX_ElemAlg_Figure_01_07_002b_new.jpg` |
| `fs-id1170654235434` | `CNX_ElemAlg_Figure_01_07_002c_new.jpg` |
| `fs-id1170654221344` | `CNX_ElemAlg_Figure_01_07_002d_new.jpg` |
| `fs-id1170654903748` | `CNX_ElemAlg_Figure_01_07_003a_new.jpg` |
| `fs-id1170654048412` | `CNX_ElemAlg_Figure_01_07_003b_new.jpg` |
| `fs-id1170654048180` | `CNX_ElemAlg_Figure_01_07_003c_new.jpg` |
| `fs-id1170652616660` | `CNX_ElemAlg_Figure_01_07_003d_new.jpg` |
| `fs-id1170655218662` | `CNX_ElemAlg_Figure_01_07_004a_new.jpg` |
| `fs-id1170653985218` | `CNX_ElemAlg_Figure_01_07_004b_new.jpg` |
| `fs-id1170653901496` | `CNX_ElemAlg_Figure_01_07_004c_new.jpg` |
| `fs-id1170653744228` | `CNX_ElemAlg_Figure_01_07_004d_new.jpg` |
| `eip-id1169752964044` | `CNX_ElemAlg_Figure_01_07_005a_img_new.jpg` |
| `eip-id1169752799574` | `CNX_ElemAlg_Figure_01_07_005b_img_new.jpg` |
| `eip-id1169750840488` | `CNX_ElemAlg_Figure_01_07_005c_img_new.jpg` |
| `eip-id1169754058794` | `CNX_ElemAlg_Figure_01_07_006a_img_new.jpg` |
| `eip-id1169754058811` | `CNX_ElemAlg_Figure_01_07_006b_img_new.jpg` |
| `eip-id1169754362233` | `CNX_ElemAlg_Figure_01_07_006c_img_new.jpg` |
| `eip-id1169754130042` | `CNX_ElemAlg_Figure_01_07_009a_img_new.jpg` |
| `eip-id1169753944316` | `CNX_ElemAlg_Figure_01_07_009d_img_new.jpg` |
| `eip-id1169753269067` | `CNX_ElemAlg_Figure_01_07_010a_img_new.jpg` |
| `eip-id1169753284625` | `CNX_ElemAlg_Figure_01_07_010d_img_new.jpg` |
| `eip-id1169752908904` | `CNX_ElemAlg_Figure_01_07_012_img_new.jpg` |
| `eip-id1169752926445` | `CNX_ElemAlg_Figure_01_07_016_img_new.jpg` |
| `fs-id1170654966693` | `CNX_ElemAlg_Figure_01_07_017_img_new.jpg` |
| `fs-id1170654982890` | `CNX_ElemAlg_Figure_01_07_018_img_new.jpg` |
| `fs-id1170655065300` | `CNX_ElemAlg_Figure_01_07_201_img_new.jpg` |

## Preserved media-type debt

All 49 files have JPEG signatures and decode as JPEG. Eighteen image elements
correctly declare `image/jpeg`; 31 `.jpg` files incorrectly declare
`image/png`. The mismatches are exactly Figures 005a–005d, 006a–006d,
009a–009d, 010a–010d, 011, 012, 013a–013b, 014a–014b, 015, 016, 019,
020a–020c, and 022a–022c. Preserve these inherited source attributes in
localized CNXML unless an exact derivative-assembly MIME policy is separately
admitted.

## Exact direct-media inventory

The declared type below is the authority CNXML value. Every file’s detected
format is JPEG.

| Media owner | File | Bytes | SHA-256 | Declared type |
|---|---|---:|---|---|
| `fs-id1170654939786` | `CNX_ElemAlg_Figure_01_07_001_new.jpg` | 81,137 | `f893955d271e14287ec2ce2dda7f7c526385788be0a745932afffe43104028d7` | `image/jpeg` |
| `fs-id1170655232620` | `CNX_ElemAlg_Figure_01_07_002a_new.jpg` | 70,539 | `7e310d2388163796168361df735b1b87104b002e2cfb95ec6dc68588b98c94c1` | `image/jpeg` |
| `fs-id1170654238417` | `CNX_ElemAlg_Figure_01_07_002b_new.jpg` | 64,019 | `6955b53d46a425a417a15751a03fc9d6a2e5dfd89c300577bdc60331a5244be4` | `image/jpeg` |
| `fs-id1170654235434` | `CNX_ElemAlg_Figure_01_07_002c_new.jpg` | 74,292 | `db8b83560bc7801c4fa9c3e0524bf8eadf03ada03992837c5214cecf32fe41a9` | `image/jpeg` |
| `fs-id1170654221344` | `CNX_ElemAlg_Figure_01_07_002d_new.jpg` | 65,409 | `4d424bedd1db8ac572e01f1a074d3dfbc031adc9e9959bcd2cc14f4ca0772abd` | `image/jpeg` |
| `fs-id1170654903748` | `CNX_ElemAlg_Figure_01_07_003a_new.jpg` | 94,123 | `6ff895054695c3d6476a3bf1f508cf4f7e0837331952dd1a6991966c6282142e` | `image/jpeg` |
| `fs-id1170654048412` | `CNX_ElemAlg_Figure_01_07_003b_new.jpg` | 82,998 | `9d0f9c2bc75c4aafe2bccc5b32f92919f63add53936ef69af9a4171e31d8a110` | `image/jpeg` |
| `fs-id1170654048180` | `CNX_ElemAlg_Figure_01_07_003c_new.jpg` | 100,493 | `6a1a0fad7f3f4c43b6e7df770a8946044e435a2fc1c77ebf8bd91242ebf4ecd3` | `image/jpeg` |
| `fs-id1170652616660` | `CNX_ElemAlg_Figure_01_07_003d_new.jpg` | 78,128 | `e3b99de69fde110bff2fb013dca9be5e4e5f70d057e537a29c8818786b066495` | `image/jpeg` |
| `fs-id1170655218662` | `CNX_ElemAlg_Figure_01_07_004a_new.jpg` | 69,700 | `d411a1c31f9f349e00c9bf78fc786e5f54a0e27b6a3d1ec009b1749fc82dbd77` | `image/jpeg` |
| `fs-id1170653985218` | `CNX_ElemAlg_Figure_01_07_004b_new.jpg` | 70,201 | `c6ce86394130559b8c562f812715ecc3cf6e43c68303f243c8f28611d8449594` | `image/jpeg` |
| `fs-id1170653901496` | `CNX_ElemAlg_Figure_01_07_004c_new.jpg` | 86,185 | `731310748bce6bcc313737b1d6ce5b24495681c1f9f055991747b6095561c5f0` | `image/jpeg` |
| `fs-id1170653744228` | `CNX_ElemAlg_Figure_01_07_004d_new.jpg` | 77,216 | `9820b35a01ed3f1fd7f355a062c4ab3db2d8159f15668787f4fdf1546e8d2b56` | `image/jpeg` |
| `eip-id1169752964044` | `CNX_ElemAlg_Figure_01_07_005a_img_new.jpg` | 36,283 | `898cac2cc8457319505d5162b22614082e87996fbc79e3ce17d0e80607a64300` | `image/png` |
| `eip-id1169752799574` | `CNX_ElemAlg_Figure_01_07_005b_img_new.jpg` | 37,739 | `fe28736469111a6de4bbe5190e2746110c821dc391411b1c3a4217bad1ef4ddd` | `image/png` |
| `eip-id1169750840488` | `CNX_ElemAlg_Figure_01_07_005c_img_new.jpg` | 34,944 | `857854a8282a50a2d7f97cfdb43cab9c94cc0080b4a9e530e6e4148a90714252` | `image/png` |
| `eip-id1169750591270` | `CNX_ElemAlg_Figure_01_07_005d_img_new.jpg` | 30,862 | `6df7e55d08483c2b2af33dc79da0fcf3aaddd2b1c057b0240085d4f418164635` | `image/png` |
| `eip-id1169754058794` | `CNX_ElemAlg_Figure_01_07_006a_img_new.jpg` | 36,500 | `a1b5d65ada72317c28cc773abc003b2835501ecbe369eceb452ff1d44ed97429` | `image/png` |
| `eip-id1169754058811` | `CNX_ElemAlg_Figure_01_07_006b_img_new.jpg` | 38,120 | `a7d6027f7e8e54452fe30f33ad9023dc50580c280448fac15e4adebbf4ec5d7d` | `image/png` |
| `eip-id1169754362233` | `CNX_ElemAlg_Figure_01_07_006c_img_new.jpg` | 33,746 | `fc02aa281a8da28f61a966abe34df87c098e299b706ed6c711a8c9db61575650` | `image/png` |
| `eip-id1169754362250` | `CNX_ElemAlg_Figure_01_07_006d_img_new.jpg` | 33,081 | `37b8967733298b383da261d26baa50abd11870232ee8dcbf7a8f034b09d805cf` | `image/png` |
| `eip-id1169754130042` | `CNX_ElemAlg_Figure_01_07_009a_img_new.jpg` | 42,705 | `d840f204675e52104c3b0e875c052b21b4c70d7df5285d7e6ff03874ea4b0f98` | `image/png` |
| `eip-id1169753944283` | `CNX_ElemAlg_Figure_01_07_009b_img_new.jpg` | 37,660 | `0a9af756e0c04dfdad3dc33aa22d415df605c3c8d5f3a4aa9743dfbcfaa8adfe` | `image/png` |
| `eip-id1169753944299` | `CNX_ElemAlg_Figure_01_07_009c_img_new.jpg` | 36,315 | `607f51e3bbd3658017f74ac4cd1e6e89a0efcde4becea7aa627efc22ac7a16e5` | `image/png` |
| `eip-id1169753944316` | `CNX_ElemAlg_Figure_01_07_009d_img_new.jpg` | 38,717 | `f0c788f07546d1a27cba081d94a280fefd527049f294d1fe3bc3e2cf8e7cc9f4` | `image/png` |
| `eip-id1169752872718` | `CNX_ElemAlg_Figure_01_07_010b_img_new.jpg` | 38,618 | `4164cc03ef97e045e4396d962c1b74ec7fba3f256e681886a19dffd03a2361b1` | `image/png` |
| `eip-id1169750874908` | `CNX_ElemAlg_Figure_01_07_010c_img_new.jpg` | 41,198 | `5d2fb2eedc1da343b55afae1b75d744f627863bebb8c61c074fc3e65fce033e7` | `image/png` |
| `eip-id1169753269067` | `CNX_ElemAlg_Figure_01_07_010a_img_new.jpg` | 33,341 | `1af40cfde1d6cb8fd434a12e3c45dc9a638f3bb48404448f917f57df6d37b83c` | `image/png` |
| `eip-id1169753284625` | `CNX_ElemAlg_Figure_01_07_010d_img_new.jpg` | 41,256 | `cc9525d02374c71883934cb28bfff6ca167ec35a9a348154f196361a52b06a7b` | `image/png` |
| `eip-id1169753258712` | `CNX_ElemAlg_Figure_01_07_011_img_new.jpg` | 31,662 | `c7913dc6045d8f1ccde303715a3714692045daa86fe6f01c222af554aab77359` | `image/png` |
| `eip-id1169752908904` | `CNX_ElemAlg_Figure_01_07_012_img_new.jpg` | 37,967 | `1b54747748e968010fc509a835fecb888cb5ee71778293119e9f62e36301c7d8` | `image/png` |
| `eip-id1169749465627` | `CNX_ElemAlg_Figure_01_07_013a_img_new.jpg` | 39,043 | `cfe064ab99d5e42118a4ac9265c6f73ed0cafe13c6473dd8d717fd86d3213a20` | `image/png` |
| `eip-id1169754029608` | `CNX_ElemAlg_Figure_01_07_013b_img_new.jpg` | 31,828 | `14a9347141cd2a7a2dc35a5d802c16ae4e1af79b9a8c11bfc44db66f9dc1beac` | `image/png` |
| `eip-id1169751952546` | `CNX_ElemAlg_Figure_01_07_014a_img_new.jpg` | 36,709 | `54a9fa8ea4f166d41bec02a6bc195d65f55b7a2f8de368435d3cfc47ec6990a8` | `image/png` |
| `eip-id1169751952565` | `CNX_ElemAlg_Figure_01_07_014b_img_new.jpg` | 41,594 | `3ea7c9d52b70e6fd6385f9b7f931dce0131f0f4ec3c173ca02601ce3483ee689` | `image/png` |
| `eip-id1169754122161` | `CNX_ElemAlg_Figure_01_07_015_img_new.jpg` | 37,403 | `22747071a28fe5394dddf06669587dbb09c8f77d96919baa1cc89dac0b9305e2` | `image/png` |
| `eip-id1169752926445` | `CNX_ElemAlg_Figure_01_07_016_img_new.jpg` | 28,127 | `0634d074d1d9ea185869234e013489bc023dd26c66ea664167ef10958c0173f9` | `image/png` |
| `fs-id1170654966693` | `CNX_ElemAlg_Figure_01_07_017_img_new.jpg` | 39,039 | `7803c85f0cd2eb952cb64758f3b4617da884e4482042cca1745c016717e96fc1` | `image/jpeg` |
| `fs-id1170654982890` | `CNX_ElemAlg_Figure_01_07_018_img_new.jpg` | 68,071 | `0b901610cbc55efdea9936078d36862eeac6f36544b90cd6220378a1293f9924` | `image/jpeg` |
| `eip-id1169749852706` | `CNX_ElemAlg_Figure_01_07_019_img_new.jpg` | 41,232 | `9e6fd66a96019b8287c6667ec5f7ed031ef8b82b01a1cce30e179f54fffb607f` | `image/png` |
| `fs-id1170655166487` | `CNX_ElemAlg_Figure_01_07_023_img_new.jpg` | 41,803 | `cb611f575fbe57c083771c245b9613ef6082e514f06211a65a10692a6d864cd6` | `image/jpeg` |
| `eip-id1169750795982` | `CNX_ElemAlg_Figure_01_07_020a_img_new.jpg` | 43,573 | `db155843298c77ac49fde0b021f97d8f424b27ea20796d7ef9d28a1be1864078` | `image/png` |
| `eip-id1169750875596` | `CNX_ElemAlg_Figure_01_07_020b_img_new.jpg` | 44,144 | `88558f8bcde1360bcf2e17f8776cd41c32905d45aaea8394600178b13281d1bd` | `image/png` |
| `eip-id1169753258746` | `CNX_ElemAlg_Figure_01_07_020c_img_new.jpg` | 602,732 | `2d2e7895c8f8800e7af0d707e63a58640c560c984e96dcf7d4f89025bebcf61b` | `image/png` |
| `fs-id1170654985014` | `CNX_ElemAlg_Figure_01_07_021_img_new.jpg` | 41,827 | `6cf225bed91eaba907ef5aaa10d61fee9ac825ee8c8077ad0e4601c86ac3499f` | `image/jpeg` |
| `eip-id1169750875648` | `CNX_ElemAlg_Figure_01_07_022a_img_new.jpg` | 41,146 | `00a3bf00ef43925c21d7d64ff721cc23d073fb891cedee014085d2e6cdd0d30e` | `image/png` |
| `eip-id1169753320625` | `CNX_ElemAlg_Figure_01_07_022b_img_new.jpg` | 41,759 | `bd58188c626efa671613884e5acbea495cb183a2e4715056d7ca1790aeb1563e` | `image/png` |
| `eip-id1169753184552` | `CNX_ElemAlg_Figure_01_07_022c_img_new.jpg` | 45,337 | `388b6174212447deef2973366c804a49ac43faad4e7d4e10e49aa3e3b567167a` | `image/png` |
| `fs-id1170655065300` | `CNX_ElemAlg_Figure_01_07_201_img_new.jpg` | 62,478 | `c2aab832820c759e6f371bef5441e3c701d3473f1e5a972153f2ad82fd020d7a` | `image/jpeg` |

## Admission rule

No finding above changes authority. Every determined target correction must be
recorded in `05_CORRECTIONS.csv`; every accessibility attribute remains
reader-facing Indonesian; the MathML correction must be exact and hash-bound.
The 28 English-labelled rasters remain source witnesses, not localized assets.
This audit alone does not admit the translated target.
