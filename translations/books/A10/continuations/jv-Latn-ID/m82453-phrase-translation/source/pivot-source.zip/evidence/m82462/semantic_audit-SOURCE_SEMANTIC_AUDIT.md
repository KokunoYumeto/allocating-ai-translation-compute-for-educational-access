# m82462 source semantic audit

## Authority and audit boundary

- Source: authority/source/modules/m82462/index.cnxml
- Expected and observed size: **1,147 bytes**
- Expected and observed SHA-256: **7f29e8b9558d6d37553e5991cfffc7cc27c320e2a92ed98db563e76a90e8a51e**
- Module metadata: content ID m82462; UUID c591f886-799f-41d7-b3de-c43a547ed8ed; title **Introduction**; document class introduction.
- Direct media only: the single image/@src reference in this CNXML, resolved to authority/source/media/CNX_ElemAlg_Figure_02_00_001_img_new.jpg.
- Frozen source and its direct asset were read only. No source, translation target, live ledger, backend, or sibling module was edited.

## Verdict

The document is well-formed XML. All three IDs are unique. It contains one splash photograph, one accurate alt, one caption, and one reader paragraph. It contains **no exercises, problems, supplied solutions, examples, equations, MathML, tables, or links**, so mathematical transformation coverage is exactly 0/0 rather than missing work.

The explicit addition-preserves-equality statement is mathematically sound. Two low-severity precision corrections remain: the physical claim omits the equal-distance/symmetric-placement condition required for equal torque, and the closing “what we do to one side ... we must also do to the other” heuristic should be limited to defined, equivalence-preserving operations when it is presented as a method for solving equations. These are **EA2-C0204 and EA2-C0205 (P3)**. There are no P1 or P2 findings, no MIME mismatch, no English-labelled raster, and no source-specific raster replacement/reflow debt.

Correction inventory: **P1 0 / P2 0 / P3 2**. No correction has been applied to frozen authority.

## XML and topology inventory

| Surface | Count |
|---|---:|
| All elements | 13 |
| CNXML namespace elements | 9 |
| MDML namespace elements | 4 |
| MathML namespace elements | 0 |
| IDs / unique IDs / duplicate IDs | 3 / 3 / 0 |
| Titles, CNXML / MDML | 1 / 1 |
| Content blocks / paragraphs / captions | 1 / 1 / 1 |
| Figures / media / images / unique direct assets | 1 / 1 / 1 / 1 |
| Sections / notes / examples | 0 / 0 / 0 |
| Exercises / problems / supplied solutions | 0 / 0 / 0 |
| Equations / MathML roots / MathML elements / mtext | 0 / 0 / 0 / 0 |
| Tables / rows / entries | 0 / 0 / 0 |
| Links | 0 |
| Accessibility attributes, alt / aria-label / summary | 1 / 0 / 0 |

The three IDs in document order are CNX_ElemAlg_Figure_02_00_001, fs-id1166503473429, and fs-id1166503226544.

Deterministic receipts:

- Ordered-ID SHA-256: **3f59087a5f848fdac9f3135465404f91c75e926e21cd9a1f08adb361577f2ced**. Preimage is every nonempty id in document order, LF-joined without a terminal LF.
- Topology SHA-256: **58f28f4c7629816f56d58bdfdb1c835d6e2f17f44278d796daeeac19409a2246**. Each preorder element contributes {namespace-uri}local-name, a tab, and id-or-empty; rows are LF-joined without a terminal LF.
- Exercise, problem/solution, and MathML coverage streams are empty by source topology. SHA-256 of the empty UTF-8 stream is **e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855**.

## Complete semantic and mathematical audit

The full reader surface is:

1. Caption: the rocks must remain balanced around the center for the formation to hold its shape.
2. Paragraph fs-id1166503226544: adding equal weight on both sides is compared with adding the same quantity to both sides of an equation; the paragraph previews solving equations by performing the same operation on both sides.

The algebraic preservation statement is correct: if a=b, then a+c=b+c for every defined quantity c. There is no displayed formula, exercise, worked example, answer, or hidden raster mathematics to recompute.

The physical analogy needs a precision qualifier. Equal weights on opposite sides of a balance point do not alone guarantee equilibrium: torque is weight multiplied by perpendicular distance from the balance point. Placing equal added weights symmetrically, at equal effective distances, preserves the balance. EA2-C0204 adds that condition without changing the intended equation analogy.

The final heuristic also needs a narrow qualification when used to justify solving an equation. Applying the same defined function to two already equal values preserves equality, but arbitrary same-on-both-sides transformations need not preserve an equivalent solution set: multiplying both sides by zero loses information, squaring can introduce extraneous roots, and an operation may be undefined. EA2-C0205 says to use the same valid, equivalence-preserving operation on both sides. This leaves the preceding, fully correct addition statement intact.

## Exact correction finding

| Candidate | Priority | Owner | Finding and required reader treatment |
|---|---|---|---|
| EA2-C0204 | P3 | fs-id1166503226544 | Clarify that equal added rocks preserve physical balance when placed symmetrically at equal distances from the balance point; retain the correct statement that adding the same quantity to both sides preserves an equation. |
| EA2-C0205 | P3 | fs-id1166503226544 | Qualify the solving heuristic as applying the same defined, equivalence-preserving operation to both sides; do not imply that every arbitrary same-on-both-sides transformation preserves the solution set. |

These are concise upstream-worthy conceptual-precision candidates, suitable for later deduplication into the single corpus-level report. Neither claims that the chapter's stated addition property is wrong.

## Accessibility audit

- Media fs-id1166503473429 has the nonempty alt: “This is a photo of several rocks carefully stacked to achieve balance.”
- Visual inspection confirms the raster is a photograph of multiple rocks stacked in a balanced formation. The alt identifies the image type, subject, arrangement, and pedagogically relevant concept.
- The caption supplies the relationship to balance. No visible text, labels, numerals, equations, or other language-specific pixels occur in the photograph.
- There are no tables or additional accessibility attributes.
- Result: **PASS**. No alt correction and no localized raster reconstruction are required.

## Links and reference closure

The module contains no target-id, document, or URL links. Reference closure is therefore complete within the source plus its one direct asset.

## Direct asset closure

| Media ID | Source | Bytes | Dimensions | Declared → actual MIME | SHA-256 |
|---|---|---:|---:|---|---|
| fs-id1166503473429 | ../../media/CNX_ElemAlg_Figure_02_00_001_img_new.jpg | 389,719 | 975×450 | image/jpeg → image/jpeg | 1aa4da73b19ca49299a62bb558c8a5150c16e388e2814b33476b7501d112f96f |

The file exists, its JPEG signature and PIL decoding agree with the declaration, and the decoded image is 975×450 in CMYK mode.

Deterministic closure receipts:

- Asset-manifest SHA-256: **5a733e80f72c5842971a2aa6a5344a493291ff8ac7cdb2cbb24f17f7aa481efa**. Its one LF-terminated row is media-id TAB src TAB bytes TAB sha256 TAB declared-mime TAB actual-mime.
- Raw source-plus-asset SHA-256: **f600f0bb1c51b9a5d6d87f5d5c0c622599b1e31be62590bce3106c817217e422**. Preimage is raw CNXML followed directly by the asset bytes.

## Raster and reflow disposition

The 975×450 photograph is already a high-resolution, wide splash asset. It has no embedded English and no narrow mathematical strip. It should be centered and fitted responsively by ordinary reader assembly while preserving aspect ratio, caption association, alt, hash, and rights provenance. Stretching beyond its useful resolution is unnecessary, but no semantic replacement, OCR, localization, or special reflow candidate is warranted.

## Source-preservation disposition

The authoritative CNXML and direct asset remain byte-identical. EA2-C0204 and EA2-C0205 are proposed reader corrections only; the source paragraph and asset remain immutable witnesses. Any later upstream report must be deduplicated with the corpus-level issue rather than submitted independently from this audit.
