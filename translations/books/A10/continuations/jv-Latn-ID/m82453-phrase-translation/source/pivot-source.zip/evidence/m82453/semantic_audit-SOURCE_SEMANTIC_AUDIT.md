# m82453 Frozen-Source Semantic Audit

Source: `authority/source/modules/m82453/index.cnxml`  
Bytes: 184,248  
SHA-256: `a8fdd235aa254c5a0a1248fa858e9b3579d9b40982bbc514cbe6a18c3e6fcbed`  
Scope: read-only source audit before target admission

## Coverage and closure

- 18 examples; 156 exercises/problems; 105 supplied solutions.
- 20 tables; 50 referenced media; 10 glossary definitions; 409 MathML
  nodes; 5 internal cross-references.
- 1,001 IDs, all unique; every media reference exists; every internal
  cross-reference resolves to the intended local object.
- No incorrect final numerical answer, algebraic simplification, like-term
  result, or phrase-to-expression answer was found beyond the defects below.

## Material source defects

1. `fs-id1167836504155` / `fs-id1167836692989`: the worked row says to
   replace `x` with 4 and the next row expands four factors, but raster
   `CNX_ElemAlg_Figure_01_02_012b_img_new.jpg` displays `3^x`. The target
   derivative must display `3^4` and use matching localized alt text.
2. `fs-id1169148881010` / `fs-id1169149089480`: the worked row says to
   substitute `x=4`, but raster `CNX_ElemAlg_Figure_01_02_013b_img_new.jpg`
   repeats `2x^2+3x+8`. The target derivative must display
   `2(4)^2+3(4)+8` and use matching localized alt text.
3. `fs-id1170654982105`, `fs-id1170655213989`, embedded media
   `fs-id1170655219218`, and key-concept list `fs-id1170655207980` define
   `a^n` by saying to multiply `a` by itself `n` times. This is conventionally
   off by one and omits the domain. Target wording: for a positive integer
   `n`, `a^n` is the product of `n` factors equal to `a`; likewise describe
   `2^9` as the product of nine factors equal to 2.
4. List `fs-id1166422559187` switches from the surrounding `n^2` and `9n^2`
   to `x^2` and `9x^2`; retain `n`.
5. Table `eip-72` describes “6 less than the width” as `w-6`, while the
   problem and solution use 6 less than the length, `l-6`.
6. Table `fs-id1170655178881` gives the wrong operation-row order and claims
   four multiplication notations although five appear. Describe addition,
   subtraction, multiplication, division, and all five multiplication forms.

The two raster corrections are implemented as immutable same-name derivative
overlays and bound in `MEDIA_OVERLAY_MANIFEST.csv`; authority bytes remain
unchanged.

## Accessibility corrections

- Number-line media `fs-id1170652623871` and `fs-id1167269961954` must state
  the left/right relation; the latter also says “numbered line.”
- `fs-id1167836700561` malforms `(4+3)·7`; `fs-id1167836329648` omits the dot
  in `(7)·7`; `fs-id1170653192952` has `x2`, “n blue,” and an unmatched quote;
  `fs-id1170655111048` has stray `v7`.
- Bare expressions are incorrectly called equations at
  `fs-id1167836282522`, `fs-id1167833397265`, `fs-id1167836622811`, and
  `fs-id1167836363366`. `fs-id1167836294733` should simply describe `7-4`
  without guessing that it is a score or date.
- Three table descriptions misspell “parentheses”:
  `fs-id1167833022118`, `fs-id1167829713618`, and `fs-id1167829840981`.
- `fs-id1167836329359` and `fs-id1167833047529` say “To the write” rather
  than “To the right.” The `fs-id1167829840981` description also says all of
  `6-6` is red although only the newly computed second 6 is highlighted.
- The figure for `fs-id1170655219218` misspells “superscripted.”

## Other determined source corrections

- `fs-id1166425080552`: singular “activity” requires “gives.”
- `fs-id1170655129489`, `fs-id1170655202549`, and `fs-id1170655133650`:
  reorder the prompt as “Evaluate … when `x=…`.”
- `fs-id1166425197914`: emphasis should enclose only “and,” not “and t.”
- Table `eip-470`: “phase” should be “phrase.”
- `fs-id1170655222142` and `fs-id1170655304740`: claim-introduction
  fragments should end in colons.
- Exactly 37 image elements in the contiguous source region corresponding to
  lines 516–881 declare `image/png` although their `.jpg` files are JPEGs.
  This broad inherited MIME defect is recorded but retained in CNXML pending a
  systematic assembly-level policy; it is not silently normalized in one
  module.

## Canonical id-ID choices for this module

`expression` → `ekspresi`; `equation` → `persamaan`; `equal sign` → `tanda
sama dengan`; `variable` → `variabel`; `term` → `suku`; `coefficient` →
`koefisien`; `constant term` → `suku konstanta`; `like terms` → `suku
sejenis`; `combine like terms` → `menggabungkan suku sejenis`; `simplify an
expression` → `menyederhanakan ekspresi`; `evaluate an expression` →
`menentukan nilai ekspresi`; `substitute` → `mensubstitusikan` (imperative:
`substitusikan`); `order of operations` → `urutan operasi hitung`; `grouping
symbols` → `simbol pengelompokan`; `parentheses/brackets/braces` → `tanda
kurung/tanda kurung siku/tanda kurung kurawal`; `exponent` → `eksponen`;
`base` → `bilangan pokok (basis)`, then `bilangan pokok`; `power` → `pangkat`;
`exponential notation` → `notasi berpangkat`; `inequality` →
`pertidaksamaan`; `dividend/divisor/quotient` → `bilangan yang
dibagi/pembagi/hasil bagi`; `sum/difference/product` →
`jumlah/selisih/hasil kali`.

Guardrails: do not call a bare expression a `persamaan`; keep `menentukan
nilai` distinct from `menyederhanakan`; distinguish `eksponen` from `pangkat`;
localize “English phrase” as `frasa dalam bahasa Indonesia`; do not transplant
PEMDAS as an Indonesian mnemonic—state the four ordered tiers and the
left-to-right rule explicitly.
