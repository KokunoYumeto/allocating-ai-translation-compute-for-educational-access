# m82461 source semantic audit

## Authority and audit boundary

- Source: authority/source/modules/m82461/index.cnxml
- Expected and observed size: **284,041 bytes**
- Expected and observed SHA-256: **df82cee2f1a278bb88f392572457ee679bc09d108962a9b6c72ba5bb0084655e**
- Module metadata: content ID m82461; UUID 69fe7540-4ca9-4cf1-8e7c-cfd3d94cf3fc; title **Systems of Measurement**.
- Direct media only: the 44 image/@src references in this CNXML, resolved to authority/source/media.
- The authority source and all direct assets were read only. No source or translation target was created, edited, normalized, or repaired by this audit.

## Verdict

The CNXML is well formed. All 2,644 IDs are unique, every one of the 11 local target-id links resolves to one unique in-module owner, and all 44 direct media references close to present, decodable assets. The nine document links are declared chapter-review references and were inventoried without entering sibling modules.

Every one of the **566 problems**, all **306 supplied solutions**, all **260 unsupplied problem statements**, all **15 worked examples**, the visible mathematics in all **18 tables**, all **621 MathML roots**, and all **37 raster-backed solution surfaces** was independently checked. No supplied final numeric answer is wrong under the module's own conversion conventions. Confirmed defects comprise a stray comparison sign that makes one exercise malformed, two under-specified word problems, four material accessibility inaccuracies, two omitted variable restrictions, and source copy/accessibility defects. Direct-asset debt comprises 29 false PNG declarations, 25 English-labelled rasters, and 14 additional cramped math-only rasters.

Correction inventory: **P1 0 / P2 6 / P3 22**, represented exactly by **EA2-C0176 through EA2-C0203** in PROPOSED_CORRECTIONS.csv. No correction has been applied to frozen authority.

## XML and topology inventory

| Surface | Count |
|---|---:|
| All elements | 8,697 |
| CNXML namespace elements | 3,459 |
| MDML namespace elements | 4 |
| MathML namespace elements | 5,234 |
| IDs / unique IDs / duplicate IDs | 2,644 / 2,644 / 0 |
| Sections, total / top-level / nested | 23 / 10 / 13 |
| Paragraphs / notes / examples | 1,055 / 34 / 15 |
| Exercises / problems / supplied solutions | 566 / 566 / 306 |
| Problems without supplied solutions | 260 |
| Equations / MathML roots / MathML mtext | 2 / 621 / 331 |
| Tables / rows / entries | 18 / 81 / 164 |
| Media / images / unique direct assets | 44 / 44 / 44 |
| Figures | 4 |
| Links, local / document | 11 / 9 |
| Accessibility attributes, alt / aria-label / summary | 44 / 14 / 4 |
| Notes by class | 30 try / 1 be-prepared / 1 howto / 2 unclassified |

Deterministic structural receipts:

- Ordered-ID SHA-256: **7c6a089a892ff79617c23c4d608c125919de2b09aef8c111674bd016a117a761**. Preimage is every nonempty id in document order, joined by LF with no terminal LF.
- Topology SHA-256: **c4e63fedd400a1086b6afada0cec62394903286e09010ed0b8e68a2b7480156b**. Each preorder element contributes {namespace-uri}local-name, a tab, and id-or-empty; rows are LF-joined without a terminal LF.
- Math semantic-surface SHA-256: **10f8a49cebd5efc40bb109c974d62ea6a8ef1aaa7ba049558b993d6019cbbb68** across 5,234 MathML elements. Each MathML element contributes expanded tag, sorted attributes, and stripped direct text in document order.
- Exercise topology ledger: **566 rows**, SHA-256 **7a8d3f58f23e237253c29a5d42411a19193975994fefe322b23d82eac8e53aba**. Each row is exercise-id, problem-id, and solution-id-or-empty separated by tabs, LF-joined without terminal LF.
- Supplied pair ledger: **306 rows**, SHA-256 **d900167245f550a539832a107230d71ed6461f8a1bb084dd6c4f49a949973790**. Each row is problem-id TAB solution-id.
- Unsupplied-problem ledger: **260 rows**, SHA-256 **d4465b96e48f91d868f21315d5997de83d8a568060aaa4e1031ad0d7f711d2a6**. Each row is a problem ID.
- Independent ordinal coverage ledger: **566 rows / 29,998 bytes**, SHA-256 **3aef586a51d1b791467ec619c42e3decd36a3bb76d1dd0216039848a287daa50**. Its LF-terminated rows are ordinal TAB exercise-id TAB problem-id TAB solution-id-or-hyphen.
- Independent worked-example ledger: **15 rows / 1,140 bytes**, SHA-256 **fc970a79f5c5a445508883e762b38f6f3e64175674f67ff65d9ac41032ad84ae**.

## Section and exercise coverage

| Section ID | Surface | Problems | Supplied | Unsupplied | Examples | Solution rasters |
|---|---|---:|---:|---:|---:|---:|
| fs-id1170654126241 | Make Unit Conversions in the U.S. System | 12 | 12 | 0 | 4 | 7 |
| fs-id1170653806821 | Use Mixed Units in the U.S. System | 6 | 6 | 0 | 2 | 3 |
| fs-id1170654181456 | Make Unit Conversions in the Metric System | 9 | 9 | 0 | 3 | 13 |
| fs-id1170654114169 | Use Mixed Units in the Metric System | 6 | 6 | 0 | 2 | 0 |
| fs-id1170653885743 | Convert Between U.S. and Metric Systems | 6 | 6 | 0 | 2 | 0 |
| fs-id1170654125831 | Fahrenheit and Celsius Temperatures | 6 | 6 | 0 | 2 | 10 |
| fs-id1170653917356 | Practice Makes Perfect | 84 | 42 | 42 | 0 | 0 |
| fs-id1170653735611 | Everyday Math | 2 | 1 | 1 | 0 | 0 |
| fs-id1170653879428 | Writing Exercises | 2 | 1 | 1 | 0 | 0 |
| fs-id1170654237664 | Whole Numbers review | 36 | 18 | 18 | 0 | 0 |
| fs-id1170652664898 | Language of Algebra review | 44 | 22 | 22 | 0 | 0 |
| fs-id1170654016600 | Integers review | 72 | 36 | 36 | 0 | 0 |
| fs-id1170654285032 | Fractions visualization review | 50 | 25 | 25 | 0 | 0 |
| fs-id1170653894414 | Fraction addition/subtraction review | 34 | 17 | 17 | 0 | 0 |
| fs-id1170654061596 | Decimals review | 60 | 30 | 30 | 0 | 0 |
| fs-id1170654236418 | Real Numbers review | 30 | 15 | 15 | 0 | 4 |
| fs-id1170654144964 | Properties of Real Numbers review | 34 | 17 | 17 | 0 | 0 |
| fs-id1170652788357 | Systems of Measurement review | 38 | 19 | 19 | 0 | 0 |
| fs-id1170654186018 | Chapter Practice Test | 35 | 18 | 17 | 0 | 0 |

Wrapper receipts:

- Section Exercises fs-id1170653917353: 88 problems / 44 supplied; ledger SHA-256 **9aab2e8d4e89d2a07b2546ac153682aeda036dcf794f53dd88e45534b5e2e9c0**.
- Chapter Review fs-id1170653907575: 398 problems / 199 supplied; ledger SHA-256 **fbbc78153cdbea7f60b203a7765f8e0a0fc4accf967b58d91dd388f23830f6da**.
- Chapter Practice Test fs-id1170654186018: 35 problems / 18 supplied; ledger SHA-256 **e48ead7fb9c0b6e3f9b9cd23f0b3db2c0c0e43dfefdad50d6682c4a24cf12a34**.

## Mathematical and solution audit

### Worked examples

| # | Example | Problem → solution | Result |
|---:|---|---|---|
| 1 | fs-id1170654038452 | fs-id1170652619424 → fs-id1170653806518 | PASS: 66 in = 5.5 ft; accessibility defects EA2-C0180 and raster localization debt |
| 2 | fs-id1170653740449 | fs-id1170654016452 → fs-id1170654026793 | PASS: 3.2 ton = 6,400 lb |
| 3 | fs-id1170653884339 | fs-id1170654078868 → fs-id1170653815775 | PASS: 9 weeks = 90,720 min; aria operation-label defect EA2-C0186 |
| 4 | fs-id1170653736488 | fs-id1170653889570 → fs-id1170653868720 | PASS numerically: 1 gal = 128 fl oz; source says ordinary ounces, EA2-C0182 |
| 5 | fs-id1170654217418 | fs-id1170654014673 → fs-id1170653795707 | PASS: 3 lb 6 oz; prompt-unit mismatch EA2-C0184 and incomplete raster alt EA2-C0181 |
| 6 | fs-id1170653881632 | fs-id1170653908540 → fs-id1170652622776 | PASS: 25 ft 4 in |
| 7 | fs-id1170653908291 | fs-id1170653799921 → fs-id1170654176791 | PASS: 10 km = 10,000 m |
| 8 | fs-id1170653898510 | fs-id1170654203077 → fs-id1170653834770 | PASS: 3,200 g = 3.2 kg; “function” typo EA2-C0185 |
| 9 | fs-id1170653917879 | fs-id1170653912013 → fs-id1170654080821 | PASS: 350 L = 0.35 kL; 4.1 L = 4,100 mL |
| 10 | fs-id1170653770878 | fs-id1170654068967 → fs-id1170653737171 | PASS: 1.60 m − 0.85 m = 0.75 m; generic summary EA2-C0187 |
| 11 | fs-id1170653769022 | fs-id1170653834744 → fs-id1170653769748 | PASS: 3×150 mL = 0.45 L; spelling defect EA2-C0194 |
| 12 | fs-id1170654075277 | fs-id1170653899040 → fs-id1170654011769 | PASS numerically: 500 mL ≈ 16.7 fl oz; source says ordinary ounces, EA2-C0182 |
| 13 | fs-id1170653836983 | fs-id1170653768884 → fs-id1170652658229 | PASS: 100 km / 1.61 ≈ 62 mi |
| 14 | fs-id1170654015022 | fs-id1170653930602 → fs-id1170653755791 | PASS: 50°F = 10°C |
| 15 | fs-id1170654129736 | fs-id1170653798022 → fs-id1170653769463 | PASS: 20°C = 68°F |

### Exact math findings

- **EA2-C0176, P2:** exercise fs-id1170652618835 / problem fs-id1170652618837 has a literal greater-than sign between parts ⓐ and ⓑ. It is outside MathML and turns part ⓐ into an incomplete comparison. Delete it and preserve only a separator/newline. The intended evaluations are −13 and 5.
- **EA2-C0177, P2:** problem fs-id1170653793290 asks to convert 2 months 5 days to days, and solution fs-id1170654159512 says 65 days. The module defines no month conversion and calendar months vary. State “assume 30 days per month” or replace the duration with fixed dates/units.
- **EA2-C0178, P2:** problem fs-id1170654233920 asks how many reflectors, 16 yd apart, are needed along a one-mile stripe. Since 1,760/16 = 110 gaps, the count is 111 if both endpoints receive reflectors and 110 only under another endpoint convention. Specify placement; the recommended explicit version includes both endpoints and answers 111.
- **EA2-C0183, P3:** problem fs-id1170653797913 and supplied solution fs-id1170654128438 cancel p and report 2/9 without retaining p≠0; companion unsupplied problem fs-id1170654233515 has the same requirement for q. State the original domains.
- **EA2-C0184, P3:** four prompts request only pounds or gallons while the source/intended answers remain mixed units. Reword fs-id1170654014673, fs-id1170653913548, fs-id1170653896355, and fs-id1170654239296 to request pounds-and-ounces or gallons-and-quarts, or answer wholly in the requested larger unit.

All 306 supplied results were recomputed. Apart from the explicit convention, domain, unit-label, and answer-format defects above, their arithmetic is exact under the printed conventions across whole-number, signed-number, fraction, decimal, radical/classification, property, U.S./metric conversion, and temperature work. All 260 unsupplied statements were checked; their mathematical qualification defects are the stray comparison at fs-id1170652618837, the endpoint ambiguity at fs-id1170654233920, and the missing q≠0 restriction at fs-id1170654233515. Additional copy and format findings are catalogued below.

## Exact correction findings

| Candidate | Priority | Exact owner(s) | Finding and required reader treatment |
|---|---|---|---|
| EA2-C0176 | P2 | fs-id1170652618835 / fs-id1170652618837 | Remove the stray literal > between independent parts; preserve a newline/separator and evaluate to −13 and 5. |
| EA2-C0177 | P2 | fs-id1170653793290 / fs-id1170654159512 | State a 30-day-month convention for the 65-day answer or replace the variable month unit. |
| EA2-C0178 | P2 | fs-id1170654233920 | Specify reflector endpoint placement; with both endpoints included, 110 gaps require 111 reflectors. |
| EA2-C0179 | P2 | fs-id1170654027716 aria-label | Restore 12, 3, and 5,280 in the voiced U.S. length conversions. |
| EA2-C0180 | P2 | fs-id1170654071984 alt | Restore the omitted multiplier 1 in both quoted instructions for Figure 017a. |
| EA2-C0181 | P2 | eip-id1169750704513 alt | Include the first steak's 14 ounces; the current alt starts only with the latter two steaks. |
| EA2-C0182 | P3 | fs-id1170653889570 / fs-id1170653868720; fs-id1170653899040 / fs-id1170654011769 | Say fluid ounces (fl oz), not undifferentiated mass ounces, in both volume examples and their accessible surfaces. |
| EA2-C0183 | P3 | fs-id1170653797913 / fs-id1170654128438; fs-id1170654233515 | Retain p≠0 and q≠0 when cancellation hides the zero-divisor restriction. |
| EA2-C0184 | P3 | fs-id1170654014673; fs-id1170653913548; fs-id1170653896355; fs-id1170654239296 | Align four mixed-unit prompts with their mixed-unit answers. |
| EA2-C0185 | P3 | fs-id1170654203077 / fs-id1170653834770 / eip-id1169750760364 | “Write 1 as a function” must be “Write 1 as a fraction.” |
| EA2-C0186 | P3 | eip-id1169753123087 aria-label | The visible final operation is Multiply, not Simplify. |
| EA2-C0187 | P3 | eip-765 summary | Replace the generic summary with the actual 1.60 m − 0.85 m = 0.75 m calculation. |
| EA2-C0188 | P3 | eip-id1169754143940 and eip-id1169748340002 aria-label | Remove duplicated “we have we have” from both accessible narrations. |
| EA2-C0189 | P3 | fs-id1170653846703 | Restore parallel number: “cup, pint, quart, and gallon.” |
| EA2-C0190 | P3 | fs-id1170653741424 | “The roots words” must be “The root words.” |
| EA2-C0191 | P3 | fs-id1170654013407 | “The length … are measured” must use singular “is measured.” |
| EA2-C0192 | P3 | fs-id1170654031695 and fs-id1170654035773 | “mixed units of measures” must be “mixed units of measure” or simply “mixed units.” |
| EA2-C0193 | P3 | fs-id1170654192559; fs-id1170654073701; fs-id1170654080766 | Repair attributive measures: 1-pound 2-ounce steak, 6-foot 6-inch / 3-foot 8-inch cords, and a 2-foot 10-inch box. |
| EA2-C0194 | P3 | fs-id1170653772190 and fs-id1166423033430 | Correct “millileters” and “exerices.” |
| EA2-C0195 | P3 | fs-id1170654125330; fs-id1170654022367; fs-id1170654154257 | Correct weighted→weighed and weights→weighs in three problem statements. |
| EA2-C0196 | P3 | fs-id1170654149007; fs-id1170653870080; fs-id1166424994187 | Add the missing terminal period and remove two duplicated commas. |
| EA2-C0197 | P3 | fs-id1170654182318 | Chapter-review heading “1.1 Define U.S. Units…” must identify section 1.10, not 1.1. |
| EA2-C0198 | P3 | fs-id1170652940512 | Supplied answer “1.12 meter” must be “1.12 meters.” |
| EA2-C0199 | P3 | fs-id1170654238544 | Remove duplicated “the” in “on the the SUV.” |
| EA2-C0200 | P3 | fs-id1170653895608 and fs-id1170654151020 | Preserve source/ID parity but suppress two genuinely empty trailing solution paragraphs in assembled readers. |
| EA2-C0201 | P3 | 29 media IDs listed below | PNG declarations point to JPEG bytes; use truthful JPEG metadata or deterministic real-PNG derivatives. |
| EA2-C0202 | P3 | 25 media IDs listed below | Recreate reader-visible English rasters as localized semantic content. |
| EA2-C0203 | P3 | 14 media IDs listed below | Replace cramped math-only raster strips with reflowable MathML/SVG/HTML equivalents. |

## Accessibility audit

- 44/44 media elements have nonempty alt text.
- 18/18 tables have an accessibility attribute: 14 aria-label and 4 summary.
- Total audited accessibility attributes: **62**.
- Every alt was compared with its decoded raster. The four exact accessible-content defects are EA2-C0179, EA2-C0180, EA2-C0181, and EA2-C0186; EA2-C0187 and EA2-C0188 are lower-severity summary/narration copy defects.
- fs-id1170654027716 voices “foot equals inches,” “yard equals feet,” and “mile equals feet,” omitting the visible factors 12, 3, and 5,280.
- fs-id1170654071984 omits “1” twice from the Figure 017a instructional text, although the raster says “multiply … by 1.”
- eip-id1169750704513 omits the 14-ounce first steak and therefore does not describe the displayed addition that produces 2 lb 22 oz.
- eip-id1169753123087 calls the final row “Simplify,” while the visible table labels it “Multiply.”
- eip-765 provides only a generic table summary; the correction should name the actual metric subtraction.
- eip-id1169754143940 and eip-id1169748340002 each duplicate “we have.”
- The other 42 alts and 13 table descriptions accurately cover their visible source surfaces. Four solution paragraphs contain media rather than text and are not empty semantic records.

The 18 table IDs are:

fs-id1170654027716, eip-id1169750866374, eip-id1169753123087, eip-id1169754171774, eip-id1169750704484, eip-id1169750705411, fs-id1170653789448, eip-id1169752203306, eip-id1169750760364, eip-id1169754143940, eip-id1169748340002, eip-765, eip-270, fs-id1170653913870, eip-461, eip-310, eip-id1169749562678, and eip-id1169750701791.

## Links and reference closure

All 11 local links resolve uniquely:

| Owner | Target |
|---|---|
| fs-id1170653916421 | fs-id1170654027716 |
| fs-id1170654027574 | fs-id1170654027716 |
| fs-id1170652648089 | fs-id1170653789448 |
| fs-id1170653792025 | fs-id1170653898510 |
| fs-id1166422551215 | fs-id1170653789448 |
| fs-id1166422551215 | fs-id1170653789448 |
| fs-id1170654236427 | fs-id1170653913870 |
| fs-id1170653893032 | CNX_ElemAlg_Figure_01_10_008 |
| fs-id1170653881351 | CNX_ElemAlg_Figure_01_10_009 |
| fs-id1170653736108 | CNX_ElemAlg_Figure_01_10_010 |
| fs-id1170653807898 | CNX_ElemAlg_Figure_01_10_011 |

The empty bodies are intentional auto-label surfaces. Nine chapter-review links declare documents m82452, m82453, m82454, m82456, m82457, m82458, m82459, m82460, and m82461. They were inventoried as declared cross-document dependencies; resolving sibling modules was outside this bounded audit. There are no URL links.

## Direct asset closure

All 44 references are unique, present, and PIL-decodable. Every byte stream is JPEG. Total referenced bytes: **2,422,030**.

| Media ID | File | Bytes | Dimensions | Declared → actual MIME | SHA-256 |
|---|---|---:|---:|---|---|
| fs-id1170653895402 | CNX_ElemAlg_Figure_01_10_016_img_new.jpg | 44,302 | 419×123 | JPEG → JPEG | 1b875095e4e42b284168536f73aa50cf9d3e60a71606f5ce45cf2460368e8542 |
| fs-id1170654071984 | CNX_ElemAlg_Figure_01_10_017a_img_new.jpg | 110,429 | 718×145 | JPEG → JPEG | 073007c43944c22f0b6eee57ff2eecfd0dde9c2e4679994556f612644ef05cdb |
| fs-id1170654026865 | CNX_ElemAlg_Figure_01_10_017b_img_new.jpg | 68,843 | 718×90 | JPEG → JPEG | d99d98e4a7f6783588559fa9088a33092a94601672db4150036f78c72fb6c750 |
| fs-id1170654030491 | CNX_ElemAlg_Figure_01_10_017c_img_new.jpg | 74,136 | 718×102 | JPEG → JPEG | 7c0aeb0c57a17720d4f113a78d02a73f9af6eed4a04d649af798fdd50af35e98 |
| fs-id1170653797102 | CNX_ElemAlg_Figure_01_10_017d_img_new.jpg | 64,807 | 718×38 | JPEG → JPEG | bd502ce33b9e3134dc04820e730fff58416463a44d78785f75e606facb5844cf |
| eip-id1169750866446 | CNX_ElemAlg_Figure_01_10_018_img_new.jpg | 32,894 | 186×43 | PNG → JPEG | cc5b8da479ad18b9a56337d6f819aa9cf309cbb30a3f27994d16530f067bd44f |
| eip-id1169753123179 | CNX_ElemAlg_Figure_01_10_001_img_new.jpg | 32,663 | 258×62 | PNG → JPEG | 918f7d26cc24d569232f9368a7caa9923239ca68930b5297aedaee516e47b503 |
| eip-id1169750758852 | CNX_ElemAlg_Figure_01_10_019_img_new.jpg | 14,923 | 458×62 | PNG → JPEG | 9f0021dd14f6df3088f549ca9f110e385a01dde09a0f5f07ef2b0c7f961ec260 |
| eip-id1169750704513 | CNX_ElemAlg_Figure_01_10_014_img_new.jpg | 11,662 | 211×127 | PNG → JPEG | edbcfbee8e9432b5b7610cb5c1a95efacf04a5260634d44eb2e8792013c33d44 |
| eip-id1169750705429 | CNX_ElemAlg_Figure_01_10_015a_img_new.jpg | 29,333 | 188×74 | PNG → JPEG | 83942f2b03b8c1e5300bb93d499eff4eb5fbcb303c29e2ba17346f9733f61cce |
| eip-id1169750705447 | CNX_ElemAlg_Figure_01_10_015b_img_new.jpg | 29,159 | 188×45 | PNG → JPEG | 72458a111d3cea6f4f16847cce15a8c0ce380072bc168b780dbfad9aff2edfb8 |
| eip-id1169752203335 | CNX_ElemAlg_Figure_01_10_002a_img_new.jpg | 28,445 | 221×14 | PNG → JPEG | 2cfc88d3abf22ef6da9e83b068b44d57af3e2789e20ee6a40aeaea4300f226a8 |
| eip-id1169752202935 | CNX_ElemAlg_Figure_01_10_002b_img_new.jpg | 33,884 | 221×32 | PNG → JPEG | 1849fe8260ed7d1d76e3962d8befcb75a19677ed9677d55b7a028ce780781245 |
| eip-id1169752202952 | CNX_ElemAlg_Figure_01_10_002c_img_new.jpg | 36,039 | 221×32 | PNG → JPEG | 04d20272303859f93b8631ee6fa9005a025c0e5a2d0b33bb53507b50481df985 |
| eip-id1169750760384 | CNX_ElemAlg_Figure_01_10_004a_img_new.jpg | 27,311 | 206×17 | PNG → JPEG | 5760a49d34c0d98fe88ab0ecc32c505a6ba8aa547b19c8610541aef493eea508 |
| eip-id1169750760403 | CNX_ElemAlg_Figure_01_10_004b_img_new.jpg | 26,528 | 206×17 | PNG → JPEG | 1be3fe071b055b9196867ef04d6c21110ab6521ea1d66229aac0fab7fd1ac653 |
| eip-id1169750760421 | CNX_ElemAlg_Figure_01_10_004c_img_new.jpg | 29,799 | 206×38 | PNG → JPEG | 2c38a309ea4526ee71ec6c90a45e796a275726bc09824fb3f227af3b99911689 |
| eip-id1169750760440 | CNX_ElemAlg_Figure_01_10_004d_img_new.jpg | 30,980 | 206×38 | PNG → JPEG | 42be9ec296fd2dea0b20b4a9eb803357f3957306b2d350647ab119f6a2a32a7d |
| fs-id1170654008560 | CNX_ElemAlg_Figure_01_10_005_img_new.jpg | 25,852 | 192×67 | JPEG → JPEG | fa6d1936518322c7fb999d431179fea9b089ed3ed5cb516b3b03a4ab87cd0ac7 |
| eip-id1169754197015 | CNX_ElemAlg_Figure_01_10_006_img_new.jpg | 9,029 | 358×29 | PNG → JPEG | 9e4eeddc4d31e4aac0ecd7f2f07e9a4873254d27bf0ba29c11c9f961e85852c1 |
| eip-id1169748340021 | CNX_ElemAlg_Figure_01_10_007a_img_new.jpg | 22,909 | 122×13 | PNG → JPEG | b12ef83276bf210475e5642d89f543472344ff51e32465dd20cc109046b8021f |
| eip-id1169748340038 | CNX_ElemAlg_Figure_01_10_007b_img_new.jpg | 28,976 | 122×33 | PNG → JPEG | 17634420e56113f38b3e195bd5a804aa845ff1b1b1705297aeac2667ca4a439c |
| eip-id1169748340054 | CNX_ElemAlg_Figure_01_10_007c_img_new.jpg | 29,978 | 122×36 | PNG → JPEG | 4e1828c331eff9ebf5d491246ab77f3db323552d773ce93f5cd50481dfb65147 |
| eip-id1169748340071 | CNX_ElemAlg_Figure_01_10_007d_img_new.jpg | 29,345 | 122×36 | PNG → JPEG | 350266d3897844bd52a5280f005fc42cc07fa3dab92f3abf7cce7925fbb7a053 |
| eip-id1169748340087 | CNX_ElemAlg_Figure_01_10_007e_img_new.jpg | 26,536 | 122×16 | PNG → JPEG | 59a79c6d3a52bdbc48e6349ecd84979629af15eca388756fe0bc6a0e00515806 |
| fs-id1170654009196 | CNX_ElemAlg_Figure_01_10_008_img_new.jpg | 50,644 | 419×73 | JPEG → JPEG | ca00d25779c91ba8091682bd6434d952a23a7cbf677f50c2ce2f68990c9ecac7 |
| fs-id1170654030469 | CNX_ElemAlg_Figure_01_10_009_img_new.jpg | 664,497 | 268×222 | JPEG → JPEG | 8246a50f7307cc669d0294bd4fa690c90c6b3ffd93fe7f0cda7d1a1cb352e2f9 |
| fs-id1170653910440 | CNX_ElemAlg_Figure_01_10_010_img_new.jpg | 124,664 | 527×258 | JPEG → JPEG | 6712072038bfbb4c315d9c0c001b12fc3fe22923f34704e8394d98038e92b423 |
| fs-id1170654141345 | CNX_ElemAlg_Figure_01_10_011_img_new.jpg | 93,691 | 363×614 | JPEG → JPEG | ea2ef10ea34e9e4c9fc7cdea1a1099ca1e4c6c7899de8a30d842df8b6b39886e |
| eip-id1169752086556 | CNX_ElemAlg_Figure_01_10_012b_img_new.jpg | 37,174 | 114×32 | PNG → JPEG | be86ab9ad95ccd91dd0ad5786e85e866d8fc93b196aaad33f0b84bfa7e51ae87 |
| eip-id1169752086570 | CNX_ElemAlg_Figure_01_10_012a_img_new.jpg | 37,905 | 149×15 | PNG → JPEG | 4e7605b3786042161c11edd04bd15b3da7f6040545105ed7ffbaf06bd9de3fea |
| eip-id1169752086580 | CNX_ElemAlg_Figure_01_10_012c_img_new.jpg | 38,872 | 114×32 | PNG → JPEG | 5d7f71a8120b38a3ad7e3372f4ff506fd44b4606957c44146fb3f47c8d6c7902 |
| eip-id1169752086596 | CNX_ElemAlg_Figure_01_10_012d_img_new.jpg | 36,801 | 114×32 | PNG → JPEG | a2996c5c120ae280db0bc91a6658b0da2ce283133fa73e01274a2ede411058d2 |
| eip-id1169752086613 | CNX_ElemAlg_Figure_01_10_012e_img_new.jpg | 34,150 | 114×13 | PNG → JPEG | 1dd5f34647fa3b499e5151f53743f99b85bcb2eab0e1cf7be36b88ba52bfb99f |
| eip-id1169750701810 | CNX_ElemAlg_Figure_01_10_013b_img_new.jpg | 38,443 | 117×32 | PNG → JPEG | 9d2cfc9a8b0f7392d8cff30f79bae2384ee76078581403252cdadd951f0e694a |
| eip-id1169750701824 | CNX_ElemAlg_Figure_01_10_013a_img_new.jpg | 37,038 | 149×15 | PNG → JPEG | ea6c428d7be5086917c7dd052eacc75050c7387d55e0efddc5a5249ae6a6d2af |
| eip-id1169750701834 | CNX_ElemAlg_Figure_01_10_013c_img_new.jpg | 40,129 | 117×32 | PNG → JPEG | c201adce2dd0c27f2ab344a1572392500ae79cd0e2a0660f24b59dfea2378834 |
| eip-id1169750701850 | CNX_ElemAlg_Figure_01_10_013d_img_new.jpg | 39,001 | 117×13 | PNG → JPEG | 0f9013607592f3ddc8eafc0718d77a1885ad7c8af721d3b2441f5ee80e0e34e1 |
| eip-id1169750701867 | CNX_ElemAlg_Figure_01_10_013e_img_new.jpg | 40,496 | 117×13 | PNG → JPEG | 07382b1e991e98c175dcd79f0556cacc72d65e6f3a7c9362b10a12f30f17587b |
| fs-id1170654113998 | CNX_ElemAlg_Figure_01_10_201_img_new.jpg | 115,073 | 632×301 | JPEG → JPEG | 993ee163ec20e33cd359bf549ec337766e1eaca3d565762f88b072b862fa11d8 |
| fs-id1170654230878 | CNX_ElemAlg_Figure_01_10_202_img_new.jpg | 24,693 | 243×75 | JPEG → JPEG | 4fb3f157dbfd51cf57acdb243f3fb81a67d7f0824c6fbd61eb7cc3f2740aa58d |
| fs-id1170653773218 | CNX_ElemAlg_Figure_01_10_204_img_new.jpg | 23,184 | 243×77 | JPEG → JPEG | 20854f18333215cf7b9949e097ac6ee66f5e13f12ea400f2e2ad2c15e8557929 |
| fs-id1170652629303 | CNX_ElemAlg_Figure_01_10_206_img_new.jpg | 23,517 | 243×60 | JPEG → JPEG | 92d37d747920bee88357ff310fe5b76e272bc9c2b3d928435b2ea77e6f569b88 |
| fs-id1170654148784 | CNX_ElemAlg_Figure_01_10_208_img_new.jpg | 23,296 | 243×62 | JPEG → JPEG | f4a6bc23be46ead33c44fa6fa8a4d1373d98e85d0363ee0e0ec3fbe5db7f0115 |

Deterministic closure receipts:

- Asset-manifest SHA-256: **9c19378fb516fb18419df345b313ed4a5e4a4b85646690a944b32ab1fc4a9865**. In media document order, each LF-terminated row is media-id TAB src TAB bytes TAB sha256 TAB declared-mime TAB actual-mime.
- Raw source-plus-assets SHA-256: **d1b9c54f7ebb555bfde6389eea8bcea7d63e65ba975d5ff21d88fb172c32d791**. Preimage is raw CNXML followed without separators by every referenced asset in media document order.
- MIME was identified from byte signatures and successful image decoding. Exactly 29 image/png declarations point to JPEG streams; the remaining 15 declarations are truthful image/jpeg.

## English-labelled rasters and reflow obligations

Exactly 25 rasters contain reader-visible English and require localized semantic reconstruction:

fs-id1170653895402, fs-id1170654071984, fs-id1170654026865, fs-id1170654030491, fs-id1170653797102, eip-id1169750866446, eip-id1169753123179, eip-id1169750758852, eip-id1169750704513, eip-id1169750705429, eip-id1169750705447, eip-id1169752203335, eip-id1169752202935, eip-id1169752202952, eip-id1169750760384, eip-id1169750760403, eip-id1169750760421, eip-id1169750760440, eip-id1169754197015, fs-id1170654009196, fs-id1170654030469, fs-id1170654141345, eip-id1169752086570, eip-id1169750701824, and fs-id1170654113998.

EA2-C0202 requires prose/MathML/table/SVG reconstruction rather than translated alt text alone. In particular, Figure 201 must become a semantic localized self-check table; Figure 011 needs localized thermometer labels; Figures 008 and 009 need localized scale labels; and the worked strips must become selectable content with preserved reading order.

Fourteen additional math-only rasters are only 13–67 pixels high or are multi-step strips that become cramped/blurry in a page-width reader:

fs-id1170654008560, eip-id1169748340021, eip-id1169748340038, eip-id1169748340054, eip-id1169748340071, eip-id1169748340087, eip-id1169752086556, eip-id1169752086580, eip-id1169752086596, eip-id1169752086613, eip-id1169750701810, eip-id1169750701834, eip-id1169750701850, and eip-id1169750701867.

EA2-C0203 requires reflowable MathML/SVG/HTML equivalents, preserving source IDs, alt witnesses, asset hashes, visual cancellation/arrows, and rights provenance. The scale fs-id1170653910440 and four number-line assets fs-id1170654230878, fs-id1170653773218, fs-id1170652629303, and fs-id1170654148784 are neither English-labelled nor cramped formula strips; they remain valid direct assets.

## Source-preservation disposition

The authoritative CNXML and all 44 direct assets remain byte-identical. Reader corrections must be admitted through the correction ledger from the rows in PROPOSED_CORRECTIONS.csv; source-origin text, formulas, IDs, references, assets, and hashes remain immutable witnesses. Upstream reporting is deferred for later deduplication into at most one concise corpus-level issue.
