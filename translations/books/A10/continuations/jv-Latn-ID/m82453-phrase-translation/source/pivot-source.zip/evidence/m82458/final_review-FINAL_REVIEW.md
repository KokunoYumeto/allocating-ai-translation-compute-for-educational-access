# m82458 Final Admission Review

Boundary: `EA2-B0008-m82458`  
Reviewed: 2026-08-21  
Verdict: **PASS** (`P1=0`, `P2=0`, `P3=0`)

## Frozen identity

- Authority: 130,960 bytes; SHA-256
  `678dc0c3ae2aad0192c0314395541720d6c6eb97f56d2f4d169f056fe1e630cb`.
- Indonesian target: 125,305 bytes; SHA-256
  `ce2d93e04d449194c5b3f82c0e857f2ce3b216113b80b310625b7cc0a7702172`.
- Machine audit: 2,136 bytes; SHA-256
  `69c5db4cf04027df3ea886407ce6ddc2a06cffbba284680edcaa93e57faa3a41`.
- Target manifest: 102 bytes; SHA-256
  `ef4c40d9b0f8d7e15f03eb598d5310d7fd0f5c22c19dbf2845c7f63b117322e9`.
- Exception declaration: 1,262 bytes; SHA-256
  `1331f82b8e87204419d41915bd18ab9972984d081301485891074a88a0833fda`.
- Source semantic audit: 18,711 bytes; SHA-256
  `3ac654124701a5b7ec2e88d2be82abbe8830927077236c3ef295c6a21afac12f`.
- Terminology/accessibility plan: 16,310 bytes; SHA-256
  `ece5bcff42c1500fa5315d43c6adb09e6de7aa3b6fed6170504086de1aeaf105`.

## Exact structural and asset result

The source contains 2,989 elements and the target contains 2,987. The only
topology delta is the intentional removal of a stray leading `mn` zero and its
following `mspace` from equation `fs-id1170655111307`. The source renders the
malformed expression `0 0.03 = 3/100`; the target correctly renders
`0.03 = 3/100`. One exact structural exception binds owner, math index, source
and target canonical hashes, and the `mn −1` / `mspace −1` delta. After that
replacement is normalized, ordered topology and child vectors are exact.

All 1,013 IDs remain unique and in exact source order. Non-reader attributes,
references, source media paths, and MIME declarations are unchanged. The
target retains 11 sections, 17 examples, 179 exercises and problems, 115
supplied solutions, 22 tables, 49 media, and two resolving local links. The
1,291 target MathML elements have no protected `mn`, `mo`, or `mi` drift; only
11 lexical `mtext` nodes are translated.

All 49 direct rasters exist and total 3,002,999 bytes. Their ordered manifest
hash is `189e04c9cd3fa0075018bfba608a7db4264fc73e8381d61111cdf3cfd4a21a11`;
their ordered raw-byte concatenation hash is
`be51f51905f6824f67ad714ad07489f1386f9ba4c588d577582866d5d308fcf6`.
Thirty-one inherited `image/png` declarations point to JPEG bytes and remain
recorded derivative-assembly debt rather than silent source edits.

## Mathematics and source corrections

Independent mathematical review checked all 179 problems and all 115 supplied
solutions, including signs, rounding precision, decimal/fraction/percent
conversion, repeating blocks, currency, and open-response dispositions. No
answer-key arithmetic error remains. The accessible path for `−5/8` now states
the full result `−5/8 = −0.625` in both visible Indonesian prose and alt text.

Twenty-one reader corrections are applied and recorded. They include the
decimal-places multiplication rule, the stray MathML zero, the dropped
negative sign, three meaning-changing table narrations, incorrect rounding
digits and place names, misleading arrow descriptions, corrupted `$3.99`, an
omitted leading zero, duplicated table narration, and bounded source copyedits.
Two further records preserve the procedure-scope gap and the grouped MIME debt.
All 23 correction candidates passed exact owner-level final assertions.

## Language and accessibility

All 343 English-bearing direct reader slots are translated and nonblank. The
place-value naming lesson is retained but explicitly identified as the method
used in the source lesson. A concise first-use note explains ordinary
Indonesian `koma` reading while retaining source dot-decimal and comma-grouping
notation consistently with formulas, exercises, answers, and images. English
`-th` is explained transparently as Indonesian `per-`; ten-thousandths use the
unambiguous form `per sepuluh ribu`.

Exactly 71 reader-facing accessibility attributes are localized: 49 alts, 17
ARIA labels, and five summaries. All 28 English-labelled source rasters are
explicitly disclosed and their meaningful labels or mathematical actions are
given in Indonesian. Numeric-only rasters are described semantically without a
false disclosure. All 11 English-bearing MathML `mtext` nodes are Indonesian.
Final residue, terminology, grammar, inline-boundary, punctuation, and spacing
checks pass.

This admission does not claim a rendered reader build, full-page visual QA, or
publication. Those remain later book-level gates.
