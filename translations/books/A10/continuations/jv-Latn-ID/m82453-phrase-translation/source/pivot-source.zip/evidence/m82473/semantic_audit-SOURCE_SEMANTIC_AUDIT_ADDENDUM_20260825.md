# m82473 source semantic and accessibility audit addendum

Status: **complete audit; 21 high-confidence source defects bounded for target-only correction; frozen source unchanged**

Model provenance: OpenAI Codex gpt-5.6-sol, Ultra.

## Authority and method

- Frozen source: `authority/source/modules/m82473/index.cnxml` — 124,371 bytes — SHA-256 `e6dc099430c7ecd3d26f843827ac2f89936a2fe30b09f1ffd02b23622d278ec2`.
- Scope: all 12 `aria-label` values, five table `summary` values, 49 media `alt` values, nearby visible prose and equations, and all 49 directly referenced rasters.
- Method: compare each accessibility surface with its owning visible content, protected MathML, adjacent problem/solution, and when relevant the exact raster bytes. Only deterministic, high-confidence discrepancies are recorded. Style preferences are excluded.
- Disposition: the authority bytes remain immutable. The Indonesian target expresses the verified meaning. Nothing is submitted upstream during translation; any later upstream report remains subject to the single, unsigned, full-corpus rule.

## Additional findings

1. **M82473-A01 — ambiguous equation alt.** `eip-id1167269798270@alt`, source line 114, says `eta = 31.5` or `n = 31.5`. Raster `CNX_ElemAlg_Figure_03_02_001c_img_new.jpg`, SHA-256 `69c708c0c505ec1cfe0b9a1cd99702f4fcdd85faae2514feccf00012f28588c5`, unambiguously shows `n = 31.5`. Target slot: `s00034`.
2. **M82473-A02 — spurious operator punctuation in alt.** `eip-id1167270035889@alt`, line 228, represents `144 = p · 96` as `144 = p ×. 96`. Raster SHA-256 `a44ef45032c47da161b292a16793e93aa96cae51411e6fbb1226da11cfa90eef` shows one multiplication dot. Target slot: `s00067`.
3. **M82473-A03 — broken word order.** Visible table text owned by `eip-id1167270258146`, line 308, says `the amount of tip should Dezohn leave`; the problem asks for `the amount of tip Dezohn should leave`. Target slot: `s00109`; the table label in `s00104` also uses the intended meaning.
4. **M82473-A04 — wrong variable in alt.** `eip-id1167266359735@alt`, line 408, says `85 = 0.02 * q`; its raster, table label, visible definition, and result use `a`. Raster SHA-256 `0bf7d0eb9403462afba438a0d869927714d5bb65c160b81a4e528f993f1a525f` visibly shows `85 = 0.02 · a`. Target slot: `s00154`.
5. **M82473-A05 — added variable in alt.** `eip-id1167263490699@alt`, line 498, claims the raster shows `p = 50%`; raster SHA-256 `fd97e4bdfca24f3b411222f9acd02a6a19ba7d21723223f0853813a3ba61d63c` shows only `50%`. Target slot: `s00192`.
6. **M82473-A06 — defective final-answer predicate.** Visible text owned by `eip-id1167266128044`, line 511, says `50% is fat`; the quantity is a share of calories, so the complete meaning is `50% of the calories come from fat`. Target slot: `s00198`.
7. **M82473-A07 — wrong rounded percentage.** `eip-id1167265455648@aria-label`, line 563, and visible check text at line 626 use `0.384` and `38.4%`. Deterministically, `10/26 = 0.384615…`, which rounds to `0.385` and `38.5%`. The worked rasters and final visible answer at line 631 already show `0.385` and `38.5%`. Target slots: `s00217` and `s00246`.
8. **M82473-A08 — increase/decrease mismatch.** `eip-id1167267830176@aria-label`, line 677, tells the reader to find the amount of increase in a percent-decrease example. The operands `3.71 − 3.64 = 0.07` and every adjacent label establish the amount of decrease. Target slot: `s00269`.
9. **M82473-A09 — visible typo.** Visible table text owned by `eip-id1167267830176`, line 705, says `original amaount`; intended text is `original amount`. Target slot: `s00284`.
10. **M82473-A10 — duplicated multiplication sign in alt.** `eip-id1167267833215@alt`, line 714, says `0.07 = p ××3.71`. Raster SHA-256 `2447422cdc48f0aa44a67e11da58e7f987409e4845077875cdc91b83d709e3bd` shows one multiplication dot. Target slot: `s00287`.
11. **M82473-A11 — missing independent clause.** `fs-id1168345390261`, line 772, says `The interest is computed as a certain percent of the principal; called the rate of interest, r.` The intended second clause requires a subject: `This percent is called the rate of interest, r.` Target slot sequence includes `s00311`.
12. **M82473-A12 — table-label structural and lexical mismatches.** `eip-id1167269931674@aria-label`, line 1060, incorrectly places `Read the problem again` in the first table row although it is outside the table; says `sales price` instead of `sale price`; and ends with redundant `$91 dollars`. Lines 1063–1107 establish the actual six-step table and exact `$91` answer. Target slot: `s00473`.
13. **M82473-A13 — wrong variable case in two alts.** `eip-id1167265671550@alt` and `eip-id1167266227365@alt`, lines 1085 and 1090, use uppercase `S`; the defined variable and both rasters use lowercase `s`. Raster SHA-256 values: `c58b3a783b292f980ba68885ae3b633365c021572571c45bfb909af0af2e2339` and `5a957b122f04820d05d782c60a03c41d9c3ea7e038c9f99d92080adf10abe6f4`. Target slots: `s00487`, `s00490`.
14. **M82473-A14 — corrupted currency values in table label.** `eip-id1167271021883@aria-label`, line 1188, twice says `7.05 ... >1`. Nearby visible text, raster alts, equations, and arithmetic all establish `$17.05 ... $31`. Target slot: `s00542`.
15. **M82473-A15 — mathematically false percent-increase answer.** Problem `fs-id1168345431724`, line 2080, asks what `200% more shirts` means; answer `fs-id1168345431731`, line 2083, says twice as many. A 200% increase adds twice the original to the original, yielding three times as many. Target slot: `s00822`.
16. **M82473-A16 — wrong self-check table dimensions.** `fs-id1168345511139@alt`, line 2095, says two rows and four columns while it then enumerates one header plus five objective rows. Raster `CNX_ElemAlg_Figure_03_02_201_img_new.jpg`, SHA-256 `2999e98dfe2fad0ec06741d8164ef78c28cd6b936a4c150bfa31075eb9e4f9c1`, visibly has six rows and four columns. Target slot: `s00826`.

## Previously sealed findings

17. **M82473-SD01.** `eip-id1167271405408` visible text, line 1343: `phtograph` → `photograph`; target slot `s00623` expresses `foto`.
18. **M82473-SD02.** `eip-id1167267776590@aria-label`, line 1350: `origin cost` → `original cost`; target slot `s00624` uses `harga beli`.
19. **M82473-SD03.** The same label says `mores than the net price` and ends the comparison as a statement; intended meaning is `more than the original cost?`; target slot `s00624` uses the correct comparison and question.
20. **M82473-SD04.** Visible text owned by `eip-id1167267776590`, line 1394, says `net price` although the example defines and compares the original cost; target slot `s00646` uses `harga beli`.
21. **M82473-SD05.** `fs-id1168345510016`, line 2125, inserts a comma between subject and predicate in the original-cost definition; target slot `s00839` has normal punctuation.

## Admission gate

Admission requires all 21 findings to have exact target witnesses and live `05_CORRECTIONS.csv` rows, with the frozen source hash unchanged. The correction rows must remain local and unsubmitted while the corpus is incomplete. The module must also retain all CNXML IDs, topology, MathML, references, assets, and exact source-style numeric punctuation except where a recorded mathematical or accessibility correction changes the source value.
