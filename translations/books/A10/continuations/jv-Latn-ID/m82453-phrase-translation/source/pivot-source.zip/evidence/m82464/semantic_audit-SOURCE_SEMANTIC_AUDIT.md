# m82464 source semantic and mathematical audit

## Authority and bounded scope

- Frozen source: `authority/source/modules/m82464/index.cnxml`.
- Exact source size: **133,732 bytes**.
- Exact source SHA-256: **099aae173772040a83d8c9160980922315352fc2a699af7c6f25ddc594a0c0bc**.
- Module metadata: content ID `m82464`; UUID `b879afa3-111c-4c63-a6fd-751ce025accd`; title **Solve Equations using the Division and Multiplication Properties of Equality**.
- Collection witness: `authority/source/collections/elementary-algebra-2e.collection.xml`, **5,256 bytes**, SHA-256 **5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72**.
- Collection membership: `m82464` occurs exactly once among the 82 ordered `col31130` module references, at one-based source order **15**, between `m82463` and `m82465`.
- Direct-media boundary: the 73 `image/@src` references in this CNXML, each resolved to `authority/source/media` in document order.
- The frozen source, direct assets, translated targets, live ledgers, backend, readers, sibling modules, and other books were not edited. This packet records only source-side controls in `qa/m82464`.

## Verdict

The source is well-formed XML. All **798 IDs are unique**. Every one of the **141 exercises** has exactly one direct problem. Exactly **93** have one direct supplied solution and **48** intentionally have none; no exercise has multiple problems or multiple solutions. All 93 supplied answers and worked checks were independently recomputed or verified against their stated problems. The 48 unsupplied problems were also solved independently to establish that each is coherent and that the alternating answer-key omissions do not conceal broken relations. There are **no P1 mathematical defects and no wrong supplied answers**.

Nineteen correction candidates remain. Fourteen are target-applicable: three P2 mathematical/accessibility defects and eleven P3 copy/accessibility defects. Five are assembly-only raster, MIME, localization, and reflow records. Correction inventory: **P1 0 / P2 3 / P3 16**. Target-applicable range: **EA2-C0223–EA2-C0236**. Assembly-only range: **EA2-C0237–EA2-C0241**.

Frozen authority remains byte-identical. No correction is applied merely by being described here.

## XML and topology inventory

| Surface | Count |
|---|---:|
| All elements | 3,652 |
| CNXML namespace elements | 1,424 |
| MDML namespace elements | 4 |
| MathML namespace elements | 2,224 |
| IDs / unique IDs / duplicate IDs | 798 / 798 / 0 |
| Titles, total / unique normalized strings | 28 / 14 |
| Sections / notes / examples | 10 / 34 / 14 |
| Lists / items | 2 / 6 |
| Paragraphs / captions | 267 / 2 |
| Exercises / problems / supplied solutions | 141 / 141 / 93 |
| CNXML equations / MathML roots / MathML elements / `mtext` | 3 / 291 / 2,224 / 40 |
| Tables / rows / entries | 15 / 106 / 259 |
| Figures / media / images / unique direct assets | 2 / 73 / 73 / 73 |
| Links, total / internal / cross-document / URL | 4 / 2 / 2 / 0 |
| Terms / definitions / glossary nodes | 3 / 0 / 0 |
| Reader-facing attributes, `alt` / `aria-label` / `summary` / `title` | 73 / 13 / 2 / 0 |

Deterministic topology receipts:

- Ordered-ID SHA-256: **653a9fddc5223d5f345d1ff0645816c2d17beb42c4a4d2a43b214a5061e13dae** over **15,161 bytes**. Preimage is every nonempty ID in document order, LF-joined without a terminal LF.
- Topology SHA-256: **d579a67287b5c0360355ae3902716fda5dc27107f2ab99108dfabe56b8eba6db** over **154,595 bytes**. Each preorder element contributes expanded tag, TAB, and ID-or-empty; rows are LF-joined without a terminal LF.
- Math semantic-surface SHA-256: **bc5b3710ac4c3f74798a273c958424530e046425011fc10a54170be24bd66116** over **97,643 bytes** across 2,224 MathML elements. Each MathML element contributes expanded tag, sorted attributes, and normalized direct text in document order.

## Exhaustive reader-block projection

The exact structural reader projection contains **562 blocks**:

- 28 `title`;
- 267 `para`;
- 6 `item`;
- 259 `entry`;
- 2 `caption`.

Exactly **421** blocks have normalized descendant text. Exactly **141** do not: 70 media-only table entries and 71 intentional empty grid/spacer entries in worked tables. No paragraph, title, item, or caption is unexpectedly empty. The 71 blank entries preserve table geometry and are not missing translations; native reader reflow may replace their layout role while maintaining source topology provenance.

Projection contract: each LF-terminated row is `ordinal|local-name|nearest-id-owner|sha256(normalized-descendant-text)|has-text`. The projection is **56,568 bytes**, SHA-256 **286c4f320a2600aa78364eaba3740e00eebb08073942007957d7d6b6f3795290**. First row:

`1|title|title|a99d96f6abb085ed455e38030c43cfbfd2a4c1f76625aa5a2ac3746167fc951b|1`

Last row:

`562|para|para#fs-id1168343052954|5bb3c89160718282936d4c5d85a9ea383f76e9b263a0cdd6731e5035d0915f5d|1`

This is the exhaustive translation traversal. A translator must visit all 562 slots in order, translate all 421 text-bearing blocks, preserve the media-only structures, and retain provenance for the 71 intentional empty table cells without inventing prose.

## Exercise, answer, and mathematical audit

Deterministic relation receipts:

- Exercise topology ledger: **141 rows / 7,154 bytes**, SHA-256 **4294b3a30c68d2e020c7645c305feea9e4b091625e74ab7312a4e1f3cfdbae99**. Each row is exercise ID TAB problem ID TAB solution-ID-or-empty, LF-joined without terminal LF.
- Supplied pair ledger: **93 rows / 3,521 bytes**, SHA-256 **a2e518c48d5faf1522e8c6ccdf3a397683468cb4e16bc1bae880dd4b63d0bc5b**. Each row is problem ID TAB solution ID.
- Unsupplied-problem ledger: **48 rows / 911 bytes**, SHA-256 **a0ba9c6de9029e42a3d69fc50d04e500cc5e230bfd7217f667f312860b9a3a2b**. Each row is one problem ID.
- Independent ordinal coverage ledger: **141 rows / 7,659 bytes**, SHA-256 **a0ec74bdb3ff142d2605fb46f628f1543fc6211aeb6f43a423409831fbcc62d1**. Each LF-terminated row is ordinal TAB exercise ID TAB problem ID TAB solution-ID-or-hyphen.
- Worked-example ledger: **14 rows / 531 bytes**, SHA-256 **14ec0a6fca13677d6606215c823d67663d0b02d183517df72b0ccb5b249e5ad6**. Each row binds one example ID to its descendant exercise ID(s), LF-joined without terminal LF.

Coverage by instructional wrapper:

| Wrapper | Exercises | Supplied solutions |
|---|---:|---:|
| Readiness notes before the first section | 2 | 2 |
| Solve Equations Using the Division and Multiplication Properties of Equality | 15 | 15 |
| Solve Equations That Require Simplification | 6 | 6 |
| Translate to an Equation and Solve | 15 | 15 |
| Translate and Solve Applications | 6 | 6 |
| Practice Makes Perfect | 93 | 47 |
| Everyday Math | 2 | 1 |
| Writing Exercises | 2 | 1 |

The 48 unsupplied problems follow the source's intended alternating answer-key pattern in practice, everyday-math, and writing sections. Independent recomputation covered integer, fraction, decimal, and zero-coefficient cases; variables on either side; equations requiring simplification and distribution; product, quotient, and fractional-part sentence translations; unit-price, proportional-area, commission, stamp, height, and mileage applications; and the two explanatory writing prompts. Every problem is well-posed under the stated elementary-algebra conventions.

The 93 supplied surfaces were recomputed independently. This included all 14 worked examples, all displayed division/multiplication steps and reciprocal cancellations, every question-over-equals verification, the Denae and Andreas solution tables, the supplied odd-numbered practice answers, and the final supplied application and writing responses. The algebra and numeric results are correct. In particular:

- `5x=-27`, `y/-7=-14`, `-n=9`, `(3/4)x=12`, and `8/15=-(4/5)x` preserve signs, division restrictions, and reciprocal direction;
- simplification examples produce `y=-3` and `a=-5`, with the substitution checks agreeing;
- sentence translations preserve operand order for products, quotients, and fraction-of expressions;
- Denae's unit price is `$1.79`, Andreas's original price is `$16,000`, the Mehta assessed value is `$120,000`, and Stella's whole-garden amount is 21 flats;
- the supplied stamp answer `s=15` satisfies `0.49s+0.21(s-5)=9.45`.

No supplied result or source MathML formula requires a mathematical answer correction. Three non-answer defects do change or weaken the accessible mathematical statement: the ordinal-14 alt drops a negative denominator, the ordinal-49 alt changes variable `a` to `q`, and the prose summary of the four equality properties uses the wrong shared preposition and omits the nonzero divisor condition. They are EA2-C0223–EA2-C0225.

## MathML and embedded text

There are **291 MathML roots**, **2,224 MathML elements**, and **40 `m:mtext` nodes**. The exact `mtext` split is:

- lexical, translate: 12 conditional `If`/`if`/`then` nodes; 4 named-property labels; 4 `For any ... numbers` phrases; 5 `and`; and 1 `Let` = **26**;
- protected symbolic/invisible: 11 standalone U+2212 minus signs and 3 U+200B zero-width spaces in the stamp equation = **14**.

All 26 lexical nodes require Indonesian localization without flattening their enclosing MathML tables. The 11 protected minus signs must remain U+2212 and must not become hyphens or words. The three zero-width spaces are frozen source witnesses in the stamp expression; translation must not turn them into visible text. Final semantic reflow may normalize presentation only with source/target provenance intact.

Fractions, unary negatives, decimals, implicit multiplication, reciprocal cancellation, `mover` question marks, check marks, table order, and the nonzero condition `c != 0` must remain structurally intact.

## Semantic and pedagogical findings

The module's progression is coherent:

1. model `2x=6` with two envelopes and six counters;
2. introduce the Division Property of Equality and solve coefficient equations;
3. introduce the Multiplication Property of Equality and solve quotient equations;
4. handle unary negative coefficients and fractional coefficients by reciprocals;
5. simplify both sides before isolation where necessary;
6. collect all four equality properties;
7. translate product, quotient, and fractional-part sentences into equations;
8. solve unit-cost, original-price, assessed-value, and whole-garden applications;
9. consolidate with practice, everyday-math, writing, and self-check work.

Physical workspace sides in the envelope model are `sisi`, while algebraic sides are `ruas`. The formal equality-properties table and the surrounding learner prose must not use physical `keseimbangan` as a substitute for the mathematical relation `kesamaan`. The reciprocal terminology must remain beginner-readable while retaining the multiplicative-inverse relation already established in the terminology ledger.

The source copy defects are independent of the correct answers: `Multiple both sides by 8`; `#10.74`; `4-years old` plus an interrupting comma; two quotient sentences missing `of`; one missing article in `price of pair`; an extra comma in `fabric, would`; and the subject-verb mismatch in `The 6 counters ... gives`. These are recorded rather than silently normalized.

## Exact correction findings

| Candidate | Priority | Target stage | Owner | Finding |
|---|---|---|---|---|
| EA2-C0223 | P2 | target | media `eip-id1169750595124` | Alt voices `-7y/7=98`; the visible/source equation is `(-7y)/(-7)=98`. |
| EA2-C0224 | P2 | target | media `eip-id1169750931996` | Alt changes visible `-4a=20` to `-4q=20`. |
| EA2-C0225 | P2 | target | para `fs-id1168344565919` | Equality-property summary applies “from” to all four operations and omits that a divisor must be nonzero. |
| EA2-C0226 | P3 | target | table `eip-id1168184785308` | Aria label says “three-eights,” not “three-eighths.” |
| EA2-C0227 | P3 | target | table `eip-id1163599134733` | Instruction says “Multiple both sides by 8,” not “Multiply.” |
| EA2-C0228 | P3 | target | table `eip-802` | Unit-price check prints `#10.74` instead of `$10.74`. |
| EA2-C0229 | P3 | target | para `fs-id1168344418901` | “4-years old” and the comma before “when the car was new” make the application ungrammatical. |
| EA2-C0230 | P3 | target | para `fs-id1168343063574` | “The quotient c and -19” omits “of.” |
| EA2-C0231 | P3 | target | para `fs-id1168343048302` | “The quotient k and 22” omits “of.” |
| EA2-C0232 | P3 | target | para `fs-id1168344555887` | “price of pair of sport socks” omits the article “a.” |
| EA2-C0233 | P3 | target | para `fs-id1168344475602` | “How much fabric, would Nancy need” contains an erroneous comma. |
| EA2-C0234 | P3 | target | para `fs-id1168344520671` | “The 6 counters divided into 2 equal groups gives” has a subject-verb mismatch. |
| EA2-C0235 | P3 | target | media `eip-id1169750753300` | Alt inaccurately claims white text appears on a white background while also saying the characters are clearly visible. |
| EA2-C0236 | P3 | target | three worked-table aria labels | Unmatched or misplaced quotation marks occur in `eip-id1169748428935`, `eip-id1169752834967`, and `eip-id1169754127633`. |
| EA2-C0237 | P3 | assembly | 67 image declarations | Declared PNG points to JPEG bytes. |
| EA2-C0238 | P3 | assembly | six English-labelled rasters | Reader-visible English requires localized semantic reconstruction or the interim fallback trio. |
| EA2-C0239 | P3 | assembly | 65 notation-only rasters | Fixed 13–38-pixel math/check strips require centered responsive reflow; seven tiny strips also consume 4,034,424 bytes. |
| EA2-C0240 | P3 | assembly | two envelope/counter diagrams | The 215x163 and 211x193 pedagogical diagrams are too small for page-filling output without blur. |
| EA2-C0241 | P3 | assembly | rasters 69 and 73 | Visible source pixels use “three – eighths” and the malformed self-check header “No-I don’t get it!” |

The CSV is the controlling correction proposal. Upstream reporting remains deferred until full-corpus completion and deduplication into at most one concise issue.

## Accessibility surface audit

All **88 reader-facing attributes are nonempty**: 73 alt values, 13 table aria-labels, and 2 summaries. Their ordered attribute projection has **88 rows / 8,855 bytes**, SHA-256 **1ea1236bcf3c775bd7fb4cd70124059c9ab8a9dcedf7573924483abaae071ed6**. Each LF-terminated row is ordinal, owner local-name, owner ID, attribute name, normalized-value hash, and nonempty flag.

Every referenced raster was visually compared with its alt/aria surface. The exact material mismatches are EA2-C0223, EA2-C0224, EA2-C0226, and EA2-C0235. EA2-C0236 records punctuation defects that do not change the equations but degrade narration. The remaining source attributes correctly identify the displayed equations, reciprocal steps, red operations, crossed factors, question-over-equals checks, check marks, counter models, worked tables, and self-check grid.

The two summaries belong to the Denae and Andreas worked tables. Both correctly describe the step-by-step application structure and require ordinary localization rather than correction.

Translation must rebuild every visible attribute from the visual and correction evidence. Blindly translating the defective English attribute is forbidden. The self-check alt uses proper Unicode curly quotation marks in the source XML; terminal replacement glyphs are not a source-byte defect.

## Direct asset closure and visual classification

All **73 references are unique, present, and PIL-decodable**. Total referenced bytes: **5,072,059**. Every file has a JPEG signature and decodes as `image/jpeg`; 72 decode in CMYK mode and one in RGB mode. Exactly **67** image elements nevertheless declare `image/png`; the other six truthfully declare `image/jpeg`. No two referenced assets share a SHA-256 hash.

Deterministic closure receipts:

- Asset-manifest SHA-256: **8a3f996a4b70874225b4ccf7a67e193d3d5d2f9e77a5b94a56c06950dbe47847**. In media document order, each LF-terminated row is media ID TAB source path TAB bytes TAB SHA-256 TAB declared MIME TAB actual MIME. The manifest is **12,114 bytes**.
- Raw source-plus-assets SHA-256: **0d3fe3444f70c441a99ca6e33b71378902f5e5508967fc0794fee7930b2df25b** over **5,205,791 bytes**. The preimage is raw CNXML followed without separators by every referenced asset in media document order.

Complete visual classification in direct-media order:

| Ordinals | Asset family | Count | Visual class |
|---|---|---:|---|
| 1–2 | `001–002` | 2 | envelope-and-counter diagrams; ordinal 2 includes the notation `2x=6` |
| 3–11 | `003a–c`, `004a–f` | 9 | notation-only division and check sequences |
| 12–24 | `005a–f`, `006a–g` | 13 | notation-only multiplication/unary-negative sequences |
| 25–38 | `007a–g`, `008a–g` | 14 | notation-only reciprocal and fraction checks |
| 39–56 | `009a–g`, `010a–k` | 18 | notation-only simplification and substitution checks |
| 57–59 | `011a–c` | 3 | ordinal 57 English sentence-to-equation; two notation-only steps |
| 60–62 | `012a–c` | 3 | ordinal 60 English sentence-to-equation; two notation-only steps |
| 63–65 | `013a–c` | 3 | ordinal 63 English sentence-to-equation; two notation-only steps |
| 66–68 | `014a–c` | 3 | ordinal 66 English sentence-to-equation; two notation-only steps |
| 69–72 | `015a–d` | 4 | ordinal 69 English sentence-to-equation; three notation-only steps |
| 73 | `201` | 1 | English self-check table |

Therefore the exact classes are **6 English-labelled rasters**, **65 notation-only rasters**, and **2 pedagogical diagrams**. English-labelled ordinals are 57, 60, 63, 66, 69, and 73. Diagram ordinals are 1–2. All other ordinals are notation-only.

False-PNG declaration ordinals are 3–65 and 69–72. Truthful JPEG declaration ordinals are 1–2, 66–68, and 73.

The 65 notation rasters are only 13–38 pixels high. Seven of them, ordinals 39–45, are just 205–231 pixels wide and 17–24 pixels high but together consume **4,034,424 bytes**, nearly four-fifths of the entire direct asset closure. The English equation diagrams are 182–348 pixels wide except the 658x167 self-check. Stretching any of these fixed-pixel rows is not acceptable reflow.

## Reflow and localization disposition

Final reader assembly must replace the six English-labelled rasters with localized semantic HTML/MathML/SVG or an equivalent selectable structure. An interim translated module may retain each source raster only with the complete fallback trio: nonempty accurate Indonesian alt, a visible Indonesian transcription/key adjacent to the image, and an explicit disclosure that the retained source pixels contain English. The fallback does not satisfy final publication reflow QA.

The 65 notation-only rasters must be reconstructed as centered responsive math/check rows wherever practical. Preserve exact signs, fractions, reciprocal cancellation, red operation highlights, question-over-equals marks, check marks, source order, IDs, asset hashes, and rights linkage. Native rows must occupy useful content width without stretching tiny JPEGs, remain centered on wide pages, wrap or regroup safely on narrow screens, and expose a logical screen-reader order.

The two envelope/counter diagrams must be redrawn responsively or replaced with verified high-resolution derivatives. Preserve two envelopes, six counters, equality/workspace division, the `2x=6` label where present, caption relationships, alt meaning, source asset hashes, and rights provenance.

The final semantic reconstruction must naturally correct the two embedded English copy defects in EA2-C0241. It must not reproduce the spaced dash in “three – eighths” or the malformed “No-I don’t get it!” header.

## Links and reference closure

Both internal targets resolve uniquely inside m82464:

- `CNX_ElemAlg_Figure_02_02_001`;
- `CNX_ElemAlg_Figure_02_02_002`.

Both cross-document readiness links resolve uniquely in the declared Elementary Algebra 2e source modules:

| Document | Target ID | Witness source bytes | Witness source SHA-256 |
|---|---|---:|---|
| m82456 | `fs-id1170652633002` | 122,022 | 1d3b69d74603175eb3c8aae95319b14bee988a56345c67384c0090b29995ab33 |
| m82455 | `fs-id1170654287812` | 118,967 | 794635f93249017847f2646910d007e9de53b00ee6037133aa5c3edb7c2b88ec |

There are no URL links and no unresolved source references.

## Source-preservation disposition

The authoritative CNXML and all 73 direct assets remain byte-identical. Reader corrections must be linked to the explicit correction IDs in `PROPOSED_CORRECTIONS.csv`. Source-origin prose, formulas, IDs, hierarchy, references, assets, and hashes remain immutable witnesses. No translated target, ledger entry, backend record, reader, or publication artifact was created by this bounded control task.
