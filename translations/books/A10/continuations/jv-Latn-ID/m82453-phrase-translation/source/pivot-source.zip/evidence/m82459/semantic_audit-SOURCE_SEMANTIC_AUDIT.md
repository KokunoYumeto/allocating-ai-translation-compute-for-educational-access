# m82459 source semantic audit — *The Real Numbers*

## Scope and immutable witness

- Corpus boundary: OpenStax *Elementary Algebra 2e*, module `m82459` only.
- Source: `authority/source/modules/m82459/index.cnxml`
- Source size: 132,536 bytes.
- Source SHA-256: `730f4347e986d692a35dbecd7d22a68b461de068dafe077809c9f37844ab2fb0`.
- Module title: **The Real Numbers**.
- Metadata UUID: `addd5899-22fe-4839-98ab-796b22867e38`.
- The source parsed successfully as XML with `lxml` using its declared CNXML, MDML, and MathML namespaces. No source or asset was changed by this audit.

The review covered the complete CNXML tree, every one of the 106 problem blocks, all 74 supplied solution blocks, all 14 worked examples, all 13 links, all 26 directly referenced rasters, and every `alt`, `summary`, and `aria-label` surface. Mathematical checking was semantic rather than a text-only comparison.

## Exact structural inventory

| Surface | Count | Result |
|---|---:|---|
| All XML elements | 4,444 | 1,293 CNXML + 4 MDML + 3,147 MathML |
| Elements carrying `id` | 715 | 715 unique; no duplicate IDs |
| Sections | 10 | 6 top-level, with 4 nested under the untitled review wrapper |
| Paragraphs / notes / lists | 270 / 41 / 10 | Present and readable |
| Math roots / all MathML / `mtext` | 367 / 3,147 / 114 | Math is native MathML, not flattened |
| Equations | 13 | Included in mathematical review |
| Examples | 14 | All contain an exercise, problem, and supplied solution |
| Exercises / problems | 106 / 106 | Exact one-to-one closure |
| Supplied solutions / hints | 74 / 0 | 32 review exercises intentionally have no supplied solution |
| Tables | 10 | 8 use `summary`; 2 use `aria-label` |
| Figures / media / images | 7 / 26 / 26 | Every media node has one image and an `alt` value |
| Links | 13 | All are internal `target-id` links; 13/13 targets resolve |
| Glossaries / definitions | 1 / 6 | Six glossary meanings present |
| Term nodes | 22 | 16 identified inline terms plus 6 glossary term nodes |
| Accessibility attributes | 36 | 26 `alt` + 8 `summary` + 2 `aria-label` |
| Code / interactive / audio / video | 0 | None in this module |

The document-order topology witness is SHA-256 `59440c47dc2b4ac01aac30eb0508023bb20678fd8e4ab8b03de9f786872f837c`, computed over LF-joined lines of `{namespace}local-name<TAB>id` for every element. The ordered-ID witness is SHA-256 `a15c63b4c8d51cd162b93a6a284d5e49dc47895132dde26e92bfc78445943821`, computed over the 715 LF-joined IDs in document order.

## Semantic map

The four declared objectives and the four teaching sections align:

1. simplify expressions with square roots;
2. identify integers, rational numbers, irrational numbers, and real numbers;
3. locate fractions on the number line;
4. locate decimals on the number line.

| Top-level section | ID | Examples | Exercises | Solutions | Media |
|---|---|---:|---:|---:|---:|
| Simplify Expressions with Square Roots | `fs-id1170655215359` | 2 | 6 | 6 | 3 |
| Identify Integers, Rational Numbers, Irrational Numbers, and Real Numbers | `fs-id1170655177893` | 5 | 15 | 15 | 1 |
| Locate Fractions on the Number Line | `fs-id1170655059535` | 2 | 6 | 6 | 5 |
| Locate Decimals on the Number Line | `fs-id1170655029899` | 5 | 15 | 15 | 10 |
| Key Concepts | `fs-id1170654936545` | 0 | 0 | 0 | 0 |
| Untitled review wrapper | `fs-id1170655028698` | 0 | 64 | 32 | 7 |
| **Total** |  | **14** | **106** | **74** | **26** |

The review wrapper contains `Practice Makes Perfect` (`fs-id1170653802020`), `Everyday Math` (`fs-id1170655114059`), `Writing Exercises` (`fs-id1170654904697`), and `Self Check` (`fs-id1170655177758`). The conceptual vocabulary is square/square root/radical/principal square root; counting, whole, integer, rational, irrational, and real number sets; number lines; proper/improper fractions; and equivalent decimals.

## Link and dependency closure

All link targets exist in this same module. The exact owner-to-target pairs are:

- `fs-id1170655000486` → `CNX_ElemAlg_Figure_01_08_001`
- `fs-id1170655203491`, `fs-id1170655353090`, `fs-id1170655188953`, `fs-id1170655215831`, and `fs-id1170654944810` → `CNX_ElemAlg_Figure_01_08_002`
- `fs-id1170655133440` → `fs-id1170654942212`
- `fs-id1170655150929` → `CNX_ElemAlg_Figure_01_08_006`
- `fs-id1170655081279` → `CNX_ElemAlg_Figure_01_08_007`
- `fs-id1170655090207` → `CNX_ElemAlg_Figure_01_08_010`
- `fs-id1170655060667` → `CNX_ElemAlg_Figure_01_08_013`
- `fs-id1170654943214` → `CNX_ElemAlg_Figure_01_08_015`
- `fs-id1170654941319` → `fs-id1170655062741`

There are 26 media references and 26 unique paths; all resolve beneath `authority/source/media`. Their combined size is 782,940 bytes. A canonical media manifest formed in media document order as `media-id<TAB>src<TAB>bytes<TAB>sha256<TAB>declared-MIME<TAB>actual-MIME<LF>` has SHA-256 `28e9076dfd45391ab1c5a78256e75f620a0ce1b86126c0458c0b01c8bb5a70e9`. Concatenating the raw CNXML bytes followed by the 26 raw asset byte streams in media order yields closure SHA-256 `30899767b19b090547ac457e96d8ab7308fcc1f53a1c4164210db8fed9057f38`.

| Media ID | Asset | Bytes | SHA-256 | Declared / actual |
|---|---|---:|---|---|
| `fs-id1170655354103` | `CNX_ElemAlg_Figure_01_08_016_img_new.jpg` | 49,495 | `6250b1297397eec731997445aefcb33d0bea6c7132fdbc1e89bfce6b28310b6f` | JPEG / JPEG |
| `fs-id1170655028242` | `CNX_ElemAlg_Figure_01_08_001_img_new.jpg` | 26,941 | `084228b1b9c1fda93fbd7917906a3bb1fd2f3e00a57ae1a07cce727d6a21f4ca` | JPEG / JPEG |
| `fs-id1170655162081` | `CNX_ElemAlg_Figure_01_08_017_img_new.jpg` | 42,955 | `9b1eb7831984fa7ecaa6b27478809221c453ef57c746dc2588c892e332b0c349` | JPEG / JPEG |
| `fs-id1170655170188` | `CNX_ElemAlg_Figure_01_08_001_new.jpg` | 60,489 | `bf5c4c171a3eb34b798fd61aa2b907ee032b7baa292a1659b8e287c618732b8b` | JPEG / JPEG |
| `fs-id1170655114295` | `CNX_ElemAlg_Figure_01_08_002_new.jpg` | 24,286 | `f690226e1c303f412b2d43a8d56ff2de24a9186638b79304c01a4be10a689ab2` | JPEG / JPEG |
| `fs-id1170655098989` | `CNX_ElemAlg_Figure_01_08_003_img_new.jpg` | 24,104 | `9bc7a728857b029abea48cff1b386afb39cadc4f467a5180a6b47d777ab74374` | JPEG / JPEG |
| `fs-id1170654914692` | `CNX_ElemAlg_Figure_01_08_004_img_new.jpg` | 27,386 | `26c8a5617f04561a04fb8341856d600f143211197743f80147e7cdeaaaea9596` | JPEG / JPEG |
| `fs-id1170655199365` | `CNX_ElemAlg_Figure_01_08_005_img_new.jpg` | 27,632 | `d148ea3cb258f431aeef683d73cf5394e6590f9ec634e50af353bec11a3191da` | JPEG / JPEG |
| `fs-id1170654925833` | `CNX_ElemAlg_Figure_01_08_006_img_new.jpg` | 26,064 | `4cb49ea450cdfa3020573861b1a07f6e8f8b2e85604e379dbc7324ffc8a6a22d` | JPEG / JPEG |
| `fs-id1170655090842` | `CNX_ElemAlg_Figure_01_08_007_new.jpg` | 19,921 | `3f7610074d8c5f5f01efbef07c399b4bb51bfa6c0a1e1095665268c11624e9d4` | JPEG / JPEG |
| `fs-id1170654968607` | `CNX_ElemAlg_Figure_01_08_008_img_new.jpg` | 21,281 | `5bfa72eb70c87d7098d617d6dc3e8f3afaba1ff886d1bd4f961567d108557aa1` | JPEG / JPEG |
| `fs-id1170654905999` | `CNX_ElemAlg_Figure_01_08_009_img_new.jpg` | 22,007 | `537e53e77123b50f5437738a936009e6ccd49d56743e3e757a5e033ed618969b` | JPEG / JPEG |
| `fs-id1170654963334` | `CNX_ElemAlg_Figure_01_08_010_new.jpg` | 28,280 | `2d4c799c90dbc9d66417091ffef35f0c1444d69be2a40f55382bd1b4ce421d3a` | JPEG / JPEG |
| `fs-id1170655003783` | `CNX_ElemAlg_Figure_01_08_011_img_new.jpg` | 24,763 | `d8544b5ef8c56489a310c0ce0f7139f53e4ac961ad8a3d7861bfbd7acc2bd1f6` | JPEG / JPEG |
| `fs-id1170654944612` | `CNX_ElemAlg_Figure_01_08_012_img_new.jpg` | 26,708 | `d617b44a9d59d8396eb0e6d209dc2d48ced45a337f4866fcfdaa87c08650f036` | JPEG / JPEG |
| `fs-id1170655029517` | `CNX_ElemAlg_Figure_01_08_013_new.jpg` | 27,403 | `e64e665c46249a1ab2df403489a4190419b58c822f61e5f029e1e832b4ed3619` | JPEG / JPEG |
| `eip-id1169746116992` | `CNX_ElemAlg_Figure_01_08_014a_img_new.jpg` | 34,090 | `c3689c684705f88036995c4b6cc924f499a857ca8a6d8715210c47bc3fa433d7` | **PNG / JPEG** |
| `eip-id1169746117002` | `CNX_ElemAlg_Figure_01_08_014b_img_new.jpg` | 37,728 | `2f20f565aec7498bfa263944d6502ac2e3fbe371a79ff4eaaa9f09e6deebec31` | **PNG / JPEG** |
| `fs-id1170655192776` | `CNX_ElemAlg_Figure_01_08_015_new.jpg` | 22,268 | `8cfc0065bd524b8f0bc3f99302bcc76cfd53e2a489a1aad12ab4ef04703bf3b9` | JPEG / JPEG |
| `fs-id1170655080413` | `CNX_ElemAlg_Figure_01_08_202_img_new.jpg` | 24,744 | `d6fb9934a63ae1376b2033fd519bc8e7d8ac29bb31974675373193c455dc0326` | JPEG / JPEG |
| `fs-id1170653193526` | `CNX_ElemAlg_Figure_01_08_203_img_new.jpg` | 26,035 | `90ac59ee93eb2ca4b87640fb46fe82e77899176eb705cece55f4bfd6d376906c` | JPEG / JPEG |
| `fs-id1170655353874` | `CNX_ElemAlg_Figure_01_08_205_img_new.jpg` | 27,020 | `b8a01722b4b642a18f60ed9658a82326e7a12dfede299c1df6f86f0049664815` | JPEG / JPEG |
| `fs-id1170655124914` | `CNX_ElemAlg_Figure_01_08_207_img_new.jpg` | 28,255 | `df209299109ef62fcbf24932581c0bfb9ca5bb7e98c7b1db1c1fdbe525133947` | JPEG / JPEG |
| `fs-id1170655095903` | `CNX_ElemAlg_Figure_01_08_209_img_new.jpg` | 18,617 | `6edb4c2aa192011044436b0de5da01445fb6c3ae2c5b3eb4d28f45405ea89ee2` | JPEG / JPEG |
| `fs-id1170654941068` | `CNX_ElemAlg_Figure_01_08_211_img_new.jpg` | 19,545 | `89270ce2b81444dfd686fb23ff07ba39db1a05342318b4fa93e1f26583389cff` | JPEG / JPEG |
| `fs-id1170655166340` | `CNX_ElemAlg_Figure_01_08_201_img_new.jpg` | 64,923 | `9d9c90aae7f065ccc57bca97d65fb31c70a020b129debe4515d8c72703512b04` | JPEG / JPEG |

## Independent mathematics review

All 14 worked examples and all 74 supplied solutions were evaluated against their corresponding problem statements. The square-root evaluations, rational/irrational and real-number classifications, set-membership lists, fraction/decimal placements, inequality symbols, fraction conversions, and applied whole-number answers are correct except for the specifically identified prose defects below.

- The 74 solution blocks consist of 14 worked-example solutions, 28 `try` solutions, and 32 review/applied/writing solutions.
- Thirteen of the fourteen worked-example solutions are fully correct.
- Worked example `fs-id1170654942212`, solution `fs-id1170655104625`, table `eip-313`, has correct final comparison signs in all four parts but wrong positional prose in parts ⓑ and ⓒ. This is not a translation choice; it is an upstream source defect.
- The remaining 60 supplied solutions are mathematically consistent with their problems. Open-ended responses marked “answers may vary” are appropriate to their prompts.
- The 32 exercises without supplied solutions are coherent and solvable from the section instruction blocks; no malformed operand or impossible requested classification was found.

## Correction candidates and risks

Severity definitions used here: **P1** = objectively false mathematical content; **P2** = materially misleading reasoning, accessibility, or assembly metadata; **P3** = localized precision/copyedit/structural hygiene issue. These are source observations. A translation may disclose or locally correct them, but must preserve the source witness and record every delta rather than silently rewriting it.

| Priority | Owner ID(s) | Finding | Recommended disposition |
|---|---|---|---|
| P1 | equation `fs-id1166422870658` | The source says `π = 3.141592654…`. The actual decimal begins `3.141592653589…`; `3.141592654` is a rounded finite approximation and cannot be followed by an ellipsis under exact equality. | Use either `π ≈ 3.141592654` or an exact-prefix form such as `π = 3.141592653…`; record the source delta. |
| P1 | para `fs-id1170655203491` | The source calls both `3` and `−5` “whole numbers,” but `−5` is not a whole number; both values are integers. | Change “whole numbers” to “integers” and record the source delta. |
| P2 | para `fs-id1170654872607` | “The square root of *m* … is the positive number whose square is *m*” excludes `√0 = 0`, contradicting the immediately preceding treatment of zero. | Say “nonnegative number,” or qualify the sentence for `m > 0`. |
| P2 | example `fs-id1170654942212`; solution `fs-id1170655104625`; table `eip-313` | Part ⓑ says `−3 1/2` is **to the right of** `−3`, but it is to the left. Part ⓒ says `−3/4` is **to the right of** `−1/4`, but it is to the left. The displayed `<` answers are correct. | Change “right” to “left” in those two explanation cells; preserve the correct inequalities. |
| P2 | media `fs-id1170655192776` | The `alt` says the number line has no points. The raster visibly marks four points: `−9`, `−6`, `−3`, and `−2`, with the first pair cyan and the second pair red. | Replace the alt description with the actual marked values and their left/right relationships. |
| P2 | media `eip-id1169746116992`, `eip-id1169746117002` | Both `.jpg` files contain JPEG bytes but their CNXML `<image>` nodes declare `mime-type="image/png"`. | Preserve the byte hashes; change declarations to `image/jpeg` in the localized derivative or transcode deliberately and re-hash. |
| P3 | para `fs-id1170655215831` | The text calls `7/4`, `−9/2`, and `8/3` fractions “in which the numerator is greater than the denominator.” For a signed numerator, `−9` is not greater than `2`; the intended criterion is magnitude/the unsigned fraction part. | Say that the absolute value of each fraction is at least one, or that the numerator of its positive magnitude exceeds the denominator. |
| P3 | para `fs-id1170655081279` | “We write 0 as 0.0 and 1 and 1.0” has the second conjunction where “as” is required. | Change to “0 as 0.0 and 1 as 1.0.” |
| P3 | para `fs-id1170655203491` | “We’ll start with the whole numbers 3 and −5. because …” has a sentence-breaking period before lowercase “because.” | Replace the period with a comma or begin a new capitalized sentence. |
| P3 | table `fs-id1170654958097` (`aria-label`) | The accessibility prose contains “colums” and “The third for reads.” | Change to “columns” and “The third row reads.” |
| P3 | media `fs-id1170655029517` (`alt`) | It says the number line runs from “negative 0.0 to 1.0”; the raster starts at ordinary `0.0`. | Remove “negative.” |
| P3 | media `fs-id1170654925833` (`alt`) | A sentence boundary is missing after “between negative 4 and negative 3.” | Add the period. |
| P3 | media `fs-id1170655166340` (`alt`) | Quotation punctuation around the last two objective-row labels is unbalanced; the text opens no quote before “locate fractions” but closes one after it. | Normalize quotation marks while translating the self-check table. |
| P3 | para `fs-id1171784141775` | The paragraph contains only two `<newline/>` elements. It is layout spacing with no semantic content. | Preserve only if topology parity requires it; do not expose it as learner content. |

No other incorrect result was found in the 74 supplied solutions. In particular, the four final inequalities in `eip-313` must not be “fixed”; only its two directional explanations are wrong.

## English-labelled rasters and localization obligations

Four of the 26 rasters contain embedded English and therefore cannot become a fully Indonesian reader merely by translating CNXML text:

| Media ID | Asset | Embedded English |
|---|---|---|
| `fs-id1170655354103` | `CNX_ElemAlg_Figure_01_08_016_img_new.jpg` | `Number`, `Square` |
| `fs-id1170655028242` | `CNX_ElemAlg_Figure_01_08_001_img_new.jpg` | `radical sign`, `radicand` |
| `fs-id1170655170188` | `CNX_ElemAlg_Figure_01_08_001_new.jpg` | `Real Numbers`, `Rational Numbers`, `Integers`, `Whole Numbers`, `Counting Numbers`, `Irrational Numbers` |
| `fs-id1170655166340` | `CNX_ElemAlg_Figure_01_08_201_img_new.jpg` | self-check headings and all four “I can…” objective labels |

The other 22 rasters contain only numerals, mathematical notation, colored points, or unlabeled line work. For the four English-labelled rasters, the Indonesian edition should use a localized redraw when feasible and retain a visible Indonesian transcription/gloss when reuse of the upstream raster is necessary. All 26 English `alt` values, all 8 `summary` values, both `aria-label` values, the 114 MathML `mtext` nodes, titles, captions, metadata abstract, and visible table/list prose require Indonesian localization. Mathematical glyphs, element IDs, link targets, and asset provenance must remain stable.

Three narrow 243-pixel number-line assets—media `fs-id1170654914692`, `fs-id1170655199365`, and `fs-id1170655124914`—have crowded adjacent fraction labels. Their alt descriptions preserve the intended order, but a reflowed reader should render them at adequate width or provide a scalable/localized redraw rather than upscale a cramped bitmap.

## Admission recommendation

The source and its direct dependency closure are usable for translation: XML is well formed, IDs and internal references close, every asset exists, and the exercise/solution graph is coherent. Translation should proceed with the source kept immutable. Admission must carry explicit correction records for the false π expansion, the incorrect classification of `−5` as a whole number, the zero-excluding square-root definition, the two wrong direction statements, the inaccurate four-point alt description, and the two MIME mismatches. The smaller copy/accessibility findings should be corrected in the Indonesian derivative with source-delta receipts. No other P1 error was found in the reviewed source.
