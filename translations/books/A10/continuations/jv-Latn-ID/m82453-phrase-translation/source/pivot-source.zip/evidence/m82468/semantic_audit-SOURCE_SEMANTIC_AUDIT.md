# m82468 Source Semantic Audit

## Audit result

`m82468` is verified as frozen-collection ordinal **18**, immediately after `m82467` (17) and before `m82469` (19). The CNXML is well-formed, its 584 IDs are unique, all four explicit links resolve to their exact frozen targets, and all 118 referenced media files exist with unique paths and byte hashes.

Every supplied final answer is correct, but one intermediate worked raster is mathematically wrong. The m82467 rereview/admission gate was still open when this audit began, then resolved during final validation: the live ledgers now contain m82467 through `EA2-T0376` and `EA2-C0274`, admitted at `2026-08-23T01:55:17+02:00`. This audit records the next eight proposed terminology rows, the next sixteen proposed correction rows, several accessibility-critical narration errors, one worked raster sequence that switches the authoritative variable `a` to `d` in three steps, and the incorrect `−16/8` numerator in `CNX_ElemAlg_Figure_02_05_004c_img_new.jpg`.

- Audit scope: frozen collection witness; `authority/source/modules/m82468/index.cnxml`; its 118 directly referenced frozen assets; the three explicit external cross-link targets; the one explicit local target; current terminology/correction maxima; and the m82467 proposed-to-admitted range transition.
- Write scope: only the five files under `qa/m82468/` requested for pretranslation control.
- Frozen source was not modified. No target, builder, map, ledger admission, backend, reader, publication, or sibling-module mutation was performed.
- Model provenance: **OpenAI Codex gpt-5.6-sol, Ultra**
- Audit timestamp: `2026-08-23T01:54:47+02:00`

## Exact authority binding

| Witness | Identity |
|---|---|
| Collection | `authority/source/collections/elementary-algebra-2e.collection.xml` |
| Collection bytes | `5256` |
| Collection SHA-256 | `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72` |
| Collection UUID | `55931856-c627-418b-a56f-1dd0007683a8` |
| Collection language/license | `xml:lang="en"`; CC BY-NC-SA 4.0 at the recorded Creative Commons URL |
| Module | `authority/source/modules/m82468/index.cnxml` |
| Module bytes | `121782` |
| Module SHA-256 | `c37321a5d8e4dd5f83f90b4b65c2b3516474b5cdea885f84a28ca15e5cea37e0` |
| Content ID / UUID | `m82468` / `298d833c-c21e-4d03-a6e0-05bf439099e9` |
| Source title | `Solve Equations with Fractions or Decimals` |
| Media set | 118 document-order references; 118 unique paths; 118 present; 0 duplicate byte hashes; 2,468,718 total bytes |
| Media manifest digest | `1c3d0138f3fd9254f191ee5fd048d6bf24c4ecc77a566140b1957ed1ab1672de` |

The media manifest digest is SHA-256 over the UTF-8, LF-joined document-order rows `src<TAB>byte_count<TAB>lowercase_sha256`, with no terminal row added outside that join. Appendix B supplies every constituent row so the digest is reproducible.

## Frozen collection order proof

The collection begins with standalone module `m82630` (ordinal 1), followed by 11 modules in **Foundations** (ordinals 2–12). In **Solving Linear Equations and Inequalities**, the order is:

| Global ordinal | Module |
|---:|---|
| 13 | `m82462` |
| 14 | `m82463` |
| 15 | `m82464` |
| 16 | `m82465` |
| 17 | `m82467` |
| **18** | **`m82468`** |
| 19 | `m82469` |
| 20 | `m82470` |

This proves both the requested ordinal and immediate-predecessor relation from the frozen collection itself.

## Explicit cross-links

There are four `<link>` elements. Each `target-id` exists exactly once in the named frozen module or locally.

| From | Destination | Target kind | Destination bytes | Destination SHA-256 | Result |
|---|---|---|---:|---|---|
| readiness multiplication review | `m82456#fs-id1170653798020` | `example` in **Visualize Fractions** | 122022 | `1d3b69d74603175eb3c8aae95319b14bee988a56345c67384c0090b29995ab33` | resolved |
| readiness LCD review | `m82457#fs-id1170655126635` | `example` in **Add and Subtract Fractions** | 132165 | `a8db22ca9c8c10c7f95fa3aa4dcb18596711741478515c220a75e291273983e9` | resolved |
| readiness decimal review | `m82458#fs-id1170654990020` | `example` in **Decimals** | 130960 | `678dc0c3ae2aad0192c0314395541720d6c6eb97f56d2f4d169f056fe1e630cb` | resolved |
| explanatory paragraph | local `m82468#fs-id1168341916916` | `example`, **How to Solve Equations with Fraction Coefficients** | — | bound by module hash | resolved |

The three external link elements have no literal child text; a derivative must generate an intelligible localized link label from the destination context rather than expose an empty control.

## CNXML topology and identifier inventory

The module parses as XML. No XSD claim is made. All 584 `id` attributes are unique; no duplicate or empty `id` was found.

| Element or feature | Count |
|---|---:|
| top-level/nested `section` | 8 |
| `example` | 10 |
| `note` | 24: 3 `be-prepared`, 20 `try`, 1 `howto` |
| `exercise` / direct `problem` | 91 / 91 |
| direct `solution` | 62 |
| `para` | 165 |
| `list` / `item` | 4 / 9 |
| `table` / `row` / `entry` | 10 / 117 / 255 |
| `media` / `image` | 118 / 118 |
| `link` | 4 |
| `m:math` / `equation` | 159 / 1 |
| `mfrac` / `mrow` / `mn` / `mi` / `mo` | 165 / 228 / 547 / 216 / 361 |
| `newline` / `emphasis` / `span` | 8 / 7 / 2 |

Section hierarchy:

1. `fs-id1168345447739` — Solve Equations with Fraction Coefficients
2. `fs-id1168345511517` — Solve Equations with Decimal Coefficients
3. `fs-id1168341968295`, class `key-concepts` — Key Concepts
4. `fs-id1168345270037`, class `section-exercises`, untitled wrapper
   - `fs-id1168341901823`, class `practice-perfect` — Practice Makes Perfect
   - `fs-id1168345376622`, class `everyday` — Everyday Math
   - `fs-id1168341972689`, class `writing` — Writing Exercises
   - `fs-id1166502060699` — Self Check

The abstract has two objectives: solve equations with fraction coefficients; solve equations with decimal coefficients. The named how-to has three ordered steps: find the LCD of all fractions, multiply both equation sides by it, then apply the general linear-equation strategy.

## Exercise and supplied-answer topology

| Surface | Exercises | Supplied solutions | Intentionally unsupplied |
|---|---:|---:|---:|
| readiness quiz | 3 | 3 | 0 |
| worked examples | 10 | 10 | 0 |
| Try It notes | 20 | 20 | 0 |
| Practice Makes Perfect | 52 | 26 | 26 |
| Everyday Math | 2 | 1 | 1 |
| Writing Exercises | 4 | 2 | 2 |
| **Total** | **91** | **62** | **29** |

The 52 practice exercises form 26 adjacent pairs; only the second exercise in each pair has a source `<solution>`. Everyday Math supplies only the second answer. Writing Exercises supplies only the second and fourth answers. This is a deliberate source boundary, not missing content.

The 29 unsupplied exercise IDs are:

`fs-id1168345423582`, `fs-id1168345406285`, `fs-id1168345741346`, `fs-id1168345487453`, `fs-id1168341927106`, `fs-id1168345622776`, `fs-id1168341961035`, `fs-id1168341973996`, `fs-id1168345509894`, `fs-id1168345251332`, `fs-id1168345543623`, `fs-id1168342104283`, `fs-id1168341861960`, `fs-id1168345465807`, `fs-id1168341973671`, `fs-id1168345421025`, `fs-id1168341968246`, `fs-id1168341863575`, `fs-id1168345433184`, `fs-id1168341847921`, `fs-id1168345406619`, `fs-id1168345255647`, `fs-id1168345556312`, `fs-id1168341973102`, `fs-id1168345384059`, `fs-id1168345509798`, `fs-id1168345376627`, `fs-id1168345508617`, and `fs-id1168345385351`.

Appendix A records independent results for QA. Results marked omitted are forbidden from the learner-facing translation.

## Independent mathematics review

All 84 solve-the-equation prompts at exercise ordinals 4–87 were independently reduced as exact linear equations. The readiness products/LCD were independently recomputed, the fraction LCD in ordinal 88 is 24, and the decimal-denominator prompt in ordinal 91 correctly supplies 100 (the displayed equation itself would solve to `x=5`, but that is not what the prompt asks).

Findings:

- All 62 supplied solution outcomes agree with independent computation or, for the open writing response, correctly allow variation.
- No extraneous, missing, or nonunique algebraic solution was found.
- The readiness results `3`, `12`, and `478` are correct.
- Worked values `y=7`, `v=40`, `a=-2`, `x=-3`, `y=9`, `x=1`, `a=-12`, `q=-5`, `x=8`, and `x=9` are correct.
- The `a/6+2=a/4+3` example has a correct numerical solution `a=-12`, but three source rasters visibly switch the variable to `d`; that visual semantic defect is `EA2-C0280`.
- The `a=-2` check is wrong on both visual and accessibility surfaces: the raster visibly prints `−16/8−4/8`, while the source parent aria-label and individual alt voice `16/8−4/8`. Since `(3/8)(−2)=−6/8`, `EA2-C0278` must replace the raster with a hash-bound responsive derivative showing `−6/8−4/8` and make both narrations agree with it.

## Worked tables

| Table ID | Semantic role | Rows / entries | `aria-label` length | Audit note |
|---|---|---:|---:|---|
| `eip-id1168184123630` | direct fraction solution | 7 / 14 | 1452 | math is seven tiny rasters |
| `eip-id1168185099989` | `v=40` worked/check | 12 / 28 | 2293 | individual variable/check-mark alt defects |
| `eip-id1168184905253` | `a=-2` worked/check | 16 / 37 | 3086 | parent and child check narration wrong |
| `eip-id1168464992092` | `x=-3` worked/check | 12 / 29 | 2149 | mathematically valid equivalent check transform |
| `eip-id1168463852453` | `y=9` worked/check | 13 / 26 | 2917 | final check intentionally left to learner |
| `eip-id1168463821427` | `x=1` worked/check | 11 / 26 | 1991 | no outcome defect found |
| `eip-id1168464994289` | `a=-12` worked/check | 12 / 28 | 2265 | three rasters use `d`; two alts misvoice `a`/sign |
| `eip-id1168463876929` | `q=-5` worked/check | 13 / 25 | 3034 | parent narration changes numerator/denominator/grouping |
| `eip-id1168464992576` | decimal `x=8` | 11 / 22 | 2523 | check raster includes full evaluation |
| `eip-id1168464992414` | decimal `x=9` | 10 / 20 | 1770 | learner performs final substitution check |

All ten tables have nonempty long-form `aria-label` attributes, but they are image-heavy layout tables with no native mathematical equivalent for 114 equation strips. A derivative should avoid duplicating a full-table narration beside fully semantic rows; use one coherent reading order.

## Media and accessibility inventory

- 118 `<media>` nodes, each with one `<image>` and nonempty `alt`; alt lengths range from 55 to 651 characters.
- Every referenced filename ends in `.jpg`, and every file has actual JPEG bytes.
- 114 images falsely declare `image/png`; four truthfully declare `image/jpeg` (media ordinals 8, 9, 10, and 118).
- Those four truthful declarations are also the four reader-visible English assets: three rows of the named fraction-clearing procedure and the self-check table.
- The remaining 114 images are equation/check strips, 151–363 px wide and 13–74 px high. Of them, 112 are under 40 px high, 56 under 20 px, and 110 contain fewer than 10,000 pixels.
- All 118 files total 2,468,718 bytes. Embedded XMP totals 2,075,334 bytes (84.1%); no ICC payload was found. Native math is preferred, then deterministic profile stripping for any retained derivatives.
- No referenced file is missing; no path is referenced twice; no two referenced files share a SHA-256 hash.
- The 658×103 self-check is a flattened 3×4 table with blank response cells and malformed embedded header `No-I don't get it!`.
- The source module root lacks `xml:lang`; the separate collection supplies English only at collection scope.
- Thirty-one unary minus signs are embedded in `<m:mn>` tokens in 31 contexts. Derivative MathML should separate the operator without changing values.

## Source defects and derivative dispositions

`PROPOSED_CORRECTIONS.csv` is authoritative for exact wording. Summary:

| IDs | Finding | Priority / disposition |
|---|---|---|
| `EA2-C0275` | third procedure-row alt says isolate `x`, visible/source variable is `y` | P2; correct target narration |
| `EA2-C0276` | `v=40` sequence alts substitute `y` and uppercase `V` | P2; correct target narration |
| `EA2-C0277` | two visible check marks are voiced as `√` or `V` | P3; correct target narration |
| `EA2-C0278` | `a=-2` check raster prints `−16/8`, while its narration voices `16/8`; both should be `−6/8` | P2; replace the visual with a responsive corrected derivative and correct target narration |
| `EA2-C0279` | two `a=-2` alts substitute `q` for `a` | P2; correct target narration |
| `EA2-C0280` | three `a=-12` rasters visibly use `d` | P2; reconstruct with authoritative `a` |
| `EA2-C0281` | same sequence alts substitute `q` and drop the minus from `a=-12` | P2; correct target narration |
| `EA2-C0282` | `q=-5` table narration changes `4q+3` to `4q+2`, `/4` to `/5`, and blurs multiplier scope | P2; exact semantic reconstruction |
| `EA2-C0283`–`EA2-C0284` | fragmented procedure topology and four English-bearing rasters | P3; derivative assembly/localization |
| `EA2-C0285`–`EA2-C0288` | MIME mismatch, raster reflow debt, flattened self-check, XMP bloat | P3; derivative assembly |
| `EA2-C0289`–`EA2-C0290` | missing module language and unary-minus token semantics | P3; derivative assembly |

These are derivative corrections only. The frozen CNXML and JPEGs remain immutable.

## Terminology range and controls

At audit start, the admitted terminology/correction ledgers ended at `EA2-T0354`/`EA2-C0256`, while the m82467 package reserved `EA2-T0355`–`EA2-T0376` and `EA2-C0257`–`EA2-C0274`. During final validation those exact rows were admitted without renumbering. The live ledgers now contain 376 unique term IDs through `EA2-T0376` and 274 unique correction IDs through `EA2-C0274`. No collision exists with the m82468 proposals.

Final range-check witnesses were `04_TERMINOLOGY.csv` SHA-256 `a0771d8872882066d098f6da7e6647762b70f3b42ce96333940a492dfb238d89`, `05_CORRECTIONS.csv` SHA-256 `3e3ff2e921ea68a82ebe403b541dba41d28e67fb49efcfa0c882b0d0caf3cd10`, m82467 `PROPOSED_TERMINOLOGY.csv` SHA-256 `ed3ee1695c8a01124189dd128db2835761ad39b9dceb5b3fa065141e4a837c19`, and m82467 `PROPOSED_CORRECTIONS.csv` SHA-256 `107045ed0e75c00035bc406f7025eda2c771a63f5b6c8afd2bf7d7f63613fcbb`.

This audit reserves:

- terminology: `EA2-T0377`–`EA2-T0384` (8 rows);
- corrections: `EA2-C0275`–`EA2-C0290` (16 rows).

Whole-book control **`algebraic expression` → `bentuk aljabar`** (`EA2-T0278`) is mandatory. Detailed admitted reuse and proposed mappings appear in `TERMINOLOGY_AND_ACCESSIBILITY_PLAN.md`.

## Pretranslation verdict

The bounded source audit is complete and the predecessor admission is now visible in the live ledgers, but this package itself creates no target and grants no broader mutation scope. The next executable action is: confirm the live maxima remain `EA2-T0376` and `EA2-C0274`, admit or reconcile the collision-free m82468 proposals, then construct and independently review a target bound to the exact identities above.

## Appendix A — independent exercise oracle

Rows marked **omitted—QA oracle only** must not be added to a learner-facing target.

| Ordinal | Exercise ID | Independent result | Source solution boundary |
|---:|---|---|---|
| 1 | `fs-idm212895920` | `3` | supplied |
| 2 | `fs-idm180245904` | `LCD = 12` | supplied |
| 3 | `fs-idm176743792` | `478` | supplied |
| 4 | `fs-id1168345425218` | `y = 7` | supplied |
| 5 | `fs-id1168345560882` | `x = 1/2` | supplied |
| 6 | `fs-id1168345486686` | `x = -2` | supplied |
| 7 | `fs-id1168345431358` | `v = 40` | supplied |
| 8 | `fs-id1168345742820` | `x = 12` | supplied |
| 9 | `fs-id1168345417024` | `u = -12` | supplied |
| 10 | `fs-id1168345544042` | `a = -2` | supplied |
| 11 | `fs-id1168342170196` | `x = -1` | supplied |
| 12 | `fs-id1168345291634` | `c = -2` | supplied |
| 13 | `fs-id1168345441370` | `x = -3` | supplied |
| 14 | `fs-id1168345726490` | `p = -4` | supplied |
| 15 | `fs-id1168341952150` | `q = 2` | supplied |
| 16 | `fs-id1168345725114` | `y = 9` | supplied |
| 17 | `fs-id1168345212429` | `n = 2` | supplied |
| 18 | `fs-id1168345241698` | `m = -1` | supplied |
| 19 | `fs-id1168341957764` | `x = 1` | supplied |
| 20 | `fs-id1168345301260` | `y = 2` | supplied |
| 21 | `fs-id1168345293634` | `z = -2` | supplied |
| 22 | `fs-id1168345449353` | `a = -12` | supplied |
| 23 | `fs-id1168342168201` | `b = -20` | supplied |
| 24 | `fs-id1168345500396` | `c = -6` | supplied |
| 25 | `fs-id1168345213328` | `q = -5` | supplied |
| 26 | `fs-id1168345325322` | `r = 1` | supplied |
| 27 | `fs-id1168345543571` | `s = -8` | supplied |
| 28 | `fs-id1168345276631` | `x = 8` | supplied |
| 29 | `fs-id1168345726459` | `h = 12` | supplied |
| 30 | `fs-id1168345527509` | `k = -1` | supplied |
| 31 | `fs-id1168341972822` | `x = 9` | supplied |
| 32 | `fs-id1168345577865` | `n = 9` | supplied |
| 33 | `fs-id1168345406695` | `d = 16` | supplied |
| 34 | `fs-id1168345423582` | `x = -1` | **omitted—QA oracle only** |
| 35 | `fs-id1168345638687` | `x = 1` | supplied |
| 36 | `fs-id1168345406285` | `y = -1` | **omitted—QA oracle only** |
| 37 | `fs-id1168345409307` | `y = -1` | supplied |
| 38 | `fs-id1168345741346` | `a = 3/4` | **omitted—QA oracle only** |
| 39 | `fs-id1168345541824` | `b = -2` | supplied |
| 40 | `fs-id1168345487453` | `x = 4` | **omitted—QA oracle only** |
| 41 | `fs-id1168345251352` | `x = 3` | supplied |
| 42 | `fs-id1168341927106` | `m = 20` | **omitted—QA oracle only** |
| 43 | `fs-id1168345454946` | `n = -24` | supplied |
| 44 | `fs-id1168345622776` | `x = -3` | **omitted—QA oracle only** |
| 45 | `fs-id1168345671466` | `x = -4` | supplied |
| 46 | `fs-id1168341961035` | `w = 9/4` | **omitted—QA oracle only** |
| 47 | `fs-id1168345621164` | `z = -2` | supplied |
| 48 | `fs-id1168341973996` | `x = 1` | **omitted—QA oracle only** |
| 49 | `fs-id1168342101284` | `a = 1` | supplied |
| 50 | `fs-id1168345509894` | `b = 12` | **omitted—QA oracle only** |
| 51 | `fs-id1168345520311` | `x = -6` | supplied |
| 52 | `fs-id1168345251332` | `x = 1` | **omitted—QA oracle only** |
| 53 | `fs-id1168345293361` | `x = 1` | supplied |
| 54 | `fs-id1168345543623` | `p = -41` | **omitted—QA oracle only** |
| 55 | `fs-id1168345397727` | `q = 7` | supplied |
| 56 | `fs-id1168342104283` | `x = -5/2` | **omitted—QA oracle only** |
| 57 | `fs-id1168345517405` | `x = -5/2` | supplied |
| 58 | `fs-id1168341861960` | `q = 2` | **omitted—QA oracle only** |
| 59 | `fs-id1168345542298` | `m = -1` | supplied |
| 60 | `fs-id1168345465807` | `n = -3` | **omitted—QA oracle only** |
| 61 | `fs-id1168345461131` | `p = -4` | supplied |
| 62 | `fs-id1168341973671` | `u = -6` | **omitted—QA oracle only** |
| 63 | `fs-id1168345634536` | `v = 20` | supplied |
| 64 | `fs-id1168345421025` | `c = 60` | **omitted—QA oracle only** |
| 65 | `fs-id1168345285121` | `d = -24` | supplied |
| 66 | `fs-id1168341968246` | `x = -2` | **omitted—QA oracle only** |
| 67 | `fs-id1168345667857` | `y = -1` | supplied |
| 68 | `fs-id1168341863575` | `u = 3` | **omitted—QA oracle only** |
| 69 | `fs-id1168345342771` | `v = 4` | supplied |
| 70 | `fs-id1168345433184` | `y = 10` | **omitted—QA oracle only** |
| 71 | `fs-id1168345256259` | `y = 15` | supplied |
| 72 | `fs-id1168341847921` | `j = 2` | **omitted—QA oracle only** |
| 73 | `fs-id1168341952288` | `k = 2` | supplied |
| 74 | `fs-id1168345406619` | `x = 18` | **omitted—QA oracle only** |
| 75 | `fs-id1168341912511` | `x = 20` | supplied |
| 76 | `fs-id1168345255647` | `x = 18` | **omitted—QA oracle only** |
| 77 | `fs-id1168345429469` | `x = 22` | supplied |
| 78 | `fs-id1168345556312` | `x = 20` | **omitted—QA oracle only** |
| 79 | `fs-id1168345669364` | `x = 8` | supplied |
| 80 | `fs-id1168341973102` | `n = 9` | **omitted—QA oracle only** |
| 81 | `fs-id1168345461810` | `n = 19` | supplied |
| 82 | `fs-id1168345384059` | `d = 8` | **omitted—QA oracle only** |
| 83 | `fs-id1168345635234` | `d = 10` | supplied |
| 84 | `fs-id1168345509798` | `q = 11` | **omitted—QA oracle only** |
| 85 | `fs-id1168345646408` | `q = 15` | supplied |
| 86 | `fs-id1168345376627` | `d = 18` | **omitted—QA oracle only** |
| 87 | `fs-id1168345294567` | `s = 35` | supplied |
| 88 | `fs-id1168345508617` | `LCD = 24` | **omitted—QA oracle only** |
| 89 | `fs-id1168341919404` | open response; source says answers vary | supplied |
| 90 | `fs-id1168345385351` | open explanation | **omitted—QA oracle only** |
| 91 | `fs-id1168342101299` | `LCD = 100` | supplied |

## Appendix B — exact referenced-media manifest

Each `file` is the exact basename of the CNXML reference `../../media/<file>`, resolving inside `authority/source/media/`. Rows remain in CNXML document order.

| # | media id | file | bytes | px | declared | actual | SHA-256 |
|---:|---|---|---:|---:|---|---|---|
| 1 | `eip-id1168184123661` | `CNX_ElemAlg_Figure_02_05_001a_img_new.jpg` | 17249 | 174×33 | `image/png` | `JPEG` | `1702bb859fd39530b4e52bf762f37cfa1481dc729ab62d4304b6b01a3078438b` |
| 2 | `eip-id1168184123692` | `CNX_ElemAlg_Figure_02_05_001b_img_new.jpg` | 21751 | 174×33 | `image/png` | `JPEG` | `8e2dabd964db6afad802d8632752731aa2de508cb2cc6b9313ea1f216eff5c83` |
| 3 | `eip-id1168183760303` | `CNX_ElemAlg_Figure_02_05_001c_img_new.jpg` | 17978 | 174×33 | `image/png` | `JPEG` | `a7b45648c811daec1c4ce1bd8bf6ef04ff077add9eaaee8fd6131fa5c11f219e` |
| 4 | `eip-id1168183760320` | `CNX_ElemAlg_Figure_02_05_001d_img_new.jpg` | 18486 | 174×33 | `image/png` | `JPEG` | `b2c3567d242081858632fa9cdb5aae5f4008362bb2fff9a48588b9228fe187f0` |
| 5 | `eip-id1168183760336` | `CNX_ElemAlg_Figure_02_05_001e_img_new.jpg` | 17880 | 174×33 | `image/png` | `JPEG` | `0704867802c5c3327f28b8294139906f37e23987fc5a7a878a3165831205f374` |
| 6 | `eip-id1168183760360` | `CNX_ElemAlg_Figure_02_05_001f_img_new.jpg` | 23490 | 174×35 | `image/png` | `JPEG` | `dd666f6b499b51c573461c2c890132bd5c3f01cc84187c94aaa63d73dbc74cf0` |
| 7 | `eip-id1168184126114` | `CNX_ElemAlg_Figure_02_05_001h_img_new.jpg` | 17522 | 174×13 | `image/png` | `JPEG` | `6cb8032a18aec1ef9cf83119ae873e706d6b833b18dbb3bd327eb96a695a0f61` |
| 8 | `fs-id1168345255731` | `CNX_ElemAlg_Figure_02_05_002a_img_new.jpg` | 47973 | 750×104 | `image/jpeg` | `JPEG` | `ea8de7df402461657e743f51ef2ed71b05b0925249d6172bd85c0d8b48d9056f` |
| 9 | `fs-id1168345237280` | `CNX_ElemAlg_Figure_02_05_002b_img_new.jpg` | 65674 | 750×174 | `image/jpeg` | `JPEG` | `aa5e9f7f2ce320d7743875de28908a3b521b293c6c038941946527d9bed4ac64` |
| 10 | `fs-id1168345221909` | `CNX_ElemAlg_Figure_02_05_002c_img_new.jpg` | 47984 | 750×104 | `image/jpeg` | `JPEG` | `8565c80f1dbb40440d9ea7018bc18f0f077c350903fe61a659c5fd385f68a4fd` |
| 11 | `eip-id1168179354701` | `CNX_ElemAlg_Figure_02_05_003e_img_new.jpg` | 18319 | 291×34 | `image/png` | `JPEG` | `2b784a9d466263a82093638306b39f836f0ff3dc05b4f0643fbf2e5f0542cc16` |
| 12 | `eip-id1168179354734` | `CNX_ElemAlg_Figure_02_05_003f_img_new.jpg` | 22802 | 291×41 | `image/png` | `JPEG` | `959651f78c004a1de6e58c6521a00c4e89bed154e7fe82a60b1357720c31c9f4` |
| 13 | `eip-id1168179354755` | `CNX_ElemAlg_Figure_02_05_003g_img_new.jpg` | 22103 | 291×34 | `image/png` | `JPEG` | `c60fe2caf43905450b5dd2a3c80059e065a7d7293f7124a20b81d0ecf240e8bb` |
| 14 | `eip-id1168179354777` | `CNX_ElemAlg_Figure_02_05_003h_img_new.jpg` | 18542 | 291×13 | `image/png` | `JPEG` | `896a2deef74a57d3d599efc98d14eb95cfcb6a71ecd539ead42d4bd2e3ab750c` |
| 15 | `eip-id1168179354798` | `CNX_ElemAlg_Figure_02_05_003i_img_new.jpg` | 17264 | 291×13 | `image/png` | `JPEG` | `3ba4f4a1190871799571af666f36583c28cb498694f962e01040c8317fd13b74` |
| 16 | `eip-id1168179354818` | `CNX_ElemAlg_Figure_02_05_003j_img_new.jpg` | 19931 | 291×34 | `image/png` | `JPEG` | `d7d9a2deb310ba6dea31ec8d2fdd31af31a9a6c25ee2479dc084ecb890ac62cb` |
| 17 | `eip-id1168179354839` | `CNX_ElemAlg_Figure_02_05_003k_img_new.jpg` | 17715 | 291×13 | `image/png` | `JPEG` | `6370b6e9cd2f4997f67acb7c805f6eae7a648c1c8c27223f8de9dddf0fb83060` |
| 18 | `eip-id1168179354856` | `CNX_ElemAlg_Figure_02_05_003a_img_new.jpg` | 16516 | 291×33 | `image/png` | `JPEG` | `819390bbb47518b7525da4d23b1e916148984bd68a69fa101e11a1e770faba67` |
| 19 | `eip-id1168179354883` | `CNX_ElemAlg_Figure_02_05_003b_img_new.jpg` | 20758 | 291×33 | `image/png` | `JPEG` | `f9c481f088f89e6a0bdfee162bda0970912a65533f5b509e4906598b602851df` |
| 20 | `eip-id1168179354901` | `CNX_ElemAlg_Figure_02_05_003c_img_new.jpg` | 16051 | 291×22 | `image/png` | `JPEG` | `94ebc122b31b32363c174a3d316c3f099ead15d513ccba3cd9fbc1ac692ed9a4` |
| 21 | `eip-id1168179354918` | `CNX_ElemAlg_Figure_02_05_003d_img_new.jpg` | 15079 | 291×13 | `image/png` | `JPEG` | `955385393b66e6bcb39089dd45dcd91fcfc96d396866ec70eca98e9d0bb885cc` |
| 22 | `eip-id1168184905325` | `CNX_ElemAlg_Figure_02_05_004f_img_new.jpg` | 18778 | 217×33 | `image/png` | `JPEG` | `23807922419df100ba15e20c44071e802c78cebea9f00c38bb274a6456e43735` |
| 23 | `eip-id1168184905360` | `CNX_ElemAlg_Figure_02_05_004g_img_new.jpg` | 22840 | 217×38 | `image/png` | `JPEG` | `f4652285a92e6517d28bbb8cc8b123fafbc73d3b8769cb08472575ea80a5f063` |
| 24 | `eip-id1168178100816` | `CNX_ElemAlg_Figure_02_05_004h_img_new.jpg` | 23255 | 217×33 | `image/png` | `JPEG` | `d4768643692e38b69deb664661586c1b7d323b92be28179569742c35609f1ab3` |
| 25 | `eip-id1168178100837` | `CNX_ElemAlg_Figure_02_05_004i_img_new.jpg` | 19050 | 217×14 | `image/png` | `JPEG` | `be446af70fbc1a1d837ead2f17891e8a2673cefcdfa4bc3ac9a9b4a2d5ba43cf` |
| 26 | `eip-id1168178100865` | `CNX_ElemAlg_Figure_02_05_004j_img_new.jpg` | 22684 | 217×14 | `image/png` | `JPEG` | `fb1861bcabb97069772e39c605c5af1e63533399444420baf2062757e5bec3e9` |
| 27 | `eip-id1168178100885` | `CNX_ElemAlg_Figure_02_05_004k_img_new.jpg` | 19213 | 217×14 | `image/png` | `JPEG` | `7dde1de940c3999aaff79de6525d6ce90ace7f9a36c03d5a12d0f8907c5fa4db` |
| 28 | `eip-id1168178100906` | `CNX_ElemAlg_Figure_02_05_004l_img_new.jpg` | 22063 | 217×13 | `image/png` | `JPEG` | `190a4f8d01dcb361279b947d46d81c5cdd9d1e71e639f26a4d2cc8d34f0662ee` |
| 29 | `eip-id1168178100927` | `CNX_ElemAlg_Figure_02_05_004m_img_new.jpg` | 19670 | 217×13 | `image/png` | `JPEG` | `9cea213ed04eb63ba40a41985cbaa287288bce33a811cdc956f57b3814a928cd` |
| 30 | `eip-id1168178100947` | `CNX_ElemAlg_Figure_02_05_004n_img_new.jpg` | 22258 | 217×34 | `image/png` | `JPEG` | `ad780de413dd73044a5ea9849a69d78941dcb332c284f6720b535aa1c7d8f17b` |
| 31 | `eip-id1168178100968` | `CNX_ElemAlg_Figure_02_05_004o_img_new.jpg` | 19896 | 217×13 | `image/png` | `JPEG` | `802e18f88c294a7986928170d748780d03e8e77283758c0844992cb3a80b843d` |
| 32 | `eip-id1168178100985` | `CNX_ElemAlg_Figure_02_05_004a_img_new.jpg` | 16674 | 217×33 | `image/png` | `JPEG` | `fad158ef90ae619b17aec8d97c6c7a66fa0b1924f9e770f20bc8f738371fd046` |
| 33 | `eip-id1168178101012` | `CNX_ElemAlg_Figure_02_05_004b_img_new.jpg` | 19143 | 217×33 | `image/png` | `JPEG` | `2a66f108382dc83e69c0d5bda0da87b42c17abed53faaaf3127afd8478a53c57` |
| 34 | `eip-id1168178101030` | `CNX_ElemAlg_Figure_02_05_004c_img_new.jpg` | 19365 | 217×33 | `image/png` | `JPEG` | `3a03f5f442418711fcacdfa4b2276d843ed1015ae61750f2074285bfaf13b0b9` |
| 35 | `eip-id1168178101048` | `CNX_ElemAlg_Figure_02_05_004d_img_new.jpg` | 16850 | 217×33 | `image/png` | `JPEG` | `abcdb412e59f7e5973fbcf48edaa106b290b6832bc3fe63700a5808baa9fbf29` |
| 36 | `eip-id1168178101066` | `CNX_ElemAlg_Figure_02_05_004e_img_new.jpg` | 17742 | 217×33 | `image/png` | `JPEG` | `03bd9a3f5f2191e4de0183b2e1e506e1bd7a5a6c1c0f15101a46e97dfb07e962` |
| 37 | `eip-id1168464984638` | `CNX_ElemAlg_Figure_02_05_005f_img_new.jpg` | 19422 | 176×33 | `image/png` | `JPEG` | `1fe95683537c370e0f1f2b623271a2b1b67eb2fa78c0b714a2258a1d5c252c11` |
| 38 | `eip-id1168464984660` | `CNX_ElemAlg_Figure_02_05_005g_img_new.jpg` | 21173 | 176×33 | `image/png` | `JPEG` | `a3df9f603a2ad9f4d8ca32f48a7e4d1b90898d4ec5e2305f940508f82c60f0dd` |
| 39 | `eip-id1168464996228` | `CNX_ElemAlg_Figure_02_05_005h_img_new.jpg` | 19560 | 176×13 | `image/png` | `JPEG` | `bfac523394d57de1f3bba6c102470e8397f2c86a1be58bb8ad570a9ef9bc1a22` |
| 40 | `eip-id1168464996250` | `CNX_ElemAlg_Figure_02_05_005i_img_new.jpg` | 20783 | 176×13 | `image/png` | `JPEG` | `d55c436ded8eb71a46f5a4aa914466f7d3f4dd0845166ef988bf7a530cf2c58e` |
| 41 | `eip-id1168464996271` | `CNX_ElemAlg_Figure_02_05_005j_img_new.jpg` | 18630 | 176×13 | `image/png` | `JPEG` | `ae55cc25f402a3248fca2a12dbd5c74707c49b860c857f3a603ca9e12c687d27` |
| 42 | `eip-id1168465016114` | `CNX_ElemAlg_Figure_02_05_005k_img_new.jpg` | 21436 | 176×34 | `image/png` | `JPEG` | `dbd59f58d17850f5fbe11610b1ad41f4fea5566020c3526303bb2e8e66e76b3a` |
| 43 | `eip-id1168465016135` | `CNX_ElemAlg_Figure_02_05_005l_img_new.jpg` | 19115 | 176×13 | `image/png` | `JPEG` | `83d131e406ec6fa813432b50eccfca8d35696c01aa863c3d2a4057fa1a3e4d1f` |
| 44 | `eip-id1168465016152` | `CNX_ElemAlg_Figure_02_05_005a_img_new.jpg` | 17265 | 176×32 | `image/png` | `JPEG` | `4b59282cc6cd3dc9d6c825270a1f126d259f34e2608a6ed813986f5d36d37895` |
| 45 | `eip-id1168464999838` | `CNX_ElemAlg_Figure_02_05_005b_img_new.jpg` | 19848 | 176×32 | `image/png` | `JPEG` | `1c25c635f6906a66dda8c3fbc88d7ba467b8457c4f7c6706c60ef73cf34e09d7` |
| 46 | `eip-id1168464999856` | `CNX_ElemAlg_Figure_02_05_005c_img_new.jpg` | 18765 | 176×33 | `image/png` | `JPEG` | `b4ebbd4736a6f2f78d6838098b3f0c11250d8d20039955569d322eddddaa61d0` |
| 47 | `eip-id1168464999874` | `CNX_ElemAlg_Figure_02_05_005d_img_new.jpg` | 18209 | 176×32 | `image/png` | `JPEG` | `fbc2aeafc1e24c8950c8e89a2cdbeae3c27f9af916acfb0a22ae4f588a701dec` |
| 48 | `eip-id1168464983869` | `CNX_ElemAlg_Figure_02_05_005e_img_new.jpg` | 17286 | 176×13 | `image/png` | `JPEG` | `1db2e67b35a1b26bbdd9966d725de0c77b4cbbd37c85440d928d2bbfd786d3cd` |
| 49 | `eip-id1168463877013` | `CNX_ElemAlg_Figure_02_05_006c_img_new.jpg` | 19194 | 244×32 | `image/png` | `JPEG` | `ee753c384beed9d17432e8fb482fe2241ca31328f8c29866fae9a64a68577510` |
| 50 | `eip-id1168463877034` | `CNX_ElemAlg_Figure_02_05_006d_img_new.jpg` | 21618 | 244×33 | `image/png` | `JPEG` | `b33f7ced22ebbc6e75fda639ab534dd22fbeccac4eaf1c39817246d85ab29694` |
| 51 | `eip-id1168463877054` | `CNX_ElemAlg_Figure_02_05_006e_img_new.jpg` | 20401 | 244×33 | `image/png` | `JPEG` | `a8dd61537a704cd8557c822b48fcfc05044a738ca1980e0e16cd11e2d806eabc` |
| 52 | `eip-id1168463821401` | `CNX_ElemAlg_Figure_02_05_006f_img_new.jpg` | 23616 | 244×35 | `image/png` | `JPEG` | `8c1af26c27e848b247ade0395639024b2c2ce4bb3f93577453e708e49f269108` |
| 53 | `eip-id1168463821422` | `CNX_ElemAlg_Figure_02_05_006g_img_new.jpg` | 23765 | 244×33 | `image/png` | `JPEG` | `b68d091dfcb4d2d020d89ab719de8df0275620503d2cc087c0ef4b533ddbeb42` |
| 54 | `eip-id1168463821443` | `CNX_ElemAlg_Figure_02_05_006h_img_new.jpg` | 19255 | 244×18 | `image/png` | `JPEG` | `3f0ebf5b73916bf594ef95b35bfcd18067824cf1e0c71259b8d2612eb40ddec2` |
| 55 | `eip-id1168463821465` | `CNX_ElemAlg_Figure_02_05_006i_img_new.jpg` | 21819 | 244×17 | `image/png` | `JPEG` | `2d92785f123788800fd6866901b25d78e2ed5b6b0b19dc516bdeff72d226f2b9` |
| 56 | `eip-id1168463852543` | `CNX_ElemAlg_Figure_02_05_006j_img_new.jpg` | 19362 | 244×17 | `image/png` | `JPEG` | `a2071539917667e30393dc04e32ef31c7068ae176d99d293c1083a76e7aa981b` |
| 57 | `eip-id1168463852565` | `CNX_ElemAlg_Figure_02_05_006k_img_new.jpg` | 22951 | 244×17 | `image/png` | `JPEG` | `8cbc7ab135f975ad07bf434fee9c190e7f88fdd0fab813a4d44665c79a2f9a2e` |
| 58 | `eip-id1168463852586` | `CNX_ElemAlg_Figure_02_05_006l_img_new.jpg` | 19562 | 244×17 | `image/png` | `JPEG` | `c7b0f21420477710a2ce99cb93f3d800b5447574f8a61cbff8115ae251fc8281` |
| 59 | `eip-id1168463852603` | `CNX_ElemAlg_Figure_02_05_006a_img_new.jpg` | 18682 | 244×33 | `image/png` | `JPEG` | `ac1c01174629d6f5a9ac18d6ff09f936535034ceab481f17e1629d160d3fcf43` |
| 60 | `eip-id1168463852630` | `CNX_ElemAlg_Figure_02_05_006b_img_new.jpg` | 19814 | 244×33 | `image/png` | `JPEG` | `2022b43d0e68d8c1856165ce23987880d1dc330d6f16bd213cb69fe7e5a879f3` |
| 61 | `eip-id1168463852556` | `CNX_ElemAlg_Figure_02_05_009e_img_new.jpg` | 17583 | 151×33 | `image/png` | `JPEG` | `54c095b8256f7ebd284d228b09fc6cd523c6889dff52038882f005f3b9c7ca68` |
| 62 | `eip-id1168463852577` | `CNX_ElemAlg_Figure_02_05_009f_img_new.jpg` | 22298 | 151×38 | `image/png` | `JPEG` | `3af2dad79e0488fbc832853c4ebec7f963505acf1afb22dfaf3f036c313e42a4` |
| 63 | `eip-id1168463852597` | `CNX_ElemAlg_Figure_02_05_009g_img_new.jpg` | 16438 | 151×13 | `image/png` | `JPEG` | `e98fee82b43b33499d5e1cc18bbc9c395c604094a5ef726b2cba78f4f864c82f` |
| 64 | `eip-id1168463852619` | `CNX_ElemAlg_Figure_02_05_009h_img_new.jpg` | 20504 | 151×13 | `image/png` | `JPEG` | `c7284b94798e9d050b75e83509c081c2edcdb6c82ca2eae6a40636bd3bb80602` |
| 65 | `eip-id1168463822528` | `CNX_ElemAlg_Figure_02_05_009i_img_new.jpg` | 16526 | 151×13 | `image/png` | `JPEG` | `c4874e773eb70c017d564da71f0f3ba6f6314953bddc11dc79214f8491f7eb67` |
| 66 | `eip-id1168463822549` | `CNX_ElemAlg_Figure_02_05_009j_img_new.jpg` | 20324 | 151×32 | `image/png` | `JPEG` | `2b46de9ded31b1dda2413f4ebc27bf8067d53d40bb4014826306abf6c0aa8a05` |
| 67 | `eip-id1168463822570` | `CNX_ElemAlg_Figure_02_05_009k_img_new.jpg` | 16529 | 151×13 | `image/png` | `JPEG` | `06701dcabce2ca9f97364fb64061a86f819b17c7fbb30feb8a2936fd2e54d9a8` |
| 68 | `eip-id1168463822588` | `CNX_ElemAlg_Figure_02_05_009a_img_new.jpg` | 15575 | 151×33 | `image/png` | `JPEG` | `b37493537d0a1d46243e769cd2e2499b86883ffe9541e4e4e315eb1fb5f81034` |
| 69 | `eip-id1168463822615` | `CNX_ElemAlg_Figure_02_05_009b_img_new.jpg` | 17327 | 151×33 | `image/png` | `JPEG` | `fae918aa0901d24ff5ce583af043fee430802fd2172667c923337e6808f9617b` |
| 70 | `eip-id1168463861390` | `CNX_ElemAlg_Figure_02_05_009c_img_new.jpg` | 15426 | 151×33 | `image/png` | `JPEG` | `85bac1b3677deec0b31c80f8d1248a630500367cd402204b75ee564ea2f09876` |
| 71 | `eip-id1168463861408` | `CNX_ElemAlg_Figure_02_05_009d_img_new.jpg` | 15829 | 151×32 | `image/png` | `JPEG` | `e18df3d57c97f29ad22f71536e5ba13a66cbcd38aa6d1ba912bb92b0c7a3f899` |
| 72 | `eip-id1168464996022` | `CNX_ElemAlg_Figure_02_05_010e_img_new.jpg` | 16534 | 248×29 | `image/png` | `JPEG` | `a28dfa16b851d2ca7273ab99968bed5e95b5dc15b96ef34f78d8f0de14812755` |
| 73 | `eip-id1168464996043` | `CNX_ElemAlg_Figure_02_05_010f_img_new.jpg` | 21282 | 248×38 | `image/png` | `JPEG` | `7588071f3913e40de983140e2b9abf83fddbbf9011bab272a6fb869741698f1f` |
| 74 | `eip-id1168464996064` | `CNX_ElemAlg_Figure_02_05_010g_img_new.jpg` | 20324 | 248×30 | `image/png` | `JPEG` | `cfeb5b76ea6eede317d2b01a675b35461f0107cb997bdcd9c543bda6b7e1273a` |
| 75 | `eip-id1168464996085` | `CNX_ElemAlg_Figure_02_05_010h_img_new.jpg` | 17501 | 248×13 | `image/png` | `JPEG` | `f10939749ff1f87f3bc34306b44f7bd303ee9d71f02ad99ebcc2ef0252d763dc` |
| 76 | `eip-id1168464996106` | `CNX_ElemAlg_Figure_02_05_010i_img_new.jpg` | 20978 | 248×14 | `image/png` | `JPEG` | `2efa3b207f0d953a69664ca8b124219e90123240bb90b198ad0e365410ab92a1` |
| 77 | `eip-id1168464987715` | `CNX_ElemAlg_Figure_02_05_010j_img_new.jpg` | 17207 | 248×13 | `image/png` | `JPEG` | `4f6033903f3e3fc8e9944017f3e49ade0d52c67aed9904014ef716aa4e06782d` |
| 78 | `eip-id1168464987736` | `CNX_ElemAlg_Figure_02_05_010k_img_new.jpg` | 21086 | 248×14 | `image/png` | `JPEG` | `42cb64c50e43b3d940089951e5ad3204b9495a594dc53943665a2ee3e710d8f5` |
| 79 | `eip-id1168464987758` | `CNX_ElemAlg_Figure_02_05_010l_img_new.jpg` | 17401 | 248×13 | `image/png` | `JPEG` | `216caa7831535210e946453047e48fc95300c67a192d40c9d4defef40c9558cb` |
| 80 | `eip-id1168464987775` | `CNX_ElemAlg_Figure_02_05_010a_img_new.jpg` | 14830 | 248×29 | `image/png` | `JPEG` | `8f2e49c88ea337ac52527c58432f3d60c97a8d30d4f6a6e7cd8ad7cd55cb13bf` |
| 81 | `eip-id1168464987802` | `CNX_ElemAlg_Figure_02_05_010b_img_new.jpg` | 17757 | 248×33 | `image/png` | `JPEG` | `cd3891d11abe43ec2c56aaaa8a29970ed7b37cc2f6df4ba16a37a89e735e6921` |
| 82 | `eip-id1168464987820` | `CNX_ElemAlg_Figure_02_05_010c_img_new.jpg` | 15244 | 248×22 | `image/png` | `JPEG` | `1d26dbc2f660156558a54edaae91a70583f81175f5b3ca276772f2f4d7baaf91` |
| 83 | `eip-id1168464987839` | `CNX_ElemAlg_Figure_02_05_010d_img_new.jpg` | 13954 | 248×13 | `image/png` | `JPEG` | `02e1228c714265b31d4a23484d38219322f1daea714f1c4ce302616e5a34e8e7` |
| 84 | `eip-id1168463879842` | `CNX_ElemAlg_Figure_02_05_011c_img_new.jpg` | 18720 | 264×35 | `image/png` | `JPEG` | `6d227ead13d3f35e9589e0d2e856729f80de4d6adb9b4a32187c96be8136ee21` |
| 85 | `eip-id1168463879863` | `CNX_ElemAlg_Figure_02_05_011d_img_new.jpg` | 22588 | 264×38 | `image/png` | `JPEG` | `ea81e1f41738f4cffe67a11d07c1f68029ec2ed7ce17ed84595080aedd75ff7a` |
| 86 | `eip-id1168463879884` | `CNX_ElemAlg_Figure_02_05_011e_img_new.jpg` | 22739 | 264×37 | `image/png` | `JPEG` | `08c9360d695ee7a0f98c4122a7766abb56a99fd5ecf4c8c6e2ae522b0c61c3cb` |
| 87 | `eip-id1168463779915` | `CNX_ElemAlg_Figure_02_05_011f_img_new.jpg` | 19344 | 264×17 | `image/png` | `JPEG` | `cf8ee0868aa336d35e6e565001d4a255a8f231bbf81ce907f8b1e3ce60836dda` |
| 88 | `eip-id1168463779925` | `CNX_ElemAlg_Figure_02_05_011g_img_new.jpg` | 19178 | 264×17 | `image/png` | `JPEG` | `efbdfd1c52c6fbdb9eeab787891d248c650060ae4d354a7c75db0309c074c4d0` |
| 89 | `eip-id1168463779934` | `CNX_ElemAlg_Figure_02_05_011h_img_new.jpg` | 19121 | 264×19 | `image/png` | `JPEG` | `f2cd310c50ff6dbfa3da4d4bdc51ca3abf12306bc225f471f87384c6a9a173db` |
| 90 | `eip-id1168463779956` | `CNX_ElemAlg_Figure_02_05_011i_img_new.jpg` | 22455 | 264×17 | `image/png` | `JPEG` | `4f08d329f0ff6037680fc4b5dfa277d27863cae65cbcaced52cee33c5f73a9a1` |
| 91 | `eip-id1168463779977` | `CNX_ElemAlg_Figure_02_05_011j_img_new.jpg` | 18956 | 264×17 | `image/png` | `JPEG` | `182d6b406797c7c5d7d731a3d80e3b5a28935957e594cd39fd84dbaab9907893` |
| 92 | `eip-id1168463779998` | `CNX_ElemAlg_Figure_02_05_011k_img_new.jpg` | 22324 | 264×17 | `image/png` | `JPEG` | `539989c460f364808ae98168605825a0e9fa2c83f1934af9b80549dca9679d85` |
| 93 | `eip-id1168463875811` | `CNX_ElemAlg_Figure_02_05_011l_img_new.jpg` | 19338 | 264×17 | `image/png` | `JPEG` | `8871ecfcf70bea81c5d885af80da38825038602266d011d60cbaf4744b5855ae` |
| 94 | `eip-id1168463875832` | `CNX_ElemAlg_Figure_02_05_011m_img_new.jpg` | 21820 | 264×34 | `image/png` | `JPEG` | `46246c774d1900cc3c6e6e05b14a3e0a5e29465fea336abc32a85d96c92e055f` |
| 95 | `eip-id1168463875853` | `CNX_ElemAlg_Figure_02_05_011n_img_new.jpg` | 19934 | 264×18 | `image/png` | `JPEG` | `b1a4e5ec06e4c8c76d621d865c2f24b722bf13dbb2ceff43849c9a18c3e06ed0` |
| 96 | `eip-id1168463875870` | `CNX_ElemAlg_Figure_02_05_011a_img_new.jpg` | 17852 | 264×35 | `image/png` | `JPEG` | `67a1ade98e89a9b755dba027aeb64f9414dcb6e159ec696c77e2a54ce050d03f` |
| 97 | `eip-id1168463875898` | `CNX_ElemAlg_Figure_02_05_011b_img_new.jpg` | 20446 | 264×34 | `image/png` | `JPEG` | `f74d2b08039d74efaaf884d5b328c6427d7adc275425e1efaf75da4a129ba3aa` |
| 98 | `eip-id1168464992552` | `CNX_ElemAlg_Figure_02_05_007b_img_new.jpg` | 19681 | 363×14 | `image/png` | `JPEG` | `0e0e9f52cd754e6cf968ad8e5417927a146afeac1eac4f294450047abc499cbc` |
| 99 | `eip-id1168465020048` | `CNX_ElemAlg_Figure_02_05_007c_img_new.jpg` | 22982 | 363×16 | `image/png` | `JPEG` | `a0213302ce1d79f841bcf80f9338d03fa69f56b1717a1da0630d210153a67d95` |
| 100 | `eip-id1168465020065` | `CNX_ElemAlg_Figure_02_05_007d_img_new.jpg` | 23662 | 363×16 | `image/png` | `JPEG` | `5be8041c955c7894bec73716c95d7c9ffd5041eb1d218da378a093ba6749ab73` |
| 101 | `eip-id1168465020082` | `CNX_ElemAlg_Figure_02_05_007e_img_new.jpg` | 19906 | 363×14 | `image/png` | `JPEG` | `47010ab49a21b9b2a0c81b017616fdf5df88eff90e4e7e836e114ff7dc9d5ef6` |
| 102 | `eip-id1168465020099` | `CNX_ElemAlg_Figure_02_05_007f_img_new.jpg` | 22624 | 363×13 | `image/png` | `JPEG` | `3cd6941aff3987bf57493d7ea62b5cf0dd506fb8cfc570325579da3044d6a228` |
| 103 | `eip-id1168465020116` | `CNX_ElemAlg_Figure_02_05_007g_img_new.jpg` | 20037 | 363×13 | `image/png` | `JPEG` | `273c1914853057c26bd7bea1775bc64a7deeb890a0af7d04abae20094a71ddee` |
| 104 | `eip-id1168465020134` | `CNX_ElemAlg_Figure_02_05_007h_img_new.jpg` | 24005 | 363×14 | `image/png` | `JPEG` | `bb6099f70c07f7995358f92655711bcf65bf35470a5a913b73ca787dad6181fd` |
| 105 | `eip-id1168465020151` | `CNX_ElemAlg_Figure_02_05_007i_img_new.jpg` | 20442 | 363×13 | `image/png` | `JPEG` | `2bd7dfe5a259d21ae96515b33a7b56c53df4623c95b3b34ddf5171f33ce86120` |
| 106 | `eip-id1168465020168` | `CNX_ElemAlg_Figure_02_05_007j_img_new.jpg` | 23575 | 363×34 | `image/png` | `JPEG` | `571c1fbb17d9ee337b77e75cf3a246725fb941d323ac65ee64a148ff511b4f46` |
| 107 | `eip-id1168465020185` | `CNX_ElemAlg_Figure_02_05_007k_img_new.jpg` | 20622 | 363×13 | `image/png` | `JPEG` | `339ca38c2e276c0225cbc74e510168dfc0b511cfb00c0eeb7d938e83a2ea97bf` |
| 108 | `eip-id1168464985122` | `CNX_ElemAlg_Figure_02_05_007a_img_new.jpg` | 27058 | 363×74 | `image/png` | `JPEG` | `f39a25aebf854c70611b651daed1bcae4b54def49531349ffd8463b4b9be9900` |
| 109 | `eip-id1168464992433` | `CNX_ElemAlg_Figure_02_05_008b_img_new.jpg` | 20770 | 253×15 | `image/png` | `JPEG` | `661591c1b8646c2a38f3f2e4f5fe7a9a471f598b13e03aa0f6b3a18ccce8702d` |
| 110 | `eip-id1168464992467` | `CNX_ElemAlg_Figure_02_05_008c_img_new.jpg` | 21095 | 253×15 | `image/png` | `JPEG` | `77850f0eb0dfb1d57d2e0b64bc294de0241bd45cde50cad3257da58b88065816` |
| 111 | `eip-id1168464992485` | `CNX_ElemAlg_Figure_02_05_008d_img_new.jpg` | 20154 | 253×13 | `image/png` | `JPEG` | `6a814687dfe759166b88b9b6c1c2f92ec4f7ea68ff63cefe782097b62d1a99a2` |
| 112 | `eip-id1168464992502` | `CNX_ElemAlg_Figure_02_05_008e_img_new.jpg` | 24226 | 253×17 | `image/png` | `JPEG` | `c8167dfd94f7e76bef8fcd7c5f0cd32132eb01964803846a9b83c26448de8259` |
| 113 | `eip-id1168464992519` | `CNX_ElemAlg_Figure_02_05_008f_img_new.jpg` | 20175 | 253×14 | `image/png` | `JPEG` | `4cf41436176df70b6c37ecd6e6aeeee38e68a7aca6972b6facaf35aecd55dafa` |
| 114 | `eip-id1168464992537` | `CNX_ElemAlg_Figure_02_05_008g_img_new.jpg` | 22911 | 253×13 | `image/png` | `JPEG` | `a4bc4787b4dd291b5021ec74c29244d4ed81b2091b9dd9fa00bd4f2e94dfca96` |
| 115 | `eip-id1168464992554` | `CNX_ElemAlg_Figure_02_05_008h_img_new.jpg` | 20298 | 253×13 | `image/png` | `JPEG` | `7bd753a00c78ccd2d26ab5079ccd8515821f3ac25a05654bfa0683700ed7fd86` |
| 116 | `eip-id1168464992571` | `CNX_ElemAlg_Figure_02_05_008i_img_new.jpg` | 24087 | 253×35 | `image/png` | `JPEG` | `78f1bda80cec06ad7c1b9d7a36ab33f9e3af4ffa2625e67fbf354c735ebbb2f4` |
| 117 | `eip-id1168465020030` | `CNX_ElemAlg_Figure_02_05_008j_img_new.jpg` | 20164 | 253×14 | `image/png` | `JPEG` | `69c7c2b7a2c855c55254b25a9bced014e7992636a2ca9ea3f39e91f4fd93c9ae` |
| 118 | `fs-id1168342122596` | `CNX_ElemAlg_Figure_02_05_201_img_new.jpg` | 54893 | 658×103 | `image/jpeg` | `JPEG` | `1832beb3ba775d614b0af7c5cba56bcbb3537bd542597af3cab950972990f6fb` |
