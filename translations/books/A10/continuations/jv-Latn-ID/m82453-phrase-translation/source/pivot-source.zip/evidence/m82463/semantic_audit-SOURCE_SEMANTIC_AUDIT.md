# m82463 source semantic and mathematical audit

## Authority and bounded scope

- Frozen source: `authority/source/modules/m82463/index.cnxml`.
- Exact source size: **122,749 bytes**.
- Exact source SHA-256: **b6345a5a6a99108f9d32d6518445a4ae70a6b0c54a258021dffc6f2b77b8278a**.
- Module metadata: content ID `m82463`; UUID `16401322-10a2-4be5-9d4a-efd5ccbe091f`; title **Solve Equations Using the Subtraction and Addition Properties of Equality**.
- Direct-media boundary: the 68 `image/@src` references in this CNXML, each resolved to `authority/source/media` in document order.
- The source, direct assets, translated targets, live ledgers, backend, and sibling modules were not edited. This packet only records source-side controls in `qa/m82463`.

## Verdict

The source is well-formed XML. All **711 IDs are unique**. Every one of the **116 exercises** has exactly one direct problem. Exactly **78** have one direct supplied solution and **38** intentionally have none; no exercise has multiple problems or multiple solutions. All 78 supplied answers and worked checks were independently recomputed or verified against their stated problems. The algebra, arithmetic, units, and application answers are correct. There are **no P1 mathematical defects and no P2/P3 answer defects**.

Seventeen correction candidates remain. Eleven are target-applicable source copy/accessibility repairs: six P2 accessibility defects and five P3 copy/accessibility defects. Six additional assembly records cover truthful MIME, raster localization, responsive reflow, low-resolution diagrams, empty trailing blocks, and one P2 fixed-pixel equation typo. Correction inventory: **P1 0 / P2 7 / P3 10**. Target-applicable IDs: **EA2-C0206–EA2-C0215 and EA2-C0222**. Assembly-only range: **EA2-C0216–EA2-C0221**.

Frozen authority remains byte-identical. No correction is applied merely by being described here.

## XML and topology inventory

| Surface | Count |
|---|---:|
| All elements | 3,249 |
| CNXML namespace elements | 1,234 |
| MDML namespace elements | 4 |
| MathML namespace elements | 2,011 |
| IDs / unique IDs / duplicate IDs | 711 / 711 / 0 |
| Titles, total / unique normalized strings | 32 / 19 |
| Sections / notes / examples | 11 / 35 / 12 |
| Lists / items | 12 / 42 |
| Paragraphs / captions | 236 / 3 |
| Exercises / problems / supplied solutions | 116 / 116 / 78 |
| CNXML equations / MathML roots / MathML elements / `mtext` | 3 / 220 / 2,011 / 12 |
| Tables / rows / entries | 12 / 69 / 149 |
| Figures / media / images / unique direct assets | 3 / 68 / 68 / 68 |
| Links, total / internal / cross-document / URL | 10 / 6 / 4 / 0 |
| Terms / definitions / glossary nodes | 8 / 1 / 1 |
| Reader-facing attributes, `alt` / `aria-label` / `summary` / `title` | 68 / 11 / 1 / 0 |

Deterministic topology receipts:

- Ordered-ID SHA-256: **afb08347a7cdf2815830867d21b03b5d0728e579980901d930ce220cd10b0ca9**. Preimage is every nonempty ID in document order, LF-joined without a terminal LF.
- Topology SHA-256: **eefedda01c7227c4da175d06981b0dc27fae9a27ecf0ebf1431d65cb71512bd7**. Each preorder element contributes expanded tag, TAB, and ID-or-empty; rows are LF-joined without a terminal LF.
- Math semantic-surface SHA-256: **bb6f14c9769cf1e439fce82030243c8915b55fa91681e0a0f355efe02ecd4572** across 2,011 MathML elements. Each MathML element contributes expanded tag, sorted attributes, and normalized direct text in document order.

## Exhaustive reader-block projection

The exact structural reader projection contains **462 blocks**:

- 32 `title`;
- 236 `para`;
- 42 `item`;
- 149 `entry`;
- 3 `caption`.

Exactly **373** blocks have normalized descendant text. Exactly **89** do not: 87 table entries whose content is empty or media-only, plus the genuinely empty trailing paragraphs `fs-id1168345426284` and `fs-id1168345557201`. Media-only entries retain their media topology and are not missing translations. The two empty paragraphs carry no text, math, media, or links and are the subject of assembly record EA2-C0220.

Projection contract: each LF-terminated row is `ordinal|local-name|nearest-id-owner|sha256(normalized-descendant-text)|has-text`. The projection is **46,446 bytes**, SHA-256 **5fbd2124aff51693bde969492eff1cf19eea7df6d35b71a862d3cd2f611df038**. First row:

`1|title|title|40f4d3e5d587d2da3d1381675e705f0d3b1e4bc22b5f00e5ba85b8da17159b1b|1`

Last row:

`462|para|para#fs-id1168345688116|eaab7b9bce4f357fdcec76f4ae9175c36f1bf8fbe127f8f4679447ca8f4ebace|1`

This is the exhaustive translation traversal. A translator must visit all 462 slots in order, translate all 373 text-bearing blocks, preserve media-only structure, and preserve the two empty paragraph IDs without inventing prose.

## Exercise, answer, and mathematical audit

Deterministic relation receipts:

- Exercise topology ledger: **116 rows / 5,891 bytes**, SHA-256 **9a161a6e75d51eb3389a1d6d71e1c1e47b23aa26a61be72865f85a9c489fbf18**. Each row is exercise ID TAB problem ID TAB solution-ID-or-empty, LF-joined without terminal LF.
- Supplied pair ledger: **78 rows / 2,939 bytes**, SHA-256 **1de7bb1ab341598da610e4d3dd8046bc1bd7c72ff290aa990b77ec173b91923c**. Each row is problem ID TAB solution ID.
- Unsupplied-problem ledger: **38 rows / 721 bytes**, SHA-256 **3bdd51b93e2d43a219f858337ee46271adc8707737294791cf0fbbb88d945b7d**. Each row is one problem ID.
- Independent ordinal coverage ledger: **116 rows / 6,286 bytes**, SHA-256 **724057d91a6979e5025225e189f1813eb3c03bc8876e9740778745592c797e37**. Each LF-terminated row is ordinal TAB exercise ID TAB problem ID TAB solution-ID-or-hyphen.
- Worked-example ledger: **12 rows / 455 bytes**, SHA-256 **212e22a393c71329a96e2082863f1bb58180a999b1b7bbc0076c3519d7e2e170**. Each row binds one example ID to its descendant exercise ID(s), LF-joined without terminal LF.

Coverage by instructional wrapper:

| Wrapper | Exercises | Supplied solutions |
|---|---:|---:|
| Readiness notes before the first section | 4 | 4 |
| Verify a Solution of an Equation | 3 | 3 |
| Subtraction and Addition Properties | 12 | 12 |
| Equations Requiring Simplification | 9 | 9 |
| Translate to an Equation and Solve | 6 | 6 |
| Translate and Solve Applications | 6 | 6 |
| Practice Makes Perfect | 72 | 36 |
| Everyday Math | 2 | 1 |
| Writing Exercises | 2 | 1 |

The 38 unsupplied problems follow the source's intended alternating answer-key pattern in the practice, everyday-math, and writing sections; they are not broken problem/solution links.

The audit recomputed all supplied surfaces, including:

- readiness evaluation and simplification;
- candidate-solution substitution checks;
- one-step integer, fraction, and decimal equations;
- subtraction/addition-property examples and all highlighted inverse-operation steps;
- equations that require distribution, commutative reordering, combining like terms, and isolation;
- English-sentence-to-equation translations;
- newspaper, car-price, admission-price, distance, age, weight, temperature, salary, textbook, construction, and baking applications;
- all odd-numbered supplied practice answers and the supplied writing response.

No supplied result, MathML equation, or application answer requires correction. One fixed-pixel verification asset, media `eip-id1169750892315`, appends a stray visible `z` to the constant `−8` in its first substituted line; the source problem, surrounding prose, alt, later raster lines, and final `−8=−8` result are correct. EA2-C0221 requires the native reflow to remove that pixel typo. The question-over-equals marks in checking rasters mean “is this equality true?” and must not be flattened into ordinary equals signs until the check is confirmed on the next line.

## MathML and embedded text

There are **220 MathML roots**, **2,011 MathML elements**, and **12 `m:mtext` nodes**. The `mtext` split is exact:

- lexical, translate: `If` (2), `then` (2), `$28,675 is $875 less than` (1), `and` (2), `inch` (1) = **8**;
- protected symbolic: the standalone minus sign `−` (4) = **4**.

Fractions, decimals, unary negatives, implicit multiplication, parentheses, relation signs, `mover` question marks, check marks, and table row order must remain structurally intact. The four protected minus signs must remain U+2212 and must not become a hyphen or an Indonesian word. Lexical `mtext` must be localized while its adjacent numbers, currency symbols, variables, and unit scope remain unchanged.

## Semantic and pedagogical findings

The module's mathematical progression is coherent:

1. verify a proposed solution by substitution and comparison of both equation sides;
2. model an equation with an envelope and counters;
3. derive the subtraction and addition properties of equality;
4. simplify each side before isolating a variable when required;
5. translate equality phrases into equations;
6. model and solve real-life applications;
7. consolidate the workflow in key concepts, practice, everyday math, writing, and self-check.

The formal distinction between an expression and an equation is preserved. Physical sides of the counter workspace are not equation `ruas`; use `sisi` for the physical model and `ruas kiri/kanan` for the algebraic relation. Physical balance language from m82462 must not replace formal equality language here.

Two reader-copy defects are independent of the mathematics: `fs-id1168345398198` omits “than” from “$3.25 less than,” and the title under example `fs-id1168345429454` reads “How to Solve Translate and Solve Applications.” EA2-C0214 and EA2-C0215 correct these naturally in the target while retaining the original as evidence.

## Exact correction findings

| Candidate | Priority | Target stage | Owner | Finding |
|---|---|---|---|---|
| EA2-C0206 | P2 | target | table `eip-id1169740536663` | Accessible substitution says minus 3 instead of visible/source minus 2. |
| EA2-C0207 | P2 | target | media `eip-id1169752915890` | Alt calls variable `q`; raster and problem use `a`. |
| EA2-C0208 | P3 | target | table `eip-id1169752186691` | Accessible fraction is voiced “11 eights,” not “11 eighths.” |
| EA2-C0209 | P2 | target | table `eip-id1169753315823` | Verification drops a negative sign and twice says “negative u” instead of negative 8. |
| EA2-C0210 | P2 | target | table `eip-id1169754045191` | Distributed accessible equation says plus 5y instead of minus 5y. |
| EA2-C0211 | P2 | target | solution `fs-id1168341852784` | MacIntyre alts miscount the seven-step layout and twice identify the unknown/answer as second-month rather than first-month weight. |
| EA2-C0212 | P3 | target | media `fs-id1168345276851` | Step 3 alt says “equation on both sides of the equation,” not the visible “expressions on both sides.” |
| EA2-C0213 | P3 | target | media `eip-id1169753253504` | Alt changes lowercase `x` to uppercase `X` and calls a typeset equation a speculative photograph. |
| EA2-C0214 | P3 | target | para `fs-id1168345398198` | “$3.25 less the price” is missing “than.” |
| EA2-C0215 | P3 | target | example `fs-id1168345429454` | How-to heading duplicates “Solve” and is ungrammatical. |
| EA2-C0216 | P3 | assembly | 53 image declarations | Declared PNG points to JPEG bytes. |
| EA2-C0217 | P3 | assembly | 15 English-labelled rasters | Visible English requires localized semantic reconstruction or the interim fallback trio. |
| EA2-C0218 | P3 | assembly | 50 notation-only rasters | Fixed low-height math/check strips require centered responsive reflow. |
| EA2-C0219 | P3 | assembly | three counter diagrams | Intrinsic resolution is too small for page-filling output; naive stretching is blurry. |
| EA2-C0220 | P3 | assembly | two empty paragraphs | Suppress layout-only whitespace while preserving IDs and topology parity. |
| EA2-C0221 | P2 | assembly | media `eip-id1169750892315` | Composite `n=12` check visibly shows `−8z` instead of the constant `−8` in one line. |
| EA2-C0222 | P2 | target | table `eip-id1169752878128` | Aria-label for the `y+37=−13` worked solution is copied from the earlier `x+3=8` model and voices the wrong equation, steps, result, and row count. |

The CSV is the controlling correction proposal. Upstream reporting remains deferred until full-corpus completion and deduplication into at most one concise issue.

## Accessibility surface audit

All **80 reader-facing attributes are nonempty**: 68 alt values, 11 table aria-labels, and one summary. Their ordered attribute projection has **80 rows / 8,041 bytes**, SHA-256 **9958cb7f6daa4d97458d4e095a38ea166a8019238d70b843648a0ebad6604272**. Each LF-terminated row is ordinal, owner local-name, owner ID, attribute name, normalized-value hash, and nonempty flag.

Visual comparison of every referenced raster against its alt/aria surface found the five P2 and three P3 accessibility-copy candidates EA2-C0206–EA2-C0213. A later translator-side exhaustive owner comparison found the additional P2 table-level aria defect EA2-C0222: `table#eip-id1169752878128` repeats the complete `x+3=8` label from `table#eip-id1169752224770` even though its six visible rows solve and check `y+37=−13`, yielding `y=−50`. The remaining source attributes correctly identify their visible equations, counters, arrows, red-highlighted operations, question-over-equals checks, check marks, table instructions, and self-check grid. Translation must rebuild every defective attribute from the actual visual and the correction record; blindly translating the defective English attribute is forbidden.

The single `summary` belongs to table `eip-249`, correctly identifies the seven-step car sticker-price procedure, and requires ordinary localization rather than correction.

## Direct asset closure and visual classification

All **68 references are unique, present, and PIL-decodable**. Total referenced bytes: **2,668,697**. Every file has a JPEG signature and decodes as `image/jpeg` in CMYK mode. Exactly **53** image elements nevertheless declare `image/png`; the remaining 15 truthfully declare `image/jpeg`.

Deterministic closure receipts:

- Asset-manifest SHA-256: **4b6800bc5658c875257c7a1b8b3825fddb7bc7e705fe8c2df3ca4788e3366916**. In media document order, each LF-terminated row is media ID TAB source path TAB bytes TAB SHA-256 TAB declared MIME TAB actual MIME. The manifest is **11,277 bytes**.
- Raw source-plus-assets SHA-256: **3da14492555527ad9e1cdeb9af1e7bc59c343d69d63f6345b81ec0883c9f46b7** over **2,791,446 bytes**. The preimage is raw CNXML followed without separators by every referenced asset in media document order.

Complete visual classification in direct-media order:

| Ordinals | Asset family | Count | Visual class |
|---|---|---:|---|
| 1–5 | `001a–e` | 5 | four notation/check rasters; ordinal 2 contains English “Substitute 3/2 for x.” |
| 6–8 | `002–004` | 3 | envelope-and-counter diagrams; `004` also shows `x+3=8` |
| 9–11 | `005a–c` | 3 | notation-only subtraction sequence |
| 12–17 | `006a–f` | 6 | notation-only integer equation/check sequence |
| 18–23 | `007a–f` | 6 | notation-only integer equation/check sequence |
| 24–31 | `008a–h` | 8 | notation-only fraction equation/check sequence |
| 32–37 | `009a–f` | 6 | notation-only decimal equation/check sequence |
| 38–41 | `010a–d` | 4 | English worked table for simplification and checking |
| 42–48 | `011a–g` | 7 | notation-only simplification/check sequence |
| 49–55 | `012a–g` | 7 | notation-only two-sided simplification/check sequence |
| 56–58 | `013a–c` | 3 | ordinal 56 English sentence-to-equation diagram; two notation-only steps |
| 59–60 | `014a–b` | 2 | ordinal 59 English sentence-to-equation diagram; one notation-only result |
| 61–67 | `015a–g` | 7 | English seven-step newspaper application table |
| 68 | `201` | 1 | English self-check table |

Therefore the exact classes are **15 English-labelled rasters**, **50 notation-only rasters**, and **3 pedagogical counter diagrams**. English-labelled ordinals are 2, 38–41, 56, 59, and 61–68. Notation-only ordinals are 1, 3–5, 9–37, 42–55, 57–58, and 60. Diagram ordinals are 6–8.

False-PNG declaration ordinals are 1–5, 9–37, and 42–60. Truthful JPEG declaration ordinals are 6–8, 38–41, and 61–68.

The three diagrams measure 211×129, 525×129, and 212×160. The 50 notation rasters are largely 13–52 pixels high; even the composite verification images remain fixed-pixel layouts. The worked English tables are split across multiple 740–761-pixel-wide row images. Stretching these files is not acceptable reflow.

## Reflow and localization disposition

Final reader assembly must replace the 15 English-labelled rasters with localized semantic HTML/MathML/SVG or an equivalent selectable structure. An interim translated module may retain each source raster only with the complete fallback trio: nonempty accurate Indonesian alt, a visible Indonesian transcription/key adjacent to the image, and an explicit disclosure that the retained source pixels contain English. The fallback does not satisfy final publication reflow QA.

The 50 notation-only rasters must be reconstructed as semantic math/check rows wherever practical. Preserve the source's red operation highlights, fraction stacking, relational question marks, check marks, order, and worked-table grouping. In the `n=12` composite, remove the extraneous visible `z` after `−8` under EA2-C0221. Each reconstructed table must be centered, occupy useful content width, wrap at narrow widths, and expose a logical screen-reader order. Do not enlarge a 13-pixel-high JPEG to page width.

The three counter diagrams must be redrawn responsively or replaced with verified high-resolution derivatives. Preserve the exact counts of counters, envelope, dividing line, circled removal groups, arrow direction, equation label, captions, alt, source asset hashes, and rights linkage.

## Links and reference closure

All six internal targets resolve uniquely inside m82463:

- `CNX_ElemAlg_Figure_02_01_002_img_new`;
- `CNX_ElemAlg_Figure_02_01_003_img_new`;
- `CNX_ElemAlg_Figure_02_01_004_img_new`;
- `fs-id1168345195281`;
- `fs-id1168345390064`;
- `fs-id1168345285255`.

All four cross-document readiness links resolve uniquely in the declared Elementary Algebra 2e source modules:

| Document | Target ID | Witness source bytes | Witness source SHA-256 |
|---|---|---:|---|
| m82455 | `fs-id1170654236880` | 118,967 | 794635f93249017847f2646910d007e9de53b00ee6037133aa5c3edb7c2b88ec |
| m82455 | `fs-id1170652623775` | 118,967 | 794635f93249017847f2646910d007e9de53b00ee6037133aa5c3edb7c2b88ec |
| m82460 | `fs-id1170654067908` | 164,724 | ee089e74a6609868c94808e624d57016de348a791b577458c539c93584bba9a5 |
| m82453 | `fs-id1170655207375` | 184,248 | a8fdd235aa254c5a0a1248fa858e9b3579d9b40982bbc514cbe6a18c3e6fcbed |

There are no URL links and no unresolved source references.

## Source-preservation disposition

The authoritative CNXML and all 68 direct assets remain byte-identical. Reader corrections must be linked to the explicit correction IDs in `PROPOSED_CORRECTIONS.csv`. Source-origin prose, formulas, IDs, hierarchy, references, assets, and hashes remain immutable witnesses. No target, ledger, backend record, reader, or publication artifact was created by this bounded control task.
