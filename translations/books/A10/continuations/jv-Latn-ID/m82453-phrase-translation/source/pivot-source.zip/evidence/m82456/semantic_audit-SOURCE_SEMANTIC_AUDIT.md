# m82456 Source Semantic and Accessibility Audit

Recorded: 2026-08-21  
Status: source review complete; target dispositions pending final review

## Authority and bounded closure

- Source: `authority/source/modules/m82456/index.cnxml`
- Bytes: 122,022
- SHA-256:
  `1d3b69d74603175eb3c8aae95319b14bee988a56345c67384c0090b29995ab33`
- XML parses: yes; 4,344 elements; 740 unique IDs; zero duplicate IDs.
- Exercises/problems/solutions: 121 / 121 / 80. Every supplied solution was
  independently checked on its intended domain; no answer-key arithmetic error
  was found.
- Media: 19 directly referenced JPEG assets, all present and decodable;
  1,030,026 bytes total.
- Tables: 10; all have coherent two-column row geometry and an ARIA or summary.
- Local links: 5/5 resolve within the module.

## Mathematical and domain corrections

1. Six related source loci describe simplest form or the elimination of common
   factors without consistently excluding the universal factor 1:
   `fs-id1166422535686`, `fs-id1170654037932`, `fs-id1170654203066`,
   `fs-id1170653871210`, table `eip-201`, and glossary
   `fs-id1166422601981`. Every numerator and denominator share factor 1. Use “no
   common factor greater than 1” or “no common factors other than 1” throughout.
   The target applies this same qualifier consistently at all six loci.
2. The reciprocal treatment omits or obscures the zero restriction at six
   related source loci: introductory paras `fs-id1170654185172`,
   `fs-id1170654236747`, and `fs-id1170653770746`; definition
   `fs-id1170653743664`; explanatory para `fs-id1170654008541`; and glossary
   `fs-id1166424844298`. Require a nonzero fraction/number, require nonzero
   numerator and denominator for `a/b`, and state that a nonzero number
   multiplied by its reciprocal equals 1; zero has no reciprocal. The target
   applies this same correction consistently at all six loci.
3. Exercises `fs-id1170652618854`, `fs-id1170654237545`, and
   `fs-id1170654113677` simplify respectively to `3/y`, `3/(4b)`, and `4/q`.
   Preserve the source expression domains (`x≠0,y≠0`; `a≠0,b≠0`;
   `p≠0,q≠0`) so cancellation does not silently erase restrictions.

## Accessibility corrections

4. Media `fs-id1170653880713` says the factorization uses 210 and 285. The
   problem/raster uses 210 and 385, and the leading negative must remain visible
   in the factorized fraction.
5. Table `eip-id1169753124719` omits both negative signs in
   `−12/5(−20x)` and incorrectly reports the result as `−48x`. Describe the two
   negative factors, their positive product, and the correct final `48x`.
6. Table `eip-id1169752928919` describes `(3/4)÷(5/8)` with the wrong reciprocal
   and factors: `5/8`, `4×6`, and `(3×4×2)/(4×6)`. The visible table correctly
   uses `8/5`, `4×5`, and `(3×4×2)/(4×5)`, giving `6/5`.
7. Media `eip-id1169748377665` says nonexistent `z` is canceled. The raster
   cancels common `x` and factor 2 from `(x·3·2)/(2·x·y)`, leaving `3/y`.
8. Table `eip-id1169747240983` omits both negative signs from
   `(−7/18)÷(−14/27)` and the reciprocal product. Retain them, explain that equal
   signs yield a positive quotient, and finish at `3/4`.
9. Media `fs-id1170653773104` describes one circle split into left/right sides.
   The raster shows two equal pizzas: one divided into halves with `1/2` shaded,
   the other into eighths with `4/8` shaded.
10. Media `fs-id1170655026820` drops the leading negative from the factorized
    expression; retain it.
11. Media `fs-id1170653895041` and `fs-id1170653889891` call the four visible
    compartments squares. Direct raster inspection shows four equal rectangular
    compartments inside a larger rectangle. The target describes the visible
    equal parts without asserting that each part is square.

## Source copyedits to normalize in translation

- `fs-id1170654015188`: “six section” → “six sections.”
- Figure 003 caption: “same amount is of each pizza is shaded” → “the same
  amount of each pizza is shaded.”
- `fs-id1170654030468`: “signs are the different” → “signs are different.”
- `eip-id1169750893704`: “equivalent fractions properly” → “equivalent
  fractions property.”
- `eip-201`: “demoninator” → “denominator.”
- `eip-id1169747240983`: doubled period after “multiply.”
- `fs-id1170653878324`: insert the missing article before “grouping symbol.”
- `eip-149`: “simpliy” → “simplify.”
- Glossary `fs-id1166422580993`: restore the missing punctuation/conjunction
  after `b≠0`.

## Preserved interoperability and assembly defects

Six `.jpg` assets are valid JPEG files while their CNXML image elements declare
`image/png`: media IDs `eip-id1169750893744`, `eip-id1169753269750`,
`eip-id1169747225310`, `eip-id1169750795691`, `eip-id1169753189361`, and
`eip-id1169748377665`. Preserve the source attributes in localized CNXML unless
an exact derivative-assembly MIME policy is separately admitted.

Seven of the 19 source rasters contain English labels: Figures 005, 008a, 008b,
008c, 009, 016, and 201. Until localized overlays exist, target descriptions
must explicitly identify the raster language, quote only relevant visible text,
and supply its Indonesian meaning.

## Admission rule

No finding above changes authority. Every determined target correction must be
recorded in `05_CORRECTIONS.csv`; any non-reader attribute or protected MathML
delta must be exact and hash-bound. This audit alone does not admit the target.
