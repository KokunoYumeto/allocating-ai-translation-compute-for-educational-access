# Independent mathematics and structural admission review — m82476 v4

## Scope and method

I independently reviewed the complete frozen source and complete v2 repaired Indonesian candidate bound by the v4 builder. I recomputed all controlling descriptors, parsed both CNXML documents strictly, compared all formula and MathML structure, replayed the 786 registered surfaces, and verified stable identifiers, references, exercise/problem/solution relationships, tables, and every referenced asset.

I separately compared the v2 repaired candidate to its v1 repaired predecessor. Exactly four registered surfaces differ: `s00173`, `s00174`, `s00179`, and `s00180`. The complete ordered set of 123 MathML subtrees is canonical-byte identical between those two candidates, QName counts are unchanged, and both documents contain 2,926 elements and 754 ordered unique IDs. Thus the two new cross-MathML phrase repairs affect only their declared prose text/tail surfaces and do not alter mathematical tokens, formulas, or topology.

Against the frozen source, all 123 MathML roots were reviewed. Outside four documented structural replacements, every ordered MathML QName, attribute, non-`mtext` token, and internal child tail is exact. The replacements remain mathematically correct: the erroneous source check `b² = √144` is corrected to `b = √144`; and the three Indonesian assignments `a = sudut pertama`, `a + 20 = sudut kedua`, and `90 = sudut ketiga` use baseline lexical labels rather than malformed superscripts. Left-hand expressions, spacing attributes, punctuation, the right-angle qualifier, and containing table structure remain preserved. The sole QName-count changes are `mn` 260→256 and `msup` 46→42, exactly accounted for by those four replacements.

The complete structure closes with 118 exercises, 118 direct problems, 82 direct solutions, and identical ordered relationships. Fourteen tables preserve their IDs and contain exactly 134 rows and 281 entries. All 115 reference-bearing attribute/value pairs are preserved and every local target reference resolves. Relative to the original packet targets, the exact 25-surface union of the v1 and v2 repair manifests—and no other surface—differs.

All 104 image relationships close against 104 distinct frozen JPEG assets. Every `src`, byte count, SHA-256, JPEG signature, and decoded dimension matches the manifest. Exactly 69 MIME declarations change only from `image/png` to truthful `image/jpeg`; no asset byte or source reference changes.

## Result

Complete-module mathematics and structural review passes with zero P1, P2, P3, or unresolved findings.

<!-- BEGIN EA2_M82476_ADMISSION_REVIEW_RECEIPT -->
{
  "builder": {
    "bytes": 145438,
    "path": "scripts/harden_m82476_successor_admission_v4.py",
    "sha256": "40db4d3690a61035f701d68bfae297653f688120b4e87849a3711a88f5dc1494"
  },
  "construction_map": {
    "bytes": 2175,
    "path": "qa/m82476/successor-language-repair-20260828/v2/REPAIR_MANIFEST.json",
    "sha256": "b89e587ca6cecaf9daf50659d7975a5f5173d7e857cd54ce983927f1f75fa678"
  },
  "coverage_complete": true,
  "model": "OpenAI Codex gpt-5.6-sol, Ultra",
  "module_id": "m82476",
  "p1": 0,
  "p2": 0,
  "p3": 0,
  "result": "pass",
  "review_type": "mathematics",
  "reviewer": {
    "identity": "subagent:/root/derive_m82476_backend_contract:mathematics-v4",
    "independent": true
  },
  "schema": "ea2.m82476.admission_review_receipt",
  "schema_version": "1.0.0",
  "scope": "complete_m82476_module",
  "source": {
    "bytes": 137602,
    "path": "authority/source/modules/m82476/index.cnxml",
    "sha256": "99e3e706aed8738ab63f09403baedc7c1825f21a1bc90e3663da198f94270aaa"
  },
  "target": {
    "bytes": 141836,
    "path": "work/translated-modules/m82476/index.cnxml",
    "sha256": "07cd5b14032e455531716ad0a47f417984a5dbdd2eded39b9b2fd2322df08c2b"
  },
  "unresolved": 0
}
<!-- END EA2_M82476_ADMISSION_REVIEW_RECEIPT -->
