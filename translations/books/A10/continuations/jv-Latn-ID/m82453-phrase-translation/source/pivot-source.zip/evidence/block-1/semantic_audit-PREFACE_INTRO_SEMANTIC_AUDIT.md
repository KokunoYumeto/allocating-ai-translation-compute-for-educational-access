# Preface and Chapter 1 Opener — Independent Semantic Audit

Date: 2026-08-20
Scope: translated `m82630` and `m82451` only
Authority: commit `38cae454e644abf9f0a623e876994553881597c9`
Method: exact source/target XML comparison plus independent language, meaning,
rights-language, accessibility, residue, and mojibake review. No build or visual
claim is made here.

## Frozen source witnesses

- `m82630`: 22,483 bytes; SHA-256
  `d9f45fb31f4cb399c009c2be25eca1a99132b4b6882fb07f8649c2d56974f90b`.
- `m82451`: 1,066 bytes; SHA-256
  `025f994e3c66f19462c9423788f703f7987fecb67656911d840fdd15a58d8a4a`.

## Initial independent result

Both translations were substantively strong and preserved the source shape.
The initial `m82630` target was 23,941 bytes / SHA-256
`22ba5e5a1ebabfc358a2cb1413cc55c6af51cce264ef412e88ffdc3450d9266d`.
The independent audit found one rights-scope ambiguity and several terminology
or naturalness defects. They were corrected in the working target:

- made explicit that reuse by users and organizations is limited to
  noncommercial purposes;
- changed the formula-solving phrase to `menyelesaikan rumus terhadap variabel
  tertentu`;
- normalized `Cek Diri`, `Latihan Subbab`, and `Berlatih agar Mahir`;
- improved the infinite-solutions accessibility sentence and restored its
  missing closing quotation mark;
- changed `panduan solusi reguler` to `panduan solusi standar`;
- removed a pleonasm in the exercise-renumbering discussion;
- used `menggambar grafiknya` consistently;
- corrected the institution name `Saint Louis University` and added the missing
  terminal punctuation to the Everyday Math bullet.

After those edits, `m82630` is 23,923 bytes / SHA-256
`015098db38e15422185f5d179c94b2d07dd3c074f2d4468ab65f75518fc732dd`.
A bounded post-edit replay passed XML parse, 194-node ordered topology, namespace
map, attribute-name sets, all protected attribute values, 66 unique IDs, and
source/target ID sequence. `m82451` remains 1,112 bytes / SHA-256
`3e16907bd26f3cf1cafb2ff60eadabff499f59a1f9484ce45759d2ae99cea867`,
with 13 nodes and 3 unique IDs.

## Source defects and explicit dispositions

- `m82630#eip-582` names *Prealgebra 2e* in the Elementary Algebra preface.
  It remains unchanged pending contextual adjudication; this may describe the
  actual origin of the linked tutorials rather than a simple title typo.
- `m82630#fs-id1171782146065` says `three ellipses`, uses malformed
  `x y-coordinate`, and omits a closing quotation mark. The Indonesian
  accessibility description explicitly corrects these to three dots, `x-y`,
  and balanced quotation marks.
- `m82630#eip-id1169146105286` says `Saint Louis Iniversity`; the target names
  `Saint Louis University`.
- The Chapter 9 source heading says `Roots and Radical`; Indonesian renders the
  intended plural/general concept naturally as `Akar dan Bentuk Akar`.
- The Everyday Math bullet lacks terminal punctuation; the target adds it.
- `m82630#eip-634` ends with a causal sentence fragment; its intended meaning is
  rendered as a complete Indonesian sentence.

These are source-backed deltas and must also appear in `05_CORRECTIONS.csv`
before block admission. Final whole-block rehash and independent replay remain
pending until `m82452` is frozen.
