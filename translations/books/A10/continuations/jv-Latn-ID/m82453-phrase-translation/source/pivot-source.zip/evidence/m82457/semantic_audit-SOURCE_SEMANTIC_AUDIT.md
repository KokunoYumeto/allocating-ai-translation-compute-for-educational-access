# m82457 Source Semantic Audit

Status: complete pre-translation read-only audit. This file records defects in
the frozen English authority; it does not modify authority bytes.

## Frozen source and closure

- Module: `m82457`, Section 1.6, *Add and Subtract Fractions*.
- Source: 132,165 bytes; SHA-256
  `a8db22ca9c8c10c7f95fa3aa4dcb18596711741478515c220a75e291273983e9`.
- Structure: 4,988 elements; 787 unique IDs; 14 examples; 148 exercises and
  148 problems; 95 solutions; 33 media/image references; 14 tables.
- All three internal links resolve.
- All 33 directly referenced assets exist and total 1,510,420 bytes.
- Canonical asset-manifest SHA-256:
  `4b6049fb3777e3f7a4589c00041fe1c167efa830eb9720d9512d42ed1f0948cc`.
  The manifest is compact sorted-key UTF-8 JSON without a terminal newline;
  rows are sorted by `src` and contain `src`, `bytes`, `sha256`, `declared`,
  and `actual`.
- Source-plus-manifest closure SHA-256:
  `05d80a8097a996020aa50cdda6e0edec9bca06821ab9c494dfa676657bcc84de`.

## Required mathematical and semantic corrections

1. Exercise `fs-id1170655261591`, problem `fs-id1170655219867`, solution
   `fs-id1170654972445`: the answer to
   `−2/9 + (−4/9) − 7/9` is `−13/9`, not `−1`.
2. Exercise `fs-id1170655112591`, problem `fs-id1170655112594`, solution
   `fs-id1170654972309`: the answer to `−3/8 − (−5/2)` is `17/8`, not
   `−17/8`.
3. Table `eip-id1169750824026` has an accessibility-only sign error: its
   `aria-label` says the worked result is positive `1/6`, while the visual and
   MathML correctly give `−1/6`.
4. Paragraphs `fs-id1170655175041` and `fs-id1170655175044` call 12 and 18
   numerators; they are denominators.
5. Paragraph `fs-id1170655106844` says an LCD is needed “to add,” but the
   displayed operation is subtraction.
6. Exercise `fs-id1170655114745`, problem `fs-id1170655114747`, paragraph
   `fs-id1170655351777` omits the unit: restore “1/4 cup of sugar.”
7. Preserve domains explicitly: table `fs-id1170655154397` needs `b,d ≠ 0`
   and, for division, `c ≠ 0`; exercise `fs-id1170654924538` needs `a ≠ 0`;
   exercise `fs-id1170654943686` needs `y ≠ 0`.

## Accessibility, notation, and source debt

- Translate all 47 reader-facing attributes: 33 `alt`, eight `aria-label`, and
  six `summary` values.
- Fifteen rasters retain English words or the English acronym `LCD`: media IDs
  `fs-id1170655396298`, `fs-id1170654914425`, `fs-id1170654931846`,
  `fs-id1170655102403`, `eip-id1169754362252`, `eip-id1169752827456`,
  `fs-id1170654968903`, `fs-id1170655096686`, `fs-id1170655090064`,
  `eip-id1169754119516`, `eip-id1169750875606`, `eip-id1169750785605`,
  `eip-id1169754068123`, `eip-id1169750995237`, and `fs-id1170654962520`.
  Preserve raster bytes, identify them as English-labelled source images, and
  provide complete Indonesian textual equivalents. Spell out “penyebut
  persekutuan terkecil”; do not falsely equate denominator acronym `LCD` with
  Indonesian `KPK`, which denotes a least common multiple.
- The immutable raster at media `eip-id1169750580487` is visibly cropped after
  `−3/4 +`; the expected `1/3` term is absent. The target must describe the
  truncation honestly rather than claiming the complete expression is visible.
- The image-only worked solutions `fs-id1170655216078` (rasters `001a`–`001c`)
  and `fs-id1170654953233` (rasters `010a`–`010c`) need concise visible
  Indonesian summaries in addition to complete `alt` translations.
- Twenty-five `.jpg` assets in groups `003*` through `009*` declare
  `image/png` but contain JPEG bytes. Preserve immutable names, relationships,
  bytes, and declarations; record this as derivative-assembly debt.
- Table `eip-id1169754059819` encodes three unary minus signs as `m:mn`; table
  `eip-803` encodes a minus operator as `m:mtext`. Preserve these protected
  shapes unless a separately hash-bound structural exception is approved.

## Grouped source copyedits

Naturalize the redundant/malformed English at paragraph `fs-id1170655354165`,
media `fs-id1170655396298`, table `eip-id1169754059819`, paragraph
`fs-id1170654936746`, table `eip-17`, table `fs-id1170655154397`, media
`eip-id1169750580487`, and glossary meaning `fs-id1166424922299`. Each admitted
change must receive a correction-ledger row or an explicitly grouped row with
all affected owner IDs.

All supplied numerical/algebraic answers other than the two named wrong answers
were consistent in the bounded audit. The solved/unsolved exercise splits are
intentional. Final admission still requires independent target-bound structural,
mathematical, language, accessibility, asset, and residue review.
