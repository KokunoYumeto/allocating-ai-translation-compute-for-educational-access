# m82457 Final Admission Review

Boundary: `EA2-B0007-m82457`  
Reviewed: 2026-08-21  
Verdict: **PASS** (`P1=0`, `P2=0`, `P3=0`)

## Frozen identity

- Authority: 132,165 bytes; SHA-256
  `a8db22ca9c8c10c7f95fa3aa4dcb18596711741478515c220a75e291273983e9`.
- Indonesian target: 131,631 bytes; SHA-256
  `bead90d5c0bec00fd1400c082ceaf4916cf15c0da1c143992eda75cd0348e5dc`.
- Machine audit: 1,797 bytes; SHA-256
  `babbb7050d5149be7947d727cae669d4dabfd5655515c9e68ebd0c0dee3bad22`.
- Target manifest: 102 bytes; SHA-256
  `398fd65a647748ccdf6cae55f057529704cb22999d25434df06d73b90716966b`.
- Exception declaration: 1,306 bytes; SHA-256
  `3cef4672c6d3ab001215ed94b8211cd222ffb4019929fa19ec12bfeddc774ce0`.
- Source semantic audit: 4,668 bytes; SHA-256
  `c8c1d0c560916cc2e0b937e7b92911fd540396b9a6b4e9ef96156f9f7ed8ec18`.
- Terminology/accessibility plan: 3,357 bytes; SHA-256
  `36f14e496607d5f2d159e013d525b5567db4497b652665a73846769f37173693`.

## Exact structural and asset result

Source and target both contain 4,988 elements with identical ordered topology,
child vectors, and 787 unique IDs in the same sequence. All non-reader
attributes and references are exact. The 3,761 MathML elements preserve their
tags and attributes. Exactly two protected tokens change under a hash-bound,
exactly consumed exception: the two upstream answer-key corrections described
below. No structural or protected-attribute exception is used.

Cardinalities remain exact: 148 exercises, 148 problems, 95 supplied solutions,
14 examples, 14 tables, 33 media, and three links. All three links resolve. All
33 unique authority rasters exist and total 1,510,420 bytes; the canonical asset
manifest is `4b6049fb3777e3f7a4589c00041fe1c167efa830eb9720d9512d42ed1f0948cc`.
Twenty-five inherited `image/png` declarations point to JPEG bytes and remain
explicit derivative-assembly debt rather than silent source edits.

## Mathematics and source corrections

Independent mathematical review recomputed all 14 worked examples and all 95
supplied answer/solution surfaces. Fraction arithmetic, signs, common-denominator
construction, order of operations, substitutions, applications, and declared
domains are correct. The target corrects two demonstrably wrong upstream
answers:

- `−2/9 + (−4/9) − 7/9 = −13/9`, not `−1`;
- `−3/8 − (−5/2) = +17/8`, not `−17/8`.

The target also corrects the dropped sign in the `−1/6` ARIA narration, two
denominator/numerator reversals, an addition/subtraction wording error, a missing
`cup` unit, required nonzero-domain qualifications, and bounded copyedits. Each
is preserved in the source audit and correction ledger rather than silently
rewriting authority.

## Language and accessibility

All 323 aligned prose/title/term surfaces were reviewed. Terminology is natural
and consistent, including `penyebut persekutuan terkecil`, `penyebut yang sama`,
`pecahan senilai`, `operasi hitung pada pecahan`, and `faktor yang belum ada`.
The target does not fabricate an Indonesian acronym for English raster label
`LCD`. There is no active unquoted English narrative, rejected terminology,
mojibake, or replacement character; the retained title *Prealgebra* and unit
`yard` are intentional.

Exactly 47 reader attributes are localized: 33 alts, eight ARIA labels, and six
summaries. Fifteen English-labelled source rasters are explicitly identified and
their labels/steps are translated. The two image-only worked solutions now also
have concise visible Indonesian summaries. The cropped raster at
`eip-id1169750580487` is described honestly as ending after `−3/4 +`, and the
operation-table narration distinguishes numerator-with-numerator and
denominator-with-denominator operations unambiguously.

This admission does not claim a rendered reader build, full visual-page pass,
or publication. Those remain later book-level gates.
