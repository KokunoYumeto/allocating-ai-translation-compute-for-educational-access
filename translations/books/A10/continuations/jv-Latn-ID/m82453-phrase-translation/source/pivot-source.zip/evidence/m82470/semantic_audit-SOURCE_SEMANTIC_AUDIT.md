# m82470 source semantic audit

Status: **pretranslation control complete; proposals are not admitted**  
Scope: frozen OpenStax *Elementary Algebra 2e* module `m82470` only  
Provenance: **OpenAI Codex gpt-5.6-sol, Ultra**  
Audit date: 2026-08-23 (Europe/Berlin)

This is a read-only audit of the frozen English CNXML, its directly referenced media, the collection ordering record, and its direct link targets. It does not authorize or perform a target build, registry admission, ledger update, reader/backend change, or publication action.

## Authority binding

| Object | Frozen identity |
|---|---|
| Lane | `outputs/01a01f41-26f0-7e63-952c-de86c2f9155e/elementary_algebra_2e_id` |
| Collection | `authority/source/collections/elementary-algebra-2e.collection.xml`; 5,256 bytes; SHA-256 `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72`; Git blob SHA-1 `31100884d63f0c421b15905728637d5d010fe961`; UUID `55931856-c627-418b-a56f-1dd0007683a8` |
| Module | `authority/source/modules/m82470/index.cnxml`; 280,643 bytes; SHA-256 `e0c457e6b1fb1da6d93a1ffca68347b7afb1bd73683ed9575a10672b4aef13c9`; Git blob SHA-1 `f198b3acd0c3ec1b6e0698cde8c5ba37f01cb707`; content ID `m82470`; UUID `173c310c-48fa-4aac-acb7-2aadea74b016`; title `Solve Linear Inequalities` |
| Source manifest | `authority/SOURCE_AUTHORITY_MANIFEST.csv`; 14,863 bytes; SHA-256 `b817c9bfbd1dcba59f1e6949a83727a662bf95407882634620cd46b625b6a5f2`; its module row independently matches the module byte count, hash, blob, and order 20 |
| Media manifest | `authority/MEDIA_AUTHORITY_MANIFEST.csv`; 677,864 bytes; SHA-256 `3b8478b77c8860363b7000cbffa68782320e73458289bdcda957acf1b971210f` |
| Referenced-media set | 185 distinct paths, 6,526,269 aggregate bytes, 185 distinct SHA-256 values; canonical set digest `13ea52b7a239f30d06a5b6031b4e46a9b81666e8a294e3d50a47ad7fb86844e1` |

The media-set digest is SHA-256 over UTF-8 lines sorted by relative path, each line formatted `relative_path,bytes,sha256,git_blob_sha1` and terminated by LF.

The collection traversal is unambiguous: `m82468` is ordinal 18, `m82469` is ordinal 19, `m82470` is ordinal 20, and `m82471` is ordinal 21. Thus `m82470` is immediately after `m82469`.

## Reservation boundary

No IDs in this packet are admitted. The collision check used the following boundary:

| State | Terminology | Corrections |
|---|---:|---:|
| Live admitted maximum | `EA2-T0376` | `EA2-C0274` |
| `m82468` reserved, unadmitted | `EA2-T0377`–`EA2-T0384` | `EA2-C0275`–`EA2-C0290` |
| `m82469` frozen reserved, unadmitted | `EA2-T0385`–`EA2-T0402` | `EA2-C0291`–`EA2-C0303` |
| This `m82470` proposal | `EA2-T0403`–`EA2-T0436` | `EA2-C0304`–`EA2-C0324` |

## Structural inventory

The XML loads successfully. All 1,537 `id` values are non-duplicated. No problem is orphaned and no solution is attached without a problem.

| CNXML object | Count |
|---|---:|
| Top-level and nested sections | 21 (9 top-level, 12 nested) |
| Paragraphs | 528 |
| Notes | 36: 4 `be-prepared`, 26 `try`, 6 unclassified |
| Examples | 13 |
| Exercises / problems | 274 / 274 |
| Supplied solutions | 158 |
| Intentionally unsupplied solutions | 116 |
| Tables | 19 |
| Figures | 5 |
| Media / image references | 185 / 185 |
| MathML roots | 466 |
| CNXML equations | 7 |
| Lists / items | 16 / 49 |
| Links | 17 |
| Terms explicitly tagged in CNXML | 1 (`interval notation`) |

The instructional spine has five sections:

1. Graph Inequalities on the Number Line — 6 exercises, all solved.
2. Solve Inequalities using the Subtraction and Addition Properties of Inequality — 3 exercises, all solved.
3. Solve Inequalities using the Division and Multiplication Properties of Inequality — 12 exercises, all solved.
4. Solve Inequalities That Require Simplification — 12 exercises, all solved.
5. Translate to an Inequality and Solve — 6 exercises, all solved.

Four readiness exercises precede the spine. The module then contains Key Concepts, 82 section exercises, a self-check, 119 Chapter 2 review exercises (including one open-ended Everyday Math exercise), and 30 Chapter 2 practice-test exercises. This composite shape is source-authored and must not be truncated to the five instructional sections.

## Exercise and solution topology

Exercise ordinals below are the document-order ordinals within this frozen module, not generated display numbers.

| Ordinals | Material | Problems | Supplied | Unsupplied | Source pattern |
|---|---|---:|---:|---:|---|
| 1–4 | Readiness quiz | 4 | 4 | 0 | Every item supplied |
| 5–43 | Instructional examples and Try It items | 39 | 39 | 0 | Every item supplied |
| 44–125 | Section Exercises | 82 | 41 | 41 | Supplied on odd ordinals 45–125; unsupplied on even ordinals 44–124 |
| 126–244 | Chapter 2 Review Exercises | 119 | 59 | 60 | Supplied on odd ordinals 127–243; unsupplied on even ordinals 126–244 |
| 245–274 | Chapter 2 Practice Test | 30 | 15 | 15 | Supplied on odd ordinals 245–273; unsupplied on even ordinals 246–274 |
| **Total** |  | **274** | **158** | **116** |  |

All 116 absent solutions follow the source's alternating answer-key pattern. They are not extraction loss. Translation must preserve the absences and must not invent answers.

Of the 158 supplied solutions, 88 contain media and 70 are text/MathML-only. The supplied solutions contain 158 media descendants in total. The mathematical check compared every supplied result with its problem and separately checked the property statements and identity/contradiction classifications.

## Math and semantic findings

The 466 MathML roots are nonempty and XML-well-formed. They contain 183 fractions and 12 MathML tables. Variables, comparison operators, fraction structure, interval endpoints, and inequality reversal were independently checked across the 158 supplied solutions.

Four source-level mathematical defects require mandatory target overlays:

1. `fs-id1168345425074` states, in the first positive-`c` case of the Key Concepts recap, that `a < b` implies `ac > bc`. The main property statement earlier in the module correctly has `ac < bc`. Apply `EA2-C0304`.
2. Practice-test exercise `fs-id1168345445955` asks to solve `x − 2y = 5` for `y`, but supplies `y = 4` when `x = −3` and `y = (5 − x)/2` in general. Both signs are wrong. The correct results are `y = −4` and `y = (x − 5)/2`. Apply `EA2-C0305`.
3. Review exercise `fs-id1168345726480`, part c, asks for `x ≥ −1`; its supplied asset `CNX_ElemAlg_Figure_02_07_296_img_new.jpg` visibly graphs `x ≥ 1`. Apply `EA2-C0306`; an alt-only repair is insufficient.
4. Section exercise `fs-id1168345744548` correctly reduces to `k ≤ 7`, but its supplied asset `CNX_ElemAlg_Figure_02_07_261_img_new.jpg` visibly labels the result `x ≤ 7`, and its alt repeats `x`. Apply `EA2-C0307`; an alt-only repair is insufficient.

One supplied solution image is mathematically correct while its alt is not: `fs-id1168345386567` visibly gives `g < 23/36`, but the alt repeatedly says `23/26` (`EA2-C0308`). The remaining independently checked supplied results are algebraically consistent with their problems after applying the registered corrections.

Seven U+200B zero-width spaces occur in six problem locations (`fs-id1168345450214`, `fs-id1168345677928`, `fs-id1168345745165`, `fs-id1168341959544`, `fs-id1168345688099`, and `fs-id1168345726578`). They do not change the rendered mathematics but must not be copied into the target (`EA2-C0322`).

## Tables, media, and accessibility

All 185 image references are unique, present, manifest-bound, hash-matching, and decodable. They comprise source figure-number bands 001–060 (123 assets), 204–291 (45 assets), and 294–323 (17 assets). The decoded width range is 93–900 pixels and the height range is 13–213 pixels. No two referenced assets share a SHA-256 digest.

Every `media` node has nonempty `alt`. Eighteen of the nineteen tables have a nonempty `aria-label`; the remaining text/MathML table `eip-608` has a nonempty `summary`. Presence is not semantic correctness: the audit found wrong variables, wrong ray directions, wrong inclusion claims, missing infinity symbols, and malformed interval readings. These are registered in `EA2-C0308`–`EA2-C0318` and `EA2-C0324`.

All 185 files have a `.jpg` extension and JPEG magic bytes. The CNXML correctly declares 105 as `image/jpeg` but incorrectly declares 80 as `image/png`. The 80 mismatches are the component-image groups 016, 017, 018, 025, 026, 029, 030, 031, 034, 037, 040, 043, 046, 049, 052, 055, and 058 (`EA2-C0319`). Do not re-encode authoritative bytes merely to match the declaration; if reused, declare them as JPEG.

Accessibility acceptance rules for the target are in `TERMINOLOGY_AND_ACCESSIBILITY_PLAN.md`. In particular, a corrected alt must state the inequality, endpoint inclusion, ray direction, and interval notation when those are encoded only in an image. Color alone is never the carrier of meaning.

## Link validation

All 17 links resolve within the frozen authority snapshot:

- 6 local target links resolve to 5 figures and table `fs-id1168345688476`.
- 4 explicit cross-module targets resolve: `m82453#fs-id1170655113222`, `m82463#fs-id1168345390064`, `m82464#fs-id1168344337607`, and `m82465#fs-id1168344315853`.
- 7 document-root links resolve to `m82463`, `m82464`, `m82465`, `m82467`, `m82468`, `m82469`, and `m82470`.

Direct linked-module identities checked:

| Document | Frozen title | SHA-256 |
|---|---|---|
| `m82453` | Use the Language of Algebra | `a8fdd235aa254c5a0a1248fa858e9b3579d9b40982bbc514cbe6a18c3e6fcbed` |
| `m82463` | Solve Equations Using the Subtraction and Addition Properties of Equality | `b6345a5a6a99108f9d32d6518445a4ae70a6b0c54a258021dffc6f2b77b8278a` |
| `m82464` | Solve Equations using the Division and Multiplication Properties of Equality | `099aae173772040a83d8c9160980922315352fc2a699af7c6f25ddc594a0c0bc` |
| `m82465` | Solve Equations with Variables and Constants on Both Sides | `320496fe179611ea5e34e8bbf62a28317385e19a2c8038f304183a9dd5847692` |
| `m82467` | Use a General Strategy to Solve Linear Equations | `ba8c5d2d4c0fed618bbf37ebf94d4f18681672d2563b3ae670bd07fad52de7b5` |
| `m82468` | Solve Equations with Fractions or Decimals | `c37321a5d8e4dd5f83f90b4b65c2b3516474b5cdea885f84a28ca15e5cea37e0` |
| `m82469` | Solve a Formula for a Specific Variable | `16d4267bb97fc62bff7a71c2d6051796d0c9dbf7f98f3bfc978d60ba07574676` |
| `m82470` | Solve Linear Inequalities | `e0c457e6b1fb1da6d93a1ffca68347b7afb1bd73683ed9575a10672b4aef13c9` |

The review-link labels for `m82467` and `m82468` do not exactly match those frozen target titles (`for Solving` versus `to Solve`, and `and Decimals` versus `or Decimals`). This is non-dangling but stale link text (`EA2-C0321`).

## Defect register

`PROPOSED_CORRECTIONS.csv` is authoritative for the proposed IDs and target deltas. The findings are grouped as follows:

| IDs | Finding class |
|---|---|
| `EA2-C0304`–`EA2-C0307` | Core mathematical relation, wrong formula solution, wrong endpoint, and wrong visible variable |
| `EA2-C0308`–`EA2-C0318` | Meaning-changing alt/table accessibility defects |
| `EA2-C0319` | 80 declared-MIME versus JPEG-byte mismatches |
| `EA2-C0320` | Duplicate word plus variable-case error in the distance formula review answer |
| `EA2-C0321` | Stale document-link labels |
| `EA2-C0322` | Hidden U+200B characters |
| `EA2-C0323` | Two exercise-instruction punctuation defects |
| `EA2-C0324` | Non-mathematical accessibility transcription and spelling defects |

## Gate decision

The frozen source is structurally complete and all dependencies resolve, but literal translation is **not safe** because it would propagate four mathematical defects and multiple meaning-changing accessibility defects. Target construction may proceed only with every applicable correction overlay, the solution-absence pattern preserved exactly, the media MIME declarations normalized without changing authoritative bytes, and the terminology/accessibility plan applied. No live registry or correction ledger has been modified by this audit.
