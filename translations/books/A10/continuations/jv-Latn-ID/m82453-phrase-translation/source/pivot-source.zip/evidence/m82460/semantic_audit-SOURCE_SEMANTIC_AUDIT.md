# m82460 source semantic audit

## Authority and audit boundary

- Source: `authority/source/modules/m82460/index.cnxml`
- Expected and observed size: **164,724 bytes**
- Expected and observed SHA-256: **`ee089e74a6609868c94808e624d57016de348a791b577458c539c93584bba9a5`**
- Module metadata: content ID `m82460`; UUID `4872eb92-e2a7-44bc-a560-95441f7abc20`; title **Properties of Real Numbers**.
- Direct media only: the 17 `image/@src` references in this CNXML, resolved relative to the module.
- The authority source and media were read only. This audit neither edits nor normalizes source bytes.

## Verdict

The document is well-formed XML, all 925 IDs are unique, all five internal links resolve, and all 17 direct media references close to present files. Every one of the 156 problem statements, every one of the 105 supplied solutions, and all 18 worked examples was independently checked. The algebraic and arithmetic results are otherwise sound, but one supplied answer is substantively wrong, two worked-solution surfaces contain localized defects, and repeated domain restrictions are incomplete.

Correction inventory: **P1 0 / P2 9 / P3 10**, represented exactly by `EA2-C0157` through `EA2-C0175` in `PROPOSED_CORRECTIONS.csv`. The P3 count includes source copyediting, accessibility sequencing, MIME debt, localization/reflow debt, and two semantically empty spacer paragraphs. No correction has been applied to authority source.

## XML and topology inventory

| Surface | Count |
|---|---:|
| All elements | 6,437 |
| CNXML namespace elements | 1,629 |
| MDML namespace elements | 4 |
| MathML namespace elements | 4,804 |
| IDs / unique IDs / duplicate IDs | 925 / 925 / 0 |
| Sections, total / top-level / nested | 10 / 6 / 4 |
| CNXML titles / MDML title | 37 / 1 |
| Paragraphs / notes / examples | 337 / 46 / 18 |
| Lists / list items | 15 / 44 |
| Equations / MathML roots / MathML `mtext` | 17 / 480 / 63 |
| Exercises / problems / supplied solutions | 156 / 156 / 105 |
| Tables / rows / entries | 22 / 78 / 158 |
| Media / images / unique direct assets | 17 / 17 / 17 |
| Links | 5 |
| Glossaries / definitions / terms | 1 / 4 / 22 |

Deterministic structural receipts:

- Ordered-ID SHA-256: **`2b7337c1471f4489e8ba37a872aaedd2b01860230994c032e5def4ce0534afdc`**. Preimage is every nonempty `id` in document order, joined by LF with no terminal LF.
- Topology SHA-256: **`d1507334398ad5826a039bde38d6cd1f0edd836af84b35f9ab93f5f6f762f59c`**. Each preorder element contributes `{namespace-uri}local-name<TAB>id-or-empty`; rows are joined by LF with no terminal LF.

Section ownership:

| Section ID | Title | Examples | Exercises | Solutions | Tables | Media |
|---|---|---:|---:|---:|---:|---:|
| `fs-id1170653871089` | Use the Commutative and Associative Properties | 3 | 9 | 9 | 5 | 0 |
| `fs-id1170654077757` | Use the Identity and Inverse Properties of Addition and Multiplication | 2 | 6 | 6 | 1 | 3 |
| `fs-id1170653800718` | Use the Properties of Zero | 5 | 15 | 15 | 7 | 0 |
| `fs-id1170654074010` | Simplify Expressions Using the Distributive Property | 8 | 24 | 24 | 9 | 13 |
| `fs-id1170654053685` | Key Concepts | 0 | 0 | 0 | 0 | 0 |
| `fs-id1170654071822` | untitled review wrapper | 0 | 102 | 51 | 0 | 1 |

The review wrapper contains four nested sections: `fs-id1170654071826` (Practice Makes Perfect), `fs-id1170654084022` (Everyday Math), `fs-id1170654084314` (Writing Exercises), and `fs-id1170654084420` (Self Check).

## Mathematical and solution audit

### Coverage

- 18 worked-example solutions: independently recomputed from the problem statements and checked step by step, including the four raster-based demonstrations.
- 36 “Try It” solutions: independently recomputed.
- 51 review solutions: independently recomputed, including the insurance and wine applications.
- 51 review problems intentionally have no supplied solution. Each statement was checked for a defined domain and a coherent requested operation.
- The 17 displayed equations and the visible mathematics in all 22 tables were separately checked.

### Worked examples

| # | Example | Problem → solution | Result |
|---:|---|---|---|
| 1 | `fs-id1170653877249` | `fs-id1170654077092` → `fs-id1170653909769` | PASS |
| 2 | `fs-id1170653742078` | `fs-id1170653890205` → `fs-id1170653984832` | PASS |
| 3 | `fs-id1170654014662` | `fs-id1170654014667` → `fs-id1170653901248` | PASS |
| 4 | `fs-id1170654075033` | `fs-id1170654075038` → `fs-id1170654084880` | PASS |
| 5 | `fs-id1170654078981` | `fs-id1170654073241` → `fs-id1170654073268` | PASS |
| 6 | `fs-id1170654012879` | `fs-id1170654012883` → `fs-id1170654012915` | Answers PASS; part ⓑ explanation is wrong (`EA2-C0163`) |
| 7 | `fs-id1170654014350` | `fs-id1170654014354` → `fs-id1170654075609` | PASS |
| 8 | `fs-id1170654036044` | `fs-id1170654036048` → `fs-id1170654075181` | PASS |
| 9 | `fs-id1170654059557` | `fs-id1170654059561` → `fs-id1170654059595` | PASS |
| 10 | `fs-id1170654034474` | `fs-id1170654034479` → `fs-id1170654034517` | PASS |
| 11 | `fs-id1170654078011` | `fs-id1170654078015` → `fs-id1170654078041` | PASS |
| 12 | `fs-id1170654075722` | `fs-id1170654075726` → `fs-id1170654075761` | PASS; raster math visually verified |
| 13 | `fs-id1170654075908` | `fs-id1170654075912` → `fs-id1170654075940` | PASS; raster math visually verified |
| 14 | `fs-id1170654076073` | `fs-id1170654076078` → `fs-id1170654076105` | PASS; raster math visually verified |
| 15 | `fs-id1170654067433` | `fs-id1170654067437` → `fs-id1170654067465` | PASS; raster math visually verified |
| 16 | `fs-id1170654067617` | `fs-id1170654067621` → `fs-id1170654067647` | Final result PASS; first solution line drops unary minus (`EA2-C0164`) |
| 17 | `fs-id1170654067908` | `fs-id1170654067912` → `fs-id1170654067946` | PASS |
| 18 | `fs-id1170654068424` | `fs-id1170654068428` → `fs-id1170654068469` | PASS |

Exact worked-solution defects:

- `fs-id1170654012915`, table `eip-223`, row ⓑ, source line 464: the problem is `0/−2`, but the explanation repeats “The product of any real number and 0 is 0.” The quotient and final answer `0` are correct; the reason must instead invoke zero divided by a nonzero number.
- `fs-id1170654067647`, table `eip-636`, first row, source line 973: the problem is `−(y+5)`, but the first displayed solution expression is `(y+5)`. Subsequent lines correctly rewrite it as `−1(y+5)` and end at `−y−5`.

### Supplied non-example solution ledger

All 36 Try It pairs below recompute correctly:

`fs-id1170654076917→fs-id1170653906988`, `fs-id1170653795554→fs-id1170654014491`, `fs-id1170654044584→fs-id1170653901181`, `fs-id1170654077704→fs-id1170653901148`, `fs-id1170654077036→fs-id1170654077047`, `fs-id1170654079044→fs-id1170654077742`, `fs-id1170653800547→fs-id1170653800585`, `fs-id1170654073186→fs-id1170654078943`, `fs-id1170653991352→fs-id1170654073682`, `fs-id1170654073719→fs-id1170654036171`, `fs-id1170654077664→fs-id1170654035978`, `fs-id1170654035992→fs-id1170654036032`, `fs-id1170653800649→fs-id1170653800683`, `fs-id1170653800702→fs-id1170654059538`, `fs-id1170654069484→fs-id1170654014276`, `fs-id1170654014298→fs-id1170654014333`, `fs-id1170654069200→fs-id1170654069270`, `fs-id1170654069285→fs-id1170654034465`, `fs-id1170654073889→fs-id1170654073928`, `fs-id1170654073952→fs-id1170654073990`, `fs-id1170654078131→fs-id1170654078156`, `fs-id1170654078181→fs-id1170654078206`, `fs-id1170654075789→fs-id1170654075823`, `fs-id1170654075848→fs-id1170654075882`, `fs-id1170654075969→fs-id1170654075999`, `fs-id1170654076023→fs-id1170654076051`, `fs-id1170654067335→fs-id1170654067363`, `fs-id1170654067387→fs-id1170654067415`, `fs-id1170654067512→fs-id1170654067540`, `fs-id1170654067564→fs-id1170654067592`, `fs-id1170654067804→fs-id1170654067830`, `fs-id1170654067854→fs-id1170654067880`, `fs-id1170654068319→fs-id1170654068349`, `fs-id1170654068374→fs-id1170654068406`, `fs-id1170654068580→fs-id1170654068620`, `fs-id1170654068645→fs-id1170654068685`.

The 51 review solution pairs all recompute correctly except the determinate property label in pair 48:

1–10: `fs-id1170654071842→fs-id1170654071853`, `fs-id1170654071892→fs-id1170654071917`, `fs-id1170654071979→fs-id1170653896673`, `fs-id1170653896743→fs-id1170653896775`, `fs-id1170653896844→fs-id1170653896859`, `fs-id1170653896904→fs-id1170653896941`, `fs-id1170653897015→fs-id1170653897022`, `fs-id1170653897047→fs-id1170653897054`, `fs-id1170653897080→fs-id1170653897091`, `fs-id1170653897130→fs-id1170653897151`.

11–20: `fs-id1170653897202→fs-id1170653897225`, `fs-id1170653897276→fs-id1170653897327`, `fs-id1170653897428→fs-id1170653990329`, `fs-id1170653990425→fs-id1170653990471`, `fs-id1170653990566→fs-id1170653990597`, `fs-id1170653990696→fs-id1170653990727`, `fs-id1170653990828→fs-id1170653990846`, `fs-id1170653990940→fs-id1170653990967`, `fs-id1170653991086→fs-id1170653991099`, `fs-id1170653991131→fs-id1170654031822`.

21–30: `fs-id1170654031854→fs-id1170654031866`, `fs-id1170654031902→fs-id1170654031925`, `fs-id1170654031970→fs-id1170654031993`, `fs-id1170654032034→fs-id1170654032056`, `fs-id1170654032099→fs-id1170654032134`, `fs-id1170654032188→fs-id1170654032236`, `fs-id1170654032305→fs-id1170654032348`, `fs-id1170654032411→fs-id1170654032474`, `fs-id1170654032556→fs-id1170654032585`, `fs-id1170654032661→fs-id1170654032686`.

31–40: `fs-id1170654032748→fs-id1170654032771`, `fs-id1170654007528→fs-id1170654007556`, `fs-id1170654007628→fs-id1170654007659`, `fs-id1170654007730→fs-id1170654007760`, `fs-id1170654007830→fs-id1170654007852`, `fs-id1170654007917→fs-id1170654007940`, `fs-id1170654008005→fs-id1170654008030`, `fs-id1170654008093→fs-id1170654008116`, `fs-id1170654008178→fs-id1170654008202`, `fs-id1170654008266→fs-id1170654008292`.

41–51: `fs-id1170654008358→fs-id1170654008387`, `fs-id1170654008454→fs-id1170654008479`, `fs-id1170654008542→fs-id1170654008579`, `fs-id1170654008655→fs-id1170654083595`, `fs-id1170654083675→fs-id1170654083710`, `fs-id1170654083784→fs-id1170654083823`, `fs-id1170654083901→fs-id1170654083943`, **`fs-id1170654084029→fs-id1170654084055` (parts ⓐ and ⓑ PASS; part ⓒ FAIL, `EA2-C0165`)**, `fs-id1170654084191→fs-id1170654084244`, `fs-id1170654084322→fs-id1170654084328`, `fs-id1170654084356→fs-id1170654084384`.

For `fs-id1170654084029`, parts ⓐ and ⓑ are both `5·0.20·80 = $80`. Part ⓒ asks why `5[(0.20)(80)]` equals `[5(0.20)](80)`. The unique requested answer is the **Associative Property of Multiplication**; `fs-id1170654084055` incorrectly supplies “answers will vary.”

### Problems without supplied solutions

All 51 unsupplied problem statements are mathematically coherent. Their problem IDs, in order, are:

`fs-id1170654071867`, `fs-id1170654071934`, `fs-id1170653896689`, `fs-id1170653896793`, `fs-id1170653896872`, `fs-id1170653896959`, `fs-id1170653897031`, `fs-id1170653897063`, `fs-id1170653897105`, `fs-id1170653897166`, `fs-id1170653897239`, `fs-id1170653897355`, `fs-id1170653990357`, `fs-id1170653990493`, `fs-id1170653990632`, `fs-id1170653990761`, `fs-id1170653990883`, `fs-id1170653991010`, `fs-id1170653991108`, `fs-id1170654031831`, `fs-id1170654031876`, `fs-id1170654031935`, `fs-id1170654032002`, `fs-id1170654032066`, `fs-id1170654032144`, `fs-id1170654032245`, `fs-id1170654032358`, `fs-id1170654032483`, `fs-id1170654032605`, `fs-id1170654032705`, `fs-id1170654032790`, `fs-id1170654007578`, `fs-id1170654007678`, `fs-id1170654007780`, `fs-id1170654007874`, `fs-id1170654007961`, `fs-id1170654008049`, `fs-id1170654008135`, `fs-id1170654008222`, `fs-id1170654008312`, `fs-id1170654008406`, `fs-id1170654008498`, `fs-id1170654008598`, `fs-id1170654083614`, `fs-id1170654083729`, `fs-id1170654083843`, `fs-id1170654083962`, `fs-id1170654084065`, `fs-id1170654084254`, `fs-id1170654084338`, `fs-id1170654084394`.

Two of these contain only P3 copyediting defects: `fs-id1170654084068` has “in to the oven” (`EA2-C0170`), and `fs-id1170654084256` has “a 3 pack” (`EA2-C0171`). Neither changes the mathematical task.

## Exact correction findings

| Candidate | Priority | Owner | Finding and required reader treatment |
|---|---|---|---|
| `EA2-C0157` | P2 | `fs-id1170654012970` / `eip-73` | Boxed inverse-property statement quantifies over every real `a` but omits `a≠0`; add the nonzero domain before defining `1/a`. |
| `EA2-C0158` | P2 | `fs-id1166426154985` / `fs-id1166426154990` | Glossary states that every number has a reciprocal/multiplicative inverse; restrict to nonzero numbers. |
| `EA2-C0159` | P3 | `fs-id1170654030286` | The English determiner “a” in “The reciprocal of a number” is encoded as MathML variable `<mi>a</mi>`; render it as ordinary language, not a retained variable. |
| `EA2-C0160` | P2 | `fs-id1170653991489` | “For any real number a, except 0, a/0 … [is] undefined” excludes `0/0`; division by zero is undefined for every real numerator, including zero. |
| `EA2-C0161` | P2 | `fs-id1170654014590` / `eip-866` | A single `a≠0` condition is applied to both `0/a=0` and `a/0` undefined. Split the domains: nonzero denominator only for the first; every real numerator for the second. |
| `EA2-C0162` | P2 | `fs-id1170654068740` visible final row | Key-concepts table repeats `a≠0` for `a/0`; include `a=0` in the undefined division-by-zero statement. |
| `EA2-C0163` | P2 | `fs-id1170654012915` / `eip-223` row ⓑ | Explanation for `0/−2` says “product”; replace with the zero-numerator division property. |
| `EA2-C0164` | P2 | `fs-id1170654067647` / `eip-636` first row | Initial worked line drops the unary minus from `−(y+5)`; restore it. |
| `EA2-C0165` | P2 | `fs-id1170654084055` | Insurance problem part ⓒ says “answers will vary”; replace with “Associative Property of Multiplication.” |
| `EA2-C0166` | P2 | `fs-id1170654068740` `aria-label` | Accessibility text says 18 XML rows, calls the property “Associate,” omits `c`, and voices the associative-addition right side as multiplication. Replace with an accurate concise description of the 12-row table and its formulas/domains. |
| `EA2-C0167` | P3 | `eip-id1169750566181` `aria-label` | The narration shifts “Distribute” and “Multiply” one row ahead of the actual 007a–c sequence. |
| `EA2-C0168` | P3 | `eip-id1169751856555` `aria-label` | The narration shifts “Distribute” and “Multiply” one row ahead of the actual 008a–c sequence. |
| `EA2-C0169` | P3 | `eip-id1169750823178` `aria-label` | The narration calls the final operation “Simplify,” while the visible row is “Multiply”; align the narration to the 009a–c rows. |
| `EA2-C0170` | P3 | `fs-id1170654084068` | Copyedit “put the turkey in to the oven” to “put the turkey into the oven”; translate naturally in the reader. |
| `EA2-C0171` | P3 | `fs-id1170654084256` | Copyedit attributive “a 3 pack” to “a 3-pack”; translate naturally in the reader. |
| `EA2-C0172` | P3 | `fs-id1171791165266`, `fs-id1167271014968` | Two paragraphs are genuinely empty. Preserve source/ID parity but suppress spacer output in the reader. |
| `EA2-C0173` | P3 | 12 media IDs listed below | `image/png` declarations point to JPEG byte streams. Assembly must use truthful `image/jpeg` metadata or a deterministic real-PNG derivative. |
| `EA2-C0174` | P3 | four English-labelled media IDs | Recreate the English prompt/self-check rasters as localized semantic content; alt translation alone leaves visible English. |
| `EA2-C0175` | P3 | 13 math-only media IDs | Replace cramped 13–50 px-high raster algebra snippets with reflowable MathML/SVG/HTML equivalents in the reader while preserving source provenance. |

## Accessibility audit

- 17/17 media elements have nonempty `alt` text.
- 22/22 tables have an accessibility attribute: 17 `summary` and 5 `aria-label`.
- Total audited accessibility attributes: **39** (17 alt + 17 summary + 5 aria-label).
- Each alt description was compared with the decoded raster. The image alts are content-accurate.
- Three small worked-table aria labels have sequencing/row-label errors (`EA2-C0167`–`EA2-C0169`).
- The large key-concepts aria label has a material voiced-math error and multiple copy/structure errors (`EA2-C0166`).
- The self-check is a raster table. Its alt is faithful, including the source image’s “No-I don’t get it!” punctuation, but a translated alt cannot localize or reflow visible pixels; `EA2-C0174` requires a semantic replacement.

## Links and reference closure

All five links are local `target-id` links, have no external URL/document dependency, and resolve to unique IDs:

| Owner | Target | Target kind |
|---|---|---|
| `fs-id1170654077977` | `fs-id1170654078011` | example |
| `fs-id1170654075701` | `fs-id1170654078011` | example |
| `fs-id1170654075900` | `fs-id1170654075908` | example |
| `fs-id1170654067610` | `fs-id1170654067617` | example |
| `fs-id1170654068703` | `fs-id1170654068740` | table |

The empty link bodies are intentional CNXML auto-label surfaces; they are not broken references.

## Direct asset closure

All 17 references are unique and present. Total referenced bytes: **537,353**.

| Media ID | File | Bytes | Dimensions | Declared → actual MIME | SHA-256 |
|---|---|---:|---:|---|---|
| `fs-id1170654036108` | `CNX_ElemAlg_Figure_01_09_003_img_new.jpg` | 48,061 | 435×93 | JPEG → JPEG | `0728dda0919db9dcb6ee54bb22d200290e94ad6e52c1e324dd946d3b04f12f40` |
| `fs-id1170653797753` | `CNX_ElemAlg_Figure_01_09_004_img_new.jpg` | 36,743 | 268×37 | JPEG → JPEG | `80de9318044df971403fd07780bb1104439225920a4a88d2faf6872efd02d884` |
| `fs-id1170653797768` | `CNX_ElemAlg_Figure_01_09_005_img_new.jpg` | 35,585 | 260×37 | JPEG → JPEG | `6baaf6eeed13c548a0574ec503d3807c629e5c966f6081b411a359aef87e998a` |
| `fs-id1170654075709` | `CNX_ElemAlg_Figure_01_09_006_img_new.jpg` | 26,939 | 57×36 | JPEG → JPEG | `816b715386d6709baf526c8a58acf61f964a9affbdcae89e79975ee08a5a884e` |
| `eip-id1169750566196` | `CNX_ElemAlg_Figure_01_09_007a_img_new.jpg` | 27,258 | 109×50 | PNG → JPEG | `ba8b545d06edec0114a5624bcb2b5cbd84d4fa0cbf0a5e5b946d5a654a05b20d` |
| `eip-id1169750566213` | `CNX_ElemAlg_Figure_01_09_007b_img_new.jpg` | 24,313 | 109×32 | PNG → JPEG | `1d35995decafb161eb4cc2faf65adbef665ef08aa327e91466f96e279e1831a9` |
| `eip-id1169750566230` | `CNX_ElemAlg_Figure_01_09_007c_img_new.jpg` | 24,447 | 109×13 | PNG → JPEG | `37d595d2b767fc06f9f878fca0b5a0cf2207a5841206de3bf2b6e5230199dbc1` |
| `eip-id1169751856571` | `CNX_ElemAlg_Figure_01_09_008a_img_new.jpg` | 28,191 | 163×33 | PNG → JPEG | `ba07e9f79d7f4360de507f006d6a7dd4903dcc93860df02dc5c76717ed1421ce` |
| `eip-id1169751856588` | `CNX_ElemAlg_Figure_01_09_008b_img_new.jpg` | 25,959 | 163×19 | PNG → JPEG | `785e172bb4ca5a32e476c76de2133239fbe4aaed3f7fec2bc1a028d8b91511ad` |
| `eip-id1169751856604` | `CNX_ElemAlg_Figure_01_09_008c_img_new.jpg` | 22,693 | 163×17 | PNG → JPEG | `8b368b0b56afb2df53ed616f58ecb3c08e8dbd7dad523d2c4400da1586d915ad` |
| `eip-id1169750823194` | `CNX_ElemAlg_Figure_01_09_009a_img_new.jpg` | 27,193 | 122×34 | PNG → JPEG | `52c12d4b0285aca9df9b5ce6e20cde1bf6b1390cd304f00efe1984a931eeab7a` |
| `eip-id1169750823211` | `CNX_ElemAlg_Figure_01_09_009b_img_new.jpg` | 26,923 | 123×17 | PNG → JPEG | `c5466d61d5101e0242ce707838a8c2933e8daf5c02274d6b8e4057369705e7e8` |
| `eip-id1169750823228` | `CNX_ElemAlg_Figure_01_09_009c_img_new.jpg` | 24,622 | 123×17 | PNG → JPEG | `ef3c93bed11d127411b346107ba2785380d0bf645eb1e2fd4da03d7e52bd5103` |
| `eip-id1169751973931` | `CNX_ElemAlg_Figure_01_09_010a_img_new.jpg` | 25,276 | 142×32 | PNG → JPEG | `45c104952235568b41b4dad2df579e9f8d4f2f0cbeb002c3c617258a868bdf30` |
| `eip-id1169754247252` | `CNX_ElemAlg_Figure_01_09_010b_img_new.jpg` | 29,416 | 142×36 | PNG → JPEG | `239b991668599b7635390db683d5a1c36e7961e4094377bda34dcd361c65e7bf` |
| `eip-id1169754247268` | `CNX_ElemAlg_Figure_01_09_010c_img_new.jpg` | 23,936 | 141×13 | PNG → JPEG | `f6ddac068aa16fca1c452f4756b50b856417bf1c55b3726ae37057e473886985` |
| `fs-id1170654084441` | `CNX_ElemAlg_Figure_01_09_201_img_new.jpg` | 79,798 | 632×206 | JPEG → JPEG | `e398cab9c01e22268e6d179830bf25be7bca995f10a0b66ceb420ebe72e341a2` |

Deterministic closure receipts:

- Asset-manifest SHA-256: **`50f549d26fde1877c6c67ec4afa46127456466fc6560a229be066fb6e06d05d8`**. In media document order, each LF-terminated row is `media-id<TAB>src<TAB>bytes<TAB>sha256<TAB>declared-mime<TAB>actual-mime`.
- Raw closure SHA-256: **`5c039a268906dd5885eee4c3a6e60143066daf43db933e918cccc10c97dfba3f`**. Preimage is the raw CNXML bytes followed, without separators, by each referenced asset’s raw bytes in media document order.
- MIME was established from the byte signature and decoded format, not filename extension. The 12 `007a`–`010c` files are JPEG streams despite `image/png` declarations (`EA2-C0173`).

## English-labelled rasters and reflow obligations

Four rasters contain reader-visible English and therefore cannot be localized by translating alt text alone:

1. `fs-id1170654036108` / figure 003: two full English additive-inverse prompts and “We know …” statements.
2. `fs-id1170653797753` / figure 004: embedded “We know” reciprocal statement.
3. `fs-id1170653797768` / figure 005: embedded “We know” reciprocal statement.
4. `fs-id1170654084441` / figure 201: the complete English self-check table, including “No-I don’t get it!”.

`EA2-C0174` requires semantic, localized reconstructions of all four. Figure 201 should become a real table; figures 003–005 should become text plus MathML/semantic blanks. This also fixes centering, page-width use, selection, high-zoom sharpness, and screen-reader reading order.

The remaining 13 rasters are math-only, but they are exceptionally small (13–50 px high) and encode algebra that already has exact textual/alt witnesses. `EA2-C0175` covers `fs-id1170654075709`, `eip-id1169750566196`, `eip-id1169750566213`, `eip-id1169750566230`, `eip-id1169751856571`, `eip-id1169751856588`, `eip-id1169751856604`, `eip-id1169750823194`, `eip-id1169750823211`, `eip-id1169750823228`, `eip-id1169751973931`, `eip-id1169754247252`, and `eip-id1169754247268`. Reconstruct them as reflowable MathML/SVG/HTML rather than stretching low-resolution raster strips.

## Source-preservation disposition

The authoritative CNXML and media remain byte-identical. Reader corrections must be admitted through the correction ledger using the candidate rows in `PROPOSED_CORRECTIONS.csv`; source-origin wording, formulas, IDs, media references, and asset hashes remain available as the immutable witness. Upstream reporting is deferred for later deduplication into at most one concise corpus-level issue.
