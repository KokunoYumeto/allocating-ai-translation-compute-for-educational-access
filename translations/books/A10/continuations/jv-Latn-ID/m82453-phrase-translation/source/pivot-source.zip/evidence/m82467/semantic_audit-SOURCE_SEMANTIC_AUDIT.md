# m82467 Source Semantic Audit

Status: complete read-only pretranslation control. No target, builder, map, backend, live ledger, registry, reader, publication artifact, or root log was created or changed.

## Scope and collection-order proof

The frozen collection witness is `authority/source/collections/elementary-algebra-2e.collection.xml`, 5,256 bytes, SHA-256 `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72`. It identifies **Elementary Algebra 2e**, UUID `55931856-c627-418b-a56f-1dd0007683a8`, slug `elementary-algebra-2e`, and contains exactly 82 `col:module` nodes with 82 unique `document` values.

The ordered witness gives:

- ordinal 16: `m82465`;
- ordinal 17: `m82467`;
- ordinal 18: `m82468`;
- all three in the direct subcollection **Solving Linear Equations and Inequalities**.

Thus `m82467`, not `m82466`, is the immediate ordered successor to `m82465`. The originally requested `m82466` is absent from the 82-member collection and `authority/source/modules/m82466/index.cnxml` does not exist. That mismatch was reported fail-closed before work was retargeted; no `m82466` artifact was fabricated. If the collection hash, 82/82 uniqueness, or this adjacency changes, this audit is invalid.

## Frozen module identity

| Field | Exact value |
|---|---|
| path | `authority/source/modules/m82467/index.cnxml` |
| bytes | 155,541 |
| SHA-256 | `ba8c5d2d4c0fed618bbf37ebf94d4f18681672d2563b3ae670bd07fad52de7b5` |
| XML root / namespace | `document` / `http://cnx.rice.edu/cnxml` |
| root `xml:lang` | absent |
| document title | Use a General Strategy to Solve Linear Equations |
| metadata content ID | `m82467` |
| metadata title | Use a General Strategy to Solve Linear Equations |
| metadata UUID | `b60c723d-8e0b-4b56-9594-dba6dd21d116` |
| abstract objectives | 2 |
| parse result | well-formed XML |

## Exhaustive topology and ID inventory

All 753 `id` attributes are nonempty and unique. Every section, paragraph, note, exercise, problem, solution, example, table, list, and media node has an ID; no key structural node in those classes lacks one. Every exercise has exactly one direct problem and zero or one direct solution.

Element counts:

```text
abstract=1  colspec=21  content=1  content-id=1  definition=3
document=1  emphasis=24  entry=282  example=11  exercise=124
glossary=1  image=120  item=13  label=12  link=5  list=4
math=246  meaning=3  media=120  metadata=1  mfrac=23
mi=316  mn=822  mo=949  mrow=470  mtext=9  newline=30
note=31  para=226  problem=124  row=123  section=8
solution=81  span=2  table=13  tbody=13  term=8  tgroup=13
thead=1  title=25  uuid=1
```

Attribute counts:

```text
align=12  alt=120  aria-label=13  bullet-style=1  class=71
colname=21  colnum=21  cols=13  document=5  effect=24  id=753
list-type=3  mime-type=120  nameend=52  namest=52
number-style=2  src=120  stretchy=150  target-id=5  valign=16
```

All 52 `namest` and 52 `nameend` references resolve to a `colspec` in their own table. There are zero broken table-span references. Emphasis effects are 16 bold and 8 italics. Class-bearing elements comprise 22 `note|try`, 20 `exercise|material-set-2`, 9 `table|unnumbered unstyled can-break`, 5 `note|be-prepared`, 3 `table|unnumbered unstyled`, 2 `list|stepwise`, 2 `term|no-emphasis`, 2 `span|token`, and one each of the how-to and named section classes.

### Section tree

| Depth | ID | Title / role | Direct-child outline |
|---:|---|---|---|
| 0 | `fs-id1166503472223` | Solve Equations Using the General Strategy | 2 prose paras, 8 examples, 17 notes |
| 0 | `fs-id1166503192825` | Classify Equations | 10 prose paras, 3 examples, 9 notes, 3 tables, 1 media |
| 0 | `fs-id1166503508276` | Key Concepts | one wrapper list |
| 0 | `fs-id1166503104513` | empty title; `section-exercises` | four titled child sections |
| 1 | `fs-id1166503104516` | Practice Makes Perfect | 80 exercises and 4 organizer/instruction paras |
| 1 | `fs-id1166503470727` | Everyday Math | 2 exercises |
| 1 | `fs-id1166503285739` | Writing Exercises | 4 exercises |
| 1 | `fs-id1166499832650` | Self Check | 2 paras and 1 raster checklist |

### Reader blocks

- Notes: 31 total — 5 `be-prepared`, 22 `try`, 1 `howto`, and 3 unclassed definition callouts for Conditional equation, Identity, and Contradiction.
- Examples: 11, each containing one exercise/problem/solution relation.
- Lists: 4 — 2 abstract objectives; a 5-item stepwise general strategy; a one-item Key Concepts wrapper; and its nested 5-item stepwise strategy.
- Glossary: one glossary containing 3 definitions: `conditional equation`, `contradiction`, and `identity`.
- Exercises: 124 — 5 readiness, 11 examples, 22 try-it, 80 practice, 2 everyday-math, and 4 writing.
- Solutions: 81 — all 5 readiness, 11 examples, 22 try-it, 40 of 80 practice, 1 of 2 everyday-math, and 2 of 4 writing. The remaining 43 source-unsupplied answers must stay absent from the translation.

### Tables

| # | ID | Class | Rows | Entries | Colspecs | Media | Accessibility note |
|---:|---|---|---:|---:|---:|---:|---|
| 1 | `eip-id1168186270143` | unnumbered unstyled can-break | 12 | 28 | 3 | 11 | parent aria grouping defect EA2-C0272 |
| 2 | `eip-id1168183921388` | unnumbered unstyled can-break | 14 | 33 | 3 | 12 | complete worked sequence |
| 3 | `eip-id1168183634185` | unnumbered unstyled can-break | 13 | 31 | 3 | 13 | complete worked sequence |
| 4 | `eip-id1168181353799` | unnumbered unstyled can-break | 8 | 16 | 0 | 8 | complete worked sequence |
| 5 | `eip-id1168183715192` | unnumbered unstyled can-break | 15 | 36 | 3 | 15 | parent aria inserts wrong constant; EA2-C0273 |
| 6 | `eip-id1168182924453` | unnumbered unstyled can-break | 17 | 41 | 3 | 17 | complete worked sequence |
| 7 | `eip-id1168183733452` | unnumbered unstyled can-break | 13 | 31 | 3 | 13 | one incomplete child alt; EA2-C0258 |
| 8 | `eip-id1168182228792` | unnumbered unstyled can-break | 4 | 8 | 0 | 4 | identity derivation |
| 9 | `eip-id1168183754184` | unnumbered unstyled | 3 | 6 | 0 | 3 | contradiction derivation; wrong child alt EA2-C0261 |
| 10 | `eip-id1168182169219` | unnumbered unstyled can-break | 6 | 12 | 0 | 5 | identity example |
| 11 | `eip-id1168182261320` | unnumbered unstyled | 8 | 16 | 0 | 7 | conditional-equation example |
| 12 | `eip-id1168181388994` | unnumbered unstyled | 6 | 12 | 0 | 5 | contradiction example |
| 13 | `fs-id1166503594789` | semantic source table | 4 | 12 | 3 | 0 | visible cells correct; parent aria mismatches two cells, EA2-C0262 |

All 13 labels are empty. Table 13 alone has a `thead`. The source's first five strategy images are not a CNXML table at all; they are five sequential media nodes that visually form a five-row, three-column table, recorded as EA2-C0269.

## Cross-module link closure

The five readiness links have no literal inline link text. All `document` values are members of frozen `col31130`, and every target ID resolves exactly once in the named frozen source:

| Link | Frozen witness | Bytes / SHA-256 | Target result |
|---|---|---|---|
| `m82460#fs-id1170654067617` | `authority/source/modules/m82460/index.cnxml` | 164,724 / `ee089e74a6609868c94808e624d57016de348a791b577458c539c93584bba9a5` | one `example` |
| `m82460#fs-id1170654075722` | same | same | one `example` |
| `m82460#fs-id1170654067908` | same | same | one `example` |
| `m82460#fs-id1170654078011` | same | same | one `example` |
| `m82458#fs-id1170655197222` | `authority/source/modules/m82458/index.cnxml` | 130,960 / `678dc0c3ae2aad0192c0314395541720d6c6eb97f56d2f4d169f056fe1e630cb` | one `example` |

Preserve both attributes exactly and recheck assembled-scope resolution before release.

## MathML and independent solution audit

The 246 MathML blocks occur 130 times in problems, 91 times in solutions, and 25 times in explanatory prose. They contain 23 fractions, 316 `mi`, 822 `mn`, 949 `mo`, 470 `mrow`, and 9 `mtext` nodes. The nine `mtext` values are mathematical minus signs and are recorded as operator-semantic debt EA2-C0271. One supplied negative fraction uses U+2013 EN DASH in `m:mo`, recorded as EA2-C0274.

All five readiness expressions were independently simplified. All 117 equations were independently reduced with exact rational arithmetic, including decimal literals treated as rationals. All 81 supplied solutions/classifications agree with the independent result. The 43 source-unsupplied results below are QA expectations only and must not be inserted into the translated source.

Abbreviations: `E/P/S` are exercise/problem/solution IDs; `—` means the frozen source supplies no solution.

| # | Surface | E / P / S | Problem or formula | Independent result | Source solution |
|---:|---|---|---|---|---|
| 1 | prepare | `fs-idm474216432` / `fs-idm298113312` / `fs-idm355537920` | `−(a−4)` | `−a+4` | supplied; correct |
| 2 | prepare | `fs-idm470271232` / `fs-idm344292144` / `fs-idm354541872` | `(3/2)(12x+20)` | `18x+30` | supplied; correct |
| 3 | prepare | `fs-idm454186864` / `fs-idm474394576` / `fs-idm485974304` | `5−2(n+1)` | `3−2n` | supplied; correct |
| 4 | prepare | `fs-idm325243536` / `fs-idm300135584` / `fs-idm339845792` | `3(7y+9)` | `21y+27` | supplied; correct |
| 5 | prepare | `fs-idm320378272` / `fs-idm292979184` / `fs-idm308081936` | `(2.5)(6.4)` | `16` | supplied; correct |
| 6 | example | `fs-id1166503439330` / `fs-id1166503195971` / `fs-id1166503414798` | `−6(x+3)=24` | `x=−7` | supplied; correct |
| 7 | try | `fs-id1166503509611` / `fs-id1166503215410` / `fs-id1166503415875` | `5(x+3)=35` | `x=4` | supplied; correct |
| 8 | try | `fs-id1166503186090` / `fs-id1166503605525` / `fs-id1166503229225` | `6(y−4)=−18` | `y=1` | supplied; correct |
| 9 | example | `fs-id1166503217732` / `fs-id1166503130441` / `fs-id1166503286200` | `−(y+9)=8` | `y=−17` | supplied; correct |
| 10 | try | `fs-id1166503071906` / `fs-id1166503598697` / `fs-id1166503105719` | `−(y+8)=−2` | `y=−6` | supplied; correct |
| 11 | try | `fs-id1166503085255` / `fs-id1166503250323` / `fs-id1166503151758` | `−(z+4)=−12` | `z=8` | supplied; correct |
| 12 | example | `fs-id1166503229884` / `fs-id1166503112659` / `fs-id1166503095216` | `5(a−3)+5=−10` | `a=0` | supplied; correct |
| 13 | try | `fs-id1166503111561` / `fs-id1166503415945` / `fs-id1166503589379` | `2(m−4)+3=−1` | `m=2` | supplied; correct |
| 14 | try | `fs-id1166503102000` / `fs-id1166503414548` / `fs-id1166503130262` | `7(n−3)−8=−15` | `n=2` | supplied; correct |
| 15 | example | `fs-id1166503220787` / `fs-id1166503096427` / `fs-id1166503182988` | `(2/3)(6m−3)=8−m` | `m=2` | supplied; correct |
| 16 | try | `fs-id1166503438703` / `fs-id1166503509060` / `fs-id1166503474602` | `(1/3)(6u+3)=7−u` | `u=2` | supplied; correct |
| 17 | try | `fs-id1166503072103` / `fs-id1166503241695` / `fs-id1166503251979` | `(2/3)(9x−12)=8+2x` | `x=4` | supplied; correct |
| 18 | example | `fs-id1166503077036` / `fs-id1166503598333` / `fs-id1166503062316` | `8−2(3y+5)=0` | `y=−1/3` | supplied; correct |
| 19 | try | `fs-id1166503241592` / `fs-id1166503123493` / `fs-id1166503285200` | `12−3(4j+3)=−17` | `j=5/3` | supplied; correct |
| 20 | try | `fs-id1166503129268` / `fs-id1166503083669` / `fs-id1166503589411` | `−6−8(k−2)=−10` | `k=5/2` | supplied; correct |
| 21 | example | `fs-id1166503404157` / `fs-id1166503052806` / `fs-id1166503131392` | `4(x−1)−2=5(2x+3)+6` | `x=−9/2` | supplied; correct |
| 22 | try | `fs-id1166503508080` / `fs-id1166503203543` / `fs-id1166503472126` | `6(p−3)−7=5(4p+3)−12` | `p=−2` | supplied; correct |
| 23 | try | `fs-id1166503251554` / `fs-id1166503053175` / `fs-id1166503472134` | `8(q+1)−5=3(2q−4)−1` | `q=−8` | supplied; correct |
| 24 | example | `fs-id1166503107011` / `fs-id1166503080422` / `fs-id1166503168241` | `10[3−8(2s−5)]=15(40−5s)` | `s=−2` | supplied; correct |
| 25 | try | `fs-id1166503168975` / `fs-id1166503320020` / `fs-id1166503536404` | `6[4−2(7y−1)]=8(13−8y)` | `y=−17/5` | supplied; correct |
| 26 | try | `fs-id1166503150956` / `fs-id1166503131607` / `fs-id1166503320069` | `12[1−5(4z−1)]=3(24+11z)` | `z=0` | supplied; correct |
| 27 | example | `fs-id1166503410121` / `fs-id1166503402782` / `fs-id1166503115846` | `0.36(100n+5)=0.6(30n+15)` | `n=2/5` | supplied; correct |
| 28 | try | `fs-id1166503078843` / `fs-id1166503325060` / `fs-id1166503469688` | `0.55(100n+8)=0.6(85n+14)` | `n=1` | supplied; correct |
| 29 | try | `fs-id1166503416605` / `fs-id1166503505755` / `fs-id1166503193029` | `0.15(40m−120)=0.5(60m+12)` | `m=−1` | supplied; correct |
| 30 | example | `fs-id1166503230474` / `fs-id1166503230476` / `fs-id1166503325899` | `6(2n−1)+3=2n−8+5(2n+1)` | identity; all real numbers | supplied; correct |
| 31 | try | `fs-id1166503471713` / `fs-id1166503471716` / `fs-id1166503225185` | `4+9(3x−7)=−42x−13+23(3x−2)` | identity; all real numbers | supplied; correct |
| 32 | try | `fs-id1166503595246` / `fs-id1166503595248` / `fs-id1166503414970` | `8(1−3x)+15(2x+7)=2(x+50)+4(x+3)+1` | identity; all real numbers | supplied; correct |
| 33 | example | `fs-id1166503595622` / `fs-id1166503505298` / `fs-id1166503474377` | `10+4(p−5)=0` | `p=5/2` | supplied; correct |
| 34 | try | `fs-id1166503556342` / `fs-id1166499833606` / `fs-id1166503219178` | `11(q+3)−5=19` | `q=−9/11` | supplied; correct |
| 35 | try | `fs-id1166503362826` / `fs-id1166503413914` / `fs-id1166503412243` | `6+14(k−8)=95` | `k=201/14` | supplied; correct |
| 36 | example | `fs-id1166503195938` / `fs-id1166503195940` / `fs-id1166503238457` | `5m+3(9+3m)=2(7m−11)` | contradiction; no solution | supplied; correct |
| 37 | try | `fs-id1166503236834` / `fs-id1166503236836` / `fs-id1166503212260` | `12c+5(5+3c)=3(9c−4)` | contradiction; no solution | supplied; correct |
| 38 | try | `fs-id1166503169724` / `fs-id1166503505344` / `fs-id1166503154344` | `4(7d+18)=13(3d−2)−11d` | contradiction; no solution | supplied; correct |
| 39 | practice | `fs-id1166503192805` / `fs-id1166503192808` / `—` | `15(y−9)=−60` | `y=5` | not supplied; QA only |
| 40 | practice | `fs-id1166503286052` / `fs-id1166503286054` / `fs-id1166503504141` | `21(y−5)=−42` | `y=3` | supplied; correct |
| 41 | practice | `fs-id1166503554782` / `fs-id1166503554784` / `—` | `−9(2n+1)=36` | `n=−5/2` | not supplied; QA only |
| 42 | practice | `fs-id1166503598410` / `fs-id1166503598412` / `fs-id1166503595018` | `−16(3n+4)=32` | `n=−2` | supplied; correct |
| 43 | practice | `fs-id1166503317264` / `fs-id1166503317266` / `—` | `8(22+11r)=0` | `r=−2` | not supplied; QA only |
| 44 | practice | `fs-id1166503472181` / `fs-id1166503472183` / `fs-id1166503225421` | `5(8+6p)=0` | `p=−4/3` | supplied; correct |
| 45 | practice | `fs-id1166503591272` / `fs-id1166503591274` / `—` | `−(w−12)=30` | `w=−18` | not supplied; QA only |
| 46 | practice | `fs-id1166503508726` / `fs-id1166503508728` / `fs-id1166503246260` | `−(t−19)=28` | `t=−9` | supplied; correct |
| 47 | practice | `fs-id1166503155972` / `fs-id1166503505329` / `—` | `9(6a+8)+9=81` | `a=0` | not supplied; QA only |
| 48 | practice | `fs-id1166503504248` / `fs-id1166503504250` / `fs-id1166503170001` | `8(9b−4)−12=100` | `b=2` | supplied; correct |
| 49 | practice | `fs-id1166503592865` / `fs-id1166503592867` / `—` | `32+3(z+4)=41` | `z=−1` | not supplied; QA only |
| 50 | practice | `fs-id1166503170345` / `fs-id1166503170347` / `fs-id1166503397061` | `21+2(m−4)=25` | `m=6` | supplied; correct |
| 51 | practice | `fs-id1166503407057` / `fs-id1166503439295` / `—` | `51+5(4−q)=56` | `q=3` | not supplied; QA only |
| 52 | practice | `fs-id1166503476438` / `fs-id1166503476441` / `fs-id1166503591861` | `−6+6(5−k)=15` | `k=3/2` | supplied; correct |
| 53 | practice | `fs-id1166503439230` / `fs-id1166503439232` / `—` | `2(9s−6)−62=16` | `s=5` | not supplied; QA only |
| 54 | practice | `fs-id1166503194154` / `fs-id1166503194156` / `fs-id1166503228064` | `8(6t−5)−35=−27` | `t=1` | supplied; correct |
| 55 | practice | `fs-id1166503219738` / `fs-id1166503219740` / `—` | `3(10−2x)+54=0` | `x=14` | not supplied; QA only |
| 56 | practice | `fs-id1166503590947` / `fs-id1166503590949` / `fs-id1166503591485` | `−2(11−7x)+54=4` | `x=−2` | supplied; correct |
| 57 | practice | `fs-id1166503437290` / `fs-id1166503397039` / `—` | `(2/3)(9c−3)=22` | `c=4` | not supplied; QA only |
| 58 | practice | `fs-id1166503166927` / `fs-id1166503166929` / `fs-id1166503595952` | `(3/5)(10x−5)=27` | `x=5` | supplied; correct |
| 59 | practice | `fs-id1166503176986` / `fs-id1166503176988` / `—` | `(1/5)(15c+10)=c+7` | `c=5/2` | not supplied; QA only |
| 60 | practice | `fs-id1166503167518` / `fs-id1166503167520` / `fs-id1166503221909` | `(1/4)(20d+12)=d+7` | `d=1` | supplied; correct |
| 61 | practice | `fs-id1166503594686` / `fs-id1166503594688` / `—` | `18−(9r+7)=−16` | `r=3` | not supplied; QA only |
| 62 | practice | `fs-id1166503588123` / `fs-id1166503588125` / `fs-id1166499834035` | `15−(3r+8)=28` | `r=−7` | supplied; correct |
| 63 | practice | `fs-id1166499832927` / `fs-id1166499832930` / `—` | `5−(n−1)=19` | `n=−13` | not supplied; QA only |
| 64 | practice | `fs-id1166503476274` / `fs-id1166503476276` / `fs-id1166503472240` | `−3−(m−1)=13` | `m=−15` | supplied; correct |
| 65 | practice | `fs-id1166503418096` / `fs-id1166503418098` / `—` | `11−4(y−8)=43` | `y=0` | not supplied; QA only |
| 66 | practice | `fs-id1166503128037` / `fs-id1166503128039` / `fs-id1166503150454` | `18−2(y−3)=32` | `y=−4` | supplied; correct |
| 67 | practice | `fs-id1166503115495` / `fs-id1166503115497` / `—` | `24−8(3v+6)=0` | `v=−1` | not supplied; QA only |
| 68 | practice | `fs-id1166503413816` / `fs-id1166503413818` / `fs-id1166503466904` | `35−5(2w+8)=−10` | `w=1/2` | supplied; correct |
| 69 | practice | `fs-id1166503205717` / `fs-id1166503205720` / `—` | `4(a−12)=3(a+5)` | `a=63` | not supplied; QA only |
| 70 | practice | `fs-id1166503286544` / `fs-id1166503286546` / `fs-id1166503508270` | `−2(a−6)=4(a−3)` | `a=4` | supplied; correct |
| 71 | practice | `fs-id1166503232308` / `fs-id1166503232310` / `—` | `2(5−u)=−3(2u+6)` | `u=−7` | not supplied; QA only |
| 72 | practice | `fs-id1166503596772` / `fs-id1166503596774` / `fs-id1166503559908` | `5(8−r)=−2(2r−16)` | `r=8` | supplied; correct |
| 73 | practice | `fs-id1166503209513` / `fs-id1166503209515` / `—` | `3(4n−1)−2=8n+3` | `n=2` | not supplied; QA only |
| 74 | practice | `fs-id1166503589633` / `fs-id1166503589635` / `fs-id1166503469616` | `9(2m−3)−8=4m+7` | `m=3` | supplied; correct |
| 75 | practice | `fs-id1166503410310` / `fs-id1166503410312` / `—` | `12+2(5−3y)=−9(y−1)−2` | `y=−5` | not supplied; QA only |
| 76 | practice | `fs-id1166499706850` / `fs-id1166503551443` / `fs-id1166503404120` | `−15+4(2−5y)=−7(y−4)+4` | `y=−3` | supplied; correct |
| 77 | practice | `fs-id1166503434335` / `fs-id1166503434337` / `—` | `8(x−4)−7x=14` | `x=46` | not supplied; QA only |
| 78 | practice | `fs-id1166503405989` / `fs-id1166503589742` / `fs-id1166503406969` | `5(x−4)−4x=14` | `x=34` | supplied; correct |
| 79 | practice | `fs-id1166499809545` / `fs-id1166499809548` / `—` | `5+6(3s−5)=−3+2(8s−1)` | `s=10` | not supplied; QA only |
| 80 | practice | `fs-id1166503437821` / `fs-id1166503437823` / `fs-id1166503248489` | `−12+8(x−5)=−4+3(5x−2)` | `x=−6` | supplied; correct |
| 81 | practice | `fs-id1166499710418` / `fs-id1166499710421` / `—` | `4(u−1)−8=6(3u−2)−7` | `u=1/2` | not supplied; QA only |
| 82 | practice | `fs-id1166503403498` / `fs-id1166503594434` / `fs-id1166503410858` | `7(2n−5)=8(4n−1)−9` | `n=−1` | supplied; correct |
| 83 | practice | `fs-id1166503458070` / `fs-id1166499831426` / `—` | `4(p−4)−(p+7)=5(p−3)` | `p=−4` | not supplied; QA only |
| 84 | practice | `fs-id1166503328353` / `fs-id1166503328355` / `fs-id1166503439207` | `3(a−2)−(a+6)=4(a−1)` | `a=−4` | supplied; correct |
| 85 | practice | `fs-id1166503596996` / `fs-id1166503596998` / `—` | `−(9y+5)−(3y−7)=16−(4y−2)` | `y=−2` | not supplied; QA only |
| 86 | practice | `fs-id1166503515524` / `fs-id1166503515527` / `fs-id1166503470512` | `−(7m+4)−(2m−5)=14−(5m−3)` | `m=−4` | supplied; correct |
| 87 | practice | `fs-id1166499702481` / `fs-id1166499702483` / `—` | `4[5−8(4c−3)]=12(1−13c)−8` | `c=−4` | not supplied; QA only |
| 88 | practice | `fs-id1166503320375` / `fs-id1166503320377` / `fs-id1166503470555` | `5[9−2(6d−1)]=11(4−10d)−139` | `d=−3` | supplied; correct |
| 89 | practice | `fs-id1166503509029` / `fs-id1166503509031` / `—` | `3[−9+8(4h−3)]=2(5−12h)−19` | `h=3/4` | not supplied; QA only |
| 90 | practice | `fs-id1166499832625` / `fs-id1166503592001` / `fs-id1166499832950` | `3[−14+2(15k−6)]=8(3−5k)−24` | `k=3/5` | supplied; correct |
| 91 | practice | `fs-id1166503470287` / `fs-id1166503474838` / `—` | `5[2(m+4)+8(m−7)]=2[3(5+m)−(21−3m)]` | `m=6` | not supplied; QA only |
| 92 | practice | `fs-id1166503554602` / `fs-id1166503554604` / `fs-id1166503472405` | `10[5(n+1)+4(n−1)]=11[7(5+n)−(25−3n)]` | `n=−5` | supplied; correct |
| 93 | practice | `fs-id1166503476096` / `fs-id1166503476098` / `—` | `5(1.2u−4.8)=−12` | `u=2` | not supplied; QA only |
| 94 | practice | `fs-id1166503539662` / `fs-id1166503475708` / `fs-id1166503546684` | `4(2.5v−0.6)=7.6` | `v=1` | supplied; correct |
| 95 | practice | `fs-id1166503595323` / `fs-id1166503595325` / `—` | `0.25(q−6)=0.1(q+18)` | `q=22` | not supplied; QA only |
| 96 | practice | `fs-id1166503444844` / `fs-id1166503444846` / `fs-id1166499831158` | `0.2(p−6)=0.4(p+14)` | `p=−34` | supplied; correct |
| 97 | practice | `fs-id1166503437148` / `fs-id1166503437150` / `—` | `0.2(30n+50)=28` | `n=3` | not supplied; QA only |
| 98 | practice | `fs-id1166503504899` / `fs-id1166503504901` / `fs-id1166503504538` | `0.5(16m+34)=−15` | `m=−4` | supplied; correct |
| 99 | practice | `fs-id1166503546225` / `fs-id1166503546227` / `—` | `23z+19=3(5z−9)+8z+46` | identity; all real numbers | not supplied; QA only |
| 100 | practice | `fs-id1166503238924` / `fs-id1166503238926` / `fs-id1166503472058` | `15y+32=2(10y−7)−5y+46` | identity; all real numbers | supplied; correct |
| 101 | practice | `fs-id1166503472066` / `fs-id1166503472068` / `—` | `5(b−9)+4(3b+9)=6(4b−5)−7b+21` | identity; all real numbers | not supplied; QA only |
| 102 | practice | `fs-id1166503508706` / `fs-id1166503508708` / `fs-id1166499837489` | `9(a−4)+3(2a+5)=7(3a−4)−6a+7` | identity; all real numbers | supplied; correct |
| 103 | practice | `fs-id1166499837496` / `fs-id1166499837498` / `—` | `18(5j−1)+29=47` | `j=2/5` | not supplied; QA only |
| 104 | practice | `fs-id1166503448198` / `fs-id1166503448200` / `fs-id1166503505666` | `24(3d−4)+100=52` | `d=2/3` | supplied; correct |
| 105 | practice | `fs-id1166503474768` / `fs-id1166503474771` / `—` | `22(3m−4)=8(2m+9)` | `m=16/5` | not supplied; QA only |
| 106 | practice | `fs-id1166503104139` / `fs-id1166503104141` / `fs-id1166503607565` | `30(2n−1)=5(10n+8)` | `n=7` | supplied; correct |
| 107 | practice | `fs-id1166503607581` / `fs-id1166503607583` / `—` | `7v+42=11(3v+8)−2(13v−1)` | contradiction; no solution | not supplied; QA only |
| 108 | practice | `fs-id1166503590767` / `fs-id1166503590769` / `fs-id1166503476355` | `18u−51=9(4u+5)−6(3u−10)` | contradiction; no solution | supplied; correct |
| 109 | practice | `fs-id1166503476362` / `fs-id1166503476365` / `—` | `3(6q−9)+7(q+4)=5(6q+8)−5(q+1)` | contradiction; no solution | not supplied; QA only |
| 110 | practice | `fs-id1166503437972` / `fs-id1166503437974` / `fs-id1166503471949` | `5(p+4)+8(2p−1)=9(3p−5)−6(p−2)` | contradiction; no solution | supplied; correct |
| 111 | practice | `fs-id1166503471957` / `fs-id1166503471959` / `—` | `12(6h−1)=8(8h+5)−4` | `h=6` | not supplied; QA only |
| 112 | practice | `fs-id1166503433654` / `fs-id1166503433656` / `fs-id1166503505405` | `9(4k−7)=11(3k+1)+4` | `k=26` | supplied; correct |
| 113 | practice | `fs-id1166503471906` / `fs-id1166503471908` / `—` | `45(3y−2)=9(15y−6)` | contradiction; no solution | not supplied; QA only |
| 114 | practice | `fs-id1166503433563` / `fs-id1166503433565` / `fs-id1166503474084` | `60(2x−1)=15(8x+5)` | contradiction; no solution | supplied; correct |
| 115 | practice | `fs-id1166503474092` / `fs-id1166503474094` / `—` | `16(6n+15)=48(2n+5)` | identity; all real numbers | not supplied; QA only |
| 116 | practice | `fs-id1166503472456` / `fs-id1166503472458` / `fs-id1166503591232` | `36(4m+5)=12(12m+15)` | identity; all real numbers | supplied; correct |
| 117 | practice | `fs-id1166503591240` / `fs-id1166503591242` / `—` | `9(14d+9)+4d=13(10d+6)+3` | identity; all real numbers | not supplied; QA only |
| 118 | practice | `fs-id1166503416016` / `fs-id1166503416018` / `fs-id1166503470718` | `11(8c+5)−8c=2(40c+25)+5` | identity; all real numbers | supplied; correct |
| 119 | everyday | `fs-id1166499831570` / `fs-id1166499831572` / `—` | `2L+2(L−2.5)=44` | `L=49/4` feet | not supplied; QA only |
| 120 | everyday | `fs-id1166503594746` / `fs-id1166503594748` / `fs-id1166503509338` | `0.05n+0.10(2n−1)=1.90` | `n=8` nickels | supplied; correct |
| 121 | writing | `fs-id1166503285745` / `fs-id1166503285747` / `—` | list the five general-strategy steps | open response | not supplied; QA only |
| 122 | writing | `fs-id1166503285761` / `fs-id1166503285763` / `fs-id1166503596361` | explain why both sides are simplified first | answers vary | supplied; correct |
| 123 | writing | `fs-id1166503596369` / `fs-id1166503596371` / `—` | `3−7(y−4)=38` | first distribute `−7`; `y=−1` | not supplied; QA only |
| 124 | writing | `fs-id1166499834633` / `fs-id1166503476190` / `fs-id1166499832641` | `(1/4)(8x+20)=3x−4` | `x=9`; explanations vary | supplied; correct |

## Direct asset closure and raster-text inventory

The 120 image uses resolve to 120 unique existing files under `authority/source/media`; there are zero missing files and zero duplicate source references. All 120 media nodes have nonempty unique alt text. Every file has JPEG `FF D8 FF` bytes, a `.jpg` filename, and 150×150 pixels-per-inch metadata. Seven declarations truthfully say `image/jpeg`; 113 declare `image/png` despite JPEG bytes. Total referenced bytes are 2,151,483; mismatch bytes are 1,818,857.

Dimensions range from 131×12 to 750×277. The 114 worked-math rasters at ordinals 6-119 range from 131-297 pixels wide; 111 are under 40 pixels high, 79 under 20 pixels high, and 111 under 10,000 pixels. The five strategy slices are each 750 pixels wide and 84-177 pixels high. The self-check is 658×124.

The binding asset-inventory digest is SHA-256 `fba9c73ca2733a8a499a9e955ad8fedd7973e9d9f905424c7ba4dd0e38181f61`, computed from the exact source-order references as UTF-8 lines joined by LF, with no terminal newline, using:

```text
ordinal|filename|declared=<subtype>|actual=jpeg|bytes=<integer>|px=<width>x<height>|dpi=150x150|sha256=<lowercase hex>
```

This digest plus the module source hash binds every filename, order, declaration, byte count, dimension, density, and content hash without permitting an inferred or globbed asset set. Embedded XMP payloads total 1,749,217 bytes, 81.3% of the referenced payload; individual XMP blocks range from 10,500 to 52,847 bytes.

### Raster sequence inventory

| Ordinals | Filename sequence | Visible content | Reader/localization state |
|---|---|---|---|
| 1-5 | `...001a` through `...001e` | five-step, three-column general-strategy table for `−6(x+3)=24`, including English instructions and check | English-bearing; must become one semantic localized table |
| 6-16 | `...002e` through `...002d` | worked solution/check for `−(y+9)=8`, result `y=−17` | math-only pixels; alt defects at 16 and parent table |
| 17-28 | `...004f` through `...004e` | worked solution/check for `5(a−3)+5=−10`, result `a=0` | math-only pixels |
| 29-41 | `...006f` through `...006e` | worked solution/check for `(2/3)(6m−3)=8−m`, result `m=2` | math-only pixels |
| 42-49 | `...008b` through `...008a` | worked solution/check for `8−2(3y+5)=0`, result `y=−1/3` | math-only pixels; ordinal 49 is a 185×277 composite check |
| 50-64 | `...010g` through `...010f` | worked solution/check for `4(x−1)−2=5(2x+3)+6`, result `x=−9/2` | math-only pixels; false contrast alt at 56 and parent aria defect |
| 65-81 | `...012h` through `...012g` | worked solution/check for `10[3−8(2s−5)]=15(40−5s)`, result `s=−2` | math-only pixels |
| 82-94 | `...014f` through `...014e` | worked solution/check for `0.36(100n+5)=0.6(30n+15)`, result `n=0.4` | math-only pixels; incomplete alt at 85, check-mark alt defect at 94 |
| 95 | `...016` | compact check of `7x+8=−13` at `x=−3` | math-only pixels |
| 96-99 | `...017a` through `...017d` | identity reduction `2y+6=2(y+3)` to `6=6` | math-only pixels |
| 100-102 | `...018a` through `...018c` | contradiction reduction `5z=5z−1` to `0≠−1` | math-only pixels; not-equal alt defect at 102 |
| 103-107 | `...019a` through `...019e` | identity example reducing to `−3=−3` | math-only pixels |
| 108-114 | `...020a` through `...020g` | conditional equation `10+4(p−5)=0`, result `p=5/2` | math-only pixels |
| 115-119 | `...021a` through `...021e` | contradiction example reducing to `27≠−22` | math-only pixels |
| 120 | `...201` | English three-row, four-column self-check checklist | English-bearing; malformed header and flattened-table debt |

Reader-visible English therefore occurs in exactly six rasters: ordinals 1-5 and 120. Their exact identities are:

| # | File | Bytes | Pixels | SHA-256 |
|---:|---|---:|---:|---|
| 1 | `CNX_ElemAlg_Figure_02_04_001a_img_new.jpg` | 49,913 | 750×107 | `7051677a4ea27353491532488b59eb3ea0bcc51192f9b6d0fba518929245f044` |
| 2 | `CNX_ElemAlg_Figure_02_04_001b_img_new.jpg` | 38,793 | 750×84 | `ca3f4337428d0abc962b2ccd595546b5ce82e2387686ae3b9464b28892e72a31` |
| 3 | `CNX_ElemAlg_Figure_02_04_001c_img_new.jpg` | 46,984 | 750×84 | `6f2f5fc22e84341ef050d48c896c74a32bec3c7569ec644fe359719a8868985f` |
| 4 | `CNX_ElemAlg_Figure_02_04_001d_img_new.jpg` | 41,971 | 750×100 | `805b0bf9341fcc53e1f60965792c5005af031557767c16fd850190743b051573` |
| 5 | `CNX_ElemAlg_Figure_02_04_001e_img_new.jpg` | 43,520 | 750×177 | `4114966f44ddfac596733d34db9ddc495a98373a8781bbb54fa486d3f1e34775` |
| 120 | `CNX_ElemAlg_Figure_02_04_201_img_new.jpg` | 54,660 | 658×124 | `55e56ff81377b2aaa9770b3b71183adab96f2e2decb6e35f910e3bae5e90dbe2` |

## Source defects and proposed controls

No supplied mathematical result is wrong. Eighteen bounded source/derivative debts are recorded without changing the authority bytes:

- EA2-C0257: repeated “to equal to 1” grammar error, including embedded strategy pixels;
- EA2-C0258: one alt omits `18n+1.8=9` entirely;
- EA2-C0259: two alts call check marks square-root signs;
- EA2-C0260: impossible white-on-white contrast description;
- EA2-C0261: `0≠−1` alt drops the not-equal relation;
- EA2-C0262: classification-table aria mismatches two visible cells;
- EA2-C0263: malformed self-check header `No-I don't get it!`;
- EA2-C0264: absent module-root language metadata;
- EA2-C0265: 113 MIME/signature mismatches;
- EA2-C0266: six English-bearing rasters need localization;
- EA2-C0267: 114 fixed-width math rasters need centered responsive reflow;
- EA2-C0268: self-check is a flattened nonsemantic table;
- EA2-C0269: five strategy slices lack table semantics;
- EA2-C0270: XMP metadata occupies 81.3% of asset bytes;
- EA2-C0271: nine mathematical minus signs are `m:mtext` rather than `m:mo`;
- EA2-C0272: parent aria ambiguously misvoices `−(y+9)` as `−y+9`;
- EA2-C0273: parent aria inserts a wrong `+2` in the `x=−9/2` check;
- EA2-C0274: one negative answer uses en dash instead of the minus operator.

The reservation witnesses are `qa/m82465/PROPOSED_TERMINOLOGY.csv`, 9,331 bytes, SHA-256 `962309d3545a080d4d8dcabec8289c1596d7d23887621bc04997433d94509258`, and `qa/m82465/PROPOSED_CORRECTIONS.csv`, 11,592 bytes, SHA-256 `3a3aa0776238985720d4ce9700a328bedac1ebb48e90b366699f79f3319f7eec`. They occupy `EA2-T0323` through `EA2-T0354` and `EA2-C0242` through `EA2-C0256`. This packet therefore proposes the nonoverlapping ranges `EA2-T0355` through `EA2-T0376` and `EA2-C0257` through `EA2-C0274`.

## Control conclusion

The source is in scope, well formed, dependency-closed at its direct module/link/media boundary, structurally enumerable, and mathematically checked. There is no source blocker to beginning translation. Translation must preserve the frozen topology and supplied-answer boundary while applying only the recorded derivative repairs, localizing every accessibility surface, and reflowing the fixed-width mathematics into centered responsive semantic content.
