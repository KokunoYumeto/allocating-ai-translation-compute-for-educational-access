# m82469 Source and Semantic Audit

Audit state: **pretranslation control complete; source unchanged**  
Module: `m82469`, “Solve a Formula for a Specific Variable”  
Provenance: **OpenAI Codex gpt-5.6-sol, Ultra**  
Audit timestamp: `2026-08-23T02:18:10+02:00`

## Scope and write boundary

This audit examined only the frozen collection entry, `authority/source/modules/m82469/index.cnxml`, its 42 directly referenced frozen media assets, and the two explicitly linked prerequisite targets in `m82464` and `m82465`. It did not alter any authority source, media, collection, live ledger, target module, builder, map, backend, reader, publication artifact, root log, or sibling module.

## Frozen identity and ordinal

| Object | Bytes | SHA-256 |
|---|---:|---|
| `authority/source/collections/elementary-algebra-2e.collection.xml` | 5,256 | `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72` |
| `authority/source/modules/m82469/index.cnxml` | 94,385 | `16d4267bb97fc62bff7a71c2d6051796d0c9dbf7f98f3bfc978d60ba07574676` |

The collection's ordered module sequence places `m82468` at ordinal 18, `m82469` at ordinal **19**, and `m82470` at ordinal 20. Therefore `m82469` is immediately after `m82468`, as required.

Module metadata binds:

- content ID: `m82469`
- UUID: `dbf74c23-da9a-4bc4-928d-31acbb00c054`
- document and metadata title: `Solve a Formula for a Specific Variable`
- abstract objective 1: `Use the Distance, Rate, and Time formula`
- abstract objective 2: `Solve a formula for a specific variable`

## Structural topology and ID integrity

The six top-level content children, in source order, are:

1. readiness note `fs-id1168341865013` (`be-prepared`)
2. readiness note `fs-idm351983216` (`be-prepared`)
3. section `fs-id1168345384592`, “Use the Distance, Rate, and Time Formula”
4. section `fs-id1168345644624`, “Solve a Formula for a Specific Variable”
5. section `fs-id1168345669994` (`key-concepts`), “Key Concepts”
6. section `fs-id1168345461793` (`section-exercises`), containing four subsections

The exercise subsections are:

- `fs-id1166501969669` (`practice-perfect`), “Practice Makes Perfect”: 50 exercises
- `fs-id1168345627097` (`everyday`), “Everyday Math”: 2 exercises
- `fs-id1168345741419` (`writing`), “Writing Exercises”: 2 exercises
- `fs-id1166502111178`, “Self Check”: two paragraphs and one checklist image

Element inventory:

| Element | Count |
|---|---:|
| section | 8 |
| para | 163 |
| note | 20 |
| example | 8 |
| exercise / problem | 80 / 80 |
| solution | 53 |
| list / item | 5 / 21 |
| table / tgroup / row / entry | 8 / 8 / 54 / 196 |
| equation | 1 |
| MathML `math` | 232 |
| media / image | 42 / 42 |
| link | 5 |

There are **468** `id` attributes and **no duplicate IDs**. All 80 exercises have exactly one problem. The two readiness exercises, the 24 instructional example/try exercises, and their 26 solutions are structurally complete. The section-exercise area has 54 exercises and exactly 27 supplied solutions.

## Supplied-answer boundary

The derivative must preserve the source boundary exactly: translate every existing solution, but do not synthesize, expose, or attach a solution to any source exercise that lacks one.

The 27 solution-bearing section exercises are:

`fs-id1168341968081`; `fs-id1168345508573`; `fs-id1168341906503`; `fs-id1168345556297`; `fs-id1168341902396`; `fs-id1168345688658`; `fs-id1168341923605`; `fs-id1168345661634`; `fs-id1168345385586`; `fs-id1168345456555`; `fs-id1168345622720`; `fs-id1168345670095`; `fs-id1168345517553`; `fs-id1168342170981`; `fs-id1168341915987`; `fs-id1168345416686`; `fs-id1168345622690`; `fs-id1168345690588`; `fs-id1168341861196`; `fs-id1168345525313`; `fs-id1168345465856`; `fs-id1168345424503`; `fs-id1168341968260`; `fs-id1168345741574`; `fs-id1168342104283`; `fs-id1168342170912`; `fs-id1168345405974`.

The 27 deliberately unsupplied section exercises are:

`fs-id1168345726419`; `fs-id1168341968108`; `fs-id1168345525228`; `fs-id1168341906521`; `fs-id1168345556314`; `fs-id1168341902413`; `fs-id1168345638455`; `fs-id1168345486624`; `fs-id1168341861256`; `fs-id1168345445896`; `fs-id1168345406038`; `fs-id1168341917436`; `fs-id1168345423598`; `fs-id1168345486677`; `fs-id1168345688158`; `fs-id1168345461815`; `fs-id1168345695196`; `fs-id1168345520353`; `fs-id1168345522170`; `fs-id1168345517639`; `fs-id1168345404008`; `fs-id1168345543550`; `fs-id1168341955961`; `fs-id1168345661612`; `fs-id1168345405954`; `fs-id1168345439494`; `fs-id1168345741424`.

## Independent mathematics audit

All 53 source-supplied solutions were checked independently. No wrong numerical answer or wrong symbolic rearrangement was found. Representative and boundary checks include:

- readiness: `15t=120 -> t=8`; `6x+24=96 -> x=12`
- distance/rate/time: `12(3 1/2)=42`; `60(5 1/2)=330`; `3(2 1/3)=7`; `520/65=8`; `770/70=11`; `168/3=56`
- formula rearrangement: `d=rt -> t=d/r` and `r=d/t`; `A=(1/2)bh -> h=2A/b`, `b=2A/h`
- simple interest: `5600/(0.04*7)=20000`; `2160/(0.06*3)=12000`; `5400/(0.12*5)=9000`; `3950/(0.06*5)=13166.666...`, rounded correctly to `$13,166.67`; `624/(6000*0.052)=2`
- two-variable formulas: `3x+2y=18 -> y=(18-3x)/2=-3x/2+9`; at `x=4`, `y=3`; all supplied variants in the try and practice sets substitute correctly
- perimeter/linear forms: `P=a+b+c`, `180=a+b+c`, `P=2L+2W`, and all supplied isolated-variable forms are equivalent to their source formulas
- circle/volume: `C=pi*d -> pi=C/d`; `V=LWH -> H=V/(LW)`
- temperature: `F=(9/5)C+32` gives `C=10 degrees Celsius` when `F=50 degrees Fahrenheit`

The general quotients are valid under the usual nonzero-denominator assumptions (`r`, `t`, `b`, `h`, `P`, `L`, or `W`, as applicable). In the physical contexts those quantities are intended to be positive. The source does not state those restrictions; the translation must not imply that division by zero is permitted.

One mathematical wording defect is not an answer error: `fs-id1168342104215` says “We cannot divide 13−6x by 5.” Division is possible; what is unavailable is cancellation/reduction by a common factor of 5. This is proposed as `EA2-C0293`.

## Cross-reference audit

All five links resolve.

| Source parent | Destination | Result |
|---|---|---|
| `fs-idm298926320` | `m82464#fs-id1168344337607` | exists; target is an example teaching division to isolate a variable |
| `fs-idm474352288` | `m82465#fs-id1168344197880` | exists; target is an example solving a two-step linear equation |
| `fs-id1168345376761` | local `#fs-id1168345517802` | exists; example |
| `fs-id1168345376761` | local `#fs-id1168345451567` | exists; example |
| `fs-id1168345376761` | local `#fs-id1168345451567` | exists; repeated intentional reference |

Direct target-source bindings:

| Target source | Bytes | SHA-256 |
|---|---:|---|
| `authority/source/modules/m82464/index.cnxml` | 133,732 | `099aae173772040a83d8c9160980922315352fc2a699af7c6f25ddc594a0c0bc` |
| `authority/source/modules/m82465/index.cnxml` | 102,020 | `320496fe179611ea5e34e8bbf62a28317385e19a2c8038f304183a9dd5847692` |

## Frozen media inventory

All 42 references exist and are unique. Their total is **759,276 bytes**. The SHA-256 of the ordered UTF-8 manifest lines `filename,bytes,sha256\n`, in CNXML reference order, is `4cdc4664589876c8a48dd46ab58ff38d7cecf27c401ccacee103ad6eda744355`.

Every file is actually JPEG. Four references correctly declare `image/jpeg`: `009a`, `009b`, `008`, and `201`. The other 38 declare `image/png` despite `.jpg` names and JPEG bytes; see `EA2-C0296`.

Media directory prefix: `authority/source/media/`.

| Media ID | File | Bytes | Pixels | SHA-256 |
|---|---|---:|---:|---|
| `fs-id1167268248636` | `CNX_ElemAlg_Figure_02_06_009a_img_new.jpg` | 28,842 | 108x80 | `3e1cf27f927c24f21bffa426908a117eea2342b55e703174095d7a821074bf99` |
| `fs-id1167270930865` | `CNX_ElemAlg_Figure_02_06_009b_img_new.jpg` | 31,147 | 451x119 | `8d5d77a9be871cc98ca88d2eabf94a804b09b89f4831117a529c01ea797a8c77` |
| `fs-id1167267561348` | `CNX_ElemAlg_Figure_02_06_008_img_new.jpg` | 28,379 | 109x60 | `f302f640fad35dbadc5914f8b0529689ab5dd083fdf4dce0dcd638cf17ed9df2` |
| `eip-id1168463859550` | `CNX_ElemAlg_Figure_02_06_002a_img_new.jpg` | 16,219 | 139x33 | `3dc402c23f497a9d3897ccec731e3827a2af936e2d75cc3cdb68bc52ca8074de` |
| `eip-id1168463859564` | `CNX_ElemAlg_Figure_02_06_002f_img_new.jpg` | 18,353 | 139x32 | `2911ede713d3563278429054bf5623fff2f5b146a83adefdd11dd54f27aa9699` |
| `eip-id1168463859581` | `CNX_ElemAlg_Figure_02_06_002b_img_new.jpg` | 18,599 | 139x32 | `0c8a1bc66af41dd469d36ed00c8c1ce75f4b194aaf6b261935fca08e7180c95e` |
| `eip-id1168463859603` | `CNX_ElemAlg_Figure_02_06_002c_img_new.jpg` | 20,274 | 139x33 | `4b249e9b0b4334fa69fecdf41d67499f9582c74c3e166027577c0eb6414dd462` |
| `eip-id1168463819926` | `CNX_ElemAlg_Figure_02_06_002g_img_new.jpg` | 21,383 | 139x33 | `dacff66e4182cc5f925fccc1a34b3caf2a5a18c66470348fbea13a41db737e54` |
| `eip-id1168463819943` | `CNX_ElemAlg_Figure_02_06_002d_img_new.jpg` | 17,068 | 139x13 | `69e70f50a1234cde888168aebe05954f19b895a679bbfc08e5603b3bfe60341e` |
| `eip-id1168463819957` | `CNX_ElemAlg_Figure_02_06_002h_img_new.jpg` | 17,980 | 139x14 | `8cf187b4ec9095300e0f69337576bdb565ed645019c739eb2ec7935617323570` |
| `eip-id1168463819979` | `CNX_ElemAlg_Figure_02_06_002e_img_new.jpg` | 16,029 | 139x13 | `786f78f053d1c25a9017e8b2db7418971b8aa5a81775e75848870838228ab5d7` |
| `eip-id1168463819997` | `CNX_ElemAlg_Figure_02_06_002i_img_new.jpg` | 19,166 | 139x34 | `417e9d907cfcf72d452dd0b8d9ece8858d7c079f6fbd71bcdccab748fc978b1b` |
| `eip-id1168463857761` | `CNX_ElemAlg_Figure_02_06_003a_img_new.jpg` | 11,346 | 145x13 | `71da366434037ac903cb18c92270a9e359ca58f62e08961dc70841b015b696fc` |
| `eip-id1168463857775` | `CNX_ElemAlg_Figure_02_06_003g_img_new.jpg` | 13,909 | 145x13 | `1f13e4f8194f8d67fa8b28d5f7e9c1ce1ad5711d25fb034896774e062e5c2af2` |
| `eip-id1168463857792` | `CNX_ElemAlg_Figure_02_06_003b_img_new.jpg` | 15,917 | 145x15 | `9418413d0b48b807e9cb8be1e02892db98013b6d006a4c8ae6e959600620218f` |
| `eip-id1168463857814` | `CNX_ElemAlg_Figure_02_06_003c_img_new.jpg` | 15,518 | 145x15 | `f5420071cca983af78bf4a9f12c52f9b350a0f6e6dea1c1f63d6a925493c70e8` |
| `eip-id1168463857827` | `CNX_ElemAlg_Figure_02_06_003h_img_new.jpg` | 14,804 | 145x15 | `1981385365075a04904b35fa6bd6c642741a8ff44a78fe34d8d62ef5f04f35ea` |
| `eip-id1168463857850` | `CNX_ElemAlg_Figure_02_06_003d_img_new.jpg` | 22,968 | 145x34 | `070ebb1da3f6b1d36f7fa301b4d7487e2c791eb01b955687a1cd4d1d3e0f6865` |
| `eip-id1168463871108` | `CNX_ElemAlg_Figure_02_06_003i_img_new.jpg` | 18,423 | 145x33 | `cd29bd0e4a8674cdc8617c7cb6621de9c769b733a6688f4a08cbef4b809bc925` |
| `eip-id1168463871125` | `CNX_ElemAlg_Figure_02_06_003e_img_new.jpg` | 14,517 | 145x15 | `6d47065864a4d98e4b7558c86feefada4a081e18c0868c18b4a920a1785c654f` |
| `eip-id1168463871139` | `CNX_ElemAlg_Figure_02_06_003j_img_new.jpg` | 16,025 | 145x34 | `d94b6144fbe80f677788042491fec644f1a984334cd8d12ce2c92c9160cdbad2` |
| `eip-id1168463871156` | `CNX_ElemAlg_Figure_02_06_003f_img_new.jpg` | 14,646 | 145x15 | `580c7069905203cbfce5ebd16e2277becf97fdad75ab9130974e3818673351bc` |
| `eip-id1168463871169` | `CNX_ElemAlg_Figure_02_06_003k_img_new.jpg` | 16,401 | 145x35 | `8fa7d8226499afd70af96a50c6f01f37868fd5612bd62c50f16cbda5d0d9b50a` |
| `eip-id1168463876130` | `CNX_ElemAlg_Figure_02_06_004a_img_new.jpg` | 12,335 | 180x16 | `68605a5eaffafbea25a4e730bcd7b6f808738a3e3b1e6ab0529574c4237455df` |
| `eip-id1168463876143` | `CNX_ElemAlg_Figure_02_06_004f_img_new.jpg` | 14,499 | 180x17 | `3bd1c70f25484d52798b4b5bf06a0fc2dc7e8d57a4fdfec008a3d5526fdf498f` |
| `eip-id1168463876160` | `CNX_ElemAlg_Figure_02_06_004b_img_new.jpg` | 12,976 | 180x17 | `a40f73acd7b6bd18f629b628b5e63ad2043bf78494b30e5d30b36c7d1b1fd528` |
| `eip-id1168463876186` | `CNX_ElemAlg_Figure_02_06_004c_img_new.jpg` | 16,521 | 184x17 | `bfad228afbb503be18e4799e923af1570b27f6c06ec4b651e63caccfd32d0855` |
| `eip-id1168463876204` | `CNX_ElemAlg_Figure_02_06_004g_img_new.jpg` | 18,857 | 180x17 | `ab8ae8daa7a5a588c6b97542406d108bcf227c986d37262fb4da8ea3b1e1c7850` |
| `eip-id1168464075563` | `CNX_ElemAlg_Figure_02_06_004d_img_new.jpg` | 14,544 | 180x33 | `0a79bed115c971e86c03912965a91534c90c047d533f32a6dba08216e034944f` |
| `eip-id1168464075577` | `CNX_ElemAlg_Figure_02_06_004h_img_new.jpg` | 19,394 | 180x36 | `af7daf1cd555be72719ebd49ba9f5a509e1db841978fbf944cc5772732402e74` |
| `eip-id1168464075594` | `CNX_ElemAlg_Figure_02_06_004e_img_new.jpg` | 12,077 | 181x17 | `ad345e87db4bfa4e657af5dc7a35f7505e931c5c2fd80f9aaad735343ee35023` |
| `eip-id1168464075608` | `CNX_ElemAlg_Figure_02_06_004i_img_new.jpg` | 16,679 | 180x35 | `7fbed7fcdd98c164935a244430e12127ff8f3c45d4c8d30eceb3f229bc05ec12` |
| `eip-id1168463887724` | `CNX_ElemAlg_Figure_02_06_005a_img_new.jpg` | 12,572 | 204x14 | `241ba80f5ef2c7be22eb673649bb691fd65124218bfa93a68813fbb0c092eff5` |
| `eip-id1168463887754` | `CNX_ElemAlg_Figure_02_06_005b_img_new.jpg` | 16,507 | 204x14 | `01e43f6a55790a9771a361d8c81d0788b227c5abed377080901ccc509572a07b` |
| `eip-id1168463821116` | `CNX_ElemAlg_Figure_02_06_005c_img_new.jpg` | 13,049 | 204x14 | `14dc6140694e5ab74abc0b0730f15ad5ca6789515e896b8661bbb532abbbfa12` |
| `fs-id1169149103518` | `CNX_ElemAlg_Figure_02_06_005d_img_new.jpg` | 12,974 | 204x14 | `6223016f4522a299144b9daee936f2a17818fb5806de8117843b3cc60a62c29d` |
| `eip-id1168462677795` | `CNX_ElemAlg_Figure_02_06_007a_img_new.jpg` | 14,354 | 170x16 | `a0ed1bf1bd4e38da18ee374dc01cb6891d089d7a61e04ad9c870a46fe59364c9` |
| `eip-id1168462677823` | `CNX_ElemAlg_Figure_02_06_007b_img_new.jpg` | 18,394 | 170x16 | `26a224d987d3e4d1b39b56d27742c7ca4f40b232f26616a8e3e374ca6c8083aa` |
| `eip-id1168462677840` | `CNX_ElemAlg_Figure_02_06_007c_img_new.jpg` | 15,077 | 170x17 | `fcb798672d06f76957afa2bc34b48de47c13c499f49302f6b70594d8eaa7a2c5` |
| `eip-id1168462677858` | `CNX_ElemAlg_Figure_02_06_007d_img_new.jpg` | 18,827 | 170x36 | `2dd036e4c655fe0064a10ad21656a9d6194d650730ddb38f177b622c16144c97` |
| `eip-id1168462677875` | `CNX_ElemAlg_Figure_02_06_007e_img_new.jpg` | 17,034 | 170x36 | `15026c0c08a22f4237bc8feaa51bc89dffa1e23f30b79e2e71ad19a1e31ecae7` |
| `fs-id1168341956020` | `CNX_ElemAlg_Figure_02_06_201_img_new.jpg` | 54,693 | 658x102 | `05efdf0571eb562484bc9764aa133a5ed657a5a4cc20fd27e9c7ef203a7297d1` |

## Accessibility inventory and required derivative treatment

Positive source controls:

- all 42 `media` nodes have nonempty `alt`
- all eight tables have nonempty `aria-label`
- all five links have resolvable targets
- all IDs are unique

Risks and required treatment:

1. The `009a`, `009b`, and `201` rasters contain English instructional text. Rebuild them as localized semantic HTML/table content rather than shipping English pixels.
2. Thirty-eight tiny rasters encode mathematical steps. Recreate their exact equations as native MathML and preserve operation emphasis through both text and styling; red alone must never carry the instructional distinction.
3. Several table `aria-label` descriptions state conceptual column/row counts that conflict with the six- or three-column XML grids; `eip-id1168463888057` explicitly says seven rows although the table has six. Rebuild actual semantic tables with scoped headers instead of repeating a long prose aria-label plus child alts.
4. `fs-id1167271046130` says “Ray’s trip” although the learner is Rey.
5. `eip-id1168463871139` voices capital interest variable `I` as lowercase `l`, changing the formula nonvisually.
6. Money, percent, units, signs, and products have the MathML token defects recorded in `EA2-C0298` through `EA2-C0302`.
7. Circled part tokens `ⓐ`, `ⓑ`, and `ⓒ` must retain explicit whitespace and order. They must not be communicated by glyph shape or color alone.

## Source-defect disposition

The source remains frozen. Thirteen target-only corrections are proposed in `PROPOSED_CORRECTIONS.csv`, IDs `EA2-C0291` through `EA2-C0303`. No proposed row is admitted to the live ledger by this audit.

Audit conclusion: **ready for translation after applying the terminology/accessibility plan and the 13 target-only corrections; not a build or publication approval.**
