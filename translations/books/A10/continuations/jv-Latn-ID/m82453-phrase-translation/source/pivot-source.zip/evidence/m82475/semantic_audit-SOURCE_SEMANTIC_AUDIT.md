# m82475 source semantic audit

Status: **PASS — frozen source fully inventoried; post-build A17 addendum recorded; no source or live-control mutation**

Model provenance: OpenAI Codex gpt-5.6-sol, Ultra.

## Authority and collection position

- Module `m82475`, “Solve Mixture Applications,” is collection `col31130` ordinal 24.
- Frozen source: `authority/source/modules/m82475/index.cnxml` — 104,125 bytes — SHA-256 `a0914cc484f0ae4244cb0bd25bde40ce9e0a7ad959cc7cf9c22605ac0feac21f`.
- Collection: `authority/source/collections/elementary-algebra-2e.collection.xml` — 5,256 bytes — SHA-256 `5fdc03ab9e6ee7327be72f7e0a17c4d884e65f4a8081a0b2a06dbdb1392bda72`.
- The collection contains exactly 82 module references. `m82473` is ordinal 23, `m82475` is ordinal 24, `m82476` is ordinal 25, and no `m82474` reference exists.
- The three outbound readiness links close exactly: `m82458#fs-id1170655197222`, `m82467#fs-id1166503416066`, and `m82453#fs-id1170655207375`. Their exact target source identities are frozen in `SOURCE_INVENTORY_MANIFEST.json` and rechecked by `audit_m82475_source.py`.

## Structure and semantic surfaces

- 1,934 XML elements: 1,010 CNXML, 4 MDML, and 920 MathML.
- 560 ordered IDs, all nonempty and unique.
- Nine sections in the hierarchy: five top-level sections and four children under the untitled review wrapper `fs-id1168345388183`.
- 225 paragraphs, 22 notes, 25 lists, 67 items, 8 examples, 77 exercises, 77 problems, 52 solutions, 13 equations, 8 tables, and one glossary definition.
- 541 deterministic natural-language surfaces: 392 element texts, 101 mixed-content tails, and 48 accessibility/table attributes. By field: 392 `text`, 101 `tail`, 40 `alt`, 4 `aria-label`, and 4 `summary`.
- Translation partition: 241 surfaces in front matter plus top-level section 1; 178 in sections 2–3; 122 in sections 4–5 plus the trailing glossary.

The read-only extractor records every surface’s ordinal, element preorder index, Clark QName, exact element path, nearest owner ID, field, source line, exact source text, and source-text hash. It admits CNXML text, the duplicate MDML title, CNXML-parented tails, natural-language MathML `mtext`, and the three visible accessibility fields only. All other MathML and XML bytes remain protected.

## Mathematics and exercise audit

- 51 MathML roots and 920 MathML elements, including 26 `mtext` elements. Twenty-one `mtext` values contain natural language and belong to the translation surface; the other five are empty or symbolic separators and remain protected.
- All 77 problem relationships and all 52 solution relationships were inspected. The numeric answers are arithmetically consistent with their questions. One solution noun is wrong (`fruit punch` where the requested ingredient is `fruit juice`), and the Stacey worked check contains malformed visible MathML even though the subsequent arithmetic and final amounts are correct. Both are isolated in the correction packet.
- Independent candidate review exposed a separate source defect in accessibility surface `s00090`: the sentence maps the nickel value to `0.05d`, although the problem defines `d + 9` nickels and the same sentence's full equation uses `0.05(d + 9)`. This is correction `M82475-A17`, distinct from A01's `nickles` spelling repair, and is bound to `M82475_A17_MISSING_NICKEL_QUANTITY_CORRECTION_WITNESS.json`.
- One source `<space count="7"/>` occurs at line 313. Construction and reader logic must preserve and render it; it is not ordinary collapsible prose whitespace.
- Source formulas use decimal points and source-style dollar notation. Preserve those numeric lexemes unless an admitted correction explicitly changes them.

## Tables, accessibility, and media

- Eight CNXML tables contain 57 physical rows and 110 entries.
- Forty-eight visible accessibility surfaces were inspected against their owning prose, equations, tables, and all 40 raster assets.
- All 40 direct image relationships exist, are unique, open successfully, and total 3,575,495 bytes. Their per-file path, pixel dimensions, byte count, and SHA-256 are emitted by `audit_m82475_source.py --view media`.
- Every asset is physically JPEG. Twenty image elements correctly declare `image/jpeg`; twenty math-raster image elements declare `image/png` despite `.jpg` names and JPEG signatures. The grouped metadata defect is recorded as `M82475-A16`; asset bytes must not be converted or silently changed.
- Verified accessibility defects include a wrong sign, wrong variable case, wrong operator, false orientation, and one low-information equation alt. Exact target witnesses and raster hashes are in `PROPOSED_CORRECTION_WITNESSES.json`.

## Fixed source closures

- QName stream: `0fe79cb93c2fb27fc86b82508421a57ed7e07fec7a27de0b1789b599b7968e90`.
- Ordered-ID stream: `67b9d9b6a7ae121eb1add989aadad01242e9e859c6124a8d9ee982c6cc01decf`.
- Reference stream: `5d3a0d081bdc11e8a6d6764e51026629dc0bf5338f2e329d6fffabbc6c0faf56`.
- Text-surface stream: `dc87940dbcb9a2bb3a48abeb34f1f52f423ca1261299b74cfe3e2d2586c14296`.
- Math-root stream: `4325edb2161eaee32dec76d4a83108b43b48890f64f08448b80ecea65fa1f724`.
- Media relationship/hash stream: `a6805139956b2e5f2ea996e5886a1d4d2d6b2402f821ddeb910a6215e9e8e7b5`.

## Boundary

The authority source remains unchanged. The initial source-audit operation created no target CNXML, translation map, builder, ledger row, backend record, reader artifact, publication object, or upstream message. The later A17 addendum records independent candidate-review evidence only; it changes neither source nor live controls. Proposed terminology and corrections remain internal, unadmitted construction controls.
