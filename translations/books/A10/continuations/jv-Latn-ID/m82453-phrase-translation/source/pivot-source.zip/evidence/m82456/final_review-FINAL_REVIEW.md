# m82456 Final Admission Review

Boundary: `EA2-B0006-m82456`  
Reviewed: 2026-08-21  
Verdict: **PASS** (`P1=0`, `P2=0`, `P3=0`)

## Frozen identity

- Authority: 122,022 bytes; SHA-256
  `1d3b69d74603175eb3c8aae95319b14bee988a56345c67384c0090b29995ab33`.
- Indonesian target: 121,466 bytes; SHA-256
  `953b0ced9cf9b32eeef5894997d333973108f9c3240c8afdbd5ea4e3263b0101`.
- Machine audit: 1,693 bytes; SHA-256
  `079305a55d8cd4cc1fd7f9df1fce356d99b72dea90ec294e60b9949ecdbc2d94`.
- Target manifest: 102 bytes; SHA-256
  `fb2beeffb5e83204cb10030c3746d9bb6c37cde662bc32facd4b14c8b45e12d6`.
- Source semantic audit: 5,540 bytes; SHA-256
  `add3cf91a9d4fea30abdb41e1afe73cede6f925f57bbe9b4e85a3d858fd894d6`.
- Terminology/accessibility plan: 2,841 bytes; SHA-256
  `c2ad93e73e657dd006405648cf449d62cc3f24d2efe75981417e5e60b6fe2038`.

## Exact structural result

Source and target both contain 4,344 elements with identical ordered topology,
child vectors, and 740 unique IDs in the same sequence. All non-reader
attributes, 43 reference attributes, and five local target relationships are
exact. The 3,261 MathML elements preserve tags, attributes, and every protected
non-`mtext` token. The only MathML text changes are Indonesian reader-language
localizations. No structural or protected-content exception is required.

Cardinalities remain exact: 121 exercises, 121 problems, 80 supplied solutions,
13 worked examples, 10 tables, 19 media, and five links. All 19 unique authority
rasters exist, decode as JPEG, and total 1,030,026 bytes. Six inherited
`image/png` declarations still point to JPEG bytes and are explicitly recorded
as derivative-assembly debt rather than silently rewritten.

## Mathematics, language, and accessibility

Independent mathematical review checked all 121 problems, 80 supplied
solutions, and 13 worked examples. Fraction equivalence, signs, grouping,
reciprocal multiplication, cancellation, order of operations, phrase
translations, and application answers are correct. The target consistently
states the nonzero domain of reciprocals, excludes factor 1 from the
simplest-form condition, and preserves the original domains at all three
variable-cancellation examples.

Independent language review aligned all 422 reader-text units. Natural id-ID
terminology includes `pecahan`, `pembilang`, `penyebut`, `pecahan senilai`,
`sifat pecahan senilai`, `pecahan paling sederhana`, `kebalikan`, `pecahan
kompleks`, and `garis pecahan`. The final procedural wording uses
`menghilangkan faktor persekutuan`, avoiding a literal English calque. There is
no active English narrative, rejected terminology, mojibake, or replacement
character.

Exactly 29 reader-attribute values are localized: 19 alts, six ARIA labels, and
four summaries; all are nonempty. All 19 rasters and 10 table descriptions were
visually checked. Each of the seven retained English-labelled rasters is
explicitly identified as English, quotes the relevant visible wording, and
provides its Indonesian meaning. The known source descriptions with wrong
values, signs, reciprocal factors, variables, or diagram geometry are corrected
in the target and separately logged.

This admission does not claim a rendered reader build, full visual-page pass,
or publication. Those remain later book-level gates.
