# Portable review export

MANIFEST.json describes the actual members of this transformed review package. ORIGINAL-MANIFEST.json is historical source-package evidence, not a verifier for these changed bytes. It may refer to removed operational instructions.

Preserved original manifest SHA-256: 8192e0528c6eddff8798f60b5703edc02fef70d80b51625a00f1479140890e94

Private operational text was filtered/redacted by the export process. Existing translation/source/QA receipts retain their original identities; this member-hash repair does not rerun builds, certify translation quality or rebind historical QA to changed code. The containing repository's export manifest records original and exported archive hashes and transformations.
