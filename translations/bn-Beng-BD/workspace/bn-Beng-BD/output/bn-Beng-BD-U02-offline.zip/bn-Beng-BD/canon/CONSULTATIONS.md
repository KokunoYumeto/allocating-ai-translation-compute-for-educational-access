# Canon consultation record

References are a working usage canon, not a claim of national-standard certification. All ten reference HTML pages were downloaded with SHA-256 receipts; they are readable as UTF-8 text under ignored `downloads/bn-Beng-BD/canon`. There are 13 starting examples in `register.json`. Native HTML needs no OCR. Two discovered PDFs were not used: one could not be downloaded, and the other was not trusted from its snippet. Acquire and OCR any PDF before future reliance.

## U01 drafting, 2026-08-30

Consulted government-hosted Bangladesh teacher examples BD01–BD05 while drafting. Chose একক/দশক/শতক and স্থানীয় মান; used grouping and an oral/object-based diagnostic. Kept whole-number terminology provisional instead of importing an Indian Bengali textbook convention. A00's ১৩৮, ২১৫, ১৭৬ and ২৩৭ remain its mathematical examples, not copied local-reference exercises.

## U01 revision, 2026-08-30

Read BD02, BD06, BD07, BD09 and BD10 downloaded text; read the relevant ১২৩/১৩২ passage in BD08; previously read BD01–BD05 page text. BD02 distinguishes a digit's position from its multiplied value. Accordingly, source tables use স্থান for the column name and the companion explicitly asks for numeric স্থানীয় মান. BD06 uses অযুত/লক্ষ/নিযুত/কোটি; reserved these for the next unit. BD07 supports verbal explanation, but that does not make our diagnostic standardized. BD10 contains spelling errors; do not reproduce them.

## U01 final QA, 2026-08-30

Read BD02's 359 place-value passage and BD01's block-grouping lesson again against the actual companion and source tables. Retained the distinction between a column's name and the digit's numeric contribution; the 138/215 tables, D4 and P3 reflect it. No additional terminology changes were needed. During table QA, corrected two inaccurate English source aria-labels in the translated CNXML (D018); the rendered five-column tables and all mathematics are unchanged. The canon examples guide usage, not a claim that this kit has national or teacher approval.

## Required before each next build checkpoint

1. Read the relevant local example text and the matching OpenStax section.
2. Add a dated consultation entry naming actual references, affected anchors and any resulting change or reason for no change.
3. Run QA; record human-review limitations separately. A build script loading a register is not proof that an agent read it.

## Remaining reference work

Acquire NCTB primary textbook/teacher-guide pages when reachable; OCR before use. Extend the canon for operations, fractions and measurement as those units enter production. Do not delay the existing number-sense pilot while collecting an unlimited bibliography.

## U02A drafting and revision, 2026-08-30

Read BD04 (C07), BD06 (C09) and BD10 (C13) local text again before drafting larger place value. Acquired only new BD11 (113,202-byte native HTML), preserving all ten existing locked sources; read its local extracted text in full through the number-grouping explanation. C14/C15 support the first-three-then-two digit grouping rule and reading combined thousand/lakh groups. The expanded canon has 15 examples from 11 documents.

Applied this to U02A's separate companion: `5,278,194` equals `৫২,৭৮,১৯৪`; source three-digit international groups stay untouched. Use ordinary দশ হাজার before অযুত, and explain দশ লক্ষ/নিযুত rather than assume the term is familiar. Source periods are explained as তিন ঘরের দল, not claimed as a mandated local term. Inspected both original place-value chart images before translating their descriptions. The companion distinguishes no *additional* hundreds after removing thousand groups from the false claim that the whole number contains no full hundreds.

The source asks for “place value” but often answers with place names alone. Faithful questions clarify that requested position; the separate answer supplement computes all 15 numeric contributions as well. Large billion/trillion examples remain optional teacher/reference material. No native-teacher approval is implied by these consultations.

## U02B drafting/revision and numeric-name QA, 2026-08-30

Reused the BD11/C14-C15 naming/grouping passage while drafting. Added and read three short government Accessible Dictionary HTML pages: BD12's পঁয়ষট্টি (65), BD13's সাঁইত্রিশ (37), and BD14's ঊনত্রিশ/উনত্রিশ (29) and ঊনচল্লিশ/উনচল্লিশ (39). Chose consistent editorial forms, without claiming alternatives are numerically wrong. Canon now has 18 examples from 14 readable documents; the original 10-document set remains intact.

Applied the entries to 165/37/137/529/839 in the source and worked-answer supplement. Visually read source figures 013–015. Kept English s/and conventions explicitly English; retained the source's international grouping rather than silently replacing it with lakh/crore. The helper number_names.py independently parses the six complete source answer names and 14 companion answer names back to their expected integers. It is an editorial QA lexicon, not an official spelling authority. Reviewed the 2014/April source example and 365-day-year assumption; contextual notes are separate from the faithful source.

## U02C drafting/revision/QA, 2026-08-30

Kept BD11's distinction between domestic comma groups and spoken thousand/lakh groups in view while reversing names into digits. The local dictionary passages consulted for U02B remain the spelling witnesses; the new writing cases additionally pass independent numeric-name parsing. Inspected figures 016–018; figure 017 and the canonical solution jointly expose the original alt-text error 742 versus 073. Explicitly corrected the translated description and retained all original bytes. The companion has fewer new assessment items because it follows U02B's already complete diagnostic rather than pretending each adjacent section starts a new course.

## U02D drafting, revision and mathematical QA, 2026-08-30

Searched specifically for Bangladesh rounding usage; did not adopt Indian Bengali, Assamese or un-OCRed PDF search hits. Acquired the single small BD15 HTML witness and read its local extracted text, including the ROUND paragraph in context. C19 supports the lexical phrase আসন্ন মান, not a primary-grade curriculum or the accuracy of the page's unrelated software advice. The initial canon has now grown to 19 examples from 15 documents. Used the phrase with an immediate plain-language explanation: the nearest multiple of the named place.

Consulted the established C04/C07 position-versus-value distinction and C14 grouping rule during revision: ask for দশকের/শতকের/হাজারের স্থানে, not a digit's numeric contribution. Reviewed C19 against the drafted introduction and final practice wording; no claim of NCTB-approved terminology was added. All 23 original figures were visually read. Corrected two false place names in source descriptions and three false dot-color descriptions, retaining all original image/witness bytes. The companion explicitly labels this lesson's halfway-up convention and the historical 2013 example. Twelve worked tasks, eleven source answer cases and 31 displayed rounding results pass integer/distance checks; every source exercise has a worked supplement.

## U02E and full-module assembly, 2026-08-31

Read the actual BD02 local ৩৫৯/৫০/৩০০ passage and BD11 local grouping/naming passage again against the full practice key. Continue the established C01 block/group register; no need to acquire another reference for the same topic. Previously read BD12–BD15 spellings/rounding passages remain relevant to the 32 naming/writing cases and 30 practice rounding answers. The source answer key uses international grouping in Bengali digits explicitly, while the child lessons retain their separate Bangladesh grouping explanation. The full module glossary uses the same provisional whole-number/origin/coordinate terms as U01, not newly invented alternatives.

Inspected the six new figure references: the PNG version of chart 011, four block models and the six-row self-assessment chart. Expanded the last figure's text equivalent to include all six visible skills; the original short alt omits that detail. Retained source college-campus language in faithful prose but used a supportive teacher/peer next-step checklist in the separately authored companion. Checked all 58 practice answers (including the 29 absent in the source); original 29 solutions remain unchanged in structure. Whole-module title, objectives and seven glossary definitions are now translated and assembled, without claiming native-teacher or PDF validation.

## U02 reading-edition QA, 2026-08-31

Re-read BD11.txt lines 43–73, especially combined অযুত/হাজার and নিযুত/লক্ষ names and the rightmost-three/then-two comma rule, while reviewing the rendered larger-type child tables. Re-read BD15.txt lines 89–95 for আসন্ন মান in context. These support the established language choices only, not curriculum approval or universal halfway-up rounding. No fresh reference download was needed. Print-v3 pages 1–57 now visually checked; screen review continues in exact-hash records under output/pdf. Figure-text boundary spacing was fixed at rendering level, with source translation values unchanged.
