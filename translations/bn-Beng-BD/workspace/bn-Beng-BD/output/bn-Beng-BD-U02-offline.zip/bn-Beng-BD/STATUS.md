# Bangladesh Bangla production status

Updated: 2026-08-31. Branch: `codex/bn-beng-bd-numeracy-pilot`.
Entire assignment remains active: full 75-module A00 collection, selected foundational A10, AX-1 editions/QA and AX-3 Grades 2–5 companion across all assigned domains.

## Current boundary

One complete A00 source-translation draft: m81243, with 2,122 document elements, 628 original IDs, eight sections, 88 exercises, all 59 supplied solutions, title/objectives and seven glossary entries. All 47 source media references match inspected/retained originals. See `output/m81243/qa-receipt.json`.

Source/companion checkpoint committed as `03f58f3` (96 changed files); all 156 indexed language files matched working bytes. A separate math-capable merged font now covers approximation/checkbox glyphs without changing U01. The U02 compilation has 57 print and 83 screen pages; all 140 final-v3 page images passed visual inspection. Two fresh small-build cycles reproduced all 20 tracked output/source/U01 hashes exactly.

U01 plus U02A–E provide separate companions. U02A–D add 48 worked child tasks; U01 has 14. U02E separately supplies worked answers for all 58 final practice exercises, including 29 unanswered in the source. Source structure is never silently filled with new answers. Whole-module and section HTML builds pass structural/math checks and deterministic rebuilding.

The hash-gated U02 offline package includes 144 files and verifies 338 local HTML references, all member bytes and deterministic ZIP rebuilding. Its exact hash is in output/U02/package-receipt.json. Next: backfill m81241/m81242 and continue m81244 onward. Follow NEXT_UNIT.json. The PDF visual pass is not completed editorial/native-teacher/screen-reader workflow.

## Acquisition and canon

All required source corpora already acquired and locked: A00, A10 corrected v1.0.2 release, canonical OpenStax bundle and program AX-1/AX-3 authority snapshot. No repeated license/supply audit. Large corpora remain ignored; no current source deletion/replacement authorized.

Canon: 19 Bangladesh usage examples from 15 readable HTML witnesses, hash-verified with locally read extraction. Used at drafting, revision and QA. No un-OCRed PDF reference used. Government-hosted teacher/dictionary usage is not NCTB certification.

Storage pause was lifted by the coordinator after user-authorized cleanup. Most recent local check exceeded 11 GB free. This task deleted no files.

## Verified released increment

U01 committed as `fda5f78`: deterministic HTML/CNXML, 9-page print PDF, 13-page screen PDF, all 22 actual pages visually inspected, and verified offline ZIP. Its original package is a checkpoint snapshot, not a package of all current U02 work.

U01 HTML/CNXML hashes remain unchanged after renderer extensions. Updated canon receipts contain newer references than the earlier ZIP snapshot.

## Limits and persistence

Browser runtime failed before connection twice; no browser visual check is claimed. No Bangladesh teacher, screen-reader or real physical-print validation has occurred. PDFs are untagged; no PDF/UA claim. Bengali PDF copy/search text is unreliable because shaping yields private-use extraction codes. The semantic text gate checks HTML-to-flowable input before font encoding, not exact Unicode PDF extraction; HTML remains the semantic edition.

74 other A00 modules, selected A10, operations/fractions/measurement/pattern companion domains and their full workflows remain. Keep the approximately 3,000-character goal active, externalize decisions and verify compactions against source files, hashes and original user messages. No push/publication has occurred.
