# Bangladesh Bangla production checkpoint

Date: 2026-08-30. Branch: `codex/bn-beng-bd-numeracy-pilot`.
Scope: **U01 pilot, not the complete Grades 2–5 numeracy kit**. The durable goal remains active. Use Git history for the exact checkpoint commit; do not infer completion from this file or a compaction summary.

## Acquired and locked

- Complete shallow program catalog: 2,673 tracked physical files.
- Complete shallow A00 Indonesian source: 3,709 tracked physical files.
- A10 six-file wrapper plus corrected v1.0.2 source release; all 82 translated module hashes verified.
- Complete canonical OpenStax archive at `38cae454e644abf9f0a623e876994553881597c9`: 13,738 files, 956,565,492 uncompressed bytes; reconstructed Git tree matches the source authority.
- AX-1 and AX-3 specifications retained from the catalog authority snapshot, not invented separate repositories.
- Thirteen Bangladesh usage examples from ten acquired/readable HTML references, with drafting, revision and QA consultation records. No un-OCRed PDF used.

Full source corpora remain in ignored downloads, not the offline learner package. All required notices, exact locks and a canonical per-file manifest are retained.

## Translated

`m81243#fs-id1830385` and `m81243#fs-id2340048`, ending at `eip-id1168898089706`: 515 source elements, 87 IDs, six source exercises/solutions, ten original figures and translated text equivalents. There are 124 translated text/description slots and 97 unique strings. Two inaccurate source table aria-labels are explicitly corrected and logged; all mathematical values and structure remain unchanged.

Separate child-facing companion: four diagnostics, eight practice tasks and two exit tasks, with full worked answers and expanded explanations for source Try It exercises. Source digits/dollars and localized companion notation are clearly distinguished.

Outputs: offline HTML, 9-page print PDF and 13-page screen PDF, plus the offline ZIP. See machine-readable receipts for actual hashes and verification results. The ZIP contains an internal per-file manifest and no bulk reference corpora. Rebuilding it requires successful reproducibility and exact-hash visual receipts.

## Verification and limitations

Structural/math checks cover source IDs/MathML, all 14 companion answers, 32 arithmetic equalities, 42 internal links, all ten media identities, retained notice hashes, mapped future source anchors, and locked canon HTML plus independently re-extracted text. All 22 PDF pages were visually inspected. Reproducibility checks rebuild HTML/CNXML/font/PDFs twice; package checks compare every ZIP member and two in-memory ZIP builds.

No Bangladesh primary-teacher review, native-language sign-off, physical printing or screen-reader test has occurred. Browser runtime initialization failed before connection, so no visual browser test is claimed. PDFs are untagged and are not PDF/UA certified; HTML is the semantic edition. Text-equivalent figures are not a substitute for a future illustrated learner edition. Whole-number and number-line terminology remains marked provisional.

## Storage and next action

C: reached zero free bytes; all writes stopped. After coordinator-authorized archived-log cleanup, local checks confirmed space recovery and no empty Bangladesh files. No files were deleted by this task. Large downloads/copies/extractions remain paused; only small QA/checkpoint writes resumed.

Next: follow `NEXT_UNIT.json`, re-read original user instructions in coordinating task `[local-task-id]`, consult C07/C09/C13 and acquire readable Bangladesh lakh/crore naming evidence when storage permits. Continue from `m81243#fs-id1883656` (Identify the Place Value of a Digit). `module-map.json` records remaining place value, operations, fractions, measurement and patterns. A10 mapped material is not yet claimed translated. No push or publication has occurred.
