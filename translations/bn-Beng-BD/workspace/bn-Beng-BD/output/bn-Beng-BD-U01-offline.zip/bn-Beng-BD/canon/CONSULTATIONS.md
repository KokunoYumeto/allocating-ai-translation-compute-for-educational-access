# Canon consultation record

References are a working usage canon, not a claim of national-standard certification. All ten reference HTML pages were downloaded with SHA-256 receipts; they are readable as UTF-8 text under ignored `downloads/bn-Beng-BD/canon`. There are 13 starting examples in `register.json`. Native HTML needs no OCR. Two discovered PDFs were not used: one could not be downloaded, and the other was not trusted from its snippet. Acquire and OCR any PDF before future reliance.

## U01 drafting, 2026-08-30

Consulted government-hosted Bangladesh teacher examples BD01–BD05 while drafting. Chose একক/দশক/শতক and স্থানীয় মান; used grouping and an oral/object-based diagnostic. Kept whole-number terminology provisional instead of importing an Indian Bengali textbook convention. A00's ১৩৮, ২১৫, ১৭৬ and ২৩৭ remain its mathematical examples, not copied local-reference exercises.

## U01 revision, 2026-08-30

Read BD02, BD06, BD07, BD09 and BD10 downloaded text; read the relevant ১২৩/১৩২ passage in BD08; previously read BD01–BD05 page text. BD02 distinguishes a digit's position from its multiplied value. Accordingly, source tables use স্থান for the column name and the companion explicitly asks for numeric স্থানীয় মান. BD06 uses অযুত/লক্ষ/নিযুত/কোটি; reserved these for the next unit. BD07 supports verbal explanation, but that does not make our diagnostic standardized. BD10 contains spelling errors; do not reproduce them.

## U01 final QA, 2026-08-30

Read BD02's 359 place-value passage and BD01's block-grouping lesson again against the actual companion and source tables. Retained the distinction between a column's name and the digit's numeric contribution; the 138/215 tables, D4 and P3 reflect it. No additional terminology changes were needed. During table QA, corrected two inaccurate English source aria-labels in the translated CNXML (D018); the rendered five-column tables and all mathematics are unchanged. The canon examples guide usage, not a claim that this kit has national or teacher approval.

## Required before each next build checkpoint

1. Read the relevant local example text and the matching OpenStax section.
2. Add a dated consultation entry naming actual references, affected anchors and any resulting change or reason for no change.
3. Run QA; record human-review limitations separately. A build script loading a register is not proof that an agent read it.

## Remaining reference work

Acquire NCTB primary textbook/teacher-guide pages when reachable; OCR before use. Extend the canon for operations, fractions and measurement as those units enter production. Do not delay the existing number-sense pilot while collecting an unlimited bibliography.
