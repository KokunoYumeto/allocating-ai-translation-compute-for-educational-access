# Bangladesh Bangla numeracy — U01 pilot

Open `output/u01-number-sense.html` in a modern browser. The entire extracted folder must stay together so the local Bangla font remains available. No connection or server is required for the lesson; source-credit links open external sites only when selected.

This is an **AI-assisted draft**, not a finished Grades 2–5 kit, NCTB-approved resource, or Bangladesh teacher-reviewed publication. It is the rank-2 Bangladesh Bangla assignment (`bn-Beng-BD`), not Indian Bengali.

## What is translated

The first two complete sections of OpenStax Prealgebra 2e module `m81243`: `fs-id1830385` and `fs-id2340048`. The faithful CNXML preserves 515 elements, 87 IDs, all mathematical values and six source exercises/solutions. Its 124 translated text/description slots use 97 distinct strings, including two documented corrections to inaccurate source accessibility labels. Ten original figure files are retained; the HTML/PDF reading editions use translated text equivalents, not newly drawn diagrams.

The separate AX-3 companion, “সংখ্যা চিনি, স্থানীয় মান বুঝি,” supplies four diagnostic, eight practice and two exit tasks, all with worked answers. It uses Bangla digits, grouping objects and Bangladesh classroom language. The faithful extract retains source Western digits and US dollars. The external manipulative activity named by OpenStax is not bundled or counted as translated.

`output/pdf/u01-print.pdf` is a 12-point, 9-page A4 reading copy; `u01-screen.pdf` is a 16-point, 13-page version. Both embed a locally merged OFL Bangla/Latin font. They are untagged PDFs, not PDF/UA-conformant editions. Semantic HTML is the preferred accessibility source; actual screen-reader and teacher testing are still needed. PDF fractions are linearized as `a/b` and circled labels as `(a)/(b)`.

## Sources and usage canon

All assigned materials are acquired locally: complete shallow Indonesian program/A00 checkouts, the A10 wrapper plus corrected v1.0.2 full source release (82 module hashes verified), and the complete pinned OpenStax bundle. The canonical archive contains 13,738 files; its reconstructed Git tree matches `7907e4c81d43de1c3b6da173f0eb273c01dc5b55`. Exact URLs, commits and hashes are in `sources.lock.json`; large sources remain ignored under `downloads/bn-Beng-BD`.

The working Bangladesh usage canon has 13 examples from ten readable native HTML pages. See `canon/register.json`, download hashes and actual drafting/revision/QA consultations. These government-hosted teacher examples are usage evidence, not a claim of national certification. No inaccessible or un-OCRed PDF is counted. Whole-number, number-line and several later-unit terms remain explicitly provisional in `terminology.json`.

## Rebuild and check

Run from the repository root with Python 3.12. `build.py` and `qa.py` use the standard library. QA also requires the locked local source checkouts and raw canon files.

```powershell
python -B bn-Beng-BD/tools/build.py
python -B bn-Beng-BD/tools/qa.py
python -B bn-Beng-BD/tools/build_font.py
python -B bn-Beng-BD/tools/build_pdf.py
python -B bn-Beng-BD/tools/qa_pdf.py
python -B bn-Beng-BD/tools/check_reproducibility.py
python -B bn-Beng-BD/tools/package.py
```

For font/PDF commands, install the exact dependencies from `requirements-pdf.txt` in your environment. In this worktree they already exist in the bundled Python runtime plus ignored `vendor/bn-Beng-BD/python`; no installation is needed to read the outputs. The package builder verifies every archive member's hash, local HTML resources and byte-identical ZIP rebuilding. It refuses stale visual QA receipts.

The offline ZIP is a reading/review package; the build scripts and large-source verification manifest live in the repository checkout, not that ZIP. If rebuilt PDFs change, inspect all their pages and update the exact-hash visual receipt before repackaging. The existing canon text hashes use UTF-8 with normalized LF line endings; QA also re-extracts each locked HTML witness and requires identical text.

`prepare.py` regenerates small source witnesses and preserves completed verification records. `verify_sources.py` performs the full canonical archive/tree check. `acquire_sources.py` is an explicit future recovery tool, not part of an ordinary build; do not run new bulk acquisition while storage is constrained. Canon download receipts lock the consulted versions; do not silently replace them with later dynamic pages.

## Provenance and limits

Based on OpenStax Prealgebra 2e by Lynn Marecek and MaryAnne Anthony-Smith; copyright Rice University. Indonesian edition: KokunoYumeto project. Bangladesh translation, companion and expanded answers: Language Allocation project, AI-assisted, 2026-08-30. Preserved original credits, notices and source model provenance are in `provenance/notices`.

Source and derivative: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/), subject to component-specific notices. Noto-derived fonts: SIL OFL 1.1, with modification notice in `assets/font-receipt.json`. Supplied as-is; OpenStax/Rice names, logos and marks are not licensed or an endorsement. The reference canon is not redistributed as a textbook or relicensed. Materials are translation inputs, never a training/fine-tuning dataset.

Resume instructions and decisions are in `GOAL.md`, `DECISIONS.md`, `STATUS.md` and `NEXT_UNIT.json`. Next contiguous source: `m81243#fs-id1883656`. Operations, fractions, measurement and patterns remain planned; `module-map.json` distinguishes acquired, mapped and translated material. No publication or remote push has occurred.
