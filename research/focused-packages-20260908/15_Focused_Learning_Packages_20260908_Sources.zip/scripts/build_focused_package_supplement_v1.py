"""Readable supplement; no remote writes or mutation of prior publications."""
from pathlib import Path
import hashlib
import html
import json
import re
import zipfile
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'publication/focused_package_supplement_20260908'
PDF='13_Focused_Learning_Packages_20260908.pdf'
HTML='14_Focused_Learning_Packages_20260908.html'
ZIP='15_Focused_Learning_Packages_20260908_Sources.zip'
META='16_Focused_Learning_Packages_20260908_Metadata.json'

def sha(b): return hashlib.sha256(b).hexdigest().upper()
def info(rel):
    b=(ROOT/rel).read_bytes()
    return {'path':rel,'bytes':len(b),'sha256':sha(b)}
def inline(s,web=False):
    s=html.escape(s)
    s=re.sub(r'(https://[^\s]+)',lambda m:'<a href="'+m[1]+'">'+m[1]+'</a>',s)
    return re.sub(r'`([^`]+)`',r'<code>\1</code>' if web else r'<font name="Courier">\1</font>',s)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    text=(ROOT/'FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.md').read_text(encoding='utf-8')
    data=json.loads((ROOT/'structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json').read_text(encoding='utf-8'))
    table=(ROOT/'FOCUSED_PACKAGE_ALLOWANCE_TABLE_v1.md').read_text(encoding='utf-8').strip()
    assert table in text and '{{' not in text
    assert data['candidate_count_preserved']==775 and len(data['cells'])==30
    audit=(ROOT/'qa/FOCUSED_PACKAGE_ALLOWANCE_INDEPENDENT_AUDIT_20260908.md').read_text(encoding='utf-8')
    assert '30' in audit and '46,319' in audit
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='StudyTitle',fontName='Helvetica-Bold',fontSize=23,leading=27,spaceAfter=12,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='StudyBody',fontName='Helvetica',fontSize=10.5,leading=14.5,spaceAfter=8))
    styles.add(ParagraphStyle(name='StudyHead',fontName='Helvetica-Bold',fontSize=14,leading=18,spaceBefore=12,spaceAfter=7,keepWithNext=True,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='StudyCell',fontName='Helvetica',fontSize=8.8,leading=11.5,spaceAfter=0))
    lines=text.splitlines(); flow=[]; web=[]; i=0
    while i<len(lines):
        s=lines[i].strip()
        if not s: i+=1; continue
        if s.startswith('# '):
            flow.append(Paragraph(inline(s[2:]),styles['StudyTitle']))
            flow.append(Paragraph('Research supplement | 8 September 2026 | Ongoing, non-exhaustive study',styles['StudyBody']))
            web += ['<h1>'+html.escape(s[2:])+'</h1>','<p>Research supplement | 8 September 2026 | Ongoing, non-exhaustive study</p>']
        elif s.startswith('## '):
            flow.append(Paragraph(inline(s[3:]),styles['StudyHead']))
            web.append('<h2>'+html.escape(s[3:])+'</h2>')
        elif s.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch('[-:]+',x) for x in cells): rows.append(cells)
                i+=1
            t=Table([[Paragraph(inline(c),styles['StudyCell']) for c in row] for row in rows],colWidths=[105,88,83,111,112],repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e3edf0')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOX',(0,0),(-1,-1),.4,colors.HexColor('#8ca4b0')),('INNERGRID',(0,0),(-1,-1),.3,colors.HexColor('#bbccd3')),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            flow += [t,Spacer(1,10)]
            web.append('<div class="scroll"><table><thead><tr>'+''.join('<th scope="col">'+html.escape(c)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(c)+'</td>' for c in row)+'</tr>' for row in rows[1:])+'</tbody></table></div>')
            continue
        else:
            para=[s]
            while i+1<len(lines) and lines[i+1].strip() and not lines[i+1].startswith(('#','|')):
                i+=1; para.append(lines[i].strip())
            s=' '.join(para); flow.append(Paragraph(inline(s),styles['StudyBody'])); web.append('<p>'+inline(s,True)+'</p>')
        i+=1
    def footer(c,d):
        c.saveState();c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#49626e'))
        c.drawString(48,28,'Focused learning packages | Educational access research')
        c.drawRightString(547,28,str(d.page));c.restoreState()
    SimpleDocTemplate(str(OUT/PDF),pagesize=(595,842),leftMargin=48,rightMargin=48,topMargin=43,bottomMargin=48,title='Focused learning packages or complete textbooks?',author='').build(flow,onFirstPage=footer,onLaterPages=footer)
    body='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Focused learning packages or complete textbooks?</title><style>body{font:18px/1.65 system-ui,sans-serif;color:#182d38;max-width:850px;margin:auto;padding:2rem 1rem}h1,h2{line-height:1.2;color:#173b4c}h1{font-size:2.2rem}a{color:#075581;overflow-wrap:anywhere}code{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:.88rem}td,th{padding:.6rem;border:1px solid #b3c5cc;text-align:left;vertical-align:top}th{background:#e3edf0}.scroll{overflow-x:auto}nav{padding:.7rem;background:#edf4f6}@media print{nav{display:none}body{font-size:11pt}}</style></head><body><nav><a href="'+PDF+'">Download this PDF</a> | <a href="https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/">Full research programme</a> | <a href="'+ZIP+'">Sources and calculation</a></nav><main>'+''.join(web)+'</main></body></html>'
    (OUT/HTML).write_text(body,encoding='utf-8')
    reader=PdfReader(OUT/PDF); extracted='\n'.join(p.extract_text() for p in reader.pages)
    for value in ['33.65%','20.94%','1,047','696','351','87,655','1.646','1.210','775']:
        assert value in extracted and value in body,value
    assert '\ufffd' not in extracted and '\u25a0' not in extracted
    sources=[
        'FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.md','FOCUSED_PACKAGE_ALLOWANCE_TABLE_v1.md',
        'structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json','structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json',
        'structured/OPENSTAX_PACKAGE_SCALE_20260904.json','structured/GLOBAL_BUDGET_SCENARIOS_v1.json',
        'sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip',
        'qa/FOCUSED_PACKAGE_WORK_ALLOWANCE_QA_v1.json','qa/FOCUSED_PACKAGE_ALLOWANCE_INDEPENDENT_AUDIT_20260908.md',
        'scripts/build_focused_package_allowance_v1.py','scripts/build_focused_package_supplement_v1.py']
    entries=[info(rel) for rel in sources]
    with zipfile.ZipFile(OUT/ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for e in entries:
            assert not any(s in e['path'] for s in ['RAW_','STATE','TRANSCRIPT'])
            z.write(ROOT/e['path'],e['path'])
        z.writestr('SOURCE_MANIFEST.json',json.dumps(entries,indent=2)+'\n')
        z.writestr('REPRODUCE_AND_LICENSING.md','# Reproduce\n\nRun scripts/build_focused_package_allowance_v1.py with Python standard library; then scripts/build_focused_package_supplement_v1.py with reportlab and pypdf. No account or credentials required. Preserve relative paths. The first script verifies pinned inputs, recounts source structure, and recomputes exact conditional arithmetic. It uses existing source tokenization measurements, not new physical-compute measurements. The independent audit is evidence, not regenerated by the builder.\n\nOriginal analysis and presentation: CC BY 4.0. Third-party OpenStax source retained in sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip is CC BY-NC-SA 4.0, with its original licence and credits. That licence is not replaced by the analysis licence. Primary research papers are cited, not redistributed.\n')
    with zipfile.ZipFile(OUT/ZIP) as z:
        assert z.testzip() is None and len(z.namelist())==len(entries)+2
        for e in entries: assert sha(z.read(e['path']))==e['sha256']
    meta={'schema':'focused-learning-packages-supplement/1.0','date':'2026-09-08','status':'BUILT_VISUAL_QA_PENDING','pdf_pages':len(reader.pages),'source_units':len(entries),'archive_entries':len(entries)+2,'scope':'Conditional package-allocation results, structural source inventory and four-primary-study synthesis; ongoing global research, not final worldwide ranking.','public_formats':['PDF','HTML','source ZIP','metadata JSON'],'full_goal_complete':False,'source_manifest':entries,'files':[{'name':n,'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in [PDF,HTML,ZIP]],'prior_publications_replaced':[],'language_eligibility_reduced':False}
    (OUT/META).write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'pdf_pages':len(reader.pages),'source_units':len(entries),'output':str(OUT),'status':meta['status']}))

if __name__=='__main__': main()
