"""Render the bounded bridge-allocation result without replacing the main paper."""
from pathlib import Path
import hashlib, html, json, re, zipfile
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'publication/shared_editions_supplement_20260908'
STEM='Shared_Editions_Budget_Study_20260908'
PDF='09_'+STEM+'.pdf'; HTML='10_'+STEM+'.html'
ZIP='11_'+STEM+'_Sources.zip'; META='12_'+STEM+'_Metadata.json'

def sha(b): return hashlib.sha256(b).hexdigest().upper()
def info(p):
    b=p.read_bytes()
    return {'name':p.name,'bytes':len(b),'sha256':sha(b)}

def inline(s):
    return re.sub(r'`([^`]+)`',r'<font name="Courier">\1</font>',html.escape(s))

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    source=ROOT/'HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.md'
    text=source.read_text(encoding='utf-8')
    data=json.loads((ROOT/'structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json').read_text(encoding='utf-8'))
    assert data['all_source_rows']==775 and data['numeric_native_rows']==750
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='TitleStudy',fontName='Helvetica-Bold',fontSize=22,leading=26,spaceAfter=16,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='BodyStudy',fontName='Helvetica',fontSize=10.5,leading=14.5,spaceAfter=9))
    styles.add(ParagraphStyle(name='HeadStudy',fontName='Helvetica-Bold',fontSize=14,leading=18,spaceBefore=13,spaceAfter=7,keepWithNext=True,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='CellStudy',fontName='Helvetica',fontSize=8.3,leading=11,spaceAfter=0))
    flow=[]; web=[]; lines=text.splitlines(); i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line: i+=1; continue
        if line.startswith('# '):
            title=line[2:]; flow.append(Paragraph(inline(title),styles['TitleStudy']))
            flow.append(Paragraph('Research supplement | 8 September 2026 | Ongoing, non-exhaustive study',styles['BodyStudy']))
            web += ['<h1>'+html.escape(title)+'</h1>','<p class="status">Research supplement · 8 September 2026 · Ongoing, non-exhaustive study</p>']
        elif line.startswith('## '):
            flow.append(Paragraph(inline(line[3:]),styles['HeadStudy'])); web.append('<h2>'+html.escape(line[3:])+'</h2>')
        elif line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-:]+',c) for c in cells): rows.append(cells)
                i+=1
            t=Table([[Paragraph(inline(c),styles['CellStudy']) for c in row] for row in rows],colWidths=[128,76,83,83,83],repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e3edf0')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOX',(0,0),(-1,-1),.4,colors.HexColor('#9bb0b8')),('INNERGRID',(0,0),(-1,-1),.3,colors.HexColor('#c9d5da')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            flow += [t,Spacer(1,12)]
            web.append('<div class="scroll"><table><thead><tr>'+''.join('<th scope="col">'+html.escape(c)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(c)+'</td>' for c in row)+'</tr>' for row in rows[1:])+'</tbody></table></div>')
            continue
        else:
            paragraph=[line]
            while i+1<len(lines) and lines[i+1].strip() and not lines[i+1].startswith(('#','|')):
                i+=1; paragraph.append(lines[i].strip())
            p=' '.join(paragraph)
            flow.append(Paragraph(inline(p),styles['BodyStudy']))
            web.append('<p>'+re.sub(r'`([^`]+)`',r'<code>\1</code>',html.escape(p))+'</p>')
        i+=1
    ref_title='Source and reuse'
    refs=[
      ('Main living working paper, v0.8','https://doi.org/10.5281/zenodo.22650495','The parent publication contains the worldwide screening inputs, production assumptions, language profiles and direct educational-effect literature. This supplement adds a conditional allocation calculation, not new empirical audience or learning measurements.'),
      ('Research catalogue and current ranked comparisons','https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/rankings/','All existing comparisons remain available. Exact input filenames, source hashes, selected portfolios, solver bounds and the independent audits are included in the accompanying source archive.')]
    flow.append(Paragraph(ref_title,styles['HeadStudy'])); web.append('<h2>'+ref_title+'</h2>')
    for title,url,description in refs:
        p='<a href="'+url+'" color="#174f70">'+html.escape(title)+'</a>. '+html.escape(description)
        flow.append(Paragraph(p,styles['BodyStudy'])); web.append('<p><a href="'+url+'">'+title+'</a>. '+description+'</p>')
    notice='Original analysis and presentation: CC BY 4.0, credited to KokunoYumeto. Third-party sources retain their own credits and terms. The complete worldwide research goal remains unfinished.'
    flow.append(Paragraph(notice,styles['BodyStudy'])); web.append('<p>'+notice+'</p>')
    def footer(c,d):
        c.saveState(); c.setFont('Helvetica',8); c.setFillColor(colors.HexColor('#4c6370'))
        c.drawString(48,29,'Shared editions and educational access | Research supplement')
        c.drawRightString(547,29,str(d.page)); c.restoreState()
    SimpleDocTemplate(str(OUT/PDF),pagesize=(595,842),rightMargin=48,leftMargin=48,topMargin=44,bottomMargin=49,title='Shared editions and educational access: Hindi-Urdu budget comparison',author='KokunoYumeto').build(flow,onFirstPage=footer,onLaterPages=footer)
    html_doc='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shared editions and educational access</title><style>body{font:18px/1.6 system-ui,sans-serif;color:#182d38;margin:0 auto;padding:2rem 1rem;max-width:850px}h1,h2{line-height:1.2;color:#173b4c}h1{font-size:2.1rem}.status{color:#415d69}a{color:#075581}table{border-collapse:collapse;width:100%;font-size:.88rem}th,td{border:1px solid #b3c5cc;padding:.55rem;text-align:left;vertical-align:top}th{background:#e3edf0}.scroll{overflow-x:auto}code{overflow-wrap:anywhere}nav{padding:.7rem;background:#edf4f6} @media print{nav{display:none}body{font-size:11pt}}</style></head><body><nav><a href="'+PDF+'">Download this PDF</a> · <a href="https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/">Full research programme</a> · <a href="'+ZIP+'">Sources and calculation</a></nav><main>'+''.join(web)+'</main></body></html>'
    (OUT/HTML).write_text(html_doc,encoding='utf-8')
    reader=PdfReader(OUT/PDF); extracted='\n'.join(p.extract_text() for p in reader.pages)
    for value in ['78.29%','120.54%','87.41%','142,848,211','626,560,499','280,449,183']:
        assert value in extracted and value in html_doc,value
    assert 2<=len(reader.pages)<=7
    assert '\ufffd' not in extracted
    assert all(len(p.extract_text())>100 for p in reader.pages)
    sources={b['path'] for b in data['source_bindings']}
    sources.update(['structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json','qa/HINDI_URDU_BUDGET_ENTRY_FRONTIER_QA_v1.json','HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.md','scripts/build_hindi_urdu_budget_entry_frontier_v1.py','scripts/build_shared_editions_supplement_v1.py','qa/HINDI_URDU_FORMULA_INDEPENDENT_AUDIT_20260908.md','qa/HINDI_URDU_FRONTIER_RESULT_INDEPENDENT_AUDIT_20260908.md'])
    entries=[]
    for rel in sorted(sources):
        p=ROOT/rel; b=p.read_bytes()
        assert 'RAW_' not in rel and 'STATE' not in rel
        entries.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
    with zipfile.ZipFile(OUT/ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for e in entries: z.write(ROOT/e['path'],e['path'])
        z.writestr('REPRODUCE.md','# Reproduce this study\n\nRun scripts/build_hindi_urdu_budget_entry_frontier_v1.py with Python, NumPy and SciPy. The recorded run used Python 3.13.9, NumPy 2.4.4 and SciPy 1.17.1, one numerical worker and at most 15 seconds per solve. Run scripts/build_shared_editions_supplement_v1.py with reportlab and pypdf to build the PDF/HTML. Preserve source-relative paths. The study uses supplied dimensionless cost scenarios and inherited screening coefficients, not observed learning effects. No credentials or account access are required.\n')
        z.writestr('SOURCE_MANIFEST.json',json.dumps(entries,indent=2)+'\n')
    with zipfile.ZipFile(OUT/ZIP) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(entries)+2
        for e in entries: assert sha(z.read(e['path']))==e['sha256']
    m={'schema':'shared-editions-supplement/1.0','date':'2026-09-08','status':'BUILT_VISUAL_QA_PENDING','scope':'Conditional Hindi-Urdu bridge versus best affordable native-edition mix; four declared cost decompositions, twenty bounded optimizations. Main global paper and candidate eligibility unchanged.','main_paper_doi':'10.5281/zenodo.22650495','pdf_pages':len(reader.pages),'source_units':len(entries),'source_zip_entries':len(entries)+2,'files':[info(OUT/n) for n in (PDF,HTML,ZIP)],'source_files':entries,'full_goal_complete':False,'does_not_supersede':'The 121-page v0.8 working paper and its worldwide comparisons remain unchanged.'}
    (OUT/META).write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':m['status'],'pdf_pages':m['pdf_pages'],'source_units':len(entries),'files':m['files']}))

if __name__=='__main__': main()
