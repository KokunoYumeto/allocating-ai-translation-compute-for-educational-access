# Reproduce this study

Run scripts/build_hindi_urdu_budget_entry_frontier_v1.py with Python, NumPy and SciPy. The recorded run used Python 3.13.9, NumPy 2.4.4 and SciPy 1.17.1, one numerical worker and at most 15 seconds per solve. Run scripts/build_shared_editions_supplement_v1.py with reportlab and pypdf to build the PDF/HTML. Preserve source-relative paths. The study uses supplied dimensionless cost scenarios and inherited screening coefficients, not observed learning effects. No credentials or account access are required.
