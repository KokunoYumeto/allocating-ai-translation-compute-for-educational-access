"""Independent bounded audit; never imports or executes the producer.

Each scenario enumerates full-package bitmasks and every disjoint companion
submask. Fractions derive units from the declared formulas; inner arithmetic
is integer-only. The only written artifact is the named independent review.
"""
from fractions import Fraction
from math import isclose, lcm
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PORTFOLIO = "structured/SECONDARY_PACKAGE_PORTFOLIO_v1.json"
FRONTIER = "structured/TARGET_SPECIFIC_ALLOCATION_FRONTIER_v1.json"
SCALE = "structured/OPENSTAX_PACKAGE_SCALE_20260904.json"
PRODUCER = "scripts/build_secondary_package_portfolio_v1.py"
REVIEWER = "scripts/check_secondary_package_portfolio_v1.py"
OUTPUT = "qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v1.json"
CHECKS = []


def check(label, condition):
    if not condition:
        raise AssertionError(label)
    CHECKS.append(label)


def binding(name):
    raw = (ROOT / name).read_bytes()
    return {"path": name, "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest().upper()}


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def exact(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def mask_sums(values):
    result = [0] * (1 << len(values))
    for mask in range(1, len(result)):
        bit = mask & -mask
        result[mask] = result[mask ^ bit] + values[bit.bit_length() - 1]
    return result


def choices(full_mask, companion_mask, count):
    return tuple(2 if full_mask & (1 << i) else
                 1 if companion_mask & (1 << i) else 0
                 for i in range(count))


def main():
    original_bindings = [binding(p) for p in (PORTFOLIO, FRONTIER, SCALE, PRODUCER)]
    portfolio, frontier, scale = load(PORTFOLIO), load(FRONTIER), load(SCALE)
    for item in portfolio["source_bindings"]:
        check("source_binding:" + item["path"], binding(item["path"]) == item)
    rows = [r for r in frontier["rows"] if r["package_id"] == "Q-CATCHUP"]
    check("nine_unique_source_rows", len(rows) == len({r["route_id"] for r in rows}) == 9)
    check("reference_rows_exact_no_need_deduction", rows == portfolio["reference_rows"])
    check("same_endpoint_stage_and_comparison_set", len({
        (r["endpoint_id"], r["stage"], r["comparison_set_id"]) for r in rows}) == 1)
    other = [r["route_id"] for r in frontier["rows"] if r["package_id"] != "Q-CATCHUP"]
    check("six_other_routes_retained", len(other) == 6 and
          other == portfolio["other_numeric_routes_retained"])
    check("common_100k_workload_basis", all(
        r["workload_proxy_row_id"].startswith("COMMON100K:") and
        r["workload_unit"] == "fresh_equivalent_token_events" for r in rows))
    check("need_values_are_positive_context_estimates", all(
        Fraction(r["need_context_base"]) > 0 and
        r["need_endpoint_or_measure"] == "represented_below_level2_students_estimate"
        for r in rows))

    short = scale["candidates"]["selected_quantitative_units_scenario"]
    full = scale["candidates"]["complete_source_collection"]
    modules = {m["module_id"]: m for m in scale["modules"]}
    check("unique_source_module_inventory", len(modules) == len(scale["modules"]))
    check("strict_source_subset", set(short["module_ids"]) < set(full["module_ids"]))
    for label, package in (("companion", short), ("complete", full)):
        ids = package["module_ids"]
        check(label + "_unique_modules", len(ids) == len(set(ids)) == package["module_count"])
        check(label + "_source_bytes_sum", sum(modules[m]["bytes"] for m in ids) == package["source_bytes"])
        for tokenizer in ("cl100k_base", "o200k_base"):
            for representation in ("content_text", "whole_cnxml"):
                check(label + "_token_sum:" + tokenizer + ":" + representation,
                      sum(modules[m]["tokens"][tokenizer][representation] for m in ids)
                      == package["tokens"][tokenizer][representation])
    chapters = [c for c in scale["chapters"] if c["chapter"] in short["selected_chapters"]]
    check("six_chapters_match_companion_modules", len(chapters) == 6 and
          [m for c in chapters for m in c["module_ids"]] == short["module_ids"])
    short_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in short["module_ids"])
    full_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in full["module_ids"])
    check("expected_source_token_counts", (short_tokens, full_tokens) == (173958, 364270))
    check("package_metadata", portfolio["packages"] == {
        "companion_source_tokens": short_tokens, "complete_source_tokens": full_tokens,
        "companion_extra_full_work_share": 0.05, "selected_chapters": short["selected_chapters"]})

    # Start from workload per 100,000 source tokens; no producer scale constants.
    workloads = [Fraction(r["workload_base_fecu"]) for r in rows]
    needs = [Fraction(r["need_context_base"]) for r in rows]
    full_cost = [w * Fraction(full_tokens, 100000) for w in workloads]
    companion_cost = [w * Fraction(short_tokens, 100000) + fc * Fraction(1, 20)
                      for w, fc in zip(workloads, full_cost)]
    cost_den = lcm(*(c.denominator for c in full_cost + companion_cost))
    full_sums = mask_sums([int(c * cost_den) for c in full_cost])
    companion_sums = mask_sums([int(c * cost_den) for c in companion_cost])
    ratios = (Fraction(1, 2), Fraction(3, 4), Fraction(1))
    expected_keys = {(ratio, setup, budget) for ratio in ratios for setup in (0, 2)
                     for budget in (2000000, 5000000, 10000000, 20000000)}
    reported = {(Fraction(str(s["companion_relative_benefit"])), s["setup_rate"], s["budget"]): s
                for s in portfolio["scenarios"]}
    check("exact_24_scenario_grid", len(portfolio["scenarios"]) == len(reported) == 24
          and set(reported) == expected_keys)
    results = []
    count = len(rows)
    all_mask = (1 << count) - 1
    total_evaluations = 0
    for ratio, setup, budget in sorted(expected_keys):
        benefit_den = lcm(*(v.denominator for v in needs + [n * ratio for n in needs]))
        full_benefit = mask_sums([int(n * benefit_den) for n in needs])
        companion_benefit = mask_sums([int(n * ratio * benefit_den) for n in needs])
        best = None
        uniform = {"companion": None, "complete": None}
        evaluations = feasible = 0
        for full_mask in range(all_mask + 1):
            available = all_mask ^ full_mask
            companion_mask = available
            while True:
                evaluations += 1
                # A full source includes every companion module. With no full
                # package, the same companion source is prepared once, not once per route.
                union_tokens = full_tokens if full_mask else short_tokens if companion_mask else 0
                cost = full_sums[full_mask] + companion_sums[companion_mask] + setup * union_tokens * cost_den
                if cost <= budget * cost_den:
                    feasible += 1
                    benefit = full_benefit[full_mask] + companion_benefit[companion_mask]
                    selection = choices(full_mask, companion_mask, count)
                    candidate = (benefit, -cost, tuple(-k for k in selection), union_tokens, selection)
                    if best is None or candidate[:3] > best[:3]:
                        best = candidate
                    for label, included in (("companion", not full_mask), ("complete", not companion_mask)):
                        if included and (uniform[label] is None or candidate[:2] > uniform[label][:2]):
                            uniform[label] = candidate
                if not companion_mask:
                    break
                companion_mask = (companion_mask - 1) & available
        total_evaluations += evaluations
        expected = reported[(ratio, setup, budget)]
        prefix = expected["id"] + ":"
        check(prefix + "enumerated_all_selections", evaluations == 3 ** count == 19683)
        check(prefix + "correct_id", expected["id"] == f"q{int(ratio * 4)}/4_setup{setup}_B{budget}")
        selection = [{"route_id": r["route_id"], "language": r["language_profile"],
                      "package": "companion" if k == 1 else "complete"}
                     for r, k in zip(rows, best[4]) if k]
        benefit = Fraction(best[0], benefit_den)
        cost = Fraction(-best[1], cost_den)
        check(prefix + "optimal_selection", selection == expected["selection"])
        check(prefix + "optimal_exact_cost", cost == Fraction(**expected["cost_exact"]))
        check(prefix + "optimal_exact_benefit", benefit == Fraction(**expected["coefficient_exact"]))
        check(prefix + "cost_float_projection", float(cost) == expected["cost"])
        check(prefix + "benefit_float_projection", float(benefit) == expected["relative_context_benefit_coefficient"])
        check(prefix + "shared_source_union", best[3] == expected["source_union_tokens"])
        comparator_evidence = []
        check(prefix + "two_uniform_comparators", len(expected["uniform_comparators"]) == 2 and
              {u["package"] for u in expected["uniform_comparators"]} == set(uniform))
        for u in expected["uniform_comparators"]:
            independent = uniform[u["package"]]
            uc, ub = Fraction(-independent[1], cost_den), Fraction(independent[0], benefit_den)
            check(prefix + "uniform_" + u["package"], float(uc) == u["cost"] and float(ub) == u["coefficient"])
            comparator_evidence.append({"package": u["package"], "exact_cost": exact(uc), "exact_benefit": exact(ub)})
        best_uniform = max(Fraction(v[0], benefit_den) for v in uniform.values())
        gain = 100 * (benefit / best_uniform - 1) if best_uniform else Fraction(0)
        check(prefix + "gain_percent", isclose(float(gain), expected["gain_over_best_uniform_percent"], rel_tol=5e-13, abs_tol=1e-12))
        check(prefix + "no_observed_people_claim", expected["observed_people_helped"] is None)
        results.append({"id": expected["id"], "status": "PASS", "selection": selection,
                        "enumerated_selections": evaluations, "feasible_selections": feasible,
                        "cost_exact": exact(cost), "benefit_coefficient_exact": exact(benefit),
                        "source_union_tokens": best[3], "gain_over_best_uniform_percent_exact": exact(gain),
                        "uniform_comparators": comparator_evidence})

    check("no_missing_language_exclusion_flag", portfolio["missing_evidence_exclusion"] is False
          and all(r["exclusion_allowed"] == "False" for r in frontier["rows"]))
    check("no_global_rank_or_need_deduction", portfolio["global_rank_emitted"] is False
          and portfolio["all_worldwide_comparisons_unchanged"] is True
          and portfolio["local_case_study_need_deduction"] == 0)
    check("not_worldwide_population_label", "NOT worldwide language populations" in portfolio["scope"])
    check("not_physical_compute_label", "not physical compute or money" in portfolio["cost_unit"])
    check("uniform_benefit_hypotheses_not_national_ability", any(
        "uniform hypotheses, not estimates or national learning differences" in a for a in portfolio["assumptions"]))
    check("common_unmeasured_effect_label", any("common unmeasured positive" in a for a in portfolio["assumptions"]))
    check("no_claim_of_language_readership", any("No claim that whole country context equals exact language readership" in a
          for a in portfolio["assumptions"]))
    check("disjoint_survey_frames_explicit_assumption", any("survey frames treated as disjoint" in a
          for a in portfolio["assumptions"]))
    check("input_bytes_unchanged", original_bindings == [binding(p) for p in (PORTFOLIO, FRONTIER, SCALE, PRODUCER)])
    review = {
        "schema": "secondary-package-portfolio-independent-review/1.0",
        "status": "PASS_EXACT_FINITE_SCENARIOS_NOT_EMPIRICAL_OR_WORLDWIDE_OPTIMUM",
        "source_bindings": original_bindings,
        "reviewer_binding": binding(REVIEWER),
        "scope": "Independent arithmetic and internal interpretation review of the named nine-context subset only.",
        "method": "No producer import/execution. Exact Fraction formula derivation, dynamic integer units, and independent full-mask/disjoint-companion-submask enumeration of all 3^9 choices in each of 24 cases.",
        "formulas": {
            "complete_variable": "C_100k_i * T_full / 100000",
            "companion_variable": "C_100k_i * T_companion / 100000 + (1/20) * complete_variable_i",
            "source_preparation": "setup_rate * tokens(union of selected source modules), charged once; zero for empty portfolio",
            "benefit_coefficient": "sum(N_i for complete) + ratio * sum(N_i for companion); multiply by a common still-unmeasured gain for a conditional benefit total",
            "tie_break": "maximize coefficient, then minimize cost, then lexicographically minimize per-route 0/1/2 choices"
        },
        "source_subset": {"companion_module_count": len(short["module_ids"]),
                          "complete_module_count": len(full["module_ids"]),
                          "companion_tokens": short_tokens, "complete_tokens": full_tokens,
                          "ratio_variable_cost_companion_to_full_exact": exact(companion_cost[0] / full_cost[0])},
        "integer_cost_denominator": cost_den,
        "total_selection_evaluations": total_evaluations,
        "scenario_count": len(results),
        "check_count": len(CHECKS), "checks": CHECKS,
        "findings": [],
        "interpretation": [
            "All 24 reported selections, exact costs, exact objective coefficients, source unions and uniform comparator values agree with independent exhaustive enumeration.",
            "The reference rows are exact copies of nine Q-CATCHUP secondary survey/proficiency contexts, not worldwide language populations or exact edition audiences. Disjointness is a declared within-scenario assumption, not an empirically verified worldwide overlap estimate.",
            "The six other numeric routes are retained; no missing-language or missing-evidence value is converted to zero or an exclusion. No global funding winner is established.",
            "Workloads are logical fresh-equivalent token events derived from a common 100,000-token basis. They are not observed accelerator-seconds, energy, money, provider usage, or measured physical compute.",
            "The common full-package gain and 0.5/0.75/1 companion ratios are unmeasured hypotheses, not measured understanding gains or nationality-specific learning ability. The resulting coefficient is not observed people helped.",
            "The 36-module source subset and every package token aggregate match the named scale JSON's module inventory; this check does not independently tokenize source bytes or certify pedagogical completeness. The existing six-chapter design remains a source-scale proxy.",
            "These finite conditional calculations support one transparent subset comparison within the worldwide objective; they cannot by themselves identify the globally optimal physical-compute allocation."
        ],
        "validation_boundary": "No network, source retokenization, semantic source audit, participant evidence, publication or unrelated file inspection; empirical limitations are explicit uncertainties, not human-dependent gates.",
        "completed_work": "All requested finite scenarios and accounting/interpretation checks complete.",
        "unresolved_work": [], "next_executable_action": "Parent task may consume the review; no review-dependent pause is required.",
        "scenarios": results
    }
    (ROOT / OUTPUT).write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": review["status"], "scenario_count": len(results),
                      "selection_evaluations": total_evaluations, "check_count": len(CHECKS),
                      "review": binding(OUTPUT), "reviewer": binding(REVIEWER)}, indent=2))


if __name__ == "__main__":
    main()
