"""Exact finite scenario comparison for nine existing secondary cohort routes.

No web requests, optimization service, process spawning or publication.
Enumerates 3**9 selections with integer arithmetic. It does not replace the
worldwide audience ranking or convert survey contexts into exact readership.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
from decimal import Decimal
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
FRONTIER = 'structured/TARGET_SPECIFIC_ALLOCATION_FRONTIER_v1.json'
SCALE = 'structured/OPENSTAX_PACKAGE_SCALE_20260904.json'
OUT = 'structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json'
UNITS = 200_000_000_000
CHECKS = []

def check(name, result):
    if not result:
        raise AssertionError(name)
    CHECKS.append(name)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def load(name):
    return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))

def bind(name):
    p = ROOT/name
    return {'path':name, 'bytes':p.stat().st_size, 'sha256':sha(p)}

def scaled6(value):
    result = Decimal(value)*1_000_000
    check('six_decimal_input_exact', result == result.to_integral_value())
    return int(result)

def save(name, value):
    (ROOT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def main():
    src, scale = load(FRONTIER), load(SCALE)
    rows = [r for r in src['rows'] if r['package_id']=='Q-CATCHUP']
    check('nine_exact_routes', len(rows)==9 and len({r['route_id'] for r in rows})==9)
    check('same_endpoint_and_stage',len({(r['endpoint_id'],r['stage']) for r in rows})==1)
    check('same_existing_comparison_set',len({r['comparison_set_id'] for r in rows})==1)
    other = [r['route_id'] for r in src['rows'] if r not in rows]
    check('six_other_routes_retained',len(other)==6)
    selected_chapters = [1,2,3,4,5,6,7,8,11]
    chapters = [c for c in scale['chapters'] if c['chapter'] in selected_chapters]
    extra_module_ids = ['m81329']
    selected_ids = {m for c in chapters for m in c['module_ids']} | set(extra_module_ids)
    coverage = load('structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json')['packages']['readiness_closed57']
    module_ids = coverage['module_ids']
    check('source_coverage_exact_members', set(module_ids)==selected_ids)
    check('explicit_readiness_targets_retained', coverage['readiness_link_occurrences_to_omitted_modules']==0)
    check('expanded_unique_modules', len(module_ids)==len(set(module_ids))==57)
    modules = {m['module_id']:m for m in scale['modules']}
    expanded_tokens = sum(modules[m]['tokens']['cl100k_base']['content_text'] for m in module_ids)
    check('source_coverage_tokens_agree', expanded_tokens==coverage['tokens']['cl100k_base']['content_text'])
    short = {'selected_chapters':selected_chapters, 'module_ids':module_ids,
             'tokens':{'cl100k_base':{'content_text':expanded_tokens}}}
    full = scale['candidates']['complete_source_collection']
    st = short['tokens']['cl100k_base']['content_text']
    ft = full['tokens']['cl100k_base']['content_text']
    check('source_counts', (st,ft)==(283936,364270))
    check('actual_module_subset',set(short['module_ids']) < set(full['module_ids']))
    n = [scaled6(r['need_context_base']) for r in rows]
    c = [scaled6(r['workload_base_fecu']) for r in rows]
    # Added companion diagnostics/feedback work = 5% of full variable work.
    # C100k has six decimal places; these cost numerators have denominator UNITS.
    cost = [(0,x*(2*st+ft//10),x*2*ft) for x in c]
    check('extra_exact',ft%10==0)
    pools = []
    for selection in product(range(3), repeat=len(rows)):
        variable = sum(cost[i][k] for i,k in enumerate(selection))
        source_union = ft if 2 in selection else st if 1 in selection else 0
        nf = sum(n[i] for i,k in enumerate(selection) if k==2)
        ns = sum(n[i] for i,k in enumerate(selection) if k==1)
        pools.append((selection, variable, source_union, nf, ns))
    check('enumeration_complete',len(pools)==3**9==19683)
    scenarios=[]
    for alpha, setup, budget in product((2,3,4),(0,2),(2_000_000,5_000_000,10_000_000,20_000_000)):
        options=[]
        for sel,var,union,nf,ns in pools:
            total=var+setup*union*UNITS
            if total<=budget*UNITS:
                options.append((4*nf+alpha*ns,total,sel,union))
        best=max(options,key=lambda x:(x[0],-x[1],tuple(-k for k in x[2])))
        val,total,sel,union=best
        uniform=[]
        for typ in (1,2):
            u=max((x for x in options if all(k in (0,typ) for k in x[2])),
                  key=lambda x:(x[0],-x[1]))
            uniform.append({'package':'companion' if typ==1 else 'complete',
                            'coefficient':u[0]/4_000_000,'cost':u[1]/UNITS})
        check('feasible_selection',total<=budget*UNITS)
        check('mixed_not_worse',val/4_000_000>=max(u['coefficient'] for u in uniform))
        chosen=[{'route_id':r['route_id'],'language':r['language_profile'],
                 'package':'companion' if k==1 else 'complete'}
                for r,k in zip(rows,sel) if k]
        # Independently reconstruct selected cost as fractions, not integer units.
        replay=sum((Fraction(rows[i]['workload_base_fecu'])*
                    (Fraction(st,100000)+Fraction(ft,2_000_000) if k==1 else Fraction(ft,100000))
                    for i,k in enumerate(sel) if k),Fraction(0))+setup*union
        check('fraction_cost_replay',replay==Fraction(total,UNITS))
        scenarios.append({'id':f'q{alpha}/4_setup{setup}_B{budget}',
            'companion_relative_benefit':alpha/4,'setup_rate':setup,'budget':budget,
            'selection':chosen,'cost_exact':{'numerator':total,'denominator':UNITS},
            'cost':total/UNITS,'source_union_tokens':union,
            'relative_context_benefit_coefficient':val/4_000_000,
            'coefficient_exact':{'numerator':val,'denominator':4_000_000},
            'uniform_comparators':uniform,
            'gain_over_best_uniform_percent':0 if val==0 else
                100*((val/4_000_000)/max(u['coefficient'] for u in uniform)-1),
            'observed_people_helped':None})
    result={'schema':'secondary-quantitative-package-portfolios/1.0',
       'scope':'Nine existing source-defined secondary proficiency contexts; NOT worldwide language populations',
       'source_bindings':[bind(FRONTIER),bind(SCALE),bind('scripts/build_secondary_package_portfolio_v2.py'),bind('structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json')],
       'reference_rows':rows,'other_numeric_routes_retained':other,
       'all_worldwide_comparisons_unchanged':True,'global_rank_emitted':False,
       'missing_evidence_exclusion':False,'local_case_study_need_deduction':0,
       'cost_unit':'Declared standardized fresh-equivalent token workload, not physical compute or money',
       'endpoint':'Existing Q-CATCHUP independent secondary quantitative prerequisite tasks',
       'assumptions':[
         'One package per represented context; selected country survey frames treated as disjoint in this bounded scenario.',
         'A common unmeasured positive full-package offer-level gain includes language fit, uptake, baseline alternatives and endpoint benefit.',
         'Companion/full gain ratios 0.5, 0.75 and 1 are uniform hypotheses, not estimates or national learning differences.',
         'Nine chapters plus the formula-rearrangement module m81329 proxy the expanded companion source; 5% of full variable work is added for diagnostics, feedback and integration.',
         'Chapters 2, 5 and 7 restore substantial algebra, decimal/rate and real-number prerequisite content absent from the six-chapter proxy. The additional module closes the remaining explicit be-prepared remediation links; this is not a proven minimum or a claim of complete pedagogical prerequisites.',
         'Source preparation charged once for the exact union at rates 0 or 2 workload units per source token.',
         'No claim that whole country context equals exact language readership; no extrapolation beyond the sampled frame.',
         'No observed learning gain or empirical global winner is produced.'
       ],'packages':{'companion_source_tokens':st,'complete_source_tokens':ft,
                    'companion_extra_full_work_share':0.05,
                    'selected_chapters':short['selected_chapters'],
                    'extra_module_ids':extra_module_ids,
                    'module_ids':module_ids,
                    'module_count':len(module_ids)},
       'enumerated_selections':len(pools),'scenarios':scenarios}
    save(OUT,result)
    lines=['# Secondary catch-up: allocating packages within nine existing contexts','',
      'Conditional allocation calculation, not a worldwide language ranking. The source-defined cohort counts are retained unchanged; language fit and actual additional learning remain explicit assumptions.','',
      'The same two alternatives are offered to every context: an expanded nine-chapter companion proxy plus the formula-rearrangement lesson and additional diagnostic/feedback work, or complete prealgebra. The comparison uses the same quantitative catch-up endpoint. Three uniform companion/full benefit ratios are tested; no nationality is assigned a different learning ability.','',
      'Source counts are 283,936 and 364,270 content tokens; the companion incurs additional work equal to 5% of full-book variable work. Shared source preparation is charged once. Workload units are not money, energy or observed physical compute.','',
      '| Companion/full benefit | Setup rate | Budget millions | Selected packages | Used millions | Relative context coefficient |',
      '|---:|---:|---:|---|---:|---:|']
    for s in scenarios:
        labels='; '.join(x['language']+(' (companion)' if x['package']=='companion' else ' (full)') for x in s['selection']) or 'No package fits'
        lines.append(f"| {s['companion_relative_benefit']:.2f} | {s['setup_rate']} | {s['budget']/1e6:g} | {labels} | {s['cost']/1e6:.3f} | {s['relative_context_benefit_coefficient']:,.0f} |")
    lines += ['', '## Interpretation','',
      'This expanded alternative adds chapters 2, 5 and 7 plus the formula-rearrangement module m81329 to the six-chapter proxy. The 21 additional modules supply substantial algebra, decimal/rate and real-number prerequisite content and close the remaining explicit readiness links. Whole-chapter inclusion is conservative rather than minimal, and link closure is not proof of complete pedagogical prerequisites. Results for the original six-chapter proxy and the intermediate 56-module alternative are preserved in the source-coverage report; the original v1 scenarios are not rewritten.','',
      'Multiply the last column by the common, still-unmeasured offer-level gain to obtain a conditional benefit total. It is not a count of people educated. One package cannot be credited with outcomes it omits. The modeled contexts are separate country survey frames, not a claim of zero multilingual overlap in worldwide readership.','',
      'The six other numeric routes and all worldwide language, script, signed-language, register, stage and interlanguage options remain eligible in the larger study. This calculation does not replace their baselines or promote this nine-route subset as a global Top 10.','',
      'Every one of 19,683 choices was enumerated for 24 scenarios with integer arithmetic; selected costs were separately recomputed using exact fractions. This proves the finite scenario solutions, not the empirical input assumptions. Full inputs, choices, exact values and comparator policies are in `structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json`.']
    (ROOT/'SECONDARY_PACKAGE_PORTFOLIO_v2.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    save('qa/SECONDARY_PACKAGE_PORTFOLIO_QA_v2.json',{'status':'PASS_EXACT_SCENARIOS_NOT_EMPIRICAL_CALIBRATION','checks':len(CHECKS),'check_names':CHECKS,'scenario_count':len(scenarios),'selections_per_scenario':len(pools),'outputs':[bind(OUT),bind('SECONDARY_PACKAGE_PORTFOLIO_v2.md')]})
    print(json.dumps({'scenarios':len(scenarios),'checks':len(CHECKS),'maximum_gain_over_uniform_percent':max(s['gain_over_best_uniform_percent'] for s in scenarios),'status':'PASS'},indent=2))

if __name__=='__main__':
    main()
