"""Build the bounded Thai/Malay source ledger from nine exact retained files.

No network, subprocesses, new renders, source edits or publication. Visual
inspection declarations below record the reviewer's completed direct inspection
of the 22 existing PNG witnesses, not a claim that this script inspects images.
"""
from pathlib import Path
from pypdf import PdfReader
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = "sources/thai_malay_secondary_20260908/"
REPORT = "THAI_MALAY_SECONDARY_PACKAGE_v1.md"
OUTPUT = "structured/THAI_MALAY_SECONDARY_PACKAGE_v1.json"
SCRIPT = "scripts/build_thai_malay_secondary_evidence_v1.py"


def bind(relative):
    path = ROOT / relative
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": relative, "bytes": path.stat().st_size,
            "sha256": digest.hexdigest().upper()}


SOURCES = [
    {"id": "T1", "filename": "THA_IPST_LowerSecondary_Curriculum_2017.pdf",
     "title": "คู่มือการใช้หลักสูตร กลุ่มสาระการเรียนรู้คณิตศาสตร์ (ฉบับปรับปรุง พ.ศ. 2560) ระดับมัธยมศึกษาตอนต้น",
     "english_description": "Lower-secondary mathematics curriculum-use guide, 2017 curriculum revision",
     "author_or_institution": "Institute for the Promotion of Teaching Science and Technology (IPST)",
     "url": "https://www.scimath.org/e-books/8380/8380.pdf",
     "provenance": "IPST institutional identity and curriculum revision are present in PDF 2; official scimath URL is recorded in the named research report, not fetched again here.",
     "date": {"curriculum_revision_year_ce": 2017, "curriculum_revision_year_be": 2560,
              "underlying_core_curriculum_year_be": 2551, "publication_date": None,
              "qualifier": "2017 describes the curriculum revision, not an independently established publication date."},
     "pdf_page_count": 66, "expected_sha256": "7C03DA9A427E63D2F0E20271F4352925EBC05848E4F612A7F71098E055E6EDEB",
     "text_inspected_pdf_pages": [1, 2, 3], "visual_pdf_pages": [9, 10, 11, 13]},
    {"id": "T2", "filename": "THA_DLTV_M1_equations_episode.html",
     "title": "การแก้โจทย์ปัญหาสมการเชิงเส้นตัวแปรเดียว (3) 1 ธ.ค. 68 (มีใบกิจกรรม)",
     "english_description": "M1: Solving one-variable linear-equation problems (3), episode 102574",
     "author_or_institution": "Distance Learning Foundation (DLTV)",
     "url": "https://dltv.ac.th/teachplan/episode/102574",
     "provenance": "Retained DLTV HTML directly contains the M1 subject, indicator, objectives, assessment, school year and links to downloads 205531 and 205532.",
     "date": {"episode_date_ce": "2025-12-01", "episode_date_as_displayed": "1 ธ.ค. 68",
              "school_year_be": 2568, "term": 2, "publication_date": None,
              "qualifier": "CE conversion uses the explicitly displayed B.E. school year 2568; episode date is not a file publication timestamp."},
     "pdf_page_count": None, "expected_sha256": "09BC5DCC72151C95F34A85868F09A219F2A0959B402CF872179348A8A405EF12",
     "html_sections_inspected": ["episode title", "essential concepts/five solution steps", "indicator and objectives", "assessment", "school year and level", "download links"]},
    {"id": "T3", "filename": "THA_DLTV_M1_equations_slides.pdf",
     "title": "การแก้โจทย์ปัญหาสมการเชิงเส้นตัวแปรเดียว (3)",
     "english_description": "DLTV M1 one-variable equation teaching slides",
     "author_or_institution": "DLTV; teacher credited as ครูศิริลักษณ์ ธนูทอง on PDF 1",
     "url": "https://dltv.ac.th/utils/files/download/205531",
     "provenance": "The exact download URL is present in retained T2 HTML. PDF 1 identifies course ค21102, Mathayom 1, unit 1 and problem lesson (3).",
     "date": {"publication_date": None, "qualifier": "Undated slide file linked from the dated episode; do not infer slide publication from episode date."},
     "pdf_page_count": 24, "expected_sha256": "98F4093D201C50789C3145AD4A25363DDB715A7E3DD78522028E4A32029999B8",
     "text_inspected_pdf_pages": [1], "visual_pdf_pages": [5, 6, 21]},
    {"id": "T4", "filename": "THA_DLTV_M1_equations_activities.pdf",
     "title": "ใบกิจกรรมที่ 5 มายากลคณิต คิดสนุก; ใบกิจกรรมที่ 6 สร้างได้อย่างไร",
     "english_description": "Activities 5 and 6 for M1 one-variable equations",
     "author_or_institution": "DLTV",
     "url": "https://dltv.ac.th/utils/files/download/205532",
     "provenance": "Exact download URL occurs in retained T2 HTML. PDF 1 labels plan 15/problem lesson (4); PDF 2 labels plan 16/problem lesson (5). These identifiers differ from the episode's lesson (3).",
     "date": {"publication_date": None, "qualifier": "No independent worksheet publication date established."},
     "pdf_page_count": 3, "expected_sha256": "0047E8DF3F78363D176B7BC1617A1EDB07F9C043B7C54E6A21101AFFF4D1AF68",
     "text_inspected_pdf_pages": [3], "visual_pdf_pages": [1, 2]},
    {"id": "M1", "filename": "MYS_PPD_BatuPahat_math_page.html",
     "title": "MATEMATIK: Buku teks digital sekolah menengah",
     "english_description": "PPD Batu Pahat secondary mathematics textbook page",
     "author_or_institution": "Pejabat Pendidikan Daerah Batu Pahat",
     "url": "https://sites.google.com/moe-dl.edu.my/ppd-batu-pahat-sains-matematik/buku-teks-digital-bidang-sains-matematik/buku-teks-sekolah-menengah/matematik",
     "provenance": "Retained HTML from the education-domain district page contains separate Malay and English DLP Form 1-3 labels and the exact three Malay Drive embed IDs.",
     "date": {"publication_date": None, "qualifier": "No publication or last-updated date independently established from inspected content."},
     "pdf_page_count": None, "expected_sha256": "A71A6164B59742BB729F61CB9A38A16F67AB258CE2B238F406FA2F0489247994",
     "html_sections_inspected": ["page title", "Form 1 Malay and DLP labels", "Form 2 Malay and DLP labels", "Form 3 Malay and DLP labels", "Drive embed/download identities"]},
    {"id": "M2", "filename": "MYS_Form1_Mathematics_KSSM.pdf",
     "title": "Matematik Tingkatan 1",
     "author_or_institution": "Ooi Soo Huat; Yong Kuan Yeoh; Ng Seng How",
     "publisher": "Penerbitan Pelangi Sdn. Bhd., for Kementerian Pendidikan Malaysia",
     "isbn": "978-983-00-8244-8",
     "url": "https://drive.google.com/file/d/1uGBdQeSNrRbH1caQ33GM7ccjfVeDm-8C/view",
     "drive_file_id": "1uGBdQeSNrRbH1caQ33GM7ccjfVeDm-8C",
     "provenance": "Exact Drive ID and Malay filename occur in retained M1 HTML; authors/year are on PDF 3, copyright/publisher/ISBN on PDF 4 (printed ii).",
     "date": {"first_printing_year": 2016, "qualifier": "Edition year verified from title and copyright; no assertion that this is the latest curriculum or printing."},
     "pdf_page_count": 339, "expected_sha256": "F102E8CB7CB28200C4334B09EA5459EC74DB5E34D2FBDBDD4D4983E56AE5CE6B",
     "text_inspected_pdf_pages": [3, 4, 5, 6, 7, 8], "visual_pdf_pages": [24, 118, 135, 317, 322]},
    {"id": "M3", "filename": "MYS_Form2_Mathematics_KSSM.pdf",
     "title": "Matematik Tingkatan 2",
     "author_or_institution": "Bahariah binti Hj. Baharam; Baharizah binti Hj. Baharam; Nurul Jannah binti Ahmad; Nurazreen binti Mohd Tahir; Mohd Nazri bin Mohd Hanafiah",
     "publisher": "Rimbunan Ilmu Sdn. Bhd., for Kementerian Pendidikan Malaysia",
     "isbn": "978-967-2031-05-5",
     "url": "https://drive.google.com/file/d/1G9leLwWhwj6sZEuHmiMwMlRMXMxBLE3_/view",
     "drive_file_id": "1G9leLwWhwj6sZEuHmiMwMlRMXMxBLE3_",
     "provenance": "Exact Drive ID and Malay filename occur in retained M1 HTML; PDF 1 identifies authors/year; PDF 2 spread includes copyright, ISBN and publisher on printed ii.",
     "date": {"first_printing_year": 2017, "qualifier": "Edition year, not verification of current curriculum status."},
     "pdf_page_count": 161, "expected_sha256": "A419EB7DCA0F693A72C2BACFACEF6E168CCC58DA67F0E6163D87C2D00A720122",
     "text_inspected_pdf_pages": [1, 2, 3], "visual_pdf_pages": [15, 152]},
    {"id": "M4", "filename": "MYS_Form3_Mathematics_KSSM.pdf",
     "title": "Matematik Tingkatan 3",
     "author_or_institution": "Chiu Kam Choon; Vincent De Selva A/L Santhanasamy; Punithah Krishnan; Raja Devi Raja Gopal",
     "publisher": "Pustaka Yakin Pelajar Sdn. Bhd., for Kementerian Pendidikan Malaysia",
     "isbn": "978-967-490-042-7",
     "url": "https://drive.google.com/file/d/1adyEuntNeN5V7GJ_z-G09keMtV9YhdHx/view",
     "drive_file_id": "1adyEuntNeN5V7GJ_z-G09keMtV9YhdHx",
     "provenance": "Exact Drive ID and Malay filename occur in retained M1 HTML; PDF 5 identifies authors/publisher/year; PDF 6 (printed ii) contains copyright/ISBN/first printing.",
     "date": {"first_printing_year": 2018, "qualifier": "Edition year, not verification of current curriculum status."},
     "pdf_page_count": 276, "expected_sha256": "7D71500123226ECDA8F2211B30770CF7AC1789C3DFE02852CE49D00085CFE2AA",
     "text_inspected_pdf_pages": [1, 2, 3, 4, 5, 6], "visual_pdf_pages": [33, 262]},
    {"id": "M5", "filename": "MYS_KPM_TIMSS2023_Mathematics_Item_Analysis.pdf",
     "title": "Laporan Analisis Item Matematik TIMSS 2023",
     "author_or_institution": "Kementerian Pendidikan Malaysia",
     "url": "https://www.moe.gov.my/storage/files/shares/penerbitan_dan_jurnal/penyelidikan/pisa_timss_sea-plm/Laporan%20Analisis%20Item%20Matematik%20TIMSS%202023.pdf",
     "provenance": "Retained report title is visible on all inspected item pages; ministry URL is recorded in the named research report, not fetched again here.",
     "date": {"assessment_year": 2023, "publication_date": None,
              "qualifier": "Assessment year is not asserted to be publication year. PDF 1-3 yielded no extractable text in this check."},
     "pdf_page_count": 134, "expected_sha256": "0E44D139EFFA3792B349F7BFCE3AE9F15FF7714E79054FD2DFAD58A22EBCFFEE",
     "text_inspected_pdf_pages": [10], "text_extraction_attempted_without_text_pdf_pages": [1, 2, 3],
     "visual_pdf_pages": [58, 59, 80, 81]},
]

# Each tuple is an existing, individually displayed and visually inspected PNG.
WITNESSES = [
    ("T1", 9, ["16", "17"], "THA_curriculum_p9.png", "M1 rational-number and ratio/percentage standards; prior page lists end-M3 learner outcomes."),
    ("T1", 10, ["18", "19"], "THA_curriculum_p10.png", "M1 one-variable linear equations and graph relations; geometry and statistics also show why the catch-up endpoint is not the whole curriculum."),
    ("T1", 11, ["20", "21"], "THA_curriculum_p11.png", "M2 integer powers, real numbers, polynomial operations and quadratic factorization."),
    ("T1", 13, ["24", "25"], "THA_curriculum_p13.png", "M3 one-variable linear inequalities, quadratic equations and simultaneous linear equations, plus separate geometry content."),
    ("T3", 5, [], "THA_slides_p5.png", "Worked consecutive-even-number equation solved step by step."),
    ("T3", 6, [], "THA_slides_p6.png", "The resulting two values are checked against their sum and the original condition."),
    ("T3", 21, [], "THA_slides_p21.png", "Activity 5 instruction asks the learner to invent and explain a number trick; empty response area."),
    ("T4", 1, [], "THA_activities_p1.png", "Activity 5, plan 15/problem lesson (4), open-ended number-trick and explanation fields; no explicit group instruction."),
    ("T4", 2, [], "THA_activities_p2.png", "Activity 6, plan 16/problem lesson (5), explicitly asks another group to solve a created problem and the originating group to check correctness/reasonableness."),
    ("M2", 24, ["14"], "MYS_F1_p24.png", "Signed-fraction GeoGebra/group activity coexists with a static number-line diagram and explanation."),
    ("M2", 118, ["108"], "MYS_F1_p118.png", "Everyday algebra example with Penyelesaian, Latih Diri 5.1b, and introduction to substitution."),
    ("M2", 135, ["125"], "MYS_F1_p135.png", "Definition and worked classification of linear equations in one variable, followed by Latih Diri 6.1a."),
    ("M2", 317, ["307"], "MYS_F1_p317.png", "Jawapan begins; signed/fraction answers include diagrams and a worked contextual calculation."),
    ("M2", 322, ["312"], "MYS_F1_p322.png", "Answers for Latih Diri 5.1b from printed 108; surrounding answers include explanatory reasoning."),
    ("M3", 15, ["20", "21"], "MYS_F2_p15.png", "Area diagrams and activities introduce algebraic expansion; spread also includes an individual activity label."),
    ("M3", 152, ["294", "295"], "MYS_F2_p152.png", "Jawapan spread includes expansion, factorization and algebraic-fraction answers."),
    ("M4", 33, ["23"], "MYS_F3_p33.png", "Index-law examples show factorization and simultaneous-equation reasoning with explicit Semak Jawapan panels."),
    ("M4", 262, ["252"], "MYS_F3_p262.png", "Jawapan begins with index-law answers and some algebraic working."),
    ("M5", 58, ["56"], "MYS_TIMSS_p58.png", "ME72038 correct-option percentage 12.5 and Form 1 standard 1.3.3 are visible."),
    ("M5", 59, ["57"], "MYS_TIMSS_p59.png", "Report diagnoses denominator and fraction-concept difficulties and proposes instructional responses."),
    ("M5", 80, ["78"], "MYS_TIMSS_p80.png", "ME72069 correct percentage 22.8 and Form 1 standard 5.1.3 are visible."),
    ("M5", 81, ["79"], "MYS_TIMSS_p81.png", "Report discusses negative-number/substitution errors and recommends parentheses in substitution practice."),
]


def location(source, pages=(), printed=(), section=None, method="visual_existing_png"):
    result = {"source_id": source, "pdf_pages": list(pages), "printed_pages": list(printed), "inspection_method": method}
    if section:
        result["section"] = section
    return result


def claim(cid, statement, kind, evidence, limitation, **fields):
    return {"claim_id": cid, "statement": statement, "claim_type": kind,
            "evidence": evidence, "limits": limitation, **fields}


CLAIMS = [
    claim("T-CURRICULUM", "The Thai M1 standards include rational numbers, fractions/decimals, ratios/percentages and one-variable linear equations; later stages contain specified algebraic progression.", "direct_curriculum_content",
          [location("T1", [9, 10], ["17", "18"]), location("T1", [11], ["20", "21"]), location("T1", [13], ["24"])],
          "A curricular crosswalk does not estimate need, national access, learning effect or the full content of every lower-secondary course."),
    claim("T-LESSON-IDENTITY", "Episode 102574 binds formulation, solution and original-condition checking to indicator ค 1.3 ม. 1/1, Mathayom 1, school year 2568 term 2.", "direct_retained_html",
          [location("T2", section="indicator/objectives, five solution steps and year/level", method="retained_html_text_and_markup")],
          "The exact lesson and school-year identity is not an audience or effect measure."),
    claim("T-WORKED-FEEDBACK", "The sampled DLTV slides contain a fully worked equation derivation and a subsequent check against the consecutive-even-number problem's original condition.", "direct_observed_provision",
          [location("T3", [5, 6])], "This is evidence of actual existing worked feedback in one lesson, not an audit of all DLTV material."),
    claim("T-ACTIVITY5", "Activity 5 asks learners to create one number trick using one-variable equations and explain the method; the inspected worksheet has blank creation and explanation fields.", "direct_observed_task",
          [location("T4", [1]), location("T3", [21])],
          "Its directions do not explicitly require a group. Several name lines alone do not establish mandatory group work; independent self-checking difficulty is a design inference."),
    claim("T-ACTIVITY6", "Activity 6 explicitly requires a group to create a problem, have another group express and solve it, and jointly check correctness and reasonableness; blank checking and answer fields continue on PDF 3.", "direct_observed_task",
          [location("T4", [2]), location("T4", [3], method="pdf_text_extraction")],
          "The worksheet does not itself fill those feedback fields. This does not prove that the wider lesson ecosystem lacks further feedback."),
    claim("T-NUMBERING", "The episode and slide identify problem lesson (3), while worksheet Activity 5 names plan 15/(4) and Activity 6 names plan 16/(5).", "direct_identity_difference",
          [location("T2", section="episode title", method="retained_html_text_and_markup"), location("T3", [1], method="pdf_text_extraction"), location("T4", [1, 2])],
          "Retain the exact identifiers; the source does not establish why they differ."),
    claim("M-EXISTING-BOOKS", "The retained district page links Malay Form 1-3 textbooks separately from English DLP versions; exact linked files contain textbook identity and edition information.", "direct_observed_provision",
          [location("M1", section="Form 1-3 labels and exact Drive embed IDs", method="retained_html_text_and_markup"),
           location("M2", [3, 4], ["ii"], section="title page and copyright printed ii", method="pdf_text_extraction"),
           location("M3", [1, 2], ["ii"], section="title page and copyright printed ii", method="pdf_text_extraction"),
           location("M4", [5, 6], ["ii"], section="title page and copyright printed ii", method="pdf_text_extraction")],
          "Verified editions are 2016, 2017 and 2018. Local retained availability does not establish that they are latest editions, universally accessible, or freely reusable."),
    claim("M-F1-EXAMPLES-ANSWERS", "Form 1 has worked algebraic-expression examples, self-practice and matching exercise answers; it explains and classifies one-variable linear equations, and its answer section includes reasoning as well as short results.", "direct_observed_provision",
          [location("M2", [118, 135, 317, 322], ["108", "125", "307", "312"])],
          "The sample establishes actual existing support, not complete explanation of every exercise or measured independent-use effectiveness."),
    claim("M-F1-OFFLINE", "The signed-fraction page combines a GeoGebra/four-person discussion task with a static number-line explanation.", "direct_observed_format",
          [location("M2", [24], ["14"])],
          "Do not describe the whole book as requiring continuous internet. This check did not test the GeoGebra download, phone usability or all interactive links."),
    claim("M-F2-EXPANSION", "Form 2 introduces expansion with area diagrams and includes expansion/factorization answers in its answer section.", "direct_observed_provision",
          [location("M3", [15], ["20", "21"]), location("M3", [152], ["294", "295"])],
          "PDF pages here are two-page spreads; printed and PDF numbering must not be conflated."),
    claim("M-F3-CHECKED-WORK", "Form 3 works index-law examples through a quadratic equation and a simultaneous linear system, with answer-check panels; the answer section begins at printed 252.", "direct_observed_provision",
          [location("M4", [33], ["23"]), location("M4", [262], ["252"])],
          "Worked support is observed beyond Form 1; no universal curricular or learner-effect conclusion follows."),
    claim("M-TIMSS-FRACTIONS", "The TIMSS 2023 item-analysis report records 12.5% correct for ME72038, a fraction-subtraction-method item, and maps it to Form 1 standard 1.3.3.", "reported_assessment_item_result",
          [location("M5", [58], ["56"], section="eNO 08: response distribution and curriculum mapping"),
           location("M5", [59], ["57"], section="weaknesses and suggested teaching strategy")],
          "The percentage concerns Malaysian assessed-student responses to this item, not all Malay speakers, a language-specific causal deficit, an audience multiplier or a translation effect. The item's individual response denominator and standard error are not supplied in the inspected item table.",
          item_id="ME72038", reported_correct_percent=12.5, assessment_year=2023,
          curriculum_form=1, learning_standard="1.3.3",
          interpretation="The report identifies denominator selection and confusion between an operation on fractions and a single fraction; it supports a skill focus, not a measured intervention gain."),
    claim("M-TIMSS-SUBSTITUTION", "The TIMSS 2023 item-analysis report records 22.8% correct for ME72069, substitution into an algebraic expression including a negative value, and maps it to Form 1 standard 5.1.3.", "reported_assessment_item_result",
          [location("M5", [80], ["78"], section="eAL 04: response distribution and curriculum mapping"),
           location("M5", [81], ["79"], section="strengths, weaknesses and teaching suggestions")],
          "These are item results for assessed students, not all Standard Malay users or evidence of language-induced difficulty. Curriculum Form 1 is a content mapping; the glossary identifies Grade 8 as Form 2. No translation-benefit rate is measured.",
          item_id="ME72069", reported_correct_percent=22.8, assessment_year=2023,
          curriculum_form=1, learning_standard="5.1.3",
          interpretation="The report identifies negative-number confusion and substitution/operation selection and proposes parentheses and practice."),
    claim("M-RIGHTS", "All three sampled KPM textbooks state reserved reproduction rights; the TIMSS glossary states that use of Restricted Use Items requires written IEA permission.", "direct_source_rights_notice",
          [location("M2", [4], ["ii"], method="pdf_text_extraction"),
           location("M3", [2], ["ii"], method="pdf_text_extraction"),
           location("M4", [6], ["ii"], method="pdf_text_extraction"),
           location("M5", [10], ["8"], section="Restricted Use Items", method="pdf_text_extraction")],
          "This records the notices, not a general legal opinion. Retain PDFs as research witnesses and cite findings; this task authorizes no PDF republication or wholesale textbook/item reuse."),
    claim("PACKAGE-DESIGN", "An original, independent-use companion adding diagnostics, prerequisite routes, explanation, self-checks and offline navigation is a source-grounded construction candidate alongside a complete catch-up sequence.", "explicit_design_inference",
          [location("T4", [1, 2]), location("M2", [24, 118, 135, 322], ["14", "108", "125", "312"]),
           location("M5", [58, 59, 80, 81], ["56", "57", "78", "79"])],
          "The companion's relative learning benefit, workload advantage and national reach are unmeasured. To claim the common catch-up endpoint, its actual prerequisite routes must cover the whole endpoint, not merely fractions or one equation lesson."),
]


def main():
    report_text = (ROOT / REPORT).read_text(encoding="utf-8-sig")
    source_records = []
    readers = {}
    for original in SOURCES:
        record = dict(original)
        filename = record.pop("filename")
        wanted_hash = record.pop("expected_sha256")
        record.update(bind(SOURCE_DIR + filename))
        assert record["sha256"] == wanted_hash, "Source bytes changed: " + record["id"]
        assert filename in report_text and record["url"] in report_text
        if record["pdf_page_count"] is not None:
            reader = PdfReader(ROOT / record["path"])
            readers[record["id"]] = reader
            assert len(reader.pages) == record["pdf_page_count"]
        record["retrieval"] = {"date_reported_by_source_report": "2026-09-08",
                               "status": "HISTORICAL_DOWNLOAD_CLAIM_NOT_NETWORK_REPLAYED",
                               "current_check": "Retained bytes hashed and locally read; no fresh HTTP or authentication check."}
        record["publication_handling"] = "RESEARCH_WITNESS_ONLY_DO_NOT_PUBLISH_SOURCE_PDF" if filename.endswith(".pdf") else "RETAINED_PROVENANCE_WITNESS"
        source_records.append(record)
    source_by_id = {s["id"]: s for s in source_records}
    assert len(source_records) == 9 and len(readers) == 7
    thai_html = (ROOT / source_by_id["T2"]["path"]).read_text(encoding="utf-8")
    malay_html = (ROOT / source_by_id["M1"]["path"]).read_text(encoding="utf-8")
    for source in (source_by_id["T3"], source_by_id["T4"]):
        assert source["url"] in thai_html
    for source in (source_by_id["M2"], source_by_id["M3"], source_by_id["M4"]):
        assert 'data-embed-doc-id="' + source["drive_file_id"] + '"' in malay_html

    # Text-anchor checks supplement, but never replace, the actual visual review.
    required_anchors = [
        ("M5", 58, ["ME72038", "12.5%", "1.3.3"]),
        ("M5", 80, ["ME72069", "22.8%", "5.1.3"]),
        ("M5", 10, ["Restricted Use Items", "kebenaran", "IEA"]),
        ("M2", 4, ["978-983-00-8244-8", "2016", "Hak Cipta Terpelihara"]),
        ("M3", 2, ["978-967-2031-05-5", "2017", "Hak Cipta Terpelihara"]),
        ("M4", 6, ["978-967-490-042-7", "2018", "Hak Cipta Terpelihara"]),
    ]
    anchor_checks = []
    for sid, page, anchors in required_anchors:
        extracted = " ".join(readers[sid].pages[page - 1].extract_text().split())
        for anchor in anchors:
            assert anchor in extracted, (sid, page, anchor)
            anchor_checks.append({"source_id": sid, "pdf_page": page, "anchor": anchor, "status": "PASS"})

    witnesses = []
    for sid, page, printed, filename, note in WITNESSES:
        assert 1 <= page <= source_by_id[sid]["pdf_page_count"]
        witnesses.append({"source_id": sid, "pdf_page": page, "printed_pages": printed,
                          **bind(SOURCE_DIR + filename), "inspection_status": "VISUALLY_INSPECTED_IN_THIS_REVIEW",
                          "inspection_date": "2026-09-08", "render_status": "PREEXISTING_RENDER_REUSED_NOT_RERENDERED",
                          "observation": note})
    assert len(witnesses) == len({w["path"] for w in witnesses}) == 22
    for c in CLAIMS:
        for e in c["evidence"]:
            assert e["source_id"] in source_by_id
            for page in e["pdf_pages"]:
                assert 1 <= page <= source_by_id[e["source_id"]]["pdf_page_count"]
                if e["inspection_method"] == "visual_existing_png":
                    assert any(w["source_id"] == e["source_id"] and w["pdf_page"] == page for w in witnesses)
    output = {
        "schema": "thai-malay-secondary-package-source-evidence/1.0",
        "status": "COMPLETE_BOUNDED_SOURCE_VERIFICATION_WORDING_ISSUE_RESOLVED",
        "review_date": "2026-09-08", "report_binding": bind(REPORT), "generator_binding": bind(SCRIPT),
        "scope": {"profiles": ["th-Thai-TH", "ms-Latn-MY"],
                  "endpoint": "Independent use of signed arithmetic, fractions/decimals, ratio/percentage and elementary algebra to formulate, solve and check quantitative problems.",
                  "not_whole_lower_secondary_curriculum": True, "population_or_need_changes": 0,
                  "global_rank_changed": False, "learning_effect_measured": False,
                  "physical_compute_measured": False, "human_dependent_gate": False},
        "sources": source_records, "source_count": len(source_records), "pdf_source_count": len(readers),
        "claims": CLAIMS, "rendered_witnesses": witnesses,
        "inspection_summary": {"preexisting_pngs_found": 22, "pngs_visually_inspected_this_review": 22,
                               "pngs_merely_found_not_inspected": 0, "new_renders_created": 0,
                               "glossary_pdf10": "TEXT_EXTRACTED_AND_READ_THIS_REVIEW; no glossary PNG was among the 22 retained witnesses; not claimed visually inspected here.",
                               "copyright_and_title_pages": "Read using PDF text extraction as listed per source; not counted as visual inspections.",
                               "historical_inspection_claims": "The report's prior inspection statements are not treated as proof of this review's actions; today's inspections are separately enumerated."},
        "report_claim_findings": [
            {"id": "F1", "severity": "MINOR_WORDING_PRECISION_RESOLVED", "section": "Thai package recommendation / T-COMP",
             "original_report_phrase_observed_at_review_start": "solo alternatives to the two group activities",
             "finding": "Activity 6 explicitly requires group exchange and checking. Activity 5 asks learners to invent/explain a number trick but its directions do not explicitly require groups. Several name fields do not establish that requirement.",
             "resolution": "Parent amended the report to distinguish Activity 6's explicit group exchange from Activity 5's open-ended number-trick creation; the corrected current report was reread before this ledger was generated.",
             "current_report_phrase_verified": "Activity 6 explicitly requires group exchange; Activity 5 asks for number-trick creation without an explicit group requirement.",
             "evidence_claim_ids": ["T-ACTIVITY5", "T-ACTIVITY6"], "report_modified_by_this_task": False},
            {"id": "F2", "severity": "PROVENANCE_QUALIFICATION", "section": "Access and identity / References and exact source locations",
             "finding": "The retained local files and embedded download identities are verified. The historical no-login download/retrieval-date assertions were not network-replayed; they remain attributed to the source report, not newly independently proven.",
             "report_modified_by_this_task": False},
            {"id": "F3", "severity": "INSPECTION_METHOD_QUALIFICATION", "section": "M5 reference and evidence boundaries",
             "finding": "All 22 retained named PNG samples were actually inspected in this review. The glossary rights notice on PDF 10/printed 8 was read by text extraction, not visually rechecked; it is outside the 22 PNG witness count.",
             "report_modified_by_this_task": False}
        ],
        "evidence_boundaries": [
            "Source snapshots suffice for this local claim verification; no network requests or publication occurred.",
            "Existing material and a source-grounded improvement candidate do not prove national absence, universal language preference, a causal language deficit, national audience reach, learning gains or relative cost-effectiveness.",
            "The item results are national assessed-student response summaries, not percentages of Malay speakers and not measured deficits caused by use of Malay.",
            "Free download availability is not an open licence. The KPM textbooks and restricted-use TIMSS material remain research witnesses and are not republished by this task.",
            "Offline static-page readability is demonstrated by retained local PDFs and PNGs; mobile usability, live video, interactive assets, whole-book accessibility and all-page semantic correctness were not evaluated.",
            "Package recommendations are reversible design inferences. Missing empirical effects are recorded uncertainties, not human-response gates."
        ],
        "validation": {"source_hashes_match_inspected_bytes": True, "pdf_page_counts_checked": True,
                       "html_download_links_checked": True, "all_visual_claim_pages_have_inspected_witnesses": True,
                       "text_anchor_checks": anchor_checks, "claim_count": len(CLAIMS),
                       "authored_output_only": OUTPUT},
        "task_state": {"completed": "Nine-source metadata ledger, claim/page mapping, 22-image inspection and bounded report qualification complete.",
                       "unresolved": [], "next_action": "Parent may consume the source ledger; the identified report wording correction is already verified in the current report."}
    }
    (ROOT / OUTPUT).write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": output["status"], "sources": len(source_records), "pdfs": len(readers),
                      "visual_witnesses": len(witnesses), "claims": len(CLAIMS),
                      "output": bind(OUTPUT), "script": bind(SCRIPT)}, indent=2))


if __name__ == "__main__":
    main()
