"""Source-bound package coverage audit; offline, deterministic, no tokenizer download.

Finite scope: verify the archived collection and token records, audit original
36-module and expanded 56-module selections, test the 57-module correction that
adds the known omitted formula-readiness module, and emit source evidence plus
reproducible checks. The main task owns its private verbatim user-input log,
downstream allocation modeling, manuscripts, and publication. This script neither
retokenizes nor launches network, TeX, Lean, or additional agent operations.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SCALE = ROOT / "structured/OPENSTAX_PACKAGE_SCALE_20260904.json"
ARCHIVE = ROOT / "sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip"
OUT_JSON = ROOT / "structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json"
OUT_MD = ROOT / "PACKAGE_PREREQUISITE_COVERAGE_v1.md"
NS = {"c": "http://cnx.rice.edu/cnxml", "col": "http://cnx.rice.edu/collxml", "md": "http://cnx.rice.edu/mdml"}
ORIGINAL = [1, 3, 4, 6, 8, 11]
EXPANDED = [1, 2, 3, 4, 5, 6, 7, 8, 11]


def sha(data):
    return hashlib.sha256(data).hexdigest().upper()


def norm(text):
    return unicodedata.normalize("NFC", " ".join(text.split()))


def plain(element):
    return norm(" ".join(element.itertext())) if element is not None else ""


def readable(element):
    """Readable text, with explicitly parenthesized MathML fractions/powers.

    This is evidence display only, not the scale extraction or math rendering.
    Exact element XML is retained by hash and archived member/element locator.
    """
    if element is None:
        return ""
    name = element.tag.rsplit("}", 1)[-1]
    children = list(element)
    if name == "mfrac" and len(children) == 2:
        return f"({readable(children[0])})/({readable(children[1])})"
    if name == "msup" and len(children) == 2:
        return f"({readable(children[0])})^({readable(children[1])})"
    if name == "msub" and len(children) == 2:
        return f"({readable(children[0])})_({readable(children[1])})"
    if name == "msqrt":
        return "sqrt(" + " ".join(readable(x) for x in children) + ")"
    pieces = [element.text or ""]
    for child in children:
        pieces.extend([readable(child), child.tail or ""])
    return norm(" ".join(pieces))


def get_source():
    scale_bytes = SCALE.read_bytes()
    scale = json.loads(scale_bytes)
    archive_bytes = ARCHIVE.read_bytes()
    assert sha(archive_bytes) == scale["source_archive"]["sha256"]
    assert len(archive_bytes) == scale["source_archive"]["bytes"]
    with zipfile.ZipFile(ARCHIVE) as archive:
        source = {name: archive.read(name) for name in archive.namelist() if not name.endswith("/")}
    for record in scale["source_files"]:
        data = source[record["path"]]
        assert sha(data) == record["sha256"], record["path"]
        assert len(data) == record["bytes"], record["path"]
    collection = ET.fromstring(source["collections/prealgebra-2e.collection.xml"])
    chapters = []
    for index, ch in enumerate(collection.findall("col:content/col:subcollection", NS), 1):
        chapters.append({"chapter": index, "title": plain(ch.find("md:title", NS)),
                         "module_ids": [x.attrib["document"] for x in ch.findall("col:content/col:module", NS)]})
    assert len(chapters) == 11
    for ch, old in zip(chapters, scale["chapters"]):
        assert (ch["chapter"], ch["title"], ch["module_ids"]) == (old["chapter"], old["title"], old["module_ids"])
    records = {x["module_id"]: x for x in scale["modules"]}
    modules = {mid: ET.fromstring(source[rec["path"]]) for mid, rec in records.items()}
    full_ids = [x.attrib["document"] for x in collection.findall(".//col:module", NS)]
    assert full_ids == scale["candidates"]["complete_source_collection"]["module_ids"]
    for mid, module in modules.items():
        rec = records[mid]
        assert plain(module.find("c:metadata/md:content-id", NS)) == mid
        assert plain(module.find("c:title", NS)) == rec["title"]
        text = plain(module.find("c:content", NS))
        assert sha(text.encode("utf-8")) == rec["extracted_content_text_sha256"], mid
        assert len(text) == rec["extracted_text_codepoints"], mid
    return scale, source, chapters, records, modules, sha(scale_bytes)


def get_edges(modules, records, chapters):
    module_chapter = {mid: ch["chapter"] for ch in chapters for mid in ch["module_ids"]}
    edges = []
    for mid, root in modules.items():
        parents = {child: parent for parent in root.iter() for child in parent}
        for link in root.findall(".//c:content//c:link[@document]", NS):
            target_mid = link.attrib["document"]
            if target_mid == mid:
                continue
            ancestry = []
            cur = link
            while cur in parents:
                cur = parents[cur]
                ancestry.append(cur)
            readiness = next((x for x in ancestry if "be-prepared" in x.get("class", "").split()), None)
            para = next((x for x in ancestry if x.tag == "{" + NS["c"] + "}para"), None)
            target_id = link.get("target-id")
            target_root = modules.get(target_mid)
            target_element = None
            if target_root is not None and target_id:
                target_element = next((x for x in target_root.iter() if x.get("id") == target_id), None)
            item = {
                "source_module": mid, "source_chapter": module_chapter.get(mid),
                "source_member": records[mid]["path"], "source_member_sha256": records[mid]["sha256"],
                "source_element_id": para.get("id") if para is not None else None,
                "classification": "explicit_readiness_remediation" if readiness is not None else "other_cross_reference_not_automatically_a_prerequisite",
                "source_text": readable(para if para is not None else link),
                "readiness_note_id": readiness.get("id") if readiness is not None else None,
                "target_module": target_mid, "target_chapter": module_chapter.get(target_mid),
                "target_element_id": target_id,
                "target_module_present_in_archive": target_root is not None,
                "target_element_resolved": target_element is not None if target_id else None,
            }
            if target_mid in records:
                item.update(target_title=records[target_mid]["title"], target_member=records[target_mid]["path"],
                            target_member_sha256=records[target_mid]["sha256"])
            if target_element is not None and readiness is not None:
                item["target_excerpt"] = readable(target_element)[:900]
                item["target_excerpt_truncated"] = len(readable(target_element)) > 900
            edges.append(item)
    return edges


def package(chapter_ids, chapters, records, edges, extra_ids=()):
    mids = [mid for ch in chapters for mid in ch["module_ids"]
            if ch["chapter"] in chapter_ids or mid in extra_ids]
    selected = set(mids)
    links = [x for x in edges if x["source_module"] in selected and x["classification"] == "explicit_readiness_remediation"]
    missing = [x for x in links if x["target_module"] not in selected]
    return {
        "selected_chapters": chapter_ids, "standalone_module_ids": list(extra_ids),
        "module_order": "source collection order", "module_ids": mids, "module_count": len(mids),
        "source_bytes": sum(records[mid]["bytes"] for mid in mids),
        "tokens": {enc: {rep: sum(records[mid]["tokens"][enc][rep] for mid in mids)
                         for rep in ("content_text", "whole_cnxml")}
                   for enc in ("cl100k_base", "o200k_base")},
        "readiness_link_occurrences": len(links),
        "readiness_module_pairs": len({(x["source_module"], x["target_module"]) for x in links}),
        "readiness_link_occurrences_to_omitted_modules": len(missing),
        "readiness_module_pairs_to_omitted_modules": len({(x["source_module"], x["target_module"]) for x in missing}),
        "readiness_omitted_target_modules": sorted({x["target_module"] for x in missing}),
        "uncovered_readiness_links": missing,
    }


def inspect(module_ids, modules, records, edges):
    for mid in module_ids:
        root = modules[mid]
        print(f"\n{mid}: {records[mid]['title']}")
        print("OBJECTIVES:", [readable(x) for x in root.findall("c:metadata/md:abstract/c:list/c:item", NS)])
        for x in edges:
            if x["source_module"] == mid and x["classification"] == "explicit_readiness_remediation":
                print("READINESS:", x["source_element_id"], x["source_text"], "->", x["target_module"], x["target_element_id"], x.get("target_excerpt", ""))
        for section in root.findall("c:content/c:section", NS)[:3]:
            print("SECTION:", section.get("id"), readable(section.find("c:title", NS)))
            for para in section.findall("c:para", NS)[:3]:
                print("PASSAGE:", para.get("id"), readable(para)[:1600])


PASSAGE_SPECS = [
    ("algebra_evaluation", "m81270", "fs-id1632121", "Defines substitution and evaluation, supporting the language-of-algebra inclusion; a heading alone would not establish this conceptual content."),
    ("lcm_for_fractions", "m81273", "fs-id1731557", "Explicitly states why multiples and primes support addition/subtraction of fractions with different denominators; connects added chapter 2 to retained chapter 4."),
    ("algebra_equation_concept", "m81271", "fs-id1860947", "Defines an equation's solution as a value making it true, not just a calculation procedure. Chapter 8 readiness explicitly points back to this module."),
    ("decimal_place_value", "m81295", "fs-id1512123", "Explains decimal addition by corresponding place values; added chapter 5 is not merely a token overhead allowance."),
    ("fraction_decimal_conversion", "m81298", "fs-id2669580", "Explains why division converts fractions to decimals, which the retained percent module explicitly requests in readiness."),
    ("percent_uses_decimals", "m81306", "fs-id1470137", "Retained chapter 6 explicitly recalls earlier fraction-to-decimal conversion; also corroborated by its readiness links to chapter 5."),
    ("percent_uses_equations", "m81313", "fs-id1471476", "Retained percent applications explicitly use algebraic equations and previous fraction/decimal methods."),
    ("real_properties_bridge", "m81315", "fs-id1166497460114", "Explains that properties of numbers will be used in solving equations; this is source-supported conceptual sequencing, not a mandatory prerequisite theorem."),
    ("real_identity", "m81318", "fs-id1166497505919", "Gives the additive-identity concept. The same module contains zero-division material explicitly requested by slope readiness."),
    ("general_equation_simplification", "m81320", "fs-id1166494591280", "Retained linear-equation work requires simplification before isolating a variable, supporting language/properties content; it does not prove every chapter-7 section is necessary."),
    ("formula_manipulation", "m81329", "fs-id1169946971825", "Precisely defines solving a formula for a specified variable, the omitted readiness topic shared by two retained graphing modules."),
    ("graph_point_solving", "m81345", "eip-761", "Graphing by points selects one variable and solves for the other, corroborating the explicit formula-readiness link."),
    ("intercept_solving", "m81350", "fs-id1742796", "Finding intercepts sets one variable to zero and solves for the other, corroborating the formula-readiness link."),
]


def evidence_passages(source, records, modules):
    result = []
    for evidence_id, mid, element_id, rationale in PASSAGE_SPECS:
        element = next(x for x in modules[mid].iter() if x.get("id") == element_id)
        raw = source[records[mid]["path"]].decode("utf-8")
        marker = re.search(r'\bid=["\']' + re.escape(element_id) + r'["\']', raw)
        assert marker
        text = plain(element)
        result.append({"evidence_id": evidence_id, "module_id": mid, "title": records[mid]["title"],
                       "member": records[mid]["path"], "member_sha256": records[mid]["sha256"],
                       "element_id": element_id, "source_line": raw[:marker.start()].count("\n") + 1,
                       "upstream_url": records[mid]["url"], "source_text": text,
                       "source_text_sha256": sha(text.encode("utf-8")), "readable_text": readable(element),
                       "rationale": rationale,
                       "evidence_obtained": "fresh offline consultation of pinned archived primary source for this audit"})
    return result


def create_audit(scale, source, chapters, records, modules, scale_hash, edges):
    original = package(ORIGINAL, chapters, records, edges)
    expanded = package(EXPANDED, chapters, records, edges)
    closed = package(EXPANDED, chapters, records, edges, ["m81329"])
    assert original["module_ids"] == scale["candidates"]["selected_quantitative_units_scenario"]["module_ids"]
    assert original["tokens"] == scale["candidates"]["selected_quantitative_units_scenario"]["tokens"]
    assert (original["module_count"], original["tokens"]["cl100k_base"]["content_text"]) == (36, 173958)
    assert (expanded["module_count"], expanded["tokens"]["cl100k_base"]["content_text"]) == (56, 275407)
    assert (closed["module_count"], closed["tokens"]["cl100k_base"]["content_text"]) == (57, 283936)
    assert closed["readiness_link_occurrences_to_omitted_modules"] == 0
    assert {(x["source_module"], x["target_module"], x["target_element_id"])
            for x in expanded["uncovered_readiness_links"]} == {
                ("m81345", "m81329", "fs-id1169946893419"),
                ("m81350", "m81329", "fs-id1169946893419")}
    selected = set(closed["module_ids"])
    readiness = [x for x in edges if x["source_module"] in selected and x["classification"] == "explicit_readiness_remediation"]
    assert all(x["target_module_present_in_archive"] and x["target_element_resolved"] for x in readiness)
    assert all("missed" in x["source_text"].lower() and "review" in x["source_text"].lower() for x in readiness)
    for ch, rec in zip(chapters, scale["chapters"]):
        assert len(ch["module_ids"]) == rec["module_count"]
        assert sum(records[m]["bytes"] for m in ch["module_ids"]) == rec["source_bytes"]
        for enc in ("cl100k_base", "o200k_base"):
            for rep in ("content_text", "whole_cnxml"):
                assert sum(records[m]["tokens"][enc][rep] for m in ch["module_ids"]) == rec["tokens"][enc][rep]
    other = [x for x in edges if x["source_module"] in selected and x["classification"] != "explicit_readiness_remediation"]
    other_omitted = [x for x in other if x["target_module"] not in selected]
    evidence = evidence_passages(source, records, modules)
    license_xml = ET.fromstring(source["collections/prealgebra-2e.collection.xml"]).find("col:metadata/md:license", NS)
    original_missing = original["uncovered_readiness_links"]
    closed_by_chapter = Counter(x["target_chapter"] for x in original_missing if x["target_module"] in set(expanded["module_ids"]))
    inventory = []
    for mid in closed["module_ids"]:
        rec = records[mid]
        inventory.append({**rec,
                          "chapter": next(ch["chapter"] for ch in chapters if mid in ch["module_ids"]),
                          "objectives": [readable(x) for x in modules[mid].findall("c:metadata/md:abstract/c:list/c:item", NS)],
                          "objective_locator": "CNXML metadata/md:abstract/list/item (absent for chapter introductions)",
                          "in_original": mid in original["module_ids"], "in_expanded56": mid in expanded["module_ids"]})
    full = scale["candidates"]["complete_source_collection"]
    return {
        "schema": "package-prerequisite-coverage/1.0", "audit_date": "2026-09-09",
        "purpose": "Source-bound scope and readiness coverage for a fixed-budget allocation comparison; not measured learning or translation quality.",
        "generator": {"path": "scripts/build_package_prerequisite_coverage_v1.py", "sha256": sha(Path(__file__).read_bytes())},
        "inputs": {"scale_record": {"path": str(SCALE.relative_to(ROOT)).replace("\\", "/"), "sha256": scale_hash},
                   "source_archive": scale["source_archive"]},
        "upstream": {"repository": scale["source_repository"], "commit": scale["commit"],
                     "collection_url": scale["collection_url"],
                     "collection_member_sha256": sha(source["collections/prealgebra-2e.collection.xml"])},
        "rights": {"work": "OpenStax, Prealgebra 2e", "publisher": "OpenStax, Rice University",
                   "license_label": plain(license_xml), "license_url": license_xml.get("url"),
                   "license_member_sha256": sha(source["LICENSE"]), "readme_member_sha256": sha(source["README.md"]),
                   "notice": "Quoted primary-source passages retain source identity and attribution. Underlying source license is CC BY-NC-SA 4.0; this audit is not a relicensing of that content."},
        "method": {
            "membership": "Reparse chapter order and module membership from archived collection XML; confirm module content-id/title and all archive member hashes against the scale manifest.",
            "text": "Recompute NFC normalized content itertext hash and codepoint count for all 75 modules; retain readable objectives and selected source passages with element IDs.",
            "tokens": "Independently sum existing per-module token records after byte/text-hash binding. This run does not rerun tiktoken. Historical tokenizer is tiktoken 0.11.0. Bundled audit interpreter has no tiktoken; no installation or network attempted.",
            "token_protocol_from_scale": scale["protocol"],
            "readiness_rule": "Only cross-module CNXML links inside class=be-prepared notes are counted as explicit readiness-remediation links; every selected occurrence says missed/review and its target element resolves. These conditional remediation references indicate curricular dependency evidence, not necessary-and-sufficient prerequisites for every learner.",
            "crossrefs": "Other document links are classified separately and are not automatically promoted to prerequisite edges. Internal same-module references are excluded from cross-module counts.",
            "display": "Source text is normalized itertext. Readable display additionally parenthesizes fractions/powers and writes square roots as sqrt(...); it is not rendered mathematical or media QA.",
        },
        "chapters": [{**ch, "tokens": scale["chapters"][ch["chapter"] - 1]["tokens"]} for ch in chapters],
        "packages": {"original36": original, "expanded56": expanded, "readiness_closed57": closed},
        "full_collection_reference": {"module_count": full["module_count"], "tokens": full["tokens"],
                                      "excluded_from_57": [m for m in full["module_ids"] if m not in selected]},
        "addition_summary": {
            "chapters_added_to_36": [2, 5, 7], "modules_added": 20, "cl100k_content_tokens_added": 101449,
            "original_uncovered_readiness_occurrences_supplied_by_added_chapter": dict(sorted(closed_by_chapter.items())),
            "original_uncovered_readiness_occurrences_supplied_total": sum(closed_by_chapter.values()),
            "standalone_module_added_to_56": "m81329", "standalone_cl100k_content_tokens": records["m81329"]["tokens"]["cl100k_base"]["content_text"],
            "claim": "The 57-module alternative closes the mechanically defined explicit cross-module readiness graph for this selected source set. Neither 56 nor 57 is established as a minimum curriculum or as pedagogically prerequisite-complete."
        },
        "expert_review_record": [
            {"choice": "Retain chapter 2 in the expanded proxy", "evidence_ids": ["algebra_evaluation", "lcm_for_fractions", "algebra_equation_concept"],
             "rationale": "Variables, expressions, equality and LCM support retained equations and fraction work. Explicit readiness links from retained modules also point to chapter 2.",
             "rejected_alternative": "Price the original subset plus an arbitrary overhead while treating its conceptual omissions as repaired.",
             "uncertainty": "Whole-chapter inclusion is a transparent costing proxy, not a proven smallest remediation set.", "editorial_confidence": "High for stated source content and links; provisional for whole-chapter package design, not a calibrated probability."},
            {"choice": "Retain chapter 5 in the expanded proxy", "evidence_ids": ["decimal_place_value", "fraction_decimal_conversion", "percent_uses_decimals", "percent_uses_equations"],
             "rationale": "Decimal place value, arithmetic, fraction conversion and decimal equations are explicitly reused by retained percent and equation modules. Chapter 5 also includes ratios/rates, averages/probability and square roots; title-only comparison would miss these outcomes.",
             "rejected_alternative": "Treat percents as independent of omitted decimal and algebra preparation.",
             "uncertainty": "The entire chapter has additional outcomes; equal learning benefits cannot be inferred from equal token counts.", "editorial_confidence": "High for source mapping; provisional for package utility."},
            {"choice": "Retain chapter 7 in the expanded proxy", "evidence_ids": ["real_properties_bridge", "real_identity", "general_equation_simplification"],
             "rationale": "Objectives explicitly cover number classification, commutative/associative/distributive properties, identity/inverses/zero and measurement. Retained slope module m81354 explicitly remediates 0/4 and 4/0 through m81318, so the omission is not supported merely by a chapter title argument.",
             "rejected_alternative": "Declare all of chapter 7 irrelevant because earlier chapters already have arithmetic procedures.",
             "uncertainty": "One explicit readiness edge does not prove every chapter-7 module indispensable; algebraic concepts may be revisited in retained modules.", "editorial_confidence": "High for source content and zero-division link; provisional for whole-chapter design."},
            {"choice": "Add m81329 after expanding to 56 modules", "evidence_ids": ["formula_manipulation", "graph_point_solving", "intercept_solving"],
             "rationale": "Both graphing modules explicitly send failed readiness questions to the same formula-solving example in omitted chapter 9. Adding this actual module, not a percentage overhead, supplies those links; its own readiness targets are already included.",
             "rejected_alternative": "Label the 56-module proxy prerequisite-complete or retain its known missing readiness target to preserve a prior file list.",
             "uncertainty": "Closure applies only to the extracted explicit readiness relation, not every conceptual dependency or unobserved learner need.", "editorial_confidence": "High for deterministic link closure, not a calibrated probability of pedagogical sufficiency."},
        ],
        "source_passages": evidence,
        "module_inventory": inventory,
        "explicit_readiness_links_for_57": readiness,
        "other_cross_references": {"occurrences_from_57": len(other), "occurrences_to_omitted_modules": len(other_omitted),
                                  "omitted_target_modules": sorted({x["target_module"] for x in other_omitted}),
                                  "links_to_omitted_modules": other_omitted},
        "deterministic_checks": {"archive_bytes_and_hash": "pass", "all_recorded_archive_members": len(scale["source_files"]),
                                 "module_content_identity_title_text_hash_and_codepoints": len(modules),
                                 "collection_chapter_membership_and_token_subtotals": "11 chapters pass",
                                 "counts_36_56_57": "pass", "all_57_readiness_targets_resolve": True,
                                 "all_57_readiness_targets_selected": True,
                                 "limitations": "No fresh tokenizer execution, rendered-math audit, translation, learner validation, general crossref closure or proof of minimum/prerequisite-complete curriculum."},
        "state": {"completed": "Source verification, explicit readiness audit, finite scope correction and reproducible evidence outputs.",
                  "next_action": "Use the verified 57-module / 283936 cl100k content-token alternative in allocation sensitivity analysis; main task owns downstream modeling and publication.",
                  "human_review": "Optional later correction opportunity; no human-dependent hold."},
    }


def render_markdown(audit):
    p = audit["packages"]
    lines = ["# OpenStax package prerequisite coverage audit v1", "",
             "The original 36-module selection omits explicit source readiness material. Adding chapters 2, 5 and 7 gives 56 modules but leaves two graphing readiness links to chapter 9. Adding the specific formula-solving module `m81329` gives **57 modules and 283,936 cl100k content tokens**, with all extracted explicit cross-module readiness links internal to that package.", "",
             "This is closure of a defined source-link relation—not a claim that the package is minimal, pedagogically prerequisite-complete, learner-validated, or equivalent in outcomes to the full book.", "",
             "## Verified scope and scale", "", "| Package | Scope | Modules | cl100k content tokens | cl100k whole-CNXML tokens | Omitted readiness links |", "|---|---|---:|---:|---:|---:|"]
    labels = {"original36": "Chapters 1, 3, 4, 6, 8, 11", "expanded56": "Chapters 1–8 and 11", "readiness_closed57": "Chapters 1–8 and 11, plus m81329 from chapter 9"}
    for name, package_data in p.items():
        tok = package_data["tokens"]["cl100k_base"]
        lines.append(f"| {name} | {labels[name]} | {package_data['module_count']} | {tok['content_text']:,} | {tok['whole_cnxml']:,} | {package_data['readiness_link_occurrences_to_omitted_modules']} |")
    lines += ["", "The full collection is 75 modules / 364,270 cl100k content tokens, including the preface and three back-matter modules. Chapter introductions count as modules. Module order is always original collection order; `m81329` falls before chapter 11.", "",
              "Token totals are independently reaggregated historical per-module scale records, after verifying the actual archived module bytes and reproducing every normalized extracted-text hash and codepoint count. **This run does not retokenize.** The scale record used tiktoken 0.11.0; the bundled audit interpreter lacks tiktoken and no network/install was attempted. Content text omits some mathematical structure/media; whole CNXML includes metadata/markup. Neither representation is measured production cost or learning benefit.", "",
              "## Why the added chapters matter", ""]
    for review in audit["expert_review_record"]:
        lines += ["### " + review["choice"], "", review["rationale"], "", "Evidence: " + ", ".join(f"`{e}`" for e in review["evidence_ids"]) + ".", "", "Uncertainty: " + review["uncertainty"], ""]
    a = audit["addition_summary"]
    lines += [f"The three chapters add 20 modules / 101,449 cl100k content tokens and supply {a['original_uncovered_readiness_occurrences_supplied_total']} of the original 28 omitted readiness-link occurrences. Per added chapter: " + ", ".join(f"chapter {ch}: {count}" for ch, count in a["original_uncovered_readiness_occurrences_supplied_by_added_chapter"].items()) + ". `m81329` adds 8,529 tokens and supplies the remaining two links.", "",
              "## Exact remaining links in the 56-module candidate", ""]
    for link in p["expanded56"]["uncovered_readiness_links"]:
        lines += [f"- `{link['source_module']}#{link['source_element_id']}`: “{link['source_text']}” → `{link['target_module']}#{link['target_element_id']}` ({link['target_title']}).", ""]
    lines += ["The target example asks to solve `3x + 2y = 18` for `y`, first when `x = 4` and then in general. Both target IDs resolve in the archived bytes. These are `class=be-prepared` notes with an explicit failed-readiness remediation instruction, not arbitrary narrative cross-references.", "",
              f"The 57-module package has {p['readiness_closed57']['readiness_link_occurrences']} such cross-module link occurrences ({p['readiness_closed57']['readiness_module_pairs']} unique module pairs), all with included, resolved targets. The added module’s own readiness targets are `m81303` (unit rate), `m81322` (linear equation), and `m81308` (simple interest), already included.", "",
              "## Residual scope and limits", "",
              "Chapter 10, the other seven chapter-9 modules, the preface and three back-matter modules remain outside the 57-module package. The source-readiness test does not require them, but absence of a readiness link is not evidence that a topic has no conceptual dependencies. Whole-chapter additions also include outcomes beyond direct remediation; this audit does not prove the package smallest or estimate additional learning.", "",
              f"There are {audit['other_cross_references']['occurrences_to_omitted_modules']} other cross-reference occurrences from the 57-module set to omitted modules; target modules: " + (", ".join(f"`{m}`" for m in audit["other_cross_references"]["omitted_target_modules"]) or "none") + ". They remain recorded separately in JSON; no general cross-reference closure was imposed.", "",
              "## Consulted primary-source passages", "",
              "Below, text is mechanically extracted for evidence, with fractions/powers made readable. Element IDs and archived-member hashes bind every passage; this display is not a substitute for rendered mathematics.", ""]
    for evidence in audit["source_passages"]:
        lines += [f"### {evidence['evidence_id']}", "", f"{evidence['title']} — `{evidence['module_id']}#{evidence['element_id']}`, source line {evidence['source_line']}.", "",
                  "> " + evidence["readable_text"], "", evidence["rationale"], ""]
    lines += ["## Identity, rights and reproducibility", "",
              f"Source: OpenStax, *Prealgebra 2e*, OpenStax/Rice University. Pinned repository: [{audit['upstream']['repository']}]({audit['upstream']['repository']}); commit `{audit['upstream']['commit']}`. [Collection XML]({audit['upstream']['collection_url']}).", "",
              f"The archived collection identifies the license as [{audit['rights']['license_label']}]({audit['rights']['license_url']}). The excerpts retain source attribution; this audit does not relicense the underlying source.", "",
              f"Archive SHA-256: `{audit['inputs']['source_archive']['sha256']}`. Scale-record SHA-256: `{audit['inputs']['scale_record']['sha256']}`. Collection-member SHA-256: `{audit['upstream']['collection_member_sha256']}`.", "",
              "The JSON retains module/member hashes, objective inventories, exact target IDs, all selected readiness links, separately classified omitted crossrefs, selected source passages, an expert review record, limitations and next action. The generator verifies every recorded archive member and all 75 module identities/text hashes, then verifies chapter subtotals and the 36/56/57 counts. `--check` regenerates both outputs in memory and requires exact byte equality; the default command writes deterministic UTF-8 outputs.", "",
              "Run: `python -X utf8 scripts/build_package_prerequisite_coverage_v1.py`, then repeat with `--check`. No TeX, network, publication or additional worker is used. Human expert review is a later improvement opportunity, not a release or production hold.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--inspect", nargs="+")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    scale, source, chapters, records, modules, scale_hash = get_source()
    edges = get_edges(modules, records, chapters)
    if args.inspect:
        inspect(args.inspect, modules, records, edges)
        return
    audit = create_audit(scale, source, chapters, records, modules, scale_hash, edges)
    outputs = {OUT_JSON: (json.dumps(audit, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
               OUT_MD: render_markdown(audit).encode("utf-8")}
    for path, data in outputs.items():
        if args.check:
            assert path.read_bytes() == data, f"Deterministic replay differs: {path.name}"
        else:
            path.write_bytes(data)
    print(json.dumps({"mode": "check" if args.check else "write", "result": "pass",
                      "packages": {name: {"modules": p["module_count"], "cl100k_content_tokens": p["tokens"]["cl100k_base"]["content_text"],
                                           "omitted_readiness_links": p["readiness_link_occurrences_to_omitted_modules"]}
                                   for name, p in audit["packages"].items()},
                      "readiness_links_57": len(audit["explicit_readiness_links_for_57"]),
                      "other_omitted_crossrefs": audit["other_cross_references"]["occurrences_to_omitted_modules"],
                      "outputs": [{"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": sha(data)} for path, data in outputs.items()]}, indent=2))


if __name__ == "__main__":
    main()
