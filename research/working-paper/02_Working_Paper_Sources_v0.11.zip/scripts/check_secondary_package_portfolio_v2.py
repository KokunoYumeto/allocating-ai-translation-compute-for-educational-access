"""Independent v2 audit adapted from the preserved v1 mask checker.

No producer import/execution, network, credentials or publication. Enumerates
full-package masks and every disjoint companion submask for both 24-case grids.
The only runtime write is the exact named v2 independent review JSON.
"""
from fractions import Fraction
from math import isclose, lcm
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
PORTFOLIO = "structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json"
FRONTIER = "structured/TARGET_SPECIFIC_ALLOCATION_FRONTIER_v1.json"
SCALE = "structured/OPENSTAX_PACKAGE_SCALE_20260904.json"
PRODUCER = "scripts/build_secondary_package_portfolio_v2.py"
REVIEWER = "scripts/check_secondary_package_portfolio_v2.py"
OUTPUT = "qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v2.json"
PRIOR = "structured/SECONDARY_PACKAGE_PORTFOLIO_v1.json"
PRIOR_REVIEWER = "scripts/check_secondary_package_portfolio_v1.py"
PRIOR_PRODUCER = "scripts/build_secondary_package_portfolio_v1.py"
PREREQUISITES = "structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json"
CHECKS = []


def check(label, condition):
    if not condition:
        raise AssertionError(label)
    CHECKS.append(label)


def binding(name):
    raw = (ROOT / name).read_bytes()
    return {"path": name, "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest().upper()}


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def exact(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def mask_sums(values):
    result = [0] * (1 << len(values))
    for mask in range(1, len(result)):
        bit = mask & -mask
        result[mask] = result[mask ^ bit] + values[bit.bit_length() - 1]
    return result


def choices(full_mask, companion_mask, count):
    return tuple(2 if full_mask & (1 << i) else
                 1 if companion_mask & (1 << i) else 0
                 for i in range(count))


def audit_scenarios(portfolio, rows, short_tokens, full_tokens, edition):
    # Start from workload per 100,000 source tokens; no producer scale constants.
    workloads = [Fraction(r["workload_base_fecu"]) for r in rows]
    needs = [Fraction(r["need_context_base"]) for r in rows]
    full_cost = [w * Fraction(full_tokens, 100000) for w in workloads]
    companion_cost = [w * Fraction(short_tokens, 100000) + fc * Fraction(1, 20)
                      for w, fc in zip(workloads, full_cost)]
    cost_den = lcm(*(c.denominator for c in full_cost + companion_cost))
    full_sums = mask_sums([int(c * cost_den) for c in full_cost])
    companion_sums = mask_sums([int(c * cost_den) for c in companion_cost])
    ratios = (Fraction(1, 2), Fraction(3, 4), Fraction(1))
    expected_keys = {(ratio, setup, budget) for ratio in ratios for setup in (0, 2)
                     for budget in (2000000, 5000000, 10000000, 20000000)}
    reported = {(Fraction(str(s["companion_relative_benefit"])), s["setup_rate"], s["budget"]): s
                for s in portfolio["scenarios"]}
    check(edition + ":exact_24_scenario_grid", len(portfolio["scenarios"]) == len(reported) == 24
          and set(reported) == expected_keys)
    results = []
    count = len(rows)
    all_mask = (1 << count) - 1
    total_evaluations = 0
    for ratio, setup, budget in sorted(expected_keys):
        benefit_den = lcm(*(v.denominator for v in needs + [n * ratio for n in needs]))
        full_benefit = mask_sums([int(n * benefit_den) for n in needs])
        companion_benefit = mask_sums([int(n * ratio * benefit_den) for n in needs])
        best = None
        uniform = {"companion": None, "complete": None}
        evaluations = feasible = 0
        for full_mask in range(all_mask + 1):
            available = all_mask ^ full_mask
            companion_mask = available
            while True:
                evaluations += 1
                # A full source includes every companion module. With no full
                # package, the same companion source is prepared once, not once per route.
                union_tokens = full_tokens if full_mask else short_tokens if companion_mask else 0
                cost = full_sums[full_mask] + companion_sums[companion_mask] + setup * union_tokens * cost_den
                if cost <= budget * cost_den:
                    feasible += 1
                    benefit = full_benefit[full_mask] + companion_benefit[companion_mask]
                    selection = choices(full_mask, companion_mask, count)
                    candidate = (benefit, -cost, tuple(-k for k in selection), union_tokens, selection)
                    if best is None or candidate[:3] > best[:3]:
                        best = candidate
                    for label, included in (("companion", not full_mask), ("complete", not companion_mask)):
                        if included and (uniform[label] is None or candidate[:2] > uniform[label][:2]):
                            uniform[label] = candidate
                if not companion_mask:
                    break
                companion_mask = (companion_mask - 1) & available
        total_evaluations += evaluations
        expected = reported[(ratio, setup, budget)]
        prefix = edition + ":" + expected["id"] + ":"
        check(prefix + "enumerated_all_selections", evaluations == 3 ** count == 19683)
        check(prefix + "correct_id", expected["id"] == f"q{int(ratio * 4)}/4_setup{setup}_B{budget}")
        selection = [{"route_id": r["route_id"], "language": r["language_profile"],
                      "package": "companion" if k == 1 else "complete"}
                     for r, k in zip(rows, best[4]) if k]
        benefit = Fraction(best[0], benefit_den)
        cost = Fraction(-best[1], cost_den)
        check(prefix + "optimal_selection", selection == expected["selection"])
        check(prefix + "optimal_exact_cost", cost == Fraction(**expected["cost_exact"]))
        check(prefix + "optimal_exact_benefit", benefit == Fraction(**expected["coefficient_exact"]))
        check(prefix + "cost_float_projection", float(cost) == expected["cost"])
        check(prefix + "benefit_float_projection", float(benefit) == expected["relative_context_benefit_coefficient"])
        check(prefix + "shared_source_union", best[3] == expected["source_union_tokens"])
        comparator_evidence = []
        check(prefix + "two_uniform_comparators", len(expected["uniform_comparators"]) == 2 and
              {u["package"] for u in expected["uniform_comparators"]} == set(uniform))
        for u in expected["uniform_comparators"]:
            independent = uniform[u["package"]]
            uc, ub = Fraction(-independent[1], cost_den), Fraction(independent[0], benefit_den)
            check(prefix + "uniform_" + u["package"], float(uc) == u["cost"] and float(ub) == u["coefficient"])
            comparator_evidence.append({"package": u["package"], "exact_cost": exact(uc), "exact_benefit": exact(ub)})
        best_uniform = max(Fraction(v[0], benefit_den) for v in uniform.values())
        gain = 100 * (benefit / best_uniform - 1) if best_uniform else Fraction(0)
        check(prefix + "gain_percent", isclose(float(gain), expected["gain_over_best_uniform_percent"], rel_tol=5e-13, abs_tol=1e-12))
        check(prefix + "no_observed_people_claim", expected["observed_people_helped"] is None)
        results.append({"id": expected["id"], "status": "PASS", "selection": selection,
                        "enumerated_selections": evaluations, "feasible_selections": feasible,
                        "cost_exact": exact(cost), "benefit_coefficient_exact": exact(benefit),
                        "source_union_tokens": best[3], "gain_over_best_uniform_percent_exact": exact(gain),
                        "uniform_comparators": comparator_evidence})

    return results, total_evaluations, cost_den


def main():
    CHECKS.clear()
    inputs = (PORTFOLIO, PRIOR, FRONTIER, SCALE, PRODUCER, PRIOR_PRODUCER,
              PRIOR_REVIEWER, PREREQUISITES)
    original_bindings = [binding(p) for p in inputs]
    portfolio, old, frontier, scale = load(PORTFOLIO), load(PRIOR), load(FRONTIER), load(SCALE)
    coverage = load(PREREQUISITES)
    check("coverage_schema", coverage["schema"] == "package-prerequisite-coverage/1.0")
    check("coverage_same_scale_binding", coverage["inputs"]["scale_record"] == {
        "path": SCALE, "sha256": binding(SCALE)["sha256"]})
    for edition, data, required in (
            ("v2", portfolio, {FRONTIER, SCALE, PRODUCER, PREREQUISITES}),
            ("v1", old, {FRONTIER, SCALE, PRIOR_PRODUCER})):
        source_bindings = data["source_bindings"]
        check(edition + ":exact_source_binding_set",
              len(source_bindings) == len(required) and {b["path"] for b in source_bindings} == required)
        for item in source_bindings:
            check(edition + ":source_binding:" + item["path"], binding(item["path"]) == item)
    rows = [r for r in frontier["rows"] if r["package_id"] == "Q-CATCHUP"]
    check("nine_unique_source_rows", len(rows) == len({r["route_id"] for r in rows}) == 9)
    check("both_editions_preserve_reference_rows_without_need_deduction",
          rows == portfolio["reference_rows"] == old["reference_rows"])
    check("same_endpoint_stage_and_comparison_set", len({
        (r["endpoint_id"], r["stage"], r["comparison_set_id"]) for r in rows}) == 1)
    other = [r["route_id"] for r in frontier["rows"] if r["package_id"] != "Q-CATCHUP"]
    check("six_other_routes_retained", len(other) == 6 and
          other == portfolio["other_numeric_routes_retained"] == old["other_numeric_routes_retained"])
    check("common_100k_workload_basis", all(
        r["workload_proxy_row_id"].startswith("COMMON100K:") and
        r["workload_unit"] == "fresh_equivalent_token_events" for r in rows))
    check("positive_source_defined_context_estimates", all(
        Fraction(r["need_context_base"]) > 0 and
        r["need_endpoint_or_measure"] == "represented_below_level2_students_estimate" for r in rows))

    modules = {m["module_id"]: m for m in scale["modules"]}
    check("unique_source_module_inventory", len(modules) == len(scale["modules"]))
    original = scale["candidates"]["selected_quantitative_units_scenario"]
    full = scale["candidates"]["complete_source_collection"]
    selected_chapters = [1, 2, 3, 4, 5, 6, 7, 8, 11]
    chapters = [c for c in scale["chapters"] if c["chapter"] in selected_chapters]
    intermediate_ids = [m for c in chapters for m in c["module_ids"]]
    closed = coverage["packages"]["readiness_closed57"]
    intermediate = coverage["packages"]["expanded56"]
    ids = closed["module_ids"]
    check("coverage_selected_chapters", closed["selected_chapters"] == selected_chapters)
    check("coverage_standalone_formula_lesson", closed["standalone_module_ids"] == ["m81329"])
    check("exact_nine_chapter_set", [c["chapter"] for c in chapters] == selected_chapters)
    check("intermediate_56_unique_modules", len(intermediate_ids) == len(set(intermediate_ids)) == 56)
    check("final_57_unique_modules", len(ids) == len(set(ids)) == closed["module_count"] == 57)
    check("final_source_set", set(ids) == set(intermediate_ids) | {"m81329"})
    check("canonical_collection_order", ids == [m for m in full["module_ids"] if m in set(ids)])
    check("original_36_unique_modules", len(original["module_ids"]) == len(set(original["module_ids"])) == 36)
    check("nested_source_subsets", set(original["module_ids"]) < set(intermediate_ids)
          < set(ids) < set(full["module_ids"]))
    check("twenty_one_added_modules", len(set(ids) - set(original["module_ids"])) == 21)
    check("added_chapters_2_5_7", set(selected_chapters) - set(original["selected_chapters"]) == {2, 5, 7})
    check("intermediate_coverage_module_order", intermediate["module_ids"] == intermediate_ids)
    for label, package in (("original_companion", original), ("intermediate56", intermediate),
                           ("readiness_closed57", closed), ("complete", full)):
        pids = package["module_ids"]
        check(label + ":unique_modules", len(pids) == len(set(pids)) == package["module_count"])
        check(label + ":source_bytes_sum", sum(modules[m]["bytes"] for m in pids) == package["source_bytes"])
        for tokenizer in ("cl100k_base", "o200k_base"):
            for representation in ("content_text", "whole_cnxml"):
                check(label + ":token_sum:" + tokenizer + ":" + representation,
                      sum(modules[m]["tokens"][tokenizer][representation] for m in pids)
                      == package["tokens"][tokenizer][representation])
    for chapter in chapters:
        for tokenizer in ("cl100k_base", "o200k_base"):
            for representation in ("content_text", "whole_cnxml"):
                check(f"chapter_{chapter['chapter']}:token_sum:" + tokenizer + ":" + representation,
                      sum(modules[m]["tokens"][tokenizer][representation] for m in chapter["module_ids"])
                      == chapter["tokens"][tokenizer][representation])
    coverage_modules = {m["module_id"]: m for m in coverage["module_inventory"]}
    check("coverage_module_inventory_exact_set", len(coverage_modules) == len(coverage["module_inventory"]) == 57
          and set(coverage_modules) == set(ids))
    for module_id, item in coverage_modules.items():
        check("coverage_module_binding:" + module_id,
              all(item[key] == value for key, value in modules[module_id].items()))
    links = coverage["explicit_readiness_links_for_57"]
    check("132_explicit_readiness_occurrences", len(links) == closed["readiness_link_occurrences"] == 132)
    check("108_distinct_readiness_module_pairs",
          len({(r["source_module"], r["target_module"]) for r in links})
          == closed["readiness_module_pairs"] == 108)
    check("no_omitted_explicit_readiness_targets",
          closed["readiness_link_occurrences_to_omitted_modules"] == 0
          and closed["readiness_module_pairs_to_omitted_modules"] == 0
          and closed["readiness_omitted_target_modules"] == []
          and closed["uncovered_readiness_links"] == []
          and all(r["source_module"] in ids and r["target_module"] in ids
                  and r["target_element_resolved"] is True
                  and r["target_module_present_in_archive"] is True
                  and r["source_member_sha256"] == modules[r["source_module"]]["sha256"]
                  and r["target_member_sha256"] == modules[r["target_module"]]["sha256"] for r in links))
    check("intermediate_two_readiness_links_require_formula_lesson",
          intermediate["readiness_link_occurrences_to_omitted_modules"] == 2
          and intermediate["readiness_omitted_target_modules"] == ["m81329"]
          and {(r["source_module"], r["target_module"]) for r in intermediate["uncovered_readiness_links"]}
          == {("m81345", "m81329"), ("m81350", "m81329")})
    old_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in original["module_ids"])
    intermediate_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in intermediate_ids)
    short_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in ids)
    full_tokens = sum(modules[m]["tokens"]["cl100k_base"]["content_text"] for m in full["module_ids"])
    check("expected_source_token_counts", (old_tokens, intermediate_tokens, short_tokens, full_tokens)
          == (173958, 275407, 283936, 364270))
    for edition, data, tokens, selected in (
            ("v1", old, old_tokens, original["selected_chapters"]),
            ("v2", portfolio, short_tokens, selected_chapters)):
        metadata = {
            "companion_source_tokens": tokens, "complete_source_tokens": full_tokens,
            "companion_extra_full_work_share": 0.05, "selected_chapters": selected}
        if edition == "v2":
            metadata.update(extra_module_ids=closed["standalone_module_ids"], module_ids=ids, module_count=57)
        check(edition + ":package_metadata", data["packages"] == metadata)
        check(edition + ":declared_enumeration_size", data["enumerated_selections"] == 19683)

    results, total_evaluations, cost_den = audit_scenarios(portfolio, rows, short_tokens, full_tokens, "v2")
    prior_results, prior_evaluations, prior_cost_den = audit_scenarios(old, rows, old_tokens, full_tokens, "v1")
    before = {r["id"]: r for r in prior_results}
    comparison = []
    for result in results:
        previous = before[result["id"]]
        old_selection = {r["route_id"]: r for r in previous["selection"]}
        new_selection = {r["route_id"]: r for r in result["selection"]}
        changes = [{"route_id": r["route_id"], "language": r["language_profile"],
                    "v1_package": old_selection.get(r["route_id"], {}).get("package", "none"),
                    "v2_package": new_selection.get(r["route_id"], {}).get("package", "none")}
                   for r in rows if old_selection.get(r["route_id"], {}).get("package")
                   != new_selection.get(r["route_id"], {}).get("package")]
        old_benefit = Fraction(**previous["benefit_coefficient_exact"])
        new_benefit = Fraction(**result["benefit_coefficient_exact"])
        old_cost, new_cost = Fraction(**previous["cost_exact"]), Fraction(**result["cost_exact"])
        check(result["id"] + ":no_improvement_from_only_increased_companion_cost",
              new_benefit <= old_benefit)
        comparison.append({
            "id": result["id"], "selection_changed": bool(changes), "route_changes": changes,
            "v1_selection": previous["selection"], "v2_selection": result["selection"],
            "v1_coefficient_exact": exact(old_benefit), "v2_coefficient_exact": exact(new_benefit),
            "coefficient_delta_exact": exact(new_benefit - old_benefit),
            "v1_cost_exact": exact(old_cost), "v2_cost_exact": exact(new_cost),
            "cost_delta_exact": exact(new_cost - old_cost)})
    old_threshold = Fraction(old_tokens, full_tokens) + Fraction(1, 20)
    intermediate_threshold = Fraction(intermediate_tokens, full_tokens) + Fraction(1, 20)
    new_threshold = Fraction(short_tokens, full_tokens) + Fraction(1, 20)
    check("analytical_v1_variable_cost_break_even", isclose(float(old_threshold), 0.527552365, abs_tol=1e-9, rel_tol=0))
    check("analytical_intermediate56_variable_cost_break_even", isclose(float(intermediate_threshold), 0.80605183, abs_tol=1e-8, rel_tol=0))
    check("analytical_v2_variable_cost_break_even", new_threshold == Fraction(604299, 728540))
    check("analytical_threshold_increment", new_threshold - old_threshold == Fraction(109978, 364270))
    check("expanded_package_is_not_claimed_pedagogically_complete", any(
        "not a proven minimum or a claim of complete pedagogical prerequisites" in a
        for a in portfolio["assumptions"]))
    check("no_missing_language_exclusion_flag", portfolio["missing_evidence_exclusion"] is False
          and all(r["exclusion_allowed"] == "False" for r in frontier["rows"]))
    check("no_global_rank_or_need_deduction", portfolio["global_rank_emitted"] is False
          and portfolio["all_worldwide_comparisons_unchanged"] is True
          and portfolio["local_case_study_need_deduction"] == 0)
    check("not_worldwide_population_label", "NOT worldwide language populations" in portfolio["scope"])
    check("not_physical_compute_label", "not physical compute or money" in portfolio["cost_unit"])
    check("uniform_benefit_hypotheses_not_national_ability", any(
        "uniform hypotheses, not estimates or national learning differences" in a for a in portfolio["assumptions"]))
    check("common_unmeasured_effect_label", any("common unmeasured positive" in a for a in portfolio["assumptions"]))
    check("no_claim_of_language_readership", any("No claim that whole country context equals exact language readership" in a
          for a in portfolio["assumptions"]))
    check("disjoint_survey_frames_explicit_assumption", any("survey frames treated as disjoint" in a
          for a in portfolio["assumptions"]))
    check("all_input_bytes_unchanged", original_bindings == [binding(p) for p in inputs])
    changed_selections = sum(c["selection_changed"] for c in comparison)
    changed_coefficients = sum(Fraction(**c["coefficient_delta_exact"]) != 0 for c in comparison)
    review = {
        "schema": "secondary-package-portfolio-independent-review/2.0",
        "status": "PASS_EXACT_FINITE_SCENARIOS_NOT_EMPIRICAL_OR_WORLDWIDE_OPTIMUM",
        "source_bindings": original_bindings, "reviewer_binding": binding(REVIEWER),
        "scope": "Independent arithmetic and internal interpretation review of both proxy versions in the named nine-context subset only.",
        "method": "No producer import/execution. Exact Fraction formula derivation, dynamic integer units, independent full-mask/disjoint-companion-submask enumeration of all 3^9 choices in each of 24 cases for each version.",
        "formulas": {
            "complete_variable": "C_100k_i * T_full / 100000",
            "companion_variable": "C_100k_i * T_companion / 100000 + (1/20) * complete_variable_i",
            "source_preparation": "setup_rate * tokens(union of selected source modules), charged once; zero for empty portfolio",
            "benefit_coefficient": "sum(N_i for complete) + ratio * sum(N_i for companion); multiply by a common still-unmeasured gain for a conditional benefit total",
            "tie_break": "maximize coefficient, then minimize cost, then lexicographically minimize per-route 0/1/2 choices",
            "variable_cost_break_even": "companion/full benefit ratio = T_companion/T_full + 1/20; equal within-context benefit per variable workload, excluding shared setup and finite-budget effects"},
        "source_subset": {
            "selected_chapters": selected_chapters, "companion_module_ids": ids,
            "companion_module_count": len(ids), "complete_module_count": len(full["module_ids"]),
            "companion_tokens": short_tokens, "complete_tokens": full_tokens,
            "source_bytes": sum(modules[m]["bytes"] for m in ids),
            "added_chapters": [2, 5, 7], "extra_module_ids": ["m81329"], "added_module_count": 21,
            "added_content_tokens": short_tokens - old_tokens,
            "explicit_readiness_link_occurrences": len(links),
            "explicit_readiness_link_occurrences_to_omitted_modules": 0,
            "ratio_variable_cost_companion_to_full_exact": exact(new_threshold)},
        "comparison_to_v1": {
            "v1_companion_tokens": old_tokens, "v2_companion_tokens": short_tokens,
            "intermediate56_companion_tokens": intermediate_tokens,
            "intermediate56_variable_cost_break_even_exact": exact(intermediate_threshold),
            "intermediate56_variable_cost_break_even": float(intermediate_threshold),
            "intermediate56_status": "Source report preserved; analytical cost comparison only, not a priced v2 scenario package.",
            "v1_variable_cost_break_even_exact": exact(old_threshold),
            "v1_variable_cost_break_even": float(old_threshold),
            "v2_variable_cost_break_even_exact": exact(new_threshold),
            "v2_variable_cost_break_even": float(new_threshold),
            "threshold_increase_exact": exact(new_threshold - old_threshold),
            "changed_selection_scenarios": changed_selections,
            "changed_coefficient_scenarios": changed_coefficients,
            "scenarios": comparison},
        "integer_cost_denominator": cost_den, "v1_integer_cost_denominator": prior_cost_den,
        "total_selection_evaluations": total_evaluations + prior_evaluations,
        "v2_selection_evaluations": total_evaluations, "v1_selection_evaluations": prior_evaluations,
        "scenario_count": len(results), "prior_scenario_count": len(prior_results),
        "check_count": len(CHECKS), "checks": CHECKS, "findings": [],
        "interpretation": [
            "All 24 reported v2 selections, exact costs, exact objective coefficients, source unions and uniform comparator values agree with independent exhaustive enumeration. The 24 preserved v1 scenarios were independently recomputed by the same separate mask method for an exact paired comparison.",
            "Adding chapters 2, 5 and 7 plus formula-rearrangement lesson m81329 increases the proxy from 36 to 57 modules and from 173,958 to 283,936 content tokens. The intermediate 56-module, 275,407-token alternative remains in the source report. Source counts are checked against the existing module inventory, not independently retokenized source bytes.",
            "All 132 explicitly recorded readiness-link occurrences in the 57-module source report have included source and target modules, resolved target elements and matching source/target module hashes. The 56-module alternative omitted two links from graphing lessons to m81329. This is a check of the recorded link inventory, not an independent source-link extraction.",
            f"The within-context variable-cost break-even companion/full benefit ratio rises from {float(old_threshold):.12f} to {float(new_threshold):.12f}. The 0.75 benefit hypothesis changes from above to below this threshold; setup and indivisible finite-budget choices can still make an optimal portfolio mix packages.",
            f"Concrete paired route/package changes occur in {changed_selections} of 24 scenarios; the optimum objective coefficient decreases in {changed_coefficients}. Exact route changes, costs and objective deltas are recorded per scenario.",
            "The expanded alternative supplies additional prerequisite content and closes the explicitly recorded readiness links, but is not certified as a proven minimum, complete dependency closure or pedagogically complete package.",
            "The nine Q-CATCHUP rows remain exact secondary survey/proficiency context estimates, not worldwide language populations or exact edition audiences. Disjoint country survey frames are an explicit bounded scenario assumption.",
            "All six other numeric routes remain retained. Missing evidence causes no zero-need deduction or exclusion, and the worldwide comparisons are unchanged; no global funding winner is established.",
            "Logical fresh-equivalent token workload is not accelerator-seconds, energy, money, provider usage or measured physical compute. The common gain and companion ratios remain uniform, unmeasured hypotheses rather than observed learning or nationality-specific ability."
        ],
        "validation_boundary": "No network, producer import/execution, source retokenization, source-link extraction, semantic source audit, participant evidence or publication. The prerequisite coverage artifact and its module/link accounting are checked against the recorded inventory, not independently semantically adjudicated.",
        "completed_work": "Both finite 24-scenario grids and their direct paired allocation/break-even comparison independently recomputed.",
        "unresolved_work": [], "next_executable_action": "Parent may consume the verified arithmetic and exact paired changes without a human-dependent review pause.",
        "scenarios": results, "prior_scenarios": prior_results}
    (ROOT / OUTPUT).write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": review["status"], "scenario_count": len(results),
                      "selection_evaluations": review["total_selection_evaluations"],
                      "changed_selection_scenarios": changed_selections,
                      "changed_coefficient_scenarios": changed_coefficients,
                      "check_count": len(CHECKS), "review": binding(OUTPUT),
                      "reviewer": binding(REVIEWER)}, indent=2))


if __name__ == "__main__":
    main()
