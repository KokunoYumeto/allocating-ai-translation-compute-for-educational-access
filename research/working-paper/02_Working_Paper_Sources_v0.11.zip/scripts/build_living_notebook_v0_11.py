"""No-overwrite v0.11 build with source-specific and prerequisite-cost findings.

Third-party Thai/Malay/Khmer PDFs are research witnesses, not public payloads.
Their relative identities and observed passages are recorded in original
reports; inherited openly licensed OpenStax source retains its own terms.
"""
from pathlib import Path
import importlib.util
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def configure():
    path = ROOT / 'scripts/build_living_notebook_v0_10.py'
    source = path.read_text(encoding='utf-8')
    source = source.replace('v0_10','v0_11').replace('v0.10','v0.11').replace('0.10.0','0.11.0').replace('v010','v011')
    spec = importlib.util.spec_from_loader('v011_adapter', loader=None)
    wrapper = importlib.util.module_from_spec(spec)
    wrapper.__file__ = str(Path(__file__).resolve())
    sys.modules[spec.name] = wrapper
    exec(compile(source, wrapper.__file__, 'exec'), wrapper.__dict__)
    mod = wrapper.configure()
    mod.NEW_SOURCES += (
        'scripts/build_living_notebook_v0_10.py',
        'scripts/build_living_notebook_v0_11.py',
        'THAI_MALAY_SECONDARY_PACKAGE_v1.md',
        'structured/THAI_MALAY_SECONDARY_PACKAGE_v1.json',
        'scripts/build_thai_malay_secondary_evidence_v1.py',
        'KHMER_SECONDARY_PACKAGE_v1.md',
        'structured/KHMER_SECONDARY_PACKAGE_v1.json',
        'PACKAGE_PREREQUISITE_COVERAGE_v1.md',
        'structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json',
        'scripts/build_package_prerequisite_coverage_v1.py',
        'SECONDARY_PACKAGE_PORTFOLIO_v1.md',
        'structured/SECONDARY_PACKAGE_PORTFOLIO_v1.json',
        'scripts/build_secondary_package_portfolio_v1.py',
        'scripts/check_secondary_package_portfolio_v1.py',
        'qa/SECONDARY_PACKAGE_PORTFOLIO_QA_v1.json',
        'qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v1.json',
        'SECONDARY_PACKAGE_PORTFOLIO_v2.md',
        'structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json',
        'scripts/build_secondary_package_portfolio_v2.py',
        'scripts/check_secondary_package_portfolio_v2.py',
        'qa/SECONDARY_PACKAGE_PORTFOLIO_QA_v2.json',
        'qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v2.json',
        'qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v2.md',
        'SECONDARY_PACKAGE_SOURCE_AND_ALLOCATION_SECTION_v1.md',
        'qa/SECONDARY_SOURCE_AND_ALLOCATION_REVIEW_v1.md',
    )
    original = mod.compose_paper
    def compose():
        paper = original()
        for section in ('7.16','7.17'):
            assert len(re.findall(r'^### '+re.escape(section)+r'\s',paper,re.M))==1
        literal = (ROOT/'SECONDARY_PACKAGE_SOURCE_AND_ALLOCATION_SECTION_v1.md').read_text(encoding='utf-8').strip()
        assert paper.count(literal)==1, 'Current source/allocation section differs from verified literal'
        return paper
    mod.compose_paper = compose
    old_template = mod.prepared_template
    def prepared():
        source = old_template()
        return (source.replace('2026-09-08', '2026-09-09')
                .replace('8 September 2026', '9 September 2026')
                .replace('fixed_time = (2026, 9, 8, 0, 0, 0)',
                         'fixed_time = (2026, 9, 9, 0, 0, 0)'))
    mod.prepared_template = prepared
    return mod

if __name__ == '__main__':
    raise SystemExit(configure().main())
