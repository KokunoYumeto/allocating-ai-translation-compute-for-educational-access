# OpenStax package prerequisite coverage audit v1

The original 36-module selection omits explicit source readiness material. Adding chapters 2, 5 and 7 gives 56 modules but leaves two graphing readiness links to chapter 9. Adding the specific formula-solving module `m81329` gives **57 modules and 283,936 cl100k content tokens**, with all extracted explicit cross-module readiness links internal to that package.

This is closure of a defined source-link relation—not a claim that the package is minimal, pedagogically prerequisite-complete, learner-validated, or equivalent in outcomes to the full book.

## Verified scope and scale

| Package | Scope | Modules | cl100k content tokens | cl100k whole-CNXML tokens | Omitted readiness links |
|---|---|---:|---:|---:|---:|
| original36 | Chapters 1, 3, 4, 6, 8, 11 | 36 | 173,958 | 1,411,608 | 28 |
| expanded56 | Chapters 1–8 and 11 | 56 | 275,407 | 2,138,228 | 2 |
| readiness_closed57 | Chapters 1–8 and 11, plus m81329 from chapter 9 | 57 | 283,936 | 2,197,901 | 0 |

The full collection is 75 modules / 364,270 cl100k content tokens, including the preface and three back-matter modules. Chapter introductions count as modules. Module order is always original collection order; `m81329` falls before chapter 11.

Token totals are independently reaggregated historical per-module scale records, after verifying the actual archived module bytes and reproducing every normalized extracted-text hash and codepoint count. **This run does not retokenize.** The scale record used tiktoken 0.11.0; the bundled audit interpreter lacks tiktoken and no network/install was attempted. Content text omits some mathematical structure/media; whole CNXML includes metadata/markup. Neither representation is measured production cost or learning benefit.

## Why the added chapters matter

### Retain chapter 2 in the expanded proxy

Variables, expressions, equality and LCM support retained equations and fraction work. Explicit readiness links from retained modules also point to chapter 2.

Evidence: `algebra_evaluation`, `lcm_for_fractions`, `algebra_equation_concept`.

Uncertainty: Whole-chapter inclusion is a transparent costing proxy, not a proven smallest remediation set.

### Retain chapter 5 in the expanded proxy

Decimal place value, arithmetic, fraction conversion and decimal equations are explicitly reused by retained percent and equation modules. Chapter 5 also includes ratios/rates, averages/probability and square roots; title-only comparison would miss these outcomes.

Evidence: `decimal_place_value`, `fraction_decimal_conversion`, `percent_uses_decimals`, `percent_uses_equations`.

Uncertainty: The entire chapter has additional outcomes; equal learning benefits cannot be inferred from equal token counts.

### Retain chapter 7 in the expanded proxy

Objectives explicitly cover number classification, commutative/associative/distributive properties, identity/inverses/zero and measurement. Retained slope module m81354 explicitly remediates 0/4 and 4/0 through m81318, so the omission is not supported merely by a chapter title argument.

Evidence: `real_properties_bridge`, `real_identity`, `general_equation_simplification`.

Uncertainty: One explicit readiness edge does not prove every chapter-7 module indispensable; algebraic concepts may be revisited in retained modules.

### Add m81329 after expanding to 56 modules

Both graphing modules explicitly send failed readiness questions to the same formula-solving example in omitted chapter 9. Adding this actual module, not a percentage overhead, supplies those links; its own readiness targets are already included.

Evidence: `formula_manipulation`, `graph_point_solving`, `intercept_solving`.

Uncertainty: Closure applies only to the extracted explicit readiness relation, not every conceptual dependency or unobserved learner need.

The three chapters add 20 modules / 101,449 cl100k content tokens and supply 26 of the original 28 omitted readiness-link occurrences. Per added chapter: chapter 2: 15, chapter 5: 10, chapter 7: 1. `m81329` adds 8,529 tokens and supplies the remaining two links.

## Exact remaining links in the 56-module candidate

- `m81345#fs-idm459403184`: “Solve the formula: 5 x + 2 y = 20 for y . If you missed this problem, review .” → `m81329#fs-id1169946893419` (Solve a Formula for a Specific Variable).

- `m81350#fs-idm456569120`: “Solve: 3 x + 4 y = −12 for x when y = 0 . If you missed this problem, review .” → `m81329#fs-id1169946893419` (Solve a Formula for a Specific Variable).

The target example asks to solve `3x + 2y = 18` for `y`, first when `x = 4` and then in general. Both target IDs resolve in the archived bytes. These are `class=be-prepared` notes with an explicit failed-readiness remediation instruction, not arbitrary narrative cross-references.

The 57-module package has 132 such cross-module link occurrences (108 unique module pairs), all with included, resolved targets. The added module’s own readiness targets are `m81303` (unit rate), `m81322` (linear equation), and `m81308` (simple interest), already included.

## Residual scope and limits

Chapter 10, the other seven chapter-9 modules, the preface and three back-matter modules remain outside the 57-module package. The source-readiness test does not require them, but absence of a readiness link is not evidence that a topic has no conceptual dependencies. Whole-chapter additions also include outcomes beyond direct remediation; this audit does not prove the package smallest or estimate additional learning.

There are 7 other cross-reference occurrences from the 57-module set to omitted modules; target modules: `m81324`, `m81325`, `m81326`, `m81327`, `m81328`, `m81332`. They remain recorded separately in JSON; no general cross-reference closure was imposed.

## Consulted primary-source passages

Below, text is mechanically extracted for evidence, with fractions/powers made readable. Element IDs and archived-member hashes bind every passage; this display is not a substitute for rendered mathematics.

### algebra_evaluation

Evaluate, Simplify, and Translate Expressions — `m81270#fs-id1632121`, source line 49.

> To evaluate an algebraic expression means to find the value of the expression when the variable is replaced by a given number. To evaluate an expression , we substitute the given number for the variable in the expression and then simplify the expression using the order of operations.

Defines substitution and evaluation, supporting the language-of-algebra inclusion; a heading alone would not establish this conceptual content.

### lcm_for_fractions

Prime Factorization and the Least Common Multiple — `m81273#fs-id1731557`, source line 309.

> One of the reasons we look at multiples and primes is to use these techniques to find the least common multiple of two numbers. This will be useful when we add and subtract fractions with different denominators.

Explicitly states why multiples and primes support addition/subtraction of fractions with different denominators; connects added chapter 2 to retained chapter 4.

### algebra_equation_concept

Solving Equations Using the Subtraction and Addition Properties of Equality — `m81271#fs-id1860947`, source line 50.

> Solving an equation is like discovering the answer to a puzzle. An algebraic equation states that two algebraic expressions are equal. To solve an equation is to determine the values of the variable that make the equation a true statement. Any number that makes the equation true is called a solution of the equation. It is the answer to the puzzle!

Defines an equation's solution as a value making it true, not just a calculation procedure. Chapter 8 readiness explicitly points back to this module.

### decimal_place_value

Decimal Operations — `m81295#fs-id1512123`, source line 53.

> All three items (sandwich, water, tax) were priced in dollars and cents, so we lined up the dollars under the dollars and the cents under the cents, with the decimal point s lined up between them. Then we just added each column, as if we were adding whole numbers. By lining up decimal s this way, we can add or subtract the corresponding place values just as we did with whole numbers.

Explains decimal addition by corresponding place values; added chapter 5 is not merely a token overhead allowance.

### fraction_decimal_conversion

Decimals and Fractions — `m81298#fs-id2669580`, source line 50.

> In Decimals , we learned to convert decimals to fractions. Now we will do the reverse—convert fractions to decimals. Remember that the fraction bar indicates division. So (4)/(5) can be written 4 ÷ 5 or 5 4 . This means that we can convert a fraction to a decimal by treating it as a division problem.

Explains why division converts fractions to decimals, which the retained percent module explicitly requests in readiness.

### percent_uses_decimals

Understand Percent — `m81306#fs-id1470137`, source line 387.

> In Decimals , we learned how to convert fractions to decimals. To convert a percent to a decimal, we first convert it to a fraction and then change the fraction to a decimal.

Retained chapter 6 explicitly recalls earlier fraction-to-decimal conversion; also corroborated by its readiness links to chapter 5.

### percent_uses_equations

Solve General Applications of Percent — `m81313#fs-id1471476`, source line 49.

> We will solve percent equations by using the methods we used to solve equations with fractions or decimals. In the past, you may have solved percent problems by setting them up as proportions. That was the best method available when you did not have the tools of algebra. Now as a prealgebra student, you can translate word sentences into algebraic equations, and then solve the equations.

Retained percent applications explicitly use algebraic equations and previous fraction/decimal methods.

### real_properties_bridge

Rational and Irrational Numbers — `m81315#fs-id1166497460114`, source line 50.

> In this chapter, we'll make sure your skills are firmly set. We'll take another look at the kinds of numbers we have worked with in all previous chapters. We'll work with properties of numbers that will help you improve your number sense. And we'll practice using them in ways that we'll use when we solve equations and complete other procedures in algebra.

Explains that properties of numbers will be used in solving equations; this is source-supported conceptual sequencing, not a mandatory prerequisite theorem.

### real_identity

Properties of Identity, Inverses, and Zero — `m81318#fs-id1166497505919`, source line 52.

> What happens when we add zero to any number? Adding zero doesn’t change the value. For this reason, we call 0 the additive identity .

Gives the additive-identity concept. The same module contains zero-division material explicitly requested by slope readiness.

### general_equation_simplification

Solve Equations Using the Subtraction and Addition Properties of Equality — `m81320#fs-id1166494591280`, source line 438.

> In the examples up to this point, we have been able to isolate the variable with just one operation. Many of the equations we encounter in algebra will take more steps to solve. Usually, we will need to simplify one or both sides of an equation before using the Subtraction or Addition Properties of Equality. You should always simplify as much as possible before trying to isolate the variable.

Retained linear-equation work requires simplification before isolating a variable, supporting language/properties content; it does not prove every chapter-7 section is necessary.

### formula_manipulation

Solve a Formula for a Specific Variable — `m81329#fs-id1169946971825`, source line 194.

> To solve a formula for a specific variable means to get that variable by itself with a coefficient of 1 on one side of the equation and all the other variables and constants on the other side. We will call this solving an equation for a specific variable in general. This process is also called solving a literal equation . The result is another formula, made up only of variables. The formula contains letters, or literals .

Precisely defines solving a formula for a specified variable, the omitted readiness topic shared by two retained graphing modules.

### graph_point_solving

Graphing Linear Equations — `m81345#eip-761`, source line 112.

> We start by finding three points that are solutions to the equation. We can choose any value for x or y , and then solve for the other variable.

Graphing by points selects one variable and solves for the other, corroborating the explicit formula-readiness link.

### intercept_solving

Graphing with Intercepts — `m81350#fs-id1742796`, source line 244.

> Recognizing that the x -intercept occurs when y is zero and that the y -intercept occurs when x is zero gives us a method to find the intercepts of a line from its equation. To find the x -intercept, let y = 0 and solve for x . To find the y -intercept , let x = 0 and solve for y .

Finding intercepts sets one variable to zero and solves for the other, corroborating the formula-readiness link.

## Identity, rights and reproducibility

Source: OpenStax, *Prealgebra 2e*, OpenStax/Rice University. Pinned repository: [https://github.com/openstax/osbooks-prealgebra-bundle](https://github.com/openstax/osbooks-prealgebra-bundle); commit `38cae454e644abf9f0a623e876994553881597c9`. [Collection XML](https://raw.githubusercontent.com/openstax/osbooks-prealgebra-bundle/38cae454e644abf9f0a623e876994553881597c9/collections/prealgebra-2e.collection.xml).

The archived collection identifies the license as [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International](http://creativecommons.org/licenses/by-nc-sa/4.0/). The excerpts retain source attribution; this audit does not relicense the underlying source.

Archive SHA-256: `E9020DA36693D94C0F16FA9CA0025531551E285B5C654BE02E42C85D0679D44A`. Scale-record SHA-256: `F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16`. Collection-member SHA-256: `309FA072672372D1E46D52031167C21D9A120D1CDFDF3001548E1CA2975077A2`.

The JSON retains module/member hashes, objective inventories, exact target IDs, all selected readiness links, separately classified omitted crossrefs, selected source passages, an expert review record, limitations and next action. The generator verifies every recorded archive member and all 75 module identities/text hashes, then verifies chapter subtotals and the 36/56/57 counts. `--check` regenerates both outputs in memory and requires exact byte equality; the default command writes deterministic UTF-8 outputs.

Run: `python -X utf8 scripts/build_package_prerequisite_coverage_v1.py`, then repeat with `--check`. No TeX, network, publication or additional worker is used. Human expert review is a later improvement opportunity, not a release or production hold.
