# Secondary catch-up: allocating packages within nine existing contexts

Conditional allocation calculation, not a worldwide language ranking. The source-defined cohort counts are retained unchanged; language fit and actual additional learning remain explicit assumptions.

The same two alternatives are offered to every context: an expanded nine-chapter companion proxy plus the formula-rearrangement lesson and additional diagnostic/feedback work, or complete prealgebra. The comparison uses the same quantitative catch-up endpoint. Three uniform companion/full benefit ratios are tested; no nationality is assigned a different learning ability.

Source counts are 283,936 and 364,270 content tokens; the companion incurs additional work equal to 5% of full-book variable work. Shared source preparation is charged once. Workload units are not money, energy or observed physical compute.

| Companion/full benefit | Setup rate | Budget millions | Selected packages | Used millions | Relative context coefficient |
|---:|---:|---:|---|---:|---:|
| 0.50 | 0 | 2 | No package fits | 0.000 | 0 |
| 0.50 | 0 | 5 | Indonesian (full) | 4.891 | 3,095,344 |
| 0.50 | 0 | 10 | Indonesian (full); Brazilian Portuguese (full) | 9.741 | 4,755,948 |
| 0.50 | 0 | 20 | Indonesian (full); Brazilian Portuguese (full); Filipino (full); Vietnamese (companion) | 19.875 | 6,386,623 |
| 0.50 | 2 | 2 | No package fits | 0.000 | 0 |
| 0.50 | 2 | 5 | Indonesian (companion) | 4.625 | 1,547,672 |
| 0.50 | 2 | 10 | Indonesian (full); Brazilian Portuguese (companion) | 9.643 | 3,925,646 |
| 0.50 | 2 | 20 | Indonesian (full); Brazilian Portuguese (full); Filipino (full) | 16.207 | 6,254,366 |
| 0.75 | 0 | 2 | No package fits | 0.000 | 0 |
| 0.75 | 0 | 5 | Indonesian (full) | 4.891 | 3,095,344 |
| 0.75 | 0 | 10 | Indonesian (full); Brazilian Portuguese (full) | 9.741 | 4,755,948 |
| 0.75 | 0 | 20 | Indonesian (full); Brazilian Portuguese (full); Filipino (full); Vietnamese (companion) | 19.875 | 6,452,751 |
| 0.75 | 2 | 2 | No package fits | 0.000 | 0 |
| 0.75 | 2 | 5 | Indonesian (companion) | 4.625 | 2,321,508 |
| 0.75 | 2 | 10 | Indonesian (full); Brazilian Portuguese (companion) | 9.643 | 4,340,797 |
| 0.75 | 2 | 20 | Indonesian (full); Brazilian Portuguese (full); Filipino (full) | 16.207 | 6,254,366 |
| 1.00 | 0 | 2 | No package fits | 0.000 | 0 |
| 1.00 | 0 | 5 | Indonesian (companion) | 4.057 | 3,095,344 |
| 1.00 | 0 | 10 | Indonesian (companion); Brazilian Portuguese (companion) | 8.080 | 4,755,948 |
| 1.00 | 0 | 20 | Indonesian (companion); Brazilian Portuguese (companion); Filipino (companion); Thai (companion) | 17.906 | 6,667,187 |
| 1.00 | 2 | 2 | No package fits | 0.000 | 0 |
| 1.00 | 2 | 5 | Indonesian (companion) | 4.625 | 3,095,344 |
| 1.00 | 2 | 10 | Indonesian (companion); Brazilian Portuguese (companion) | 8.648 | 4,755,948 |
| 1.00 | 2 | 20 | Indonesian (companion); Brazilian Portuguese (companion); Filipino (companion); Thai (companion) | 18.474 | 6,667,187 |

## Interpretation

This expanded alternative adds chapters 2, 5 and 7 plus the formula-rearrangement module m81329 to the six-chapter proxy. The 21 additional modules supply substantial algebra, decimal/rate and real-number prerequisite content and close the remaining explicit readiness links. Whole-chapter inclusion is conservative rather than minimal, and link closure is not proof of complete pedagogical prerequisites. Results for the original six-chapter proxy and the intermediate 56-module alternative are preserved in the source-coverage report; the original v1 scenarios are not rewritten.

Multiply the last column by the common, still-unmeasured offer-level gain to obtain a conditional benefit total. It is not a count of people educated. One package cannot be credited with outcomes it omits. The modeled contexts are separate country survey frames, not a claim of zero multilingual overlap in worldwide readership.

The six other numeric routes and all worldwide language, script, signed-language, register, stage and interlanguage options remain eligible in the larger study. This calculation does not replace their baselines or promote this nine-route subset as a global Top 10.

Every one of 19,683 choices was enumerated for 24 scenarios with integer arithmetic; selected costs were separately recomputed using exact fractions. This proves the finite scenario solutions, not the empirical input assumptions. Full inputs, choices, exact values and comparator policies are in `structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json`.
