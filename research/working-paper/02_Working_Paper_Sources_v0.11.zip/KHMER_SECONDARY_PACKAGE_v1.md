# Khmer secondary mathematics: an independently usable companion, not a presumed first textbook

Research checkpoint, 8 September 2026. This is a resource-design finding for the existing `KM-S` quantitative catch-up comparison, not a new population estimate or a global funding rank. Proposed written interface: school-register Khmer in Khmer script (`km-Khmr` / Central Khmer candidate). It does not cover every language used in Cambodia.

## Finding and recommended comparison

The next useful comparison is **a curriculum-linked, searchable, reflowable Khmer prerequisite-and-practice companion versus a complete independently usable course**. Do not justify either option by claiming that Khmer has no mathematics books, worked examples, answers or distance-learning provision. The inspected sources contradict that premise. The companion is a provisional first resource to cost, not an empirically proven winner and not the only material worth producing.

The exact endpoint is the existing secondary quantitative catch-up target: independent use of number operations, fractions, proportions, equations and graphs, supported by diagnostics and fully worked practice. Learners may be in school, returning to education or studying autonomously. No teacher, account or continuous connection is assumed in the proposed download.

## Directly inspected supply

| Source | What was actually established | Boundary |
|---|---|---|
| Ministry-domain school E-Library, Grade 9 mathematics page | It links a main textbook, a separately authored solutions book, examination preparation and other resources. The footer identifies a school information-technology teaching team, not a complete national library census. | A working page and two successful downloads do not establish how many learners obtain or use them. |
| *Mathematics, Grade 9*, ministry textbook, printed 2020 | The downloaded PDF has 241 pages. Nine pages were inspected, including the cover, credits and contents. Printed pp. 17–18 explain proportional reasoning and show worked unit conversions; p. 41 introduces linear equations through worked transformations; pp. 1–2 include examples and exercises; p. 85 covers elementary probability. | This is evidence of substantial existing content, not an audit of every exercise, current curriculum mandate or all available editions. |
| *Grade 9 Mathematics Solutions*, attributed in the library to Hai Pahin | The separate PDF has 261 pages. Sample PDF pp. 7, 10 and 11 show exercise sets followed by multi-step numerical/algebraic solutions. | Hosting by a school does not make this a ministry-authored text; exact edition date and exhaustive textbook-to-solution alignment remain unresolved. |
| Ministry *Education Newsletters*, COVID-19 response article | Printed pp. 144–145 (PDF pp. 153–154) describe Grade 9/12 video provision, subsequent Grade 7–12 videos, textbook borrowing and self-study routes. | Historical provision is not a current usage or learning-effect estimate. The file was initially saved under the misleading locator name `education_congress_report.pdf`; its actual cover title is *Education Newsletters*. |

All 241 textbook pages returned empty extracted text in the recorded parser check, and the PDF has no `/StructTreeRoot`. The visually inspected pages are scanned images. This supports a concrete format opportunity: semantic, searchable mathematics with an adaptable reading layout. It is not an end-to-end screen-reader test or a claim that every other Khmer source has the same properties. The solutions file also showed damaged Khmer text extraction and Poppler reported missing substitute display fonts; its sampled rendered mathematical work remained visible.

The two downloaded mathematics files total **51,031,893 bytes**. They can be kept offline after acquisition. File availability therefore does not imply the proposed companion must replace them, nor does it prove that download size or layout prevents every learner from using them. A direct request to one ministry e-learning proportion-lesson URL returned HTTP 403 in this collection; that single access result is not generalized to the whole service.

## What the proposed companion should add

This recommendation follows from the existing content and the stated independent-learning endpoint; its incremental benefit is a research inference, not measured evidence.

1. Diagnose prerequisites without using prior schooling or register familiarity as a capacity test. Route a learner to relevant number, fraction and proportion support while preserving age-respectful exposition.
2. Map explanations and examples to the local textbook sequence and notation. Keep the existing Khmer disciplinary register; explain linguistic compression and symbols without deleting mathematical content.
3. Put the question, worked reasoning, answer and an explanation of common mistakes within the same navigable unit. The sampled solutions show that answers already exist; the design question is usable integration and feedback, not inventing an absence.
4. Supply semantic HTML/MathML, searchable Khmer Unicode, print PDF and an offline index. Include text descriptions for diagrams. Optional audio is a separate format and cost, not automatic universal access.
5. Keep the complete-course alternative available for learners needing a coherent sequence independent of school materials. A companion cannot receive credit for topics it does not teach.

Existing books are source and terminology witnesses, not an asserted open-derivative licence. The proposed original or openly licensed learning package can use the study's already identified OpenStax source while preserving its licence and credits and independently aligning terminology and curriculum. No third-party PDF is proposed for republication in this checkpoint.

## Consequence for allocation

This finding changes the **resource alternatives** within the Khmer route. It does not subtract from the Khmer population baseline, substitute Cambodian residents for Khmer readers, or remove the route because its exact learning gain is not measured. The existing survey-context coefficient remains conditional and unchanged.

For equal audiences and the same learning outcome, a companion outperforms the complete course when its retained additional benefit exceeds its relative all-in cost. Compare preparation, source-faithful translation or authorship, mathematical checking, semantic conversion, accessible formats and delivery on both sides. The existing 100,000-token benchmark is not the measured cost of either package. A portfolio must also account for the opportunity cost of the other editions it can buy.

The next calculation should test the companion and full-course options under the same explicit benefit assumptions used for other communities, then replace those assumptions where genuinely comparable evidence is available. The finding is **not** that Khmer should be moved down a global list because local materials exist.

## Sources and reproducibility

- School E-Library. (n.d.). *Mathematics, Grade 9* resource page. [Ministry-domain library](https://sites.google.com/moeys.gov.kh/mylibrary/%E1%9E%AF%E1%9E%80%E1%9E%9F%E1%9E%9A%E1%9E%80%E1%9E%98%E1%9E%9A%E1%9E%8F%E1%9E%94%E1%9E%8B%E1%9E%98%E1%9E%97%E1%9E%98/%E1%9E%90%E1%9E%93%E1%9E%80%E1%9E%91%E1%9F%A9/%E1%9E%82%E1%9E%8E%E1%9E%8F%E1%9E%9C%E1%9E%91%E1%9E%99).
- Ministry of Education, Youth and Sport. (2020 printing). *Mathematics, Grade 9*. [Exact school-linked PDF](https://drive.google.com/file/d/1R7us6wvRWlCZtIan5VqpKB3p4rdJTqC3/view).
- Hai Pahin [library attribution; romanization provisional]. (n.d.). *Grade 9 mathematics solutions*. [Exact school-linked PDF](https://drive.google.com/file/d/1-2jgRxAAZ8bHHDdQFtVRsVuqm8URPic6/view).
- Ministry of Education, Youth and Sport. (n.d.). Ministry of Education outlines key strategies in response to COVID-19. In *Education Newsletters* (pp. 143–146; inspected here pp. 144–145). [Ministry-hosted compilation](https://api.saladigital.org/public/orgs/63fc7c5751508ff62e6ce857/pdf/061653f9-80f0-4fc6-b9aa-528a0f8db592.pdf). Publication date is not inferred from search-engine crawl metadata.

Exact local source identities, bytes, SHA-256, inspected page lists and mechanical checks are in `structured/KHMER_SECONDARY_PACKAGE_v1.json`. Source PDFs remain research witnesses; the report and original analysis can be preserved without redistributing those PDFs.
