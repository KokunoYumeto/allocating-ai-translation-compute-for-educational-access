# Independent package-allocation review

Status: PASS for the finite arithmetic, source-inventory accounting, paired comparison, and final section 7.17 wording. This does not establish empirical learning effects, complete pedagogical prerequisites, or a worldwide optimum.

## Arithmetic and source accounting

The independent checker imports neither producer and uses disjoint full-package and companion masks. All 24 v2 scenarios and all 24 preserved v1 scenarios agree with independent exhaustive enumeration: 944,784 selections and 821 checks. Exact objectives, costs, source unions, tie-breaks, and uniform-policy comparator values agree. Nine of the 24 paired scenarios change selections and reduce the objective coefficient. The nine source-defined contexts and six other numeric routes remain unchanged.

The priced companion contains 57 canonically ordered modules, including m81329, and 283,936 cl100k content-text tokens; the full collection contains 364,270. All 132 recorded explicit readiness-link occurrences resolve to included modules. The recorded seven other cross-reference occurrences to omitted modules remain separate. This checker verifies the recorded inventory and module hashes; it does not independently extract source links or retokenize source bytes.

The companion/full variable-cost break-even ratios, including the common 5% full-work allowance, are:

- Original 36-module proxy: 384343/728540 = 0.5275523650039806.
- Preserved intermediate 56-module source option: 587241/728540 = 0.8060518296867708; analytical comparison only.
- Priced 57-module alternative: 604299/728540 = 0.8294657808768221.

These ratios exclude shared setup and finite-budget indivisibility. At benefit ratio 0.5, setup rate 2, and budget 10 million, the independently verified optimum is Indonesian complete plus Brazilian Portuguese companion. Its exact cost is 1928561706964455273/200000000000 (about 9.642809 million), and its gain over the best feasible uniform policy is exactly 27676723081900/1031781451017 percent (about 26.824211%). Complete editions for those same two contexts cost 104699260121227933/10000000000 (about 10.469926 million), exceeding that budget.

## Final section 7.17 delta verification

Status: PASS_BOUNDED_SECTION_DELTA. The sole final change replaces “Two complete editions would require about 10.47 million” with “Complete editions for those two contexts would require about 10.47 million”. This resolves the ambiguity between the named pair and any possible two contexts.

For both files below, the new phrase occurs exactly once, the old phrase is absent, and reversing that single byte replacement reproduces the previously reviewed SHA-256. The final standalone section is present verbatim in the manuscript. No other numerical or textual change was detected; the 944,784-choice enumeration was not repeated.

| File | Final SHA-256 | SHA-256 after reversing the one phrase |
|---|---|---|
| SECONDARY_PACKAGE_SOURCE_AND_ALLOCATION_SECTION_v1.md | DECA2CD15CA3A580DDA32DDDE2C6E57CB3D9B171FCAE5121B34C0BAC33BDDC2F | 2EE41D16C4A46654D8F23547D3B9B6A275C6A9D91EB51FD5BB4E35A61B421052 |
| PAPER_CURRENT_DRAFT.md | F56FD4D57DCF7BEA52FA0D07E8C1D5498CCFD6962DA5A618387655D6ED7CC885 | 10E68EC6FF45B6A250C046E15B0B88BB32640423BC1100A273464642B63A38A3 |

## Exact evidence bindings

- Checker: scripts/check_secondary_package_portfolio_v2.py; SHA-256 B10903A8FEA5159E72A636B1EA1159D0E9CAC604183FC1471E39C102AE59954F.
- Arithmetic review: qa/SECONDARY_PACKAGE_PORTFOLIO_INDEPENDENT_REVIEW_v2.json; SHA-256 D126EC3D9DBFB24DDB22FEA4595365DC352FCDDD153125F65D41D5D5A3EDC8B7.
- Priced v2 scenarios: structured/SECONDARY_PACKAGE_PORTFOLIO_v2.json; SHA-256 8266BCAD531741A704D271E028FC4C303D477F4CD9B4DC07CAB5F9D96C0B65D9.
- Source coverage: structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json; SHA-256 F81ADFBD125B73DEB86490584E31F635854AAF076F104649A7921BA5BFA99766.

The arithmetic receipt and both modeled source inputs remained byte-identical during the final wording check. No v1 artifacts, manuscript content, credentials, remote state, or publication were changed by this review. No unresolved finite-check findings remain.
