# Secondary source and allocation-language review v1

Review date: 9 September 2026. Result: **PASS for the bounded source claims and interpretation boundaries reviewed below. No manuscript correction required.**

## Exact binding and scope

The final reviewed `PAPER_CURRENT_DRAFT.md` has 307,693 bytes and SHA-256 `F56FD4D57DCF7BEA52FA0D07E8C1D5498CCFD6962DA5A618387655D6ED7CC885`. Sections 7.16 and 7.17 were read directly. The initially supplied manuscript hash was `10E68EC6FF45B6A250C046E15B0B88BB32640423BC1100A273464642B63A38A3`; the final section 7.17 was reread after its clarification that complete editions **for those two contexts** require approximately 10.47 million units. This report binds the final bytes, not the earlier version.

Source-report bindings:

| Artifact | SHA-256 |
|---|---|
| `THAI_MALAY_SECONDARY_PACKAGE_v1.md` | `0E339D8974B4D17A8EFC28DD7AF73B51BAED12832F231B12CC300046B8A00FCA` |
| `structured/THAI_MALAY_SECONDARY_PACKAGE_v1.json` | `DD45D138BC79F0D7BEDCF8EBBA0795E01BA02576B32FC3CBCA7B8909BB7D9551` |
| `KHMER_SECONDARY_PACKAGE_v1.md` | `888FDADBCACE2DAFA8EC883B961735265216EC162CBFEC0A7003BAA51D3CE24B` |
| `structured/KHMER_SECONDARY_PACKAGE_v1.json` | `43AE811BEFE69E5474487C9350627B10488728276EB8E08A5684C9F22E59CF3E` |

This was a local source review, not a fresh availability test, a whole-textbook audit, a language-effect experiment, or a new allocation enumeration. The PDF skill was read and used for read-only inspection of existing page images; no images or PDFs were rebuilt. Twelve pertinent source files were rehashed against the two source ledgers: all nine Thai/Malay sources and Khmer sources KHM-SUPPLY-001 through 003. All matched. Sixteen newly inspected Thai/Malay PNG witnesses also matched their recorded hashes. Five Khmer PNGs were inspected and individually bound below.

## Source findings for section 7.16

- **Thai curriculum and worked feedback: supported.** Existing `THA_curriculum_p9.png` and `THA_curriculum_p10.png` show the Mathayom 1 rational-number, fraction/decimal, ratio/percentage and one-variable equation content. Existing `THA_slides_p5.png` solves the consecutive-even-number equation `x + (x + 2) = 74` to obtain 36; `THA_slides_p6.png` obtains 38 and explicitly checks `36 + 38 = 74` against the original conditions. The retained episode HTML contains both exact download identifiers 205531 and 205532.
- **Thai Activity 6 versus Activity 5: correctly distinguished.** `THA_activities_p1.png` identifies Activity 5 and asks for creation and explanation of a number trick. It has blank response areas but does not explicitly require a group. `THA_activities_p2.png` identifies Activity 6 and explicitly directs another group to formulate/solve the created problem, followed by correctness/reasonableness checking by the originating group. Section 7.16 limits its group-work statement accordingly. The proposed solo feedback is identified as a design addition, not proof that every DLTV lesson lacks feedback.
- **Malay existing answer routes: supported.** `MYS_F1_p118.png` (printed 108) contains the worked fruit-price expression `5x + 8y` and Latih Diri 5.1b. `MYS_F1_p322.png` (printed 312) contains the corresponding 5.1b answers, including `x - 7`, `(y + z)/9`, `4x`, `mp + nq` and `h - 2k`. `MYS_F2_p15.png` (printed 20-21) shows algebraic expansion through area diagrams; `MYS_F2_p152.png` (294-295) supplies expansion/factorization answers. `MYS_F3_p33.png` (23) contains worked index-law and simultaneous-equation reasoning with explicit answer checks; `MYS_F3_p262.png` (252) begins the answer section. The retained district HTML contains the three exact Malay textbook Drive identities. No first-answer-key premise is present in the manuscript.
- **Malay item scores and interpretation: supported.** `MYS_TIMSS_p58.png` (printed 56) identifies ME72038 and the correct fraction-subtraction-method option at **12.5%**. `MYS_TIMSS_p59.png` (57) discusses denominator choice and confusion between two-fraction operations and a single fraction. `MYS_TIMSS_p80.png` (78) identifies ME72069, substitution of a positive and a negative value, and **22.8%** correct; `MYS_TIMSS_p81.png` (79) discusses negative-number/substitution errors and parentheses. The manuscript correctly treats these as item results for assessed students, not rates for all Malay speakers or effects caused by language. Form 1 in the report is the curriculum-content mapping, not a newly inferred sample grade. Item-specific sample denominators and standard errors were not supplied on these inspected pages.
- **Khmer substantive mathematics and separate authorship: supported.** `textbook-022.png` and `textbook-023.png` show printed 17-18: proportions, unit-conversion relations and worked conversions. `textbook-046.png` shows printed 41: linear-equation transformations, including addition/subtraction on both sides. `solutions-011.png` visibly contains multi-step numerical/algebraic radical work. `textbook-003.png` supports the ministry textbook and 2020 printing identity. The retained school-library HTML labels the distinct solutions file `កំណែលំហាត់គណិតវិទ្យា ថ្នាក់ទី៩ (ហៃ ប៉ាហ៊ិន).pdf` and binds it to Drive identifier `1-2jgRxAAZ8bHHDdQFtVRsVuqm8URPic6`. Thus school-library attribution to Hai Pahin, with provisional romanization, is supported; ministry authorship of that solutions book is not claimed.
- **Khmer scan/format and file-size claims: mechanically reproduced.** A fresh local pypdf check of the exact textbook bytes found **241 pages, zero pages with nonempty extracted text, and no `/StructTreeRoot`**. The inspected textbook pages visibly are scanned pages. The textbook has 41,150,137 bytes and the solutions book 9,881,756 bytes: their sum is **51,031,893 bytes**, or **51.0 decimal MB** to one decimal place. The retained Malaysian Form 1 file has 104,661,884 bytes, or 104.7 decimal MB. These observations justify testing semantic/reflowable and smaller-download options; they do not prove universal inability to use the existing files, all-page mathematical correctness, or complete screen-reader accessibility.

The Thai/Malay PNG names above are relative to `sources/thai_malay_secondary_20260908/`; their hashes and exact source-PDF page mappings are in the bound Thai/Malay JSON. Khmer PNG names are relative to `qa/khmer_secondary_20260908/`:

| Khmer witness | SHA-256 |
|---|---|
| `textbook-003.png` | `A92B4B70F0122B9E8C76C2483F0390FF46715B7206F17A84C8EC2E481BD67C7A` |
| `textbook-022.png` | `F45B0CE2ED62371B3A6918411E10A780BA7212BEE5753C65FB976CC31ABF4EC0` |
| `textbook-023.png` | `078010BBAAE9638E1BC2D83B1B0E45EC1ED5563C56620725AE51D08D1C004BE3` |
| `textbook-046.png` | `3C785EAFC2600A08B39C56505DD34F536BEC6982801F4CFDD00E924D5416ABB6` |
| `solutions-011.png` | `3572CC25F99A1542F60226DBE6B9AF36B1364E4D2198C7BD913E68DF8EB6DBD5` |

## Section 7.17 and inference boundaries

The source counts, module identities and explicit-readiness claims agree with the completed `PACKAGE_PREREQUISITE_COVERAGE_v1` audit: 36/173,958, 56/275,407 and 57/283,936 modules/content-token pairs; 28, two and zero readiness links to omitted modules; 132 included/resolved readiness occurrences for the final selection; seven other cross-references recorded separately. These are historical per-module token records reaggregated after source-byte/text-hash verification, not a fresh tokenizer execution.

Section 7.17 explicitly denies minimality and pedagogical prerequisite-completeness, separates standardized workload scenarios from measured accelerator/energy/money costs, and labels modeled learning benefits as unmeasured assumptions. It does not infer different learning ability by nationality. Section 7.16 explicitly rejects absence-of-mathematics and language-causation premises, preserves existing worked answers and named language/script boundaries, and treats proposed packages as source-grounded design choices rather than measured learning effects. Neither section lowers worldwide need because local materials exist. No language exclusions were introduced by this review.

**Arithmetic review is outside this review's scope.** Another reviewer owns the independent v2 calculation checks. This report does not claim to have rerun the portfolio enumeration, verified all 24 arithmetic scenarios, or independently proved the modeled 26.82% figure. Its allocation review is limited to source binding and the stated interpretation boundaries.

## Public-artifact privacy and source terms

The current OpenStax artifacts were checked for personal-account text, absolute local-path patterns, local runtime/cache markers and common credential-header markers. Correctly bounded detection produced **zero matches** in all three files. The generator header describes its finite workflow without private task paths. No source report, source PDF, or public access state was altered.

| Checked public artifact | SHA-256 |
|---|---|
| `PACKAGE_PREREQUISITE_COVERAGE_v1.md` | `4F094E4CBEB298EDCD48F024B8319AF3DB1477F57BD3C88F708451D6B7E30D22` |
| `structured/PACKAGE_PREREQUISITE_COVERAGE_v1.json` | `F81ADFBD125B73DEB86490584E31F635854AAF076F104649A7921BA5BFA99766` |
| `scripts/build_package_prerequisite_coverage_v1.py` | `6D21D0FE1DF3415F4FC4BEB7D5A81C2F0EC03D91E0D3083D4449E4CAB47D4C00` |

Those artifacts retain OpenStax/Rice University attribution, the pinned `38cae454e644abf9f0a623e876994553881597c9` source identity, archived-member identities, and **CC BY-NC-SA 4.0** source terms. They do not relabel the source as CC BY or treat research witnesses as unrestricted reusable textbooks. Current section 7.16 likewise distinguishes downloadability from permission to reproduce KPM, assessment and Khmer source material.

This finite review is complete. No human-response gate, further catalogue, repeated unchanged audit or additional publication operation is required by this report.
