# Source licenses

The original research analysis is available under CC BY 4.0. This does not relicense third-party source material.

The pinned OpenStax Prealgebra 2e CNXML source archive retains CC BY-NC-SA 4.0 and its original author and publisher credits. Its source identity is commit 38cae454e644abf9f0a623e876994553881597c9 of https://github.com/openstax/osbooks-prealgebra-bundle. The archive contains its source license and credits. Users reusing that source must follow its own terms, including the noncommercial and share-alike requirements.

Other cited or preserved source documents and fonts retain their original licenses and credits. A citation, source inventory, or source hash does not transfer ownership or change a license. Internal instruction appendices are not part of the public research payload; any public excerpt is identified as such in the snapshot manifest.
