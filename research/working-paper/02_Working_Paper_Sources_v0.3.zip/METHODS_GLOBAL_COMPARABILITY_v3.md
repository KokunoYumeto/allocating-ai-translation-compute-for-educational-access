# Comparing educational-access opportunities across languages

Active analytical specification, version 3, 4 September 2026.

## 1. Question and unit

The quantity of interest is additional functional educational access created per standardized unit of AI compute. A candidate intervention is a specified language or shared-register profile, learner stage, subject package and delivery format. Need, benefit and compute are separate quantities.

The stage codes used throughout are **P** (preschool/early childhood), **F** (foundational/primary), **S** (secondary), **V** (vocational/technical/practical), **U** (university/taught tertiary) and **R** (postgraduate/research). They label different educational endpoints, not scores or priority.

The common comparison asks what creating and distributing the same educational package to the same stated quality would add for each population. It is not a schedule for an individual project. Programme outputs, local inventories, completed translations and sunk compute are case-study evidence only; changing them cannot alter the estimates of global need.

## 2. Inclusion and hypotheses

Candidate generation begins with the frozen language registry plus explicit scripts, varieties, communities, diaspora routes, signed-language modes and interlanguage designs. An independent incoming source can introduce a new or unresolved identity. It need not already have an exact registry match. Bookkeeping and historical entries remain traceable, with contemporary learners and revitalization opportunities distinguished from nonexistent present-day native-speaker counts.

Inclusion is independent of whether a comparable population count is available. Every source observation receives a disposition: linked, candidate-linked, unresolved but retained, or explicitly out of analytical scope with a reason. Registry membership, a macro-language relationship, a written standard and an exact community are different things.

The prospective hypotheses and initial candidate expectations are frozen in `HYPOTHESES_AND_EXPECTED_CANDIDATES_v1.md`. They are tested against results and against unexpected challengers. They are not used to force ranks or to impose geographic quotas. Failure of an expected candidate to appear triggers an investigation of sources, inference and implementation.

## 3. Estimands

For intervention c and a stated horizon H, retain the original educational-access estimand:

`G(c) = sum_g P(g) * E[N(i) * (A_c(i,H) - A_0(i,H)) | g]`.

Here P(g) is the population of a mutually exclusive learner stratum, N is a specified educational-need event or bounded severity measure, and A is usable access for a stated task. Autonomous study, classroom use and research/reference use have separate endpoints. A downloaded file, spoken-language report or resource listing is not itself a measurement of A.

Within each analysis, each learner contributes once to the endpoint being counted. Different languages' standalone potential audiences may overlap. Do not divide a multilingual person's need equally among language labels merely to make a global table additive. Estimate standalone interventions and adjust overlap when evaluating portfolios.

`Efficiency(c) = G(c) / C_standardized(c)`.

C_standardized describes a common source package, model/workflow and QA target. Report input, output, caching, failed work, checking and format-production costs separately. Token counts are not automatically energy, dollars, weekly allowance or a common compute unit. Token representation ratios alone do not measure whole-workflow cost.

## 4. Evidence and inference

Use three explicit modes for each input:

1. **Direct observation:** the source measures the defined quantity for the stated population, date and educational endpoint.
2. **Evidence-based inference:** adjacent evidence is transported using an explicit relationship, with its scope mismatch and uncertainty recorded. Relevant predictors may include actual schooling language, age, educational attainment, infrastructure, displacement, publication markets and related educational systems. Such mechanisms may be geographically concentrated without geographic identity itself becoming a value judgment.
3. **Scenario:** a transparent assumption explores a plausible range where the literature does not identify a value. The output is conditional on that assumption. It is not an observed fact.

Neither missingness nor the amount of literature supplies a need score. Lack of a measurement must not produce a hidden zero, exclusion, downward ordinal adjustment or forced common midpoint. Removing evidence should usually widen the admissible comparison; a directionally informative new observation may legitimately increase or decrease estimated need.

For population, preserve direct historical counts with their dates. Project only with stated demographic assumptions and migration uncertainty. National totals can constrain resident subsets when the subset relationship is established, but a registry's associated-country total is neither a global speaker count nor a bound on diaspora. Aggregate language counts constrain combinations of their constituents; they are not assigned in full to each constituent. An unmeasured constituent remains a candidate with an explicit allocation range.

For need and supply, use stage- and subject-specific evidence. Country learning indicators cannot silently become language-group rates. A cross-language analogy is admissible when its mechanism is stated; its result stays an inference. For example, a documented Russian-language postgraduate resource gap justifies investigating parallel Ukrainian and other Slavic gaps, but does not determine their size. Different provision and disruption may change the direction.

For educational-language overlap, preserve what a source asks: mother tongue, home language, conversational ability, literacy and advanced technical reading are not interchangeable. If only marginal proportions are known, use joint-event bounds or a declared dependence model. Multiplying several national marginal rates as if they were conditional probabilities is not acceptable.

For interlanguages, make the design hypothesis concrete. Compare exact audiences, scripts, registers and mathematical prerequisites. Existing evidence and model/mechanical semantic analysis can support provisional design and reach scenarios. Neither lack of new human testing nor family membership alone decides the result. Where comprehension is unmeasured, publish the assumptions needed for a bridge to outperform separate editions and test sensitivity to them.

## 5. Comparable outputs

Publish baseline unmet need, standardized intervention benefit and benefit per compute separately. A large language can have lower per-person need and higher total benefit. A smaller community can have high severity or a uniquely valuable intervention. Do not hide either comparison.

If estimates support only ranges, report robust comparisons and possible outrankers. Candidate a robustly exceeds b only where the same comparable endpoint satisfies a's lower estimate greater than b's upper estimate across the specified admissible model set. A conditional expected order can accompany that result if its assumptions and sensitivity are visible. It cannot be relabeled as a measured global ordering.

A Top 100 is a communication and portfolio output, not an eligibility boundary. Publish the candidates outside it that plausibly outrank selections under defensible assumptions, the unresolved communities and the sources likely to discriminate. Do not place every uncertain group below every well-measured group.

## 6. Independent resource baseline

Measure independently existing educational supply by relevance, completeness, language/variety fit, practical availability, price, redistribution/adaptation permissions, accessible formats and prerequisites. A catalogue title is evidence of a listing, not universal satisfaction of need. Conversely, an absent title on one website is not evidence that a country has no such education.

Open licensing is a concrete advantage for translation and free redistribution. Existing closed or paid materials can still describe current access for people who can actually use them. Their existence does not erase unmet need among those unable to obtain them. Evaluate independent-learning and classroom routes separately.

## 7. Required tests before an allocation claim

- Every registry entry, incoming source row and candidate expectation has a traceable disposition.
- Exact, proxy, macro, script, modality, community and territorial relationships remain distinguishable.
- Evidence in one country cannot satisfy a different country's local coverage check.
- Signed classification uses typed identities, not only an English name substring.
- No language loses eligibility when a measurement is removed or a registry match is unresolved.
- Local-project fields have no effect on need, benefit, standardized cost or recommendations.
- Aggregate and constituent populations, multilingual audiences, stages and diaspora counts are not double-counted.
- Every displayed rank has a traceable estimand, compatible units and sensitivity to uncertain population, overlap, supply and cost inputs.
- Hypothesis failures and unexpected possible outrankers are investigated and reported, rather than hidden.
- Source, arithmetic and semantic QA support the actual empirical claims; successful extraction alone does not establish the final ranking.

## 8. Current implementation boundary

The identity and source-link audits are being executed. The hypothesis register exists. Full global population inference, stage/subject estimates and the next allocation comparison are not yet complete. Version-2.1 common-midpoint and strict-denominator ranking routines are historical implementations, not current allocation authority. They must not be used to generate a new public ordering under this specification.
