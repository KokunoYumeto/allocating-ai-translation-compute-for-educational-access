# Binding target-specific evidence to the secondary catch-up frontier — v1

## Why this exists

The equal-`q` frontier is only a placeholder. This checkpoint asks which existing-supply, language-fit, delivery and effect facts are already bound to each route, and which missing fact is most likely to change the conditional order.

`q` means the average net additional probability that a person inside the recorded need/context population gains usable access to the exact educational endpoint because of the intervention, relative to current independently usable alternatives. The measurement plan is:

`q = language/audience fit × reached × acquired × usable × active use × new endpoint gain − endpoint loss`

This factorization organizes evidence. It is not an independence assumption; a directly comparable intent-to-treat estimate replaces the product.

## Where one additional measurement can change the current order

| Measurement tier | Route | Equal-q position | q relative to Indonesia needed to lead | If candidate q=1, Indonesia q must be below | Package-evidence alignment |
|---|---|---:|---:|---:|---|
| A | Indonesian | 1 | 1.00× | 1.000 | direct stage and autonomous catchup endpoint near match |
| A | Brazilian Portuguese | 2 | 1.85× | 0.541 | stage matched broad complete and bounded alternatives |
| A | Filipino | 3 | 2.42× | 0.413 | direct stage and autonomous catchup endpoint near match |
| B | Thai | 4 | 9.36× | 0.107 | no stage endpoint aligned q catchup package in selected source |
| B | Vietnamese | 5 | 12.68× | 0.079 | related secondary science reading package not exact q catchup |
| C | Standard Malay, Malaysia | 6 | 15.76× | 0.063 | no target specific q catchup supply card bound |
| C | Japanese | 7 | 28.94× | 0.035 | stage matched broad transition and prerequisite alternatives |
| C | Central Khmer | 8 | 48.05× | 0.021 | no stage endpoint aligned q catchup package in selected source |
| C | Ukrainian | 9 | 51.75× | 0.019 | stage matched bounded catchup bridge near match |

Tier A contains Indonesia as the comparison anchor plus Brazilian Portuguese and Filipino. Brazilian Portuguese overtakes the point leader if its target-specific `q` is more than about 1.85 times Indonesia's; Filipino overtakes at about 2.42 times. These are the first three routes to align on exactly the same package, learner frame, horizon and delivery scenario because the result can change without an extreme effect difference.

This measurement tier is a value-of-information ordering: it says where one additional matched estimate is most likely to change the current conditional comparison. It is not a ranking of people, languages, educational need or production entitlement.

The lower tiers remain possible outrankers. A larger reversal ratio means only that, under the current need and token-workload point scenarios, a larger target-specific effect difference is required. It says nothing about a language community's educational worth and is not a reason to exclude research or production in another endpoint.

## What the existing evidence changes

- **Indonesia:** current official Grade VII student books and separate teacher guides exist. The strongest matched hypothesis is therefore an autonomous diagnostic, worked-feedback, remediation and offline companion versus a complete independent sequence—not a claim that Indonesian materials are absent.
- **Brazilian Portuguese:** the represented secondary proficiency context is large, but current evidence does not identify whether language, prerequisites, pedagogy or delivery is the binding mechanism. A bounded prerequisite package and a complete pathway must be tested against the same endpoint.
- **Filipino:** extensive official K–12 and ALS records coexist with fragmented paths, an observed anonymous-download barrier, non-universal connectivity and unresolved allocation of national burden among Filipino, English and exact local languages. The exact audience is therefore especially decision-critical.
- **Japanese and Ukrainian:** both have stage-matched bounded package hypotheses, but their most specific local evidence frames do not equal the PISA-derived Q-CATCHUP context. They remain unmeasured rather than being penalized.
- **Vietnamese:** one related secondary science-reading companion exists, but it is not the exact quantitative catch-up endpoint.
- **Thai, Central Khmer and Standard Malay:** the selected current evidence does not yet bind a stage-and-endpoint-matched Q-CATCHUP package. This is a research gap, not zero need.

## Current delivery observations

Indonesia's 2024 national marginals report 72.78% internet use, 68.65% mobile-phone ownership and 18.52% household computer ownership. The Philippines reports 67.3% internet use among people aged 10+, 48.8% household home internet, and large regional differences; its 98.8% cellphone figure is conditional on internet users. Brazil and Japan have higher national internet-use contexts, while Ukraine's current evidence includes internet, electricity, mobile-subscription and displacement frames. None is a learner-language-device cross-tab, so none is multiplied into `q`. Collectively they support simultaneous phone-readable, printable, download-once and offline routes rather than a web-only assumption.

## Complete course versus smaller package

The pinned OpenStax Prealgebra 2e source contains 364,270 measured `cl100k_base` content-text tokens across 75 modules. A six-chapter quantitative selection contains 173,958 tokens across 36 modules (47.755% of the complete source); a fractions-only chapter contains 41,336 tokens across eight modules (11.348%). These are source-representation measurements, not physical compute.

If a smaller package and the complete package genuinely produce the same endpoint, use the ratio of their positive target-specific yields rather than choosing by length alone:

| Smaller source plan | Shared setup as fraction of full variable cost | Smaller package must deliver more than this share of full-package positive yield |
|---|---:|---:|
| selected quantitative units scenario | 0.0 | 0.478 |
| selected quantitative units scenario | 0.1 | 0.525 |
| selected quantitative units scenario | 1.0 | 0.739 |
| fractions chapter only | 0.0 | 0.113 |
| fractions chapter only | 0.1 | 0.194 |
| fractions chapter only | 1.0 | 0.557 |

With no common setup, the six-chapter package is more efficient if it delivers more than 47.755% of the complete package's positive yield. If shared setup equals the complete package's variable translation workload, that threshold rises to 73.878%. The fractions-only thresholds are mathematically valid only for an explicitly narrow common endpoint; one fractions chapter cannot be credited with the complete catch-up endpoint.

For a fixed source plan, equal target-specific yield leaves the current cross-language order unchanged because every route is scaled by the same source size. Package design can change that order only through target-specific yield, unequal extra work, shared setup/reuse, delivery, or physical-compute differences.

## Next discriminating comparison

For Indonesia, Brazil and the Philippines, specify one identical quantitative endpoint and horizon; compare a bounded prerequisite/feedback companion with a complete autonomous sequence; retain current independently usable supply as the baseline; model passive, active-static, offline and supported use separately; and measure full reference production work. This produces evidence capable of replacing the equal-`q` placeholder without pretending that source availability itself is educational effect.

## Machine-readable outputs

- `structured/Q_CATCHUP_TARGET_BINDINGS_v1.csv`
- `structured/Q_CATCHUP_TARGET_BINDINGS_v1.json`
- `qa/Q_CATCHUP_TARGET_BINDINGS_QA_v1.json`
