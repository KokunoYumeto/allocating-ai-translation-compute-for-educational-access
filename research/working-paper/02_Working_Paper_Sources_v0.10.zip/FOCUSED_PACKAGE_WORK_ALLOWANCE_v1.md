# Focused learning packages or complete textbooks?

## A practical allocation result

Translating a complete textbook and making a focused learning package are different ways to use a limited production budget. The useful comparison is not pages produced. It is the additional understanding each option creates, for the same learner group, learning outcome and period of time, relative to the resources those learners can actually use already.

This study finds substantial room for focused packages when the intended outcome is narrow. Using a pinned OpenStax prealgebra source, the fractions chapter contains about 11.35% of the complete book's extracted content tokens. If a finished fractions package creates half the full book's additional benefit on the chosen outcome, it can absorb extra work equal to 33.65% of the full book's variable workload when common setup costs another 10%. That extra work could make the package independently usable: resolving prerequisites, supplying missing explanations, preserving figures and building offline navigation. The 50% benefit and 10% setup values are scenarios, not measured effects or costs.

The calculation also identifies when the fuller resource is preferable. Six selected chapters contain 47.76% of the full source tokens. If they provide only half its benefit and setup costs 10%, they are already less efficient before extra focused-package work. If they provide 75% of its benefit, the extra-work allowance becomes 24.74%. A smaller resource is not automatically more efficient, and a full book is not automatically more educationally useful on a specific outcome.

## The teaching source is not a blank page

The eight pinned fractions modules contain 108 example containers, 216 Try It notes, 19 readiness notes and 1,047 exercise nodes. Of those exercises, 696 contain a solution element and 351 do not. These categories overlap: examples and notes can contain counted exercises. An answer element may be a short answer rather than a worked explanation, and its absence does not establish that no answer exists elsewhere.

The source also contains 367 image-reference instances and links to eight modules outside this selection. A prose-only extraction is therefore not a finished autonomous learning resource. The source inventory identifies material to retain and dependencies to resolve; it does not certify the mathematical correctness, accessibility or rendered completeness of an edition.

One concrete padding scenario includes each of those eight linked modules once: 46,319 additional content tokens, bringing the package to 87,655 tokens, or 24.06% of the full source. Under the half-benefit, 10%-setup scenario, this leaves 20.94% of full variable workload for further additions before break-even. This is only a direct-link scenario, not a complete dependency closure; it neither proves all eight are compulsory nor resolves their own dependencies. It nevertheless prices an identifiable support layer instead of treating prerequisites as free.

The current OpenStax section on unlike-denominator fractions illustrates the existing structure: readiness checks, links to earlier examples, reasoned worked examples and paired practice. Translating those supports does not require inventing the whole pedagogy again. This is a source-selection advantage, not evidence that publication alone produces learning (OpenStax, pinned source; section 4.5).

## What the direct studies contribute

Sweller and Cooper (1985, Experiment 3) compared worked-example/problem pairs with problem solving among 22 Year-9 pupils. Immediate mean test times were 43.6 versus 78.1 seconds per problem and errors were 0.18 versus 1.64. The session included experimenter support. This supports example/practice pairing as a mechanism worth retaining, not a measured effect for unsupported year-long study (pp. 72-76, Table 6).

Booth and colleagues (2015) tested example-and-explanation worksheets in ordinary algebra classes. The first experiment found a positive effect; the larger second experiment did not find a significant overall treatment coefficient, while the interaction with prior knowledge indicated different responses. Its analyzed samples were 51 and 395. The useful design implication is to provide entry routes and optional explanatory support, not assume one worksheet format has the same effect for every learner (manuscript pp. 11-20, Table 4).

McGuire and colleagues (2017) randomized 196 sixth-graders to text hints, picture hints or answer-only feedback on fraction division. Among 112 selected analyzed completers, test-score differences were not significant (p = .253). Completion was 77.5%, 62.1% and 86.6%, respectively. Extra elaboration can cost work without delivering the expected benefit; quick answer access and optional explanations are a reasonable design inference, not a proven universal optimum (pp. 238-241).

Pitchford (2015) studied self-paced Chichewa mathematics apps in a Malawi primary school: 318 pupils were randomized and 283 analyzed over eight weeks. Supplied tablets, a scheduled learning centre and technical support accompanied the apps. Results included gains, with paper-generalization effects versus ordinary teaching of d = .354 in Standard 2 and .818 in Standard 3; the former was not significant. This is evidence for a supported learning package, not a translation-only effect: ordinary teaching also used Chichewa (Methods, Tables 1-4).

Together, these four studies support testing a source-faithful, example-rich, independently checkable package and keeping additional explanation optional where appropriate. They do not identify a universal benefit multiplier for any language or a complete static self-study curriculum. No missing language-matched trial is treated as zero benefit. Comparable missing cells can use the same disclosed scenarios, including scenarios in which the focused design works better than the full book on the chosen outcome.

## How much extra work fits?

Let V be the full book's variable production workload, F its common setup workload, and f = F/V. Let r be the focused/full source-length ratio. Let E be extra focused-package work beyond its scaled base workload. Let alpha be the finished focused package's additional educational benefit divided by the full book's additional benefit, with a positive full-book benefit. Benefits concern the same cohort, outcome, alternatives and horizon; they can include differences in acquisition and use.

The costs are F + V for the full book and F + rV + E for the focused package. The focused package has greater average benefit per workload precisely when:

`E / V < alpha(E) * (1 + f) - f - r`

Equality is the break-even point. The table reports the right-hand side as a percentage of the full variable workload. Positive values are the amount of extra work available before break-even at the stated final benefit. Negative values mean no nonnegative extra work makes that particular fixed-benefit scenario more efficient.

| Focused material | Final benefit relative to full book | No common setup | Setup = 10% of full variable work | Setup = full variable work |
|---|---|---|---|---|
| Fractions chapter | 50% | 38.65% | 33.65% | -11.35% |
| Six chapters | 50% | 2.24% | -2.76% | -47.76% |
| Six chapters | 75% | 27.24% | 24.74% | 2.24% |
| Fractions chapter | 100% | 88.65% | 88.65% | 88.65% |
| Six chapters | 125% | 77.24% | 79.74% | 102.24% |

These are final-design comparisons. If extra work itself raises the benefit, alpha changes with E: the formula is then an implicit condition, not permission to spend a fixed allowance regardless of results. A negative value for an unimproved design does not rule out a later effective design. Ratios above 100% are allowed because a targeted resource can outperform a full book on a narrow outcome. When alpha is below one, common setup makes the focused option less attractive; when alpha equals one, the setup term cancels from the allowance; when alpha exceeds one, the direction reverses.

## An Indonesian example on the same global basis

Under the existing standardized token-event workload scenario, the full Indonesian prealgebra content has variable workload 4.891 million units. A setup allowance of 10% adds 0.489 million. The fractions base costs 0.555 million. At a final benefit ratio of one-half, its extra-work break-even allowance is 1.646 million units: setup, focused base and extra work together then cost half the full option. At a final benefit ratio of three-quarters, the six-chapter alternative allows 1.210 million extra units. These are workload scenarios, not money, energy, subscription usage or measured Indonesian learning gains.

The same calculator provides Chinese, Hindi, Portuguese and Filipino conversions. The Portuguese input is a general Latin-script profile, not a newly measured Brazilian-specific workflow. These are illustrations of the common rule, not a new Top Five. The full set of 775 source profile IDs is retained, no population coefficient is used in this within-cohort comparison, and existing local translation work makes no deduction from global educational needs.

## Allocation recommendation

For a defined learning gap, compare a complete-book edition with a focused, dependency-complete edition before committing the whole budget. Preserve existing worked examples, practice and answer routes. Identify the missing supports explicitly rather than charging for their wholesale recreation or assuming they cost nothing. Keep any added pedagogy distinct from faithful translation.

Use the allowance to compare concrete designs, not to declare that shorter is better. For fractions catch-up, the source-length advantage makes focused packages serious contenders even with substantial additional production work. For broad prealgebra progression, the full book's additional outcomes must be credited separately; a fractions chapter cannot receive credit for teaching them. Both classroom and teacher-independent routes remain relevant.

At programme level, combine these alternatives with the worldwide audience scenarios and target-specific needs evidence. Select the affordable combination with the greatest additional benefit, counting overlapping beneficiaries and reusable setup only once. An average-efficiency comparison is an input to that portfolio decision, not a substitute for solving it when packages are indivisible. This supplement does not replace the public Top 100 or claim a completed worldwide allocation optimum.

## Sources and reproducibility

Booth, J., Oyer, M., Pare-Blagoev, E. J., Elliot, A. J., Barbieri, C., Augustine, A., & Koedinger, K. R. (2015). Learning algebra by example in real-world classrooms [Accepted manuscript]. Journal of Research on Educational Effectiveness. https://doi.org/10.1080/19345747.2015.1055636

McGuire, P., Tu, S., Logue, M. E., Mason, C. A., & Ostrow, K. (2017). Counterintuitive effects of online feedback in middle school math: Results from a randomized controlled trial in ASSISTments. Educational Media International, 54(3), 231-244. https://doi.org/10.1080/09523987.2017.1384161

OpenStax. Prealgebra 2e [Pinned CNXML source, commit 38cae454e644abf9f0a623e876994553881597c9]. https://github.com/openstax/osbooks-prealgebra-bundle/tree/38cae454e644abf9f0a623e876994553881597c9

OpenStax. Prealgebra 2e, section 4.5: Add and subtract fractions with different denominators. https://openstax.org/books/prealgebra-2e/pages/4-5-add-and-subtract-fractions-with-different-denominators

Pitchford, N. J. (2015). Development of early mathematical skills with a tablet intervention: A randomized control trial in Malawi. Frontiers in Psychology, 6, Article 485. https://doi.org/10.3389/fpsyg.2015.00485

Sweller, J., & Cooper, G. A. (1985). The use of worked examples as a substitute for problem solving in learning algebra. Cognition and Instruction, 2(1), 59-89. https://doi.org/10.1207/s1532690xci0201_3

The accompanying source package binds the two existing input datasets, the pinned source archive, the eight-module structural inventory, all 30 exact-rational scenarios, 10 workload conversions, the calculation script and independent audit. Source-size figures use cl100k_base extracted-content token counts, not images, rendered mathematics or a measured translation workflow. Production scaling is explicitly linear in that representation. The global working paper explains the inherited token-event workload assumptions. Original analysis is CC BY 4.0; the included OpenStax source retains its own CC BY-NC-SA 4.0 licence. This is an ongoing, non-exhaustive research result, not the final global study.
