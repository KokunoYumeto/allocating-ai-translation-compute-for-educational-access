"""Exact, conditional package-efficiency comparison; no global rank mutation."""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NS = {'c': 'http://cnx.rice.edu/cnxml'}
SCALE = 'structured/OPENSTAX_PACKAGE_SCALE_20260904.json'
BUDGET = 'structured/GLOBAL_BUDGET_SCENARIOS_v1.json'
EXPECTED = {
    SCALE: 'F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16',
    BUDGET: 'CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57',
}

def digest(b):
    return hashlib.sha256(b).hexdigest().upper()

def identity(rel):
    b = (ROOT / rel).read_bytes()
    return {'path': rel, 'bytes': len(b), 'sha256': digest(b)}

def number(q):
    q = Q(q)
    return {'numerator': q.numerator, 'denominator': q.denominator,
            'decimal': float(q)}

def save(rel, obj):
    (ROOT / rel).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def main():
    for rel, h in EXPECTED.items():
        assert identity(rel)['sha256'] == h, rel
    scale = json.loads((ROOT / SCALE).read_text(encoding='utf-8'))
    budget = json.loads((ROOT / BUDGET).read_text(encoding='utf-8'))
    arch = scale['source_archive']
    assert identity(arch['path'])['sha256'] == arch['sha256']
    assert identity(arch['path'])['bytes'] == arch['bytes']
    modules = {m['module_id']: m for m in scale['modules']}
    targets = scale['candidates']['fractions_chapter_only']['module_ids']
    inventory = []
    with zipfile.ZipFile(ROOT / arch['path']) as z:
        for mid in targets:
            m = modules[mid]
            b = z.read(m['path'])
            assert len(b) == m['bytes'] and digest(b) == m['sha256']
            content = ET.fromstring(b).find('c:content', NS)
            exercises = content.findall('.//c:exercise', NS)
            answered = sum(bool(e.findall('.//c:solution', NS)) for e in exercises)
            ids = [e.attrib['id'] for e in exercises]
            assert len(ids) == len(set(ids))
            counts = Counter(e.tag.rsplit('}', 1)[-1] for e in content.iter())
            outside = sorted({e.attrib['document'] for e in content.findall('.//c:link', NS)
                              if e.attrib.get('document') not in (None, *targets)})
            media = sorted({e.attrib['src'] for e in content.findall('.//c:image', NS)
                            if e.attrib.get('src')})
            inventory.append({
                'module_id': mid, 'title': m['title'], 'path': m['path'], 'url': m['url'],
                'bytes': len(b), 'sha256': digest(b),
                'content_tokens': m['tokens']['cl100k_base']['content_text'],
                'example_containers': counts['example'], 'exercise_nodes': len(exercises),
                'exercises_with_embedded_solution': answered,
                'exercises_without_embedded_solution': len(exercises) - answered,
                'try_it_notes': sum('try' in e.attrib.get('class', '').split() for e in content.iter()),
                'readiness_notes': sum('be-prepared' in e.attrib.get('class', '').split() for e in content.iter()),
                'image_reference_instances': counts['image'], 'distinct_image_paths': media,
                'linked_modules_outside_package': outside,
            })
    count_keys = ['example_containers', 'exercise_nodes', 'exercises_with_embedded_solution',
                  'exercises_without_embedded_solution', 'try_it_notes', 'readiness_notes',
                  'image_reference_instances', 'content_tokens']
    totals = {k: sum(m[k] for m in inventory) for k in count_keys}
    outside = sorted({s for m in inventory for s in m['linked_modules_outside_package']})
    dependency_rows = []
    with zipfile.ZipFile(ROOT / arch['path']) as z:
        for mid in outside:
            m = modules[mid]
            b = z.read(m['path'])
            assert len(b) == m['bytes'] and digest(b) == m['sha256']
            dependency_rows.append({'module_id': mid, 'title': m['title'], 'path': m['path'],
                                    'sha256': digest(b), 'bytes': len(b), 'url': m['url'],
                                    'content_tokens': m['tokens']['cl100k_base']['content_text']})
    dependency_tokens = sum(m['content_tokens'] for m in dependency_rows)
    assert dependency_tokens == 46319
    inv = {
        'schema': 'openstax-fractions-source-support-inventory/1.0',
        'status': 'PASS_EXACT_CNXML_HASH_AND_STRUCTURAL_INVENTORY',
        'source_commit': scale['commit'], 'source_archive': arch,
        'source_license': scale['license'], 'modules': inventory, 'totals': totals,
        'linked_modules_outside_package': outside,
        'one_hop_padding_scenario': {
            'modules': dependency_rows, 'extra_tokens': dependency_tokens,
            'combined_tokens': totals['content_tokens'] + dependency_tokens,
            'scope': 'Include every directly linked outside module once; not a transitive dependency closure or a claim all are compulsory.'},
        'scope': 'Eight pinned CNXML content elements only; no images downloaded or rendered.',
        'count_semantics': [
            'Counts are XML nodes, not unique pedagogical outcomes or disjoint activity counts.',
            'Examples and Try It notes may contain counted exercise nodes; do not add categories.',
            'Embedded solution existence does not prove a complete explanation or correct answer.',
            'Absent embedded solution does not prove that no answer exists elsewhere.',
            'Linked outside modules are dependencies to resolve, not all necessarily compulsory prerequisites.',
            'This is a source-structure inventory, not semantic, rendering, accessibility or licence-compliance certification.'
        ]
    }
    save('structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json', inv)
    full_tokens = scale['candidates']['complete_source_collection']['tokens']['cl100k_base']['content_text']
    assert full_tokens == 364270 and totals['content_tokens'] == 41336
    plans = [('fractions', 41336), ('six_chapters', 173958)]
    cells = []
    checks = 0
    for name, tokens in plans:
        r = Q(tokens, full_tokens)
        for alpha in [Q(1, 4), Q(1, 2), Q(3, 4), Q(1), Q(5, 4)]:
            for f in [Q(0), Q(1, 10), Q(1)]:
                cap = alpha * (1 + f) - f - r
                # Independently compare ratios at nonnegative trial work levels.
                samples = [Q(0), Q(1, 10), Q(1), Q(2)]
                if cap >= 0:
                    samples += [cap, cap + Q(1, 1000)]
                    if cap > 0:
                        samples.append(cap / 2)
                for e in samples:
                    assert (alpha / (f + r + e) > 1 / (1 + f)) == (e < cap)
                    checks += 1
                cells.append({'plan': name, 'tokens': tokens, 'source_ratio': number(r),
                              'final_benefit_ratio': number(alpha), 'setup_ratio': number(f),
                              'extra_work_break_even_over_full_variable_work': number(cap),
                              'positive_extra_work_range_at_this_fixed_benefit': cap > 0})
    costs = []
    selected = ['COMMON100K:zh-Hans', 'COMMON100K:hi-Deva', 'COMMON100K:id-Latn',
                'COMMON100K:pt-Latn', 'COMMON100K:fil-Latn']
    for row in budget['candidate_rows']:
        if row['row_id'] not in selected:
            continue
        base = Q(str(row['base_100k_cost_fecu']))
        v = base * Q(full_tokens, 100000)
        for name, tokens in plans:
            r = Q(tokens, full_tokens)
            alpha = Q(1, 2) if name == 'fractions' else Q(3, 4)
            f = Q(1, 10)
            cap = alpha * (1 + f) - f - r
            costs.append({'row_id': row['row_id'], 'edition': row['edition'], 'plan': name,
                          'base_100k_workload': number(base), 'full_variable_workload': number(v),
                          'setup_workload': number(f * v), 'focused_base_workload': number(r * v),
                          'final_benefit_ratio': number(alpha),
                          'extra_work_break_even_workload': number(cap * v)})
    assert len(costs) == 10 and len(cells) == 30
    data = {
        'schema': 'focused-package-work-allowance/1.0',
        'status': 'PASS_EXACT_CONDITIONAL_ARITHMETIC_NOT_AN_EMPIRICAL_EFFECT_ESTIMATE',
        'source_bindings': [identity(SCALE), identity(BUDGET), identity(arch['path'])],
        'source_support_inventory': identity('structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json'),
        'scope': 'Same language/register, cohort, alternative provision, learning outcome and horizon; compare incremental benefit per workload.',
        'definitions': {'V': 'Positive full-book variable production workload',
                        'F': 'Common setup workload; F=f*V, f>=0',
                        'r': 'Focused/full source-token ratio; only a declared linear workload proxy',
                        'E': 'Nonnegative focused-specific work, including dependencies and any additional QA/delivery work',
                        'alpha': 'Final G_focused(E)/G_full, with G_full>0; not a measured fraction and not necessarily <=1'},
        'criterion': 'E/V < alpha(E)*(1+f)-f-r',
        'one_hop_padding_scenario': {
            'extra_tokens': dependency_tokens, 'combined_tokens': 41336 + dependency_tokens,
            'combined_ratio': number(Q(41336 + dependency_tokens, full_tokens)),
            'final_benefit_ratio': number(Q(1, 2)), 'setup_ratio': number(Q(1, 10)),
            'remaining_extra_work_over_full_variable': number(Q(1, 2) * Q(11, 10) - Q(1, 10) - Q(41336 + dependency_tokens, full_tokens)),
            'scope': 'Prices all eight directly linked outside modules under the same linear proxy. Additional dependencies, media and explanations remain separately costed; not an offline-completeness assertion.'},
        'equality': 'Equal average benefit per workload, not necessarily equal total benefit or a budget-optimal choice',
        'benefit_and_work_dependency': 'Each cell fixes final alpha after work. If work changes benefit, the inequality is implicit; a negative value at E=0 cannot rule out a beneficial later design.',
        'all_source_candidate_ids': [r['row_id'] for r in budget['candidate_rows']],
        'candidate_count_preserved': len(budget['candidate_rows']),
        'case_study_need_adjustment': 0,
        'population_used_in_within_cohort_comparison': False,
        'physical_compute_measured': False, 'cells': cells, 'illustrative_workload_conversions': costs,
        'limits': ['No source length is an educational-effect estimate.',
                   'No media, dependent-module, tokenization-transfer or pedagogy workload is assumed free.',
                   'A focused unit cannot receive credit for omitted outcomes; full-book wider outcomes remain separate.',
                   'An efficiency ordering does not solve an indivisible multi-package budget portfolio.',
                   'Missing evidence or a negative benefit scenario does not remove any community from research eligibility.'],
        'validation': {'exact_ratio_checks': checks, 'scenario_cells': len(cells),
                       'converted_examples': len(costs), 'module_hashes': len(inventory)}
    }
    save('structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json', data)
    def cell(name, a, f):
        return next(c for c in cells if c['plan'] == name and Q(c['final_benefit_ratio']['numerator'], c['final_benefit_ratio']['denominator']) == a and Q(c['setup_ratio']['numerator'], c['setup_ratio']['denominator']) == f)
    def pct(c):
        return f"{100*c['extra_work_break_even_over_full_variable_work']['decimal']:.2f}%"
    table = ['| Focused material | Final benefit relative to full book | No common setup | Setup = 10% of full variable work | Setup = full variable work |',
             '|---|---|---|---|---|']
    for name, label, a in [('fractions','Fractions chapter',Q(1,2)),('six_chapters','Six chapters',Q(1,2)),('six_chapters','Six chapters',Q(3,4)),('fractions','Fractions chapter',Q(1)),('six_chapters','Six chapters',Q(5,4))]:
        table.append(f"| {label} | {100*float(a):.0f}% | " + ' | '.join(pct(cell(name,a,f)) for f in [Q(0),Q(1,10),Q(1)]) + ' |')
    (ROOT/'FOCUSED_PACKAGE_ALLOWANCE_TABLE_v1.md').write_text('\n'.join(table)+'\n', encoding='utf-8')
    save('qa/FOCUSED_PACKAGE_WORK_ALLOWANCE_QA_v1.json', {
        'schema': 'focused-package-arithmetic-qa/1.0', 'status': 'PASS_INTERNAL_EXACT_CHECKS',
        'result': identity('structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json'),
        'inventory': identity('structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json'),
        'checks': data['validation'], 'independent_audit': 'separate receipt required',
        'semantic_source_review': False, 'full_goal_complete': False})
    print(json.dumps({'validation': data['validation'], 'inventory_totals': totals,
                      'outside_module_ids': outside, 'outputs': ['structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json', 'structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json']}, indent=2))

if __name__ == '__main__':
    main()
