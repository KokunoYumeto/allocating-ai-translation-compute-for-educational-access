"""Build an original research supplement; preserve every prior publication."""
from pathlib import Path
import hashlib, html, json, re, zipfile
from reportlab import rl_config
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'publication/vocational_package_supplement_20260908'
NAMES=['17_Practical_Business_Education_20260908.pdf','18_Practical_Business_Education_20260908.html','19_Practical_Business_Education_20260908_Sources.zip','20_Practical_Business_Education_20260908_Metadata.json']

def sha(b): return hashlib.sha256(b).hexdigest().upper()
def info(p):
    b=p.read_bytes()
    return {'name':p.name,'bytes':len(b),'sha256':sha(b)}
def inline(s,web=False):
    s=html.escape(s)
    def linked(match):
        full = match[1]
        url = full.rstrip('.,;:')
        return '<a href="'+url+'">'+url+'</a>'+full[len(url):]
    s=re.sub(r'(https://[^\s]+)',linked,s)
    return s

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    text=(ROOT/'VOCATIONAL_PACKAGE_ALLOCATION_v1.md').read_text(encoding='utf-8')
    data=json.loads((ROOT/'structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json').read_text(encoding='utf-8'))
    assert len(data['audio_delivery'])==3
    assert len(data['finite_two_resource_example']['scenarios'])==4
    assert '{{' not in text
    rl_config.invariant=1
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='VTitle',fontName='Helvetica-Bold',fontSize=23,leading=27,spaceAfter=12,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='VBody',fontName='Helvetica',fontSize=10.5,leading=14.5,spaceAfter=8))
    styles.add(ParagraphStyle(name='VHead',fontName='Helvetica-Bold',fontSize=14,leading=18,spaceBefore=12,spaceAfter=7,keepWithNext=True,textColor=colors.HexColor('#173b4c')))
    styles.add(ParagraphStyle(name='VCell',fontName='Helvetica',fontSize=8.6,leading=11.1))
    lines=text.splitlines();flow=[];web=[];i=0;heads=[];table_rows=0
    while i<len(lines):
        line=lines[i].strip()
        if not line: i+=1;continue
        if line.startswith('# '):
            flow.append(Paragraph(inline(line[2:]),styles['VTitle']));web.append('<h1>'+html.escape(line[2:])+'</h1>');heads.append(line[2:])
        elif line.startswith('## '):
            flow.append(Paragraph(inline(line[3:]),styles['VHead']));web.append('<h2>'+html.escape(line[3:])+'</h2>');heads.append(line[3:])
        elif line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch('[-:]+',x) for x in row):rows.append(row)
                i+=1
            widths=[250,249] if len(rows[0])==2 else [100,125,135,139]
            if rows[0][0]=='Production budget':widths=[105,100,164,130]
            table=Table([[Paragraph(inline(c),styles['VCell']) for c in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
            table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e3edf0')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOX',(0,0),(-1,-1),.4,colors.HexColor('#8ca4b0')),('INNERGRID',(0,0),(-1,-1),.3,colors.HexColor('#bbccd3')),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
            flow.extend([table,Spacer(1,10)]);table_rows+=len(rows)
            web.append('<div class="scroll"><table><thead><tr>'+''.join('<th scope="col">'+inline(c,True)+'</th>' for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+inline(c,True)+'</td>' for c in row)+'</tr>' for row in rows[1:])+'</tbody></table></div>');continue
        else:
            para=[line]
            while i+1<len(lines) and lines[i+1].strip() and not lines[i+1].startswith(('#','|')):
                i+=1;para.append(lines[i].strip())
            line=' '.join(para);paragraph=Paragraph(inline(line),styles['VBody']);flow.append(KeepTogether([paragraph]) if len(line)<350 else paragraph);web.append('<p>'+inline(line,True)+'</p>')
        i+=1
    def footer(canvas,doc):
        canvas.saveState();canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#49626e'))
        canvas.drawString(48,28,'Practical business education | Educational access research');canvas.drawRightString(547,28,str(doc.page));canvas.restoreState()
    SimpleDocTemplate(str(OUT/NAMES[0]),pagesize=(595,842),leftMargin=48,rightMargin=48,topMargin=43,bottomMargin=48,title=heads[0],author='').build(flow,onFirstPage=footer,onLaterPages=footer)
    body='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(heads[0])+'</title><style>body{font:18px/1.65 system-ui,sans-serif;color:#182d38;max-width:850px;margin:auto;padding:2rem 1rem}h1,h2{line-height:1.2;color:#173b4c}h1{font-size:2.2rem}a{color:#075581;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:.88rem}td,th{padding:.6rem;border:1px solid #b3c5cc;text-align:left;vertical-align:top}th{background:#e3edf0}.scroll{overflow-x:auto}nav{padding:.7rem;background:#edf4f6}@media print{nav{display:none}body{font-size:11pt}}</style></head><body><nav><a href="'+NAMES[0]+'">Download PDF</a> | <a href="https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/">Full research programme</a> | <a href="'+NAMES[2]+'">Sources and calculations</a></nav><main>'+''.join(web)+'</main></body></html>'
    (OUT/NAMES[1]).write_text(body,encoding='utf-8')
    r=PdfReader(OUT/NAMES[0]);extracted='\n'.join(p.extract_text() for p in r.pages)
    for value in ['1,193','2,096','3,849','14.58','13.14','15.30','0.625','1.25','2.5','0.45','0.75','1.20','Hiligaynon']:
        assert value in extracted and value in body,value
    assert '\ufffd' not in extracted and '\u25a0' not in extracted
    sources=['VOCATIONAL_PACKAGE_ALLOCATION_v1.md','VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.md','OPENSTAX_SUBJECT_SOURCE_SCALE_v1.md','structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json','structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json','structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json','structured/OPENSTAX_PACKAGE_SCALE_20260904.json','scripts/build_vocational_package_allocation_v1.py','scripts/build_vocational_package_supplement_v1.py','qa/VOCATIONAL_PACKAGE_ALLOCATION_QA_v1.json','qa/VOCATIONAL_PACKAGE_ALLOCATION_INDEPENDENT_REVIEW_v1.md','qa/VOCATIONAL_PACKAGE_ALLOCATION_REVIEW_CLOSEOUT_v1.md','structured/GLOBAL_EDITION_REACH_BASELINE_v3.csv','structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv','publication/living_notebook_v0_9/00_START_HERE__Current_Working_Paper_v0.9.pdf']
    sources=[p.replace('structured/OPENSTAX_PACKAGE_SCALE_20260904.json','structured/OPENSTAX_SUBJECT_SOURCE_SCALE_v1.json') for p in sources]
    entries=[]
    for rel in sources:
        p=ROOT/rel
        if not p.exists():
            print(json.dumps({'status':'PDF_HTML_BUILT_SOURCE_AUDIT_PENDING','missing':rel,'pdf_pages':len(r.pages)}));return
        b=p.read_bytes()
        assert not any(x in rel for x in ['RAW_','TRANSCRIPT','STATE'])
        assert not re.search(rb'[A-Z]:[\\/]Users[\\/]',b),rel
        entries.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
    reproduce=('# Reproduce and licensing\n\nOriginal analysis and presentation: CC BY 4.0. Cited articles and their teaching scripts are not redistributed. The included v0.9 working paper is original analysis; its references do not relicense third-party works. Earlier separate publication packages containing OpenStax material retain their original CC BY-NC-SA 4.0 notice and credits; that licence is not replaced by the analysis licence.\n\nFor a full independent replay, download the three public primary PDFs named in structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json and structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json into their exact relative paths. Check the listed SHA-256 hashes. Then run scripts/build_vocational_package_allocation_v1.py with the Python standard library. This verifies source witnesses and reproduces payload sizes, thresholds and the exhaustive two-budget example. Source downloads are necessary for full source-hash replay; no account or credential is required. The original evidence extraction and independent review are retained witnesses, not regenerated by arithmetic. Run scripts/build_vocational_package_supplement_v1.py with reportlab and pypdf to rebuild readable formats. PDF/HTML are deterministic for unchanged inputs; ZIP timestamps and metadata can differ.\n\nThe two frozen worldwide tables and the v0.9 paper are included only to replay the unchanged-artifact checks; they are not new measurements and are not overwritten by this supplement. The OpenStax source-scale record contains previously measured source-text counts, not physical compute or a new tokenization experiment.\n')
    with zipfile.ZipFile(OUT/NAMES[2],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for entry in entries:z.write(ROOT/entry['path'],entry['path'])
        z.writestr('SOURCE_MANIFEST.json',json.dumps(entries,indent=2)+'\n');z.writestr('REPRODUCE_AND_LICENSING.md',reproduce)
    with zipfile.ZipFile(OUT/NAMES[2]) as z:
        assert z.testzip() is None
        for entry in entries:assert sha(z.read(entry['path']))==entry['sha256']
    meta={'schema':'vocational-package-supplement/1.0','date':'2026-09-08','status':'BUILT_VISUAL_QA_PENDING','pdf_pages':len(r.pages),'source_units':len(entries),'archive_entries':len(entries)+2,'html_headings':heads,'html_table_rows':table_rows,'source_manifest':entries,'files':[info(OUT/n) for n in NAMES[:3]],'scope':'Original vocational package recommendations from two primary studies, separate delivery and production costs, marginal-benefit thresholds and a four-scenario exact illustration; not a finished worldwide allocation order.','license':'CC BY 4.0 for original analysis; cited works retain their rights','primary_articles_redistributed':False,'supersedes_public_files':[],'full_goal_complete':False}
    (OUT/NAMES[3]).write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':meta['status'],'pdf_pages':len(r.pages),'source_units':len(entries),'archive_entries':len(entries)+2,'files':meta['files']}))

if __name__=='__main__':main()
