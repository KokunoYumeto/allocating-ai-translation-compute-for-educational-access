"""Finite-budget sensitivity across every retained edition; no empirical benefit claim."""
from pathlib import Path
import csv
import hashlib
import json
import math
import os

os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv'
SCALE = ROOT / 'structured/COMPLETE_VS_SMALLER_PACKAGES_20260904.json'
OUT = ROOT / 'structured/GLOBAL_BUDGET_SCENARIOS_v1.json'
REPORT = ROOT / 'GLOBAL_BUDGET_SCENARIOS_v1.md'
QA = ROOT / 'qa/GLOBAL_BUDGET_SCENARIOS_QA_v1.json'
SECTION = ROOT / 'GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest().upper()


def solve(cost, benefit, budget):
    # Rescale to millions for stable solver arithmetic. A single bounded worker.
    result = milp(c=-benefit / 1e6, integrality=np.ones(len(cost)),
                  bounds=Bounds(0, 1),
                  constraints=LinearConstraint((cost / 1e6)[None, :], -np.inf, budget / 1e6),
                  options={'time_limit': 15, 'mip_rel_gap': 1e-9})
    if not result.success or result.x is None:
        raise RuntimeError('Bounded optimizer did not certify its scenario: ' + str(result.message))
    picks = np.flatnonzero(result.x > .5).tolist()
    spent = float(cost[picks].sum())
    total = float(benefit[picks].sum())
    assert spent <= budget + .01
    assert abs(total / 1e6 + result.fun) < .001
    return picks, spent, total, float(result.mip_gap), float(-result.mip_dual_bound * 1e6)


def main():
    with SOURCE.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 775
    ids = [r['row_id'] for r in rows]
    assert len(set(ids)) == len(ids)
    base = np.array([float(r['compute_scenario_point']) for r in rows])
    pop = np.array([float(r['plausibly_helped_point']) for r in rows])
    assert np.all(base > 0) and np.all(pop >= 0)
    unknown_indexes = np.flatnonzero(pop <= 0).tolist()
    numeric_indexes = np.flatnonzero(pop > 0).tolist()
    # The inherited zeros are missing audience coefficients, never measured no need.
    # Numeric solutions are explicitly conditional on unknown challengers remaining symbolic.
    scale = json.loads(SCALE.read_text(encoding='utf-8'))
    source_sizes = {}
    for r in scale['openstax_text_traffic_scenarios']:
        source_sizes[r['source_plan']] = int(r['S_measured_extracted_content'])
    assert source_sizes['complete_source_collection'] == 364270
    assert source_sizes['selected_quantitative_units_scenario'] == 173958
    source_sizes['common_100k_benchmark'] = 100000
    plan_budgets = {
        'common_100k_benchmark': (5e6, 10e6, 25e6, 50e6),
        'complete_source_collection': (5e6, 10e6, 20e6),
        'selected_quantitative_units_scenario': (5e6, 10e6, 20e6),
    }
    # Budgets and effect retention are declared experimental scenarios, never observations.
    scenarios = []
    for source_plan, budgets in plan_budgets.items():
        source_size = source_sizes[source_plan]
        for budget in budgets:
            cost = base * source_size / 100000
            picks, spent, total, gap, bound = solve(cost, pop, budget)
            feasible = np.flatnonzero(cost <= budget)
            anchor = int(feasible[np.argmax(pop[feasible])]) if len(feasible) else None
            greedy, left = [], budget
            for idx in np.argsort(-pop / cost, kind='stable'):
                if cost[idx] <= left + 1e-8:
                    greedy.append(int(idx)); left -= cost[idx]
            selections = [{
                'row_id': ids[i], 'edition': rows[i]['edition_profile'],
                'cost_fecu': float(cost[i]), 'screen_coefficient': float(pop[i])
            } for i in picks]
            selections.sort(key=lambda r: (-r['screen_coefficient'], r['row_id']))
            challengers = []
            residual_by_cost = {}
            for i in unknown_indexes:
                c = float(cost[i])
                if c > budget:
                    threshold = None
                    residual = None
                else:
                    if c not in residual_by_cost:
                        residual_by_cost[c] = solve(cost, pop, budget - c)[2] if budget > c else 0.0
                    residual = residual_by_cost[c]
                    threshold = max(0.0, total - residual)
                challengers.append({'row_id': ids[i], 'edition': rows[i]['edition_profile'],
                    'audience_coefficient': None, 'audience_status': 'UNKNOWN_INHERITED_ZERO_NOT_EVIDENCE_OF_NO_READERS',
                    'cost_fecu': c, 'minimum_benefit_coefficient_to_improve_numeric_portfolio': threshold,
                    'residual_numeric_portfolio_coefficient': residual,
                    'scope': 'One symbolic challenger inserted at a time; simultaneous unknown challengers require joint optimization.'})
            scenarios.append({
                'scenario_id': f'{source_plan}::B{int(budget)}',
                'source_plan': source_plan, 'source_content_tokens': source_size,
                'budget_fecu': budget, 'spent_fecu': spent,
                'unspent_fecu': budget - spent,
                'selected_editions': selections,
                'all_edition_rows_eligible': len(rows),
                'positive_numeric_rows': len(numeric_indexes),
                'symbolic_audience_challengers': challengers,
                'additive_opportunity_coefficient': total,
                'unique_benefit_coefficient_lower_if_nested': float(pop[picks].max()) if picks else 0,
                'unique_benefit_coefficient_upper_if_disjoint': total,
                'nested_geometry_optimum': {
                    'row_id': ids[anchor] if anchor is not None else None,
                    'coefficient': float(pop[anchor]) if anchor is not None else 0,
                    'cost_fecu': float(cost[anchor]) if anchor is not None else 0,
                    'additional_editions_add_unique_benefit_in_this_geometry': False,
                },
                'simple_ratio_greedy_coefficient': float(pop[greedy].sum()),
                'optimizer_gap': gap, 'optimizer_objective_bound': bound,
                'observed_people_helped': None,
                'assumption': 'One identical source plan and common audience relevance, uptake and effect across editions; additive coefficients count overlapping edition opportunities unless disjoint audiences are expressly assumed.',
            })
    package_comparisons = []
    for budget in (5e6, 10e6, 20e6):
        full = next(s for s in scenarios if s['budget_fecu'] == budget and s['source_plan'] == 'complete_source_collection')
        smaller = next(s for s in scenarios if s['budget_fecu'] == budget and s['source_plan'] == 'selected_quantitative_units_scenario')
        package_comparisons.append({
            'budget_fecu': budget,
            'small_over_full_yield_required_under_additive_scenario': full['additive_opportunity_coefficient'] / smaller['additive_opportunity_coefficient'],
            'condition': 'Same outcome, same positive audience relevance and uptake, no unmodelled differential cost, disjoint beneficiaries or explicit edition-opportunity objective. Additional full-course outcomes are outside this one-outcome comparison.',
            'small_yield_retention_sensitivities': [{
                'retention': r,
                'small_coefficient_times_retention': r * smaller['additive_opportunity_coefficient'],
                'full_coefficient': full['additive_opportunity_coefficient'],
                'higher_coefficient': 'selected' if r * smaller['additive_opportunity_coefficient'] > full['additive_opportunity_coefficient'] else 'complete'
            } for r in (.3, .5, .8)],
        })
    out = {
        'schema': 'global-finite-budget-sensitivity/1.1.0',
        'status': 'EXACT_CONDITIONAL_BUDGET_SOLUTIONS_NOT_EMPIRICAL_GLOBAL_BENEFIT_RANK',
        'source_bindings': [{'path': str(p.relative_to(ROOT)).replace('\\', '/'), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in (SOURCE, SCALE, Path(__file__))],
        'source_plan_budgets': {k: {'source_content_tokens': source_sizes[k], 'budgets_fecu': list(v)} for k, v in plan_budgets.items()},
        'cost_scaling_assumption': 'Linear source-token scaling of the same benchmark workflow; no measured fixed setup, shared preparation, or package-specific audit overhead is imputed.',
        'objective': 'Choose complete edition packages within a finite workload budget to maximize the retained reach coefficient times declared common relevance, exposure and educational effect.',
        'benefit_equation': 'G(S) = a * u * e * sum(P_i for selected i) only for the additive opportunity scenario; unique people require beneficiary intersections.',
        'a_definition': 'Common fraction of the screening population for whom the specified subject, stage and outcome are relevant.',
        'u_definition': 'Common probability of usable acquisition and active use over a stated planning horizon.',
        'e_definition': 'Common net increment on a stated educational outcome conditional on the preceding events. No empirical value is imputed here.',
        'unit_boundary': 'FECU is the inherited declared token-event workload index. It is not measured physical computing, energy, price or subscription consumption.',
        'horizon': 'Common but not numerically measured; resulting coefficients cannot be reported as annual beneficiaries.',
        'overlap_bounds': 'Given compatible individual nonnegative benefits and no interactions, max(G_i) <= union benefit <= sum(G_i). The nested and disjoint geometries are limiting sensitivity cases, not estimated multilingual overlap.',
        'unknowns_outside_numeric_layer': 'Universal language inclusion, academic-register English, signed-language formats, additional exact varieties, displaced groups and interlanguages remain in the wider research universe. Their absence from this inherited 775-row numeric layer is no eligibility judgment.',
        'case_study_need_adjustment': 0,
        'source_size_is_evidence_of_endpoint_effect': False,
        'scenarios': scenarios,
        'complete_versus_selected': package_comparisons,
        'candidate_rows': [{'row_id': r['row_id'], 'edition': r['edition_profile'], 'inherited_reach_position': int(r['reach_position']), 'population_coefficient': float(r['plausibly_helped_point']) if float(r['plausibly_helped_point']) > 0 else None, 'audience_status': 'INHERITED_NUMERIC_BASELINE' if float(r['plausibly_helped_point']) > 0 else 'UNKNOWN_INHERITED_ZERO_NOT_EVIDENCE_OF_NO_READERS', 'base_100k_cost_fecu': float(r['compute_scenario_point']), 'baseline_research_preserved': True} for r in rows],
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    lines = ['# What a fixed translation workload budget buys', '',
             'This calculation makes the budget decision explicit across all 775 retained edition rows. Four budgets are tested for the common 100,000-token benchmark; three budgets each are tested for the complete book and six-chapter source plans. The inherited table contains 750 positive audience coefficients and 25 zero coefficients that do not establish zero readership. Those 25 are represented as unknown audiences with portfolio-entry thresholds. The numeric solutions are conditional on the stated audience scenarios; none is a global optimum over unresolved populations.', '',
             'The result is a conditional planning exercise. A language population is much larger than the audience for one book. A common fraction for subject relevance, active use and educational gain remains symbolic. Those common factors do not change the conditional selection, but their values are needed before a coefficient can be called people helped.', '',
             'The complete-source and six-chapter plans use the measured OpenStax Prealgebra 2e content-text sizes of 364,270 and 173,958 tokens. These sizes determine source workload only. They do not prove that the shorter plan produces the same educational outcome.', '',
             '## Exact solutions under the additive opportunity scenario', '',
             '| Source plan | Workload budget in millions | Workload used in millions | Editions selected | Sum of reach coefficients in millions |',
             '|---|---:|---:|---|---:|']
    for s in scenarios:
        labels = ', '.join(r['edition'].replace(', Latin-script profile','').replace(' profile','').replace(', Devanagari-script','').replace(', Arabic-script','') for r in s['selected_editions'])
        plan_label = {'common_100k_benchmark':'100k benchmark', 'complete_source_collection':'Complete book', 'selected_quantitative_units_scenario':'Six chapters'}[s['source_plan']]
        lines.append(f"| {plan_label} | {s['budget_fecu']/1e6:.0f} | {s['spent_fecu']/1e6:.3f} | {labels} | {s['additive_opportunity_coefficient']/1e6:,.1f} |")
    lines += ['', 'These sums count edition opportunities. Multilingual users can appear in more than one row. Only under the explicit disjoint-audience scenario can the sum, multiplied by the common relevance, active-use and gain factors, represent unique additional benefit.', '',
              '## Unknown audiences remain potential alternatives', '',
              'For each of the 25 inherited zero rows, the model records an unknown audience and calculates an entry threshold. If a candidate costs c and the numeric optimum at budget B has coefficient V(B), the candidate improves that solution when its coefficient exceeds V(B) minus V(B-c). This tests the full opportunity cost of inserting a package. It does not assign an unknown community zero benefit.', '',
              'The unresolved editions are: ' + '; '.join(rows[i]['edition_profile'] for i in unknown_indexes) + '.', '',
              '## When broader coverage beats a complete course', '',
              'With the same budget, a shorter source may permit more editions. Its required effect retention therefore depends on which editions fit, as well as the length ratio.', '',
              '| Budget in millions of workload events | Minimum selected-package yield as a share of complete-package yield |',
              '|---:|---:|']
    for c in package_comparisons:
        lines.append(f"| {c['budget_fecu']/1e6:.0f} | {c['small_over_full_yield_required_under_additive_scenario']:.1%} |")
    lines += ['', 'Each threshold applies only to a shared, stated learning outcome and the additive scenario above. A complete course also provides outcomes absent from six selected chapters. Those outcomes need their own comparison; they cannot be assumed away when making a final recommendation.', '',
              '## What overlap changes', '',
              'If the useful audiences for every edition were fully nested, the unique-benefit objective would favor the largest affordable individual opportunity and additional editions would add no unique reach. If audiences were disjoint, the additive budget solution above would apply. Actual multilingual overlap lies between these limiting cases and can change which additional edition is most useful. The numerical model reports both extremes rather than inventing intersections.', '',
              'This result supports a practical distinction: a sorted ratio is useful for screening, while indivisible book packages require a budget calculation. The optimizer checks all 775 rows, reports the unspent budget and compares its result with a simple benefit-per-workload greedy selection. No national wealth, local completed translation or research-availability factor changes any language denominator.', '',
              'The current budget unit is a declared token-event workload index. Physical hardware measurements may refine future estimates. Their absence does not prevent publication of this clearly stated workload-budget analysis.', '',
              '## Evidence and reproducibility', '',
              '- The existing 775-row worldwide reach and workload table supplies every edition input.',
              '- The pinned OpenStax source-scale record supplies package lengths.',
              '- Subject relevance, uptake, effect retention, overlap and budgets are declared scenario parameters.',
              '- Every optimizer run must return an optimal solution within a 15-second bound and a relative gap of at most 1e-9.',
              '- `structured/GLOBAL_BUDGET_SCENARIOS_v1.json` contains all candidates, exact selections, cost sums, solver bounds and package reversal thresholds.', '']
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    # The public manuscript consumes this exact generated section. The audit
    # compares bytes as well as recomputing every displayed cost and audience sum.
    section = ['### 7.9 How the available workload changes the translation portfolio', '',
        'The decision is which educational editions to produce within a fixed budget. This calculation tests ten portfolios across all 775 retained language-and-script rows. It uses the same positive but unknown educational yield for every edition within each source plan. Under that explicit assumption, audience size and production workload determine which editions fit. This is a provisional allocation result, not a measurement of learning gains.', '',
        'Three source plans are kept distinct: a standardized 100,000-source-token benchmark; the complete OpenStax *Prealgebra 2e* content, measured at 364,270 tokens; and six selected chapters, measured at 173,958 tokens. The benchmark is not the complete book. Workload is scaled linearly with source length; shared preparation and fixed package-specific costs are not yet estimated.', '',
        'The budget unit below is one million standardized fresh-equivalent token events. It is a declared production-workload index, not a measurement of electricity, accelerator time, subscription usage or money. The final column is a sum of potential-audience estimates before adjusting for overlapping readers. It is not a count of unique people educated.', '',
        '| Source plan | Budget, million workload units | Workload used, millions | Editions selected | Potential-audience sum, millions |',
        '|---|---:|---:|---|---:|']
    for s in scenarios:
        labels = ', '.join(r['edition'].replace(', Latin-script profile','').replace(' profile','').replace(', Devanagari-script','').replace(', Arabic-script','') for r in s['selected_editions'])
        if len(s['selected_editions']) > 8:
            labels = f"{len(s['selected_editions'])} editions; full selection in the calculation appendix"
        label = {'common_100k_benchmark':'100k benchmark', 'complete_source_collection':'Complete book', 'selected_quantitative_units_scenario':'Six chapters'}[s['source_plan']]
        section.append(f"| {label} | {s['budget_fecu']/1e6:.0f} | {s['spent_fecu']/1e6:.3f} | {labels} | {s['additive_opportunity_coefficient']/1e6:,.1f} |")
    section += ['', 'At a budget of 10 million workload units, the complete-book scenario selects Chinese and Spanish. The six-chapter scenario instead fits Chinese, Hindi, Spanish and French. The 100k benchmark is a third, shorter plan and must not be described as the complete book. Integer package costs matter: a list sorted by audience per workload does not necessarily produce the best combination that fits the budget.', '',
        'For the same learning outcome, a smaller package is preferable only if the extra audiences it reaches compensate for any lower educational yield. Under the additive-audience assumption, the six-chapter package needs to retain the following shares of the complete-book yield:', '',
        '| Budget, million workload units | Minimum six-chapter yield relative to the full book |',
        '|---:|---:|']
    for c in package_comparisons:
        section.append(f"| {c['budget_fecu']/1e6:.0f} | {c['small_over_full_yield_required_under_additive_scenario']:.1%} |")
    section += ['', 'These are decision thresholds, not observed effectiveness estimates. They apply only to a shared outcome: six chapters cannot be credited with teaching topics they omit. Conversely, a complete book does not automatically provide greater benefit on a narrow outcome such as fractions. The empirical question is which resource produces enough additional understanding for its additional cost.', '',
        'Multilingual overlap can change the portfolio. If every useful audience were nested within the largest one and each edition delivered the same benefit, additional editions would add no unique beneficiaries. If audiences were disjoint, the displayed sums would apply. Actual allocation must account for intersecting audiences, audience-specific educational yield, register and script access, and shared production costs. Counting two editions is not automatically counting two different people.', '',
        'The 25 rows with unresolved audience counts remain symbolic alternatives, not zero-need languages. For each budget, the calculation reports how large their audience-benefit contribution would need to be to improve the portfolio after paying their opportunity cost. Additional varieties, signed languages, non-academic-register English and interlanguage designs remain eligible in the wider register. None is excluded by the limits of this inherited numeric table.', '',
        'The calculation appendix `GLOBAL_BUDGET_SCENARIOS_v1.md` and its structured JSON preserve all 775 rows, ten solved scenarios, full edition selections, budget bounds and unknown-audience entry thresholds. The figures in this section are generated from those same results and checked for exact agreement.', '']
    SECTION.write_text('\n'.join(section), encoding='utf-8')
    checks = {
        'all_775_retained': len(out['candidate_rows']) == len(rows) == 775,
        'all_ten_scenarios_optimal': len(scenarios) == 10 and all(s['optimizer_gap'] <= 1e-9 for s in scenarios),
        'source_plan_budgets_and_lengths_distinct': len({s['scenario_id'] for s in scenarios}) == 10 and all(s['source_content_tokens'] == source_sizes[s['source_plan']] for s in scenarios),
        'budgets_respected': all(s['spent_fecu'] <= s['budget_fecu'] + .01 for s in scenarios),
        'bounds_consistent': all(s['unique_benefit_coefficient_lower_if_nested'] <= s['unique_benefit_coefficient_upper_if_disjoint'] for s in scenarios),
        'greedy_does_not_beat_optimum': all(s['simple_ratio_greedy_coefficient'] <= s['additive_opportunity_coefficient'] + .01 for s in scenarios),
        'no_observed_benefit_fabricated': all(s['observed_people_helped'] is None for s in scenarios),
        'zero_case_study_need_adjustment': out['case_study_need_adjustment'] == 0,
        'unknown_audiences_preserved_as_null': len(unknown_indexes) == 25 and sum(r['population_coefficient'] is None for r in out['candidate_rows']) == 25,
        'all_scenarios_expose_unknown_challengers': all(len(s['symbolic_audience_challengers']) == 25 for s in scenarios),
    }
    receipt = {'status': 'PASS' if all(checks.values()) else 'FAIL', 'checks': checks, 'outputs': [{'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in (OUT,REPORT,SECTION)]}
    QA.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt))
    assert all(checks.values())


if __name__ == '__main__':
    main()
