"""Build the v0.5 readable allocation-research checkpoint and source payload."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import html
import importlib.util
import csv
import io
import json
import re
import sys
import zipfile

from docx import Document
from docx.oxml.ns import qn
from docx.shared import RGBColor
from pypdf import PdfReader
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import KeepTogether, PageBreak, Spacer
from reportlab.platypus.tableofcontents import TableOfContents


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "publication/living_notebook_v0_5"
PDF = "00_START_HERE__Current_Working_Paper_v0.5.pdf"
MANIFEST = "01_SNAPSHOT_MANIFEST_v0.5.json"
ZIP = "02_Working_Paper_Sources_v0.5.zip"
HTML = "03_READABLE_WORKING_PAPER_v0.5.html"
DOCX = "04_EDITABLE_WORKING_PAPER_v0.5.docx"
MARKDOWN = "05_CURRENT_WORKING_PAPER_v0.5.md"
REACH_TOP100 = "06_WORLDWIDE_REACH_TOP100_v0.5.csv"
COMPUTE_TOP100 = "07_COMMON_PACKAGE_COMPUTE_PROXY_TOP100_v0.5.csv"
PROFILE_INVENTORY = "08_NONORDINAL_PROFILE_INVENTORY_v0.5.csv"
PUBLICATION_STATUS = "PUBLICATION_STATUS.md"
STAMP = "6 September 2026"
STATUS = "WORK IN PROGRESS - ONGOING - NON-EXHAUSTIVE - NOT THE FINAL PRODUCT"

SOURCES = [
    "PAPER_CURRENT_DRAFT.md",
    "GLOBAL_REACH_AND_COMMON_PACKAGE_ALLOCATION_CHECKPOINT_v1.md",
    "ACADEMIC_REGISTER_TRANSLATION_RESEARCH_v1.md",
    "HYBRID_LANGUAGE_REACH_BASELINE_v1.md",
    "HEGEMONY_BIAS_AUDIT_v1.md",
    "METHODS_GLOBAL_COMPARABILITY_v3.md",
    "EDUCATIONAL_PACKAGE_PORTFOLIO_v1.md",
    "EXPECTED_CANDIDATE_COVERAGE_v1.md",
    "HYPOTHESES_AND_EXPECTED_CANDIDATES_v1.md",
    "HYPOTHESIS_TEST_PLAN_v1.md",
    "HYPOTHESIS_OUTCOMES_v2.md",
    "AFRICAN_PACKAGE_NEEDS_20260904.md",
    "agent_reports/ARABIC_IRANIC_PACKAGE_NEEDS_20260904.md",
    "agent_reports/SIGNED_LANGUAGE_PACKAGE_NEEDS_20260904.md",
    "agent_reports/MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.md",
    "agent_reports/PORTUGUESE_SPANISH_PACKAGE_NEEDS_20260904.md",
    "SHARED_REGISTER_PORTFOLIO_COMPARISONS_v1.md",
    "INTERVENTION_EFFECT_EVIDENCE_v1.md",
    "CONDITIONAL_GLOBAL_PORTFOLIOS_v1.md",
    "CONDITIONAL_PORTFOLIO_MODEL_v1.md",
    "structured/COMPLETE_VS_SMALLER_PACKAGES_20260904.json",
    "structured/OPENSTAX_PACKAGE_SCALE_20260904.json",
    "structured/HYBRID_LANGUAGE_REACH_BASELINE_v1.json",
    "structured/HYBRID_LANGUAGE_REACH_BASELINE_v1.csv",
    "structured/GLOBAL_EDITION_REACH_BASELINE_v3.json",
    "structured/GLOBAL_EDITION_REACH_BASELINE_v3.csv",
    "structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.json",
    "structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv",
    "structured/ACADEMIC_REGISTER_TRANSLATION_EVIDENCE_v1.json",
    "structured/ACADEMIC_REGISTER_TRANSLATION_EVIDENCE_v1.csv",
    "structured/EXPECTED_CANDIDATE_COVERAGE_v1.json",
    "structured/HYPOTHESIS_CANDIDATE_REGISTER_v1.json",
    "structured/INTERVENTION_COMPARISONS_v1.json",
    "structured/UNIVERSAL_LANGUAGE_INCLUSION_REGISTER_v1.csv",
    "structured/INTERVENTION_EFFECT_EVIDENCE_v1.json",
    "structured/INTERVENTION_EFFECT_EVIDENCE_v1.csv",
    "structured/CONDITIONAL_GLOBAL_PORTFOLIOS_v1.json",
    "structured/CONDITIONAL_TOP10_PROGRAM_PORTFOLIO_v1.csv",
    "structured/CONDITIONAL_TOP100_CANDIDATE_PORTFOLIO_v1.csv",
    "structured/CONDITIONAL_PORTFOLIO_MODEL_v1.json",
    "structured/CONDITIONAL_PORTFOLIO_INTERVENTIONS_v1.csv",
    "structured/CONDITIONAL_PORTFOLIO_PARAMETERS_v1.csv",
    "structured/CONDITIONAL_PORTFOLIO_SCENARIOS_v1.csv",
    "qa/HYBRID_LANGUAGE_REACH_BASELINE_QA_v1.json",
    "qa/HYBRID_REACH_HEGEMONY_AUDIT_v1.json",
    "qa/GLOBAL_REACH_AND_COMMON_PACKAGE_SOURCE_RECEIPT_v1.json",
    "qa/GLOBAL_REACH_AND_COMMON_PACKAGE_ALLOCATION_QA_v1.json",
    "qa/GLOBAL_REACH_AND_COMMON_PACKAGE_INDEPENDENT_AUDIT_v1.json",
    "qa/ACADEMIC_REGISTER_TRANSLATION_RESEARCH_QA_v1.json",
    "qa/INTERVENTION_EFFECT_EVIDENCE_QA_v1.json",
    "qa/INTERVENTION_EFFECT_EVIDENCE_INDEPENDENT_REVIEW_v1.json",
    "qa/INTERVENTION_EFFECT_EVIDENCE_REPRODUCIBILITY_RECEIPT_v1.json",
    "qa/CONDITIONAL_GLOBAL_PORTFOLIOS_QA_v1.json",
    "qa/CONDITIONAL_GLOBAL_PORTFOLIOS_INDEPENDENT_REVIEW_v1.json",
    "qa/CONDITIONAL_GLOBAL_PORTFOLIOS_REPRODUCIBILITY_RECEIPT_v1.json",
    "qa/CONDITIONAL_PORTFOLIO_MODEL_QA_v1.json",
    "qa/CONDITIONAL_PORTFOLIO_MODEL_INDEPENDENT_REVIEW_v1.json",
    "qa/CONDITIONAL_PORTFOLIO_MODEL_REPRODUCIBILITY_RECEIPT_v1.json",
    "scripts/build_global_edition_reach_and_compute_proxy_v1.py",
    "scripts/audit_global_edition_reach_and_compute_proxy_v1.py",
    "LICENSE",
]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def write(path: Path, data: str | bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode("utf-8") if isinstance(data, str) else data)


def first_n_csv_bytes(path: Path, count: int) -> bytes:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = []
        for index, row in enumerate(reader):
            if index >= count:
                break
            rows.append(row)
        fields = reader.fieldnames
    if not fields or len(rows) != count:
        raise AssertionError({"path": str(path), "expected_rows": count, "actual_rows": len(rows)})
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return ("\ufeff" + buffer.getvalue()).encode("utf-8")


def public_text_check(path: Path) -> None:
    if path.suffix.lower() not in {".md", ".json", ".csv", ".txt", ".html"}:
        return
    text = path.read_text(encoding="utf-8-sig")
    if Path.home().name in text or re.search(r"[A-Z]:[\\/]", text):
        raise AssertionError(f"Private name or absolute Windows path in public source: {path}")


def split_markdown_table_row(line: str) -> list[str]:
    """Split a Markdown table row without treating code-span pipes as columns."""
    value = line.strip()
    if value.startswith("|"):
        value = value[1:]
    if value.endswith("|"):
        value = value[:-1]
    cells: list[str] = []
    current: list[str] = []
    in_code = False
    escaped = False
    for character in value:
        if escaped:
            if character == "|":
                current.append("|")
            else:
                current.extend(("\\", character))
            escaped = False
            continue
        if character == "\\":
            escaped = True
            continue
        if character == "`":
            in_code = not in_code
            current.append(character)
            continue
        if character == "|" and not in_code:
            cells.append("".join(current).strip())
            current = []
            continue
        current.append(character)
    if escaped:
        current.append("\\")
    cells.append("".join(current).strip())
    return cells


def table_widths(headers: list[str], width: float) -> list[float]:
    normalized = [re.sub(r"[`*_]", "", value).casefold() for value in headers]
    count = len(headers)
    if normalized[:2] == ["member", "profile"] and count == 6:
        factors = [0.10, 0.18, 0.18, 0.10, 0.28, 0.16]
    elif normalized[:2] == ["id", "study"] and count == 6:
        factors = [0.09, 0.16, 0.08, 0.21, 0.26, 0.20]
    elif normalized and normalized[0] == "display order" and count == 6:
        factors = [0.09, 0.17, 0.14, 0.19, 0.15, 0.26]
    elif count == 6:
        factors = [0.11, 0.17, 0.12, 0.20, 0.20, 0.20]
    elif count == 5:
        factors = [0.18, 0.20, 0.20, 0.21, 0.21]
    elif count == 4:
        factors = [0.13, 0.30, 0.40, 0.17]
    elif count == 3:
        factors = [0.18, 0.41, 0.41]
    elif count == 2:
        factors = [0.34, 0.66]
    else:
        factors = [1 / count] * count
    return [width * factor for factor in factors]


def parse_markdown_pdf(v03, source: str):
    """Render publication Markdown with stable bullets and literal-pipe-safe tables."""
    tiny_name = "PaperTinyV04"
    tiny_header_name = "PaperTinyHeaderV04"
    bullet_name = "PaperBulletV04"
    number_name = "PaperNumberV04"
    if tiny_name not in v03.styles:
        v03.styles.add(
            ParagraphStyle(
                name=tiny_name,
                parent=v03.styles["PaperSmall"],
                fontSize=7.25,
                leading=9.15,
                splitLongWords=True,
                spaceAfter=0,
            )
        )
        v03.styles.add(
            ParagraphStyle(
                name=tiny_header_name,
                parent=v03.styles[tiny_name],
                fontName="Noto-Bold",
            )
        )
        v03.styles.add(
            ParagraphStyle(
                name=bullet_name,
                parent=v03.styles["PaperBody"],
                leftIndent=17,
                firstLineIndent=-12,
                spaceAfter=6,
                allowWidows=0,
                allowOrphans=0,
            )
        )
        v03.styles.add(
            ParagraphStyle(
                name=number_name,
                parent=v03.styles["PaperBody"],
                leftIndent=22,
                firstLineIndent=-17,
                spaceAfter=6,
            )
        )

    lines = source.splitlines()
    story = []
    paragraph: list[str] = []
    index = 0

    def flush() -> None:
        nonlocal paragraph
        if paragraph:
            text = " ".join(item.strip() for item in paragraph)
            item = v03.P(text)
            if text.startswith("**REG-") or text == "Commissioning language:":
                item.keepWithNext = True
            story.append(item)
            paragraph = []

    def continuation_text(start: int) -> tuple[str, int]:
        """Join an indented Markdown continuation to its list item."""
        pieces: list[str] = []
        cursor = start
        while cursor < len(lines):
            candidate = lines[cursor]
            if not candidate.strip() or not re.match(r"^\s{2,}\S", candidate):
                break
            if candidate.lstrip().startswith(("#", "|", "```")):
                break
            pieces.append(candidate.strip())
            cursor += 1
        return " ".join(pieces), cursor

    def append_table(block: list[list[str]]) -> None:
        column_count = len(block[0])
        cell_style = tiny_name if column_count >= 5 else "PaperSmall"
        table_data = []
        for row_number, row in enumerate(block):
            style_name = tiny_header_name if row_number == 0 else cell_style
            table_data.append([v03.P(cell, style_name) for cell in row])
        table = v03.Table(
            table_data,
            colWidths=table_widths(block[0], v03.doc_width),
            repeatRows=1,
            splitByRow=1,
            splitInRow=0,
            hAlign="LEFT",
        )
        table.setStyle(
            v03.TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), v03.colors.HexColor("#e6f0f1")),
                    ("GRID", (0, 0), (-1, -1), 0.35, v03.colors.HexColor("#aebfc2")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        story.extend([Spacer(1, 4), table, Spacer(1, 7)])

    while index < len(lines):
        line = lines[index]
        if not line.strip():
            flush()
            index += 1
            continue
        if line.startswith("# "):
            flush()
            story.append(v03.P(line[2:], "PaperH1"))
            index += 1
            continue
        if line.startswith("## "):
            flush()
            heading = line[3:]
            # The first portfolio table is deliberately segmented into stable
            # blocks. Start it on a fresh page so the first block does not
            # leave a two-row continuation page before the next hard segment.
            if heading == "The 100-profile portfolio":
                story.append(PageBreak())
            # Keep the complete design checklist together on the following
            # page instead of allowing its fourth bullet to collide with the
            # page-number footer and leaving only two bullets on a new page.
            if heading == "Design implications":
                story.append(PageBreak())
            story.append(v03.P(heading, "PaperH2"))
            index += 1
            continue
        if line.startswith("### "):
            flush()
            heading = line[4:]
            # ReportLab can strand this heading above a following
            # KeepTogether bullet even though PaperH3 has keepWithNext set.
            if heading == "Modern Standard Arabic with explicit vernacular and displacement interfaces":
                story.append(PageBreak())
            story.append(v03.P(heading, "PaperH3"))
            index += 1
            continue
        if re.match(r"^#{4,6} ", line):
            flush()
            story.append(v03.P(re.sub(r"^#{4,6} ", "", line), "PaperH3"))
            index += 1
            continue
        if line.startswith("|"):
            flush()
            raw: list[list[str]] = []
            while index < len(lines) and lines[index].startswith("|"):
                raw.append(split_markdown_table_row(lines[index]))
                index += 1
            raw = [
                row
                for row in raw
                if not all(re.fullmatch(r":?-{2,}:?", cell or "") for cell in row)
            ]
            if not raw:
                continue
            column_count = max(map(len, raw))
            raw = [row + [""] * (column_count - len(row)) for row in raw]
            normalized = [re.sub(r"[`*_]", "", value).casefold() for value in raw[0]]
            if normalized[:2] == ["member", "profile"] and column_count == 6 and len(raw) > 25:
                # A single 100-row table can begin continuation pages above the
                # frame. Stable segments repeat the header and preserve every row.
                chunk_size = 12
                for offset in range(1, len(raw), chunk_size):
                    if offset > 1:
                        story.append(PageBreak())
                    append_table([raw[0], *raw[offset : offset + chunk_size]])
            else:
                append_table(raw)
            continue
        if re.match(r"^[-*] ", line):
            flush()
            continuation, next_index = continuation_text(index + 1)
            body = line[2:].strip()
            if continuation:
                body += " " + continuation
            # A nested KeepTogether can strand the preceding heading. Ordinary
            # paragraphs honor keepWithNext and retain widow/orphan protection.
            story.append(v03.Paragraph(
                "&#8226;&nbsp;" + v03.inline(body),
                style=v03.styles[bullet_name],
            ))
            index = next_index
            continue
        if line.startswith("> "):
            flush()
            quote = []
            while index < len(lines) and lines[index].startswith("> "):
                quote.append(lines[index][2:])
                index += 1
            quote_style = ParagraphStyle(
                name="PaperQuoteV08", parent=v03.styles["PaperBody"],
                leftIndent=14, rightIndent=10, spaceBefore=4,
            )
            story.append(v03.Paragraph(v03.inline(" ".join(quote)), quote_style))
            continue
        numbered = re.match(r"^(\d+)\.\s+(.*)", line)
        if numbered:
            flush()
            continuation, next_index = continuation_text(index + 1)
            body = numbered.group(2).strip()
            if continuation:
                body += " " + continuation
            story.append(
                KeepTogether(
                    [
                        v03.Paragraph(
                            f"<b>{numbered.group(1)}.</b>&nbsp;" + v03.inline(body),
                            style=v03.styles[number_name],
                        )
                    ]
                )
            )
            index = next_index
            continue
        if line.startswith("```"):
            flush()
            index += 1
            code: list[str] = []
            while index < len(lines) and not lines[index].startswith("```"):
                code.append(lines[index])
                index += 1
            index += 1
            story.append(v03.P(" ".join(code), "PaperSmall"))
            continue
        paragraph.append(line)
        index += 1
    flush()
    return story


def build_pdf(v03, paper: str) -> dict[str, object]:
    v03.OUT = OUT
    v03.PDF = PDF
    v03.ZIP = ZIP
    v03.MANIFEST = MANIFEST
    v03.HTML = HTML
    v03.STAMP = STAMP
    v03.STATUS = STATUS
    v03.doc_width = A4[0] - 90

    intro = [
        "How should AI compute be allocated to help more people understand educational material? This study compares the audiences, educational uses and production workloads of language and register editions.",
        "The current results include two Top 100 comparisons and ten fixed-budget translation portfolios. They show how audience size and package length affect allocation under disclosed assumptions. Direct translation research helps distinguish participation from learning.",
        "This is an ongoing, non-exhaustive study, not a final funding order. Every language and exact variety remains eligible. Missing measurements remain explicit assumptions or unresolved estimates, never evidence of no educational need.",
    ]
    cover = [
        Spacer(1, 20),
        v03.P(STATUS, "Status"),
        v03.P("Allocating AI-assisted educational publishing for greater access", "CoverTitle"),
        v03.P(
            "A living research paper on educational understanding and translation workloads",
            "CoverSub",
        ),
        v03.P("Working snapshot 0.5.0 | " + STAMP, "CoverSub"),
    ]
    cover += [v03.P(item, "CoverSub") for item in intro]
    cover += [
        Spacer(1, 10),
        v03.P(
            "Living reader: https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/",
            "PaperSmall",
        ),
        PageBreak(),
    ]
    toc = TableOfContents()
    toc.levelStyles = [
        ParagraphStyle(name="Toc0v04", fontName="Noto", fontSize=10, leading=15, leftIndent=0, firstLineIndent=0, spaceBefore=4),
        ParagraphStyle(name="Toc1v04", fontName="Noto", fontSize=9, leading=13, leftIndent=18, firstLineIndent=0),
    ]
    story = cover + [
        v03.P("Contents", "PaperH1"),
        v03.P("This table describes the current working paper. Later versions may add evidence or revise conclusions."),
        toc,
        PageBreak(),
    ]
    story += parse_markdown_pdf(v03, paper)
    appendices = [
        ("Appendix A - Full-content academic-register translation", "ACADEMIC_REGISTER_TRANSLATION_RESEARCH_v1.md"),
        ("Appendix B - Anti-hegemony model audit", "HEGEMONY_BIAS_AUDIT_v1.md"),
        ("Appendix C - Intervention-effect evidence", "INTERVENTION_EFFECT_EVIDENCE_v1.md"),
        ("Appendix D - Conditional global portfolios", "CONDITIONAL_GLOBAL_PORTFOLIOS_v1.md"),
        ("Appendix E - Normalized conditional model", "CONDITIONAL_PORTFOLIO_MODEL_v1.md"),
    ]
    for label, rel in appendices:
        story += [PageBreak(), v03.P(label, "PaperH1")]
        story += parse_markdown_pdf(v03, (ROOT / rel).read_text(encoding="utf-8"))
    story += [
        v03.P("Publication status", "PaperH1"),
        v03.P(STATUS),
        v03.P(
            "The PDF is the human-readable entry point. The editable document, full HTML reader, Markdown snapshot, portfolio CSVs, manifest, and source archive preserve the current evidence and calculations. Missing or unfinished research never makes a community ineligible."
        ),
    ]
    output = OUT / PDF
    document = v03.Doc(str(output))
    document.multiBuild(story)
    reader = PdfReader(output)
    extracted = "\n".join(page.extract_text() or "" for page in reader.pages)
    required = [
        "Simplified Standard Written Chinese",
        "775 non-English",
        "Indonesian",
        "Ukrainian",
        "governing thesis",
        "any credible nonzero educational benefit",
        "53-study",
        "18 planning scenarios",
        "1,069",
        "10,625",
        "Common-package proxy position",
        "final funding order",
        "non-exhaustive",
    ]
    missing = [value for value in required if value.casefold() not in extracted.casefold()]
    if missing:
        raise AssertionError({"missing_pdf_text": missing})
    if len(reader.pages) < 40:
        raise AssertionError("Unexpectedly short PDF")
    return {
        "pages": len(reader.pages),
        "bytes": output.stat().st_size,
        "sha256": digest(output.read_bytes()),
        "required_text_checks": required,
    }


def heading_text_without_punctuation(value: str) -> str:
    value = value.replace("&", " and ").replace("_", " ")
    value = re.sub(r"[^\w\s]", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def build_docx(doc_builder) -> dict[str, object]:
    for key in ("h1", "h2", "h3"):
        doc_builder.PRESET["headings"][key]["color"] = "000000"
    doc_builder.PRESET["colors"]["ink"] = "000000"
    output = OUT / DOCX
    report = doc_builder.build_document(OUT / MARKDOWN, None, output, None)
    document = Document(output)
    for style_name in ("Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3"):
        style = document.styles[style_name]
        style.font.color.rgb = RGBColor(0, 0, 0)
        style_ppr = style._element.get_or_add_pPr()
        style_border = style_ppr.find(qn("w:pBdr"))
        if style_border is not None:
            style_ppr.remove(style_border)
    in_abstract = False
    for paragraph in document.paragraphs:
        if paragraph.text == "Reproducibility snapshot - 1 September 2026":
            paragraph.text = "Working snapshot 0.5.0 - 6 September 2026"
        if paragraph.style.name == "Heading 1" and paragraph.text == "Abstract":
            in_abstract = True
        elif in_abstract and not paragraph.text.strip():
            in_abstract = False
        paragraph_ppr = paragraph._p.get_or_add_pPr()
        paragraph_border = paragraph_ppr.find(qn("w:pBdr"))
        if paragraph_border is not None:
            paragraph_ppr.remove(paragraph_border)
        if in_abstract and paragraph.style.name == "Normal":
            for tag in ("w:shd", "w:ind"):
                element = paragraph_ppr.find(qn(tag))
                if element is not None:
                    paragraph_ppr.remove(element)
        if paragraph.style.name in ("Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3"):
            replacement = heading_text_without_punctuation(paragraph.text)
            if replacement and replacement != paragraph.text:
                paragraph.text = replacement
            for run in paragraph.runs:
                run.font.color.rgb = RGBColor(0, 0, 0)
    dash_map = str.maketrans({"\u2011": "-", "\u2013": "-", "\u2014": "-"})
    for root in [document._element, *[part._element for section in document.sections for part in (section.header, section.footer)]]:
        for text_node in root.xpath(".//w:t"):
            if text_node.text:
                text_node.text = text_node.text.translate(dash_map)
    document.core_properties.title = "Allocating AI assisted educational publishing for greater access"
    document.core_properties.subject = "Living working paper on global educational access"
    document.core_properties.content_status = "Ongoing non exhaustive working paper"
    document.save(output)
    doc_builder.normalize_docx_zip(output)
    reopened = Document(output)
    if not any(p.style.name == "Title" and p.text == "Allocating AI assisted educational publishing for greater access" for p in reopened.paragraphs):
        raise AssertionError("DOCX title validation failed")
    report.update({"bytes": output.stat().st_size, "sha256": digest(output.read_bytes())})
    return report


def build_html(html_builder, paper: str, pdf_info: dict[str, object]) -> dict[str, object]:
    rendered, headings = html_builder.render_markdown(paper)
    rendered = re.sub(r"^<h1[^>]*>.*?</h1>\s*", "", rendered, count=1, flags=re.S)
    toc = []
    for level, title, ident in headings:
        if level == 2:
            toc.append(f'<li><a href="#{ident}">{html.escape(title)}</a></li>')
        elif level == 3:
            toc.append(f'<li class="sub"><a href="#{ident}">{html.escape(title)}</a></li>')
    css = """
:root{--ink:#17262c;--muted:#53656b;--teal:#0f5968;--pale:#edf5f5;--gold:#fff0ba;--line:#b7c8cb}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f5f7f6;color:var(--ink);font:18px/1.62 system-ui,-apple-system,"Segoe UI",sans-serif}
a{color:#075c75}.skip{position:absolute;left:-9999px}.skip:focus{left:1rem;top:1rem;background:#fff;padding:.75rem;z-index:10}
header{background:#183f48;color:#fff;padding:clamp(28px,6vw,76px) 20px}header .shell{max-width:1160px;margin:auto}header h1{font:700 clamp(2.1rem,5vw,4rem)/1.12 Georgia,serif;margin:.25em 0}.status{display:inline-block;background:var(--gold);color:#5c4300;padding:.45rem .7rem;font-weight:800}
.layout{display:grid;grid-template-columns:minmax(0,820px) 280px;gap:3rem;max-width:1160px;margin:auto;padding:42px 20px 80px}.downloads{border-bottom:1px solid var(--line);padding-bottom:1.5rem}.downloads a{display:inline-block;margin:.25rem .75rem .25rem 0;font-weight:700}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:.7rem;margin:1.5rem 0}.stat{background:var(--pale);padding:.8rem}.stat strong{display:block;font-size:1.4rem}
article h2,article h3,article h4{font-family:Georgia,serif;color:#183f48;line-height:1.2;scroll-margin-top:1rem}article h2{margin-top:2.5em}article h3{margin-top:1.8em}.toc{position:sticky;top:18px;align-self:start;max-height:calc(100vh - 36px);overflow:auto;border-left:3px solid var(--teal);padding-left:1rem;font-size:.84rem}.toc h2{margin-top:0}.toc ol{padding-left:1.25rem}.toc .sub{margin-left:1rem}
main,article{min-width:0}p,li,td,th{overflow-wrap:anywhere}.table-wrap{max-width:100%;overflow-x:auto;margin:1.4rem 0}table{border-collapse:collapse;width:100%;font-size:.86rem}caption{text-align:left;font-weight:700;margin-bottom:.5rem}th,td{border:1px solid var(--line);padding:.55rem;vertical-align:top;text-align:left}th{background:var(--pale)}pre,.math-block{max-width:100%;overflow:auto;background:#f3f5f5;padding:1rem}blockquote{border-left:4px solid var(--teal);margin-left:0;padding-left:1rem;color:#354b53}.footer{max-width:1160px;margin:auto;padding:1rem 20px 3rem;color:var(--muted)}
@media(max-width:900px){.layout{display:block}.toc{position:static;max-height:none;border-left:0;border-top:1px solid var(--line);margin-top:2rem;padding-top:1rem}}@media(max-width:600px){body{font-size:16px}.layout{padding:25px 16px 60px}header{padding:34px 16px}}
"""
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Ongoing global research on allocating AI compute for functional educational access"><title>Allocating AI-assisted educational publishing for greater access - v0.5</title><style>{css}</style></head><body>
<a class="skip" href="#paper">Skip to the paper</a><header><div class="shell"><p class="status">{STATUS}</p><h1>Allocating AI-assisted educational publishing for greater access</h1><p>This living paper compares populations plausibly helped, educational needs, intervention evidence, and production effort. It retains every language and treats missing measurements as research obligations.</p></div></header>
<div class="layout"><main><section class="downloads" aria-labelledby="download-heading"><h2 id="download-heading">Read and download this checkpoint</h2><p><a href="{PDF}">Open the {pdf_info['pages']}-page PDF</a><a href="{DOCX}">Download the editable Word document</a><a href="{MARKDOWN}">Read the Markdown source</a><a href="{REACH_TOP100}">Download the worldwide reach table</a><a href="{COMPUTE_TOP100}">Download the fixed-package workload table</a><a href="{PROFILE_INVENTORY}">Download the separate nonordinal profile inventory</a><a href="{MANIFEST}">Inspect the manifest</a><a href="{ZIP}">Download the evidence archive</a></p><div class="stats"><div class="stat"><strong>775</strong>edition-level reach rows</div><div class="stat"><strong>100</strong>explicit reach positions</div><div class="stat"><strong>100</strong>fixed-package proxy positions</div><div class="stat"><strong>1,069</strong>normalized interventions</div><div class="stat"><strong>53</strong>effect studies</div></div><p><strong>Do not confuse IDs with ranks:</strong> profile member codes are stable research identifiers. Only columns explicitly named reach position or common-package proxy position are ordinal.</p><p><strong>Stage codes:</strong> P preschool and early childhood; F foundation and primary; S secondary; V vocational and professional; U university; R postgraduate and research.</p><p>The governing access thesis is not an eligibility test. Evidence improves the design and estimates its effect; it cannot justify withholding access or inferring innate capacity.</p></section><article id="paper"><h2>Full working paper</h2>{rendered}</article></main><nav class="toc" aria-label="Paper contents"><h2>Contents</h2><ol>{''.join(toc)}</ol></nav></div><footer class="footer">Ongoing and non-exhaustive working paper. The PDF is the public entry point; the source archive contains the bound evidence and reproducibility receipts.</footer></body></html>'''
    output = OUT / HTML
    write(output, page)
    check = output.read_text(encoding="utf-8")
    required = [PDF, DOCX, MARKDOWN, REACH_TOP100, COMPUTE_TOP100, PROFILE_INVENTORY, "775", "1,069", "governing access thesis", "Full working paper"]
    missing = [value for value in required if value not in check]
    if missing or "<script" in check.lower() or "http://" in check:
        raise AssertionError({"html_missing": missing, "has_script": "<script" in check.lower()})
    return {"bytes": output.stat().st_size, "sha256": digest(output.read_bytes()), "headings": len(headings), "required_checks": required}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for rel in SOURCES:
        path = ROOT / rel
        if not path.is_file():
            raise FileNotFoundError(rel)
        public_text_check(path)

    v03 = load_module("living_v03_helpers", ROOT / "scripts/build_living_notebook_v0_3.py")
    html_builder = load_module("html_reader_helpers", ROOT / "scripts/build_html_v1.py")
    doc_builder = load_module("docx_builder_helpers", ROOT / "scripts/build_research_artifacts_v1.py")
    paper_base = (ROOT / "PAPER_CURRENT_DRAFT.md").read_text(encoding="utf-8")
    allocation_checkpoint = (ROOT / "GLOBAL_REACH_AND_COMMON_PACKAGE_ALLOCATION_CHECKPOINT_v1.md").read_text(encoding="utf-8")
    allocation_checkpoint = allocation_checkpoint.replace(
        "# Worldwide reach and common-package allocation checkpoint",
        "## 8. Worldwide reach and common-package allocation checkpoint",
        1,
    ).replace("\n## ", "\n### ")
    paper = paper_base.rstrip() + "\n\n" + allocation_checkpoint.lstrip()
    write(OUT / MARKDOWN, paper)
    write(OUT / REACH_TOP100, first_n_csv_bytes(ROOT / "structured/GLOBAL_EDITION_REACH_BASELINE_v3.csv", 100))
    write(OUT / COMPUTE_TOP100, first_n_csv_bytes(ROOT / "structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv", 100))
    write(OUT / PROFILE_INVENTORY, (ROOT / "structured/CONDITIONAL_TOP100_CANDIDATE_PORTFOLIO_v1.csv").read_bytes())
    status_text = (
        "# Publication status\n\n"
        f"**{STATUS}**\n\n"
        "This dated research checkpoint is open, evolving and non-exhaustive. It publishes a real 100-row worldwide potential-reach order and a distinct 100-row fixed-package workload proxy. Those tables order named quantities; neither ranks the worth of languages or communities and neither is yet the final target-specific funding order. The nonordinal 100-profile inventory is a separate research aid whose member codes are not ranks. Every missing or unresolved language remains eligible and is retained as a possible outranker. The PDF is the human-readable public entry point. The HTML contains the full paper, the DOCX is editable, and the source archive preserves the evidence and deterministic receipts.\n"
    )
    write(OUT / PUBLICATION_STATUS, status_text)

    pdf_info = build_pdf(v03, paper)
    docx_info = build_docx(doc_builder)
    html_info = build_html(html_builder, paper, pdf_info)

    fixed_time = (2026, 9, 6, 0, 0, 0)
    with zipfile.ZipFile(OUT / ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for rel in SOURCES:
            info = zipfile.ZipInfo(rel, date_time=fixed_time)
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (ROOT / rel).read_bytes())
        for name in (MARKDOWN, REACH_TOP100, COMPUTE_TOP100, PROFILE_INVENTORY, PUBLICATION_STATUS):
            info = zipfile.ZipInfo(name, date_time=fixed_time)
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (OUT / name).read_bytes())
    with zipfile.ZipFile(OUT / ZIP) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(SOURCES) + 5:
            raise AssertionError("Source archive integrity failure")

    source_bindings = []
    for rel in SOURCES:
        data = (ROOT / rel).read_bytes()
        source_bindings.append({"path": rel, "bytes": len(data), "sha256": digest(data)})

    public_names = [PDF, HTML, DOCX, MARKDOWN, REACH_TOP100, COMPUTE_TOP100, PROFILE_INVENTORY, ZIP, PUBLICATION_STATUS]
    artifacts = []
    for name in public_names:
        path = OUT / name
        public_text_check(path)
        data = path.read_bytes()
        artifacts.append({"name": name, "bytes": len(data), "sha256": digest(data)})

    manifest = {
        "schema": "living-educational-access-working-paper/0.5.0",
        "snapshot_date": "2026-09-06",
        "version": "0.5.0-working-paper",
        "status": STATUS,
        "final_product": False,
        "exhaustive": False,
        "moral_or_funding_rank": False,
        "missing_language_means_lower_need": False,
        "missing_evidence_means_exclusion": False,
        "local_programme_changes_global_need": False,
        "governing_access_thesis_is_scored": False,
        "governing_access_thesis": "Inherited familiarity with academic language is an institutionally distributed advantage. A complete source-faithful translation into an audience-specified adult register remains eligible whenever any credible nonzero educational benefit is plausible.",
        "paper": {"name": PDF, "entry_point": True, **pdf_info},
        "html_reader": {"name": HTML, "full_manuscript": True, **html_info},
        "editable_document": {"name": DOCX, "bytes": (OUT / DOCX).stat().st_size, "sha256": digest((OUT / DOCX).read_bytes()), "source": MARKDOWN},
        "source_archive": {"name": ZIP, "bytes": (OUT / ZIP).stat().st_size, "sha256": digest((OUT / ZIP).read_bytes()), "entries": len(SOURCES) + 5, "integrity": "PASS"},
        "public_artifacts_excluding_manifest": artifacts,
        "source_bindings": source_bindings,
        "research_coverage": {
            "global_possible_outrankers": 10625,
            "normalized_single_stage_interventions": 1069,
            "source_route_interventions": 1022,
            "first_tranche_program_stage_interventions": 47,
            "effect_studies": 53,
            "planning_scenarios": 18,
            "first_tranche_programs": 10,
            "nonordinal_profile_set": 100,
            "edition_reach_rows": 775,
            "ordinal_reach_top100_rows": 100,
            "ordinal_common_package_proxy_top100_rows": 100,
            "measured_language_script_workload_rows": 162,
            "common_envelope_workload_rows": 613,
            "robust_global_dominance_edges": 0,
            "stages": ["P", "F", "S", "V", "U", "R"],
        },
        "limits": [
            "The ten-program tranche is one replaceable hedge, not a unique optimum or final funding order.",
            "The 100-profile set is nonordinal; all other analytical entities remain possible outrankers.",
            "The reach Top 100 and common-package proxy Top 100 are ordinal only for the quantities named in their columns; neither is a final target-specific allocation order.",
            "Most exact edition audiences, matched effects, delivery use, beneficiary overlap and standardized physical-compute values remain unresolved.",
            "Token traffic is not physical compute, energy, money or educational effect.",
            "Null or adverse evidence for one design changes the implementation, not a community's eligibility for access.",
        ],
    }
    write(OUT / MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    public_text_check(OUT / MANIFEST)

    qa = {
        "schema": "living-working-paper-build-qa/0.5.0",
        "built_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_STRUCTURAL_TEXT_HTML_DOCX_AND_ARCHIVE_CHECKS_VISUAL_REVIEW_PENDING",
        "pdf": pdf_info,
        "html": html_info,
        "docx": {"bytes": (OUT / DOCX).stat().st_size, "sha256": digest((OUT / DOCX).read_bytes()), "build": docx_info},
        "source_archive": manifest["source_archive"],
        "source_bindings": len(source_bindings),
        "public_files": len(public_names) + 1,
        "zip_integrity": "PASS",
        "conditional_model_constructor": "PASS_36_OF_36",
        "conditional_model_independent_review": "PASS_39_OF_39",
        "conditional_model_reproducibility": "PASS_TWO_BYTE_IDENTICAL_BUILDS",
        "public_mutation": False,
    }
    write(ROOT / "qa/LIVING_WORKING_PAPER_BUILD_QA_v0_5.json", json.dumps(qa, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(qa, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
