"""Source-bound effects, missing-outcome bounds and explicit transport scenarios."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources/language_instruction/BALTER_EMI_2024.pdf'
OUT = ROOT / 'structured/DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.json'
REPORT = ROOT / 'DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.md'
SECTION = ROOT / 'DIRECT_TRANSLATION_EFFECT_SECTION_v1.md'


def main():
    # Transcribed from visually inspected Table 2 and participant flow, pp.9-13.
    n_s, n_e, mean_s, mean_e, sd_s, sd_e = 1134, 1129, 7.24, 4.18, 13.2, 10.2
    registered_s, registered_e, missing_s, missing_e = 1265, 1210, 131, 81
    active_s, active_e, maximum = 485, 330, 42
    difference = mean_s - mean_e
    standard_error = math.sqrt(sd_s**2/n_s + sd_e**2/n_e)
    score_ci = [difference-1.96*standard_error, difference+1.96*standard_error]
    p_s, p_e = active_s/n_s, active_e/n_e
    initiation = p_s-p_e
    initiation_se = math.sqrt(p_s*(1-p_s)/n_s+p_e*(1-p_e)/n_e)
    initiation_ci = [initiation-1.96*initiation_se, initiation+1.96*initiation_se]
    missing_initiation = [active_s/registered_s-(active_e+missing_e)/registered_e,
                          (active_s+missing_s)/registered_s-active_e/registered_e]
    # Integer outcome totals compatible with published two-decimal rounded means.
    sum_s_lo, sum_s_hi = math.ceil((mean_s-.005)*n_s), math.floor((mean_s+.005)*n_s)
    sum_e_lo, sum_e_hi = math.ceil((mean_e-.005)*n_e), math.floor((mean_e+.005)*n_e)
    missing_score = [sum_s_lo/registered_s-(sum_e_hi+missing_e*maximum)/registered_e,
                     (sum_s_hi+missing_s*maximum)/registered_s-sum_e_lo/registered_e]
    # The same comparable audience and endpoint are retained for all t values.
    scenarios = [{
        'comparable_enrollees': 1000, 'transport_multiplier': t,
        'transport_status': 'DECLARED_SENSITIVITY_NOT_ESTIMATED',
        'additional_correct_answer_units': 1000*t*difference,
        'additional_test_initiators': 1000*t*initiation,
        'score_normalized_to_42_items': t*difference/maximum,
        'outcome_units_not_additive_with_each_other': True,
    } for t in (0, .25, .5, 1)]
    data = {
        'schema':'direct-translation-effect-allocation/1.0.0',
        'timestamp_utc':datetime.now(timezone.utc).isoformat(),
        'source':{'doi':'10.1515/applirev-2022-0093','url':'https://research.chalmers.se/publication/537583/file/537583_Fulltext.pdf',
            'local_path':str(SOURCE.relative_to(ROOT)), 'bytes':SOURCE.stat().st_size,
            'sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest().upper(),
            'locators':'Printed pp.7-11 design and participant flow; p.13 Tables 2-3; p.15 section 4.2. Repository cover adds one PDF page.'},
        'comparison':'Otherwise identical eight-module self-study programming course, Swedish versus English, both culturally adapted.',
        'assigned_total':3022,'registered_total':2475,'unregistered_after_assignment':547,'excluded_switchers':212,
        'group_inputs':{'swedish':{'registered':registered_s,'analyzed':n_s,'excluded_switchers':missing_s,'active':active_s,'score_mean':mean_s,'score_sd':sd_s},
                        'english':{'registered':registered_e,'analyzed':n_e,'excluded_switchers':missing_e,'active':active_e,'score_mean':mean_e,'score_sd':sd_e}},
        'score_endpoint':{'definition':'Correct module-test answers, range 0 to 42, non-attempters counted zero in analyzed group.',
            'difference_answers':difference,'normal_95_interval_from_rounded_aggregates':score_ci,
            'normalized_mean_score_difference':difference/maximum,
            'normalized_difference_is_not_probability_someone_benefits':True,
            'reported_rank_sum_p':'<.0001','reported_cliffs_delta':.15},
        'initiation_endpoint':{'definition':'Attempt at least one module-test question. Neither course completion nor demonstrated learning.',
            'swedish_rate':p_s,'english_rate':p_e,'risk_difference':initiation,
            'normal_95_interval_from_counts':initiation_ci,'reported_chi_square':45,'reported_p':'<.00001'},
        'registered_cohort_missing_outcome_bounds':{
            'initiation_risk_difference':missing_initiation,'mean_score_difference_integer_rounding_aware':missing_score,
            'initiation_sign_survives_all_switcher_binary_outcomes':missing_initiation[0]>0,
            'score_sign_survives_all_switcher_outcomes':missing_score[0]>0,
            'interpretation':'Deterministic outcome-completion bounds among completed registrants under original assignment. Not confidence intervals, not full randomized-cohort ITT, not adjustment for registration selection and not transport uncertainty.'},
        'sampling_interval_scope':'Normal-approximation intervals calculated here, not reported source confidence intervals. They cover sampling error in analyzed groups only; they do not include selection, measurement or transport uncertainty.',
        'allocation_equation':'For M comparable future enrollees, retained effect fraction t and measured package workload C, projected additional correct-answer units per workload = M*t*3.06/C. Initiation is a separate endpoint M*t*(485/1134-330/1129)/C. Do not add the two.',
        'deployment_denominator':'M is comparable enrolled learners under a specified deployment, not the whole speaking population. No country or language receives a study-derived t without an explicit transport assumption.',
        'scenario_rows':scenarios,
        'scope_limits':['Language and testing language vary together; no separate delayed transfer test.', 'Post-assignment switching and registration selection limit causal interpretation.', 'No AI translation production-cost or quality measurement is supplied by this study.', 'The study does not estimate gains from printed prealgebra, interlanguages or adult intralingual register translation.'],
    }
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    section = f'''### 7.10 What direct translation evidence contributes to allocation

A translated self-study course can change participation as well as test performance. Bälter et al. (2024) compared otherwise identical Swedish and English programming courses. Among the 2,263 analyzed learners, the Swedish group had an average score {difference:.2f} answers higher out of 42 and a test-initiation rate {initiation*100:.2f} percentage points higher. Here initiation means attempting at least one module-test question, not completing the course (Tables 2-3 and section 4.2).

The analysis excluded 212 language switchers. Assigning their missing outcomes every allowable value gives a registered-cohort initiation difference of {missing_initiation[0]*100:.2f} to {missing_initiation[1]*100:.2f} percentage points, still positive, but a score difference of {missing_score[0]:.2f} to {missing_score[1]:.2f} answers. These are missing-outcome bounds, not confidence intervals or a full randomized-cohort estimate; 547 assigned applicants never completed registration.

This supports familiar-language self-study as a concrete intervention to compare, without assuming a universal learning effect. For 1,000 comparable future enrollees, preserving one-quarter, one-half or all of the analyzed score difference would yield 765, 1,530 or 3,060 additional correct-answer units. These are declared transport scenarios. The denominator for efficiency is the production and delivery workload of the actual course. Correct-answer units measure aggregate performance, not distinct people helped.

Allocation should therefore compare relevant learner cohorts and particular resources, preserving participation and learning as separate outcomes. The result strengthens the case for worked exercises, feedback and accessible language in self-study packages. It does not establish a population-wide benefit multiplier for any language. The calculation appendix preserves sampling intervals, missing-outcome bounds and exact assumptions.
'''
    SECTION.write_text(section,encoding='utf-8')
    report = ['# Direct translation evidence and compute allocation','',section.strip(),'',
        '## Recomputed effects','',
        '| Outcome | Analyzed-group difference | Approximate 95% sampling interval | Registered-cohort missing-outcome bounds |',
        '|---|---:|---:|---:|',
        f'| Correct answers out of 42 | {difference:.2f} | {score_ci[0]:.2f} to {score_ci[1]:.2f} | {missing_score[0]:.2f} to {missing_score[1]:.2f} |',
        f'| Test initiation percentage points | {initiation*100:.3f} | {initiation_ci[0]*100:.3f} to {initiation_ci[1]*100:.3f} | {missing_initiation[0]*100:.3f} to {missing_initiation[1]*100:.3f} |','',
        'Normal intervals use reported rounded means and standard deviations or exact binary counts. They do not include selection or transport uncertainty. Missing-score bounds use integer totals compatible with rounding of the published means. The initiation bound is based on assigning missing outcomes zero or one by original assignment. The positive bound does not remove possible selection during registration.','',
        '## Explicit deployment sensitivities','',
        '| Comparable enrollees | Fraction of analyzed effect retained | Additional correct-answer units | Additional test initiators |',
        '|---:|---:|---:|---:|']
    report += [f"| {s['comparable_enrollees']} | {s['transport_multiplier']:.0%} | {s['additional_correct_answer_units']:,.0f} | {s['additional_test_initiators']:.1f} |" for s in scenarios]
    report += ['', 'Zero retention is a sensitivity case, not a default for an unmeasured language. No scenario is assigned to a target community by evidence availability. Benefits on the two endpoints overlap and must not be added. A normalized score difference of 3.06/42 is not the probability that a person benefits.','',
        '## Source and reproducibility','',
        'Bälter, O., Kann, V., Mutimukwe, C., & Malmström, H. (2024). English-medium instruction and impact on academic performance: A randomized control study. *Applied Linguistics Review, 15*(6), 2373-2396. https://doi.org/10.1515/applirev-2022-0093','',
        'Full primary text: https://research.chalmers.se/publication/537583/file/537583_Fulltext.pdf. Printed pp.7-11,13,15; repository cover adds one PDF page. Calculations: `scripts/build_direct_translation_effect_allocation_v1.py`; inputs and results: `structured/DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.json`.','']
    REPORT.write_text('\n'.join(report),encoding='utf-8')
    checks = {'registered_counts':registered_s+registered_e==2475,
        'analyzed_counts':n_s+n_e==2263,'switchers':missing_s+missing_e==212,
        'registration_reconciliation':3022-2475==547,
        'initiation_difference_in_sampling_interval':initiation_ci[0]<initiation<initiation_ci[1],
        'positive_initiation_worst_case':missing_initiation[0]>0,
        'score_worst_case_crosses_zero':missing_score[0]<0<missing_score[1],
        'four_explicit_scenarios':len(scenarios)==4,
        'no_count_of_unique_people_from_scores':data['score_endpoint']['normalized_difference_is_not_probability_someone_benefits']}
    receipt={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,
        'artifacts':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()} for p in (OUT,REPORT,SECTION)]}
    (ROOT/'qa/DIRECT_TRANSLATION_EFFECT_ALLOCATION_QA_v1.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))
    assert all(checks.values())


if __name__ == '__main__':
    main()
