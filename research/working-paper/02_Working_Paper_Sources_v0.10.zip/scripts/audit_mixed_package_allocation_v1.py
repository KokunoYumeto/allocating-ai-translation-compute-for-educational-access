"""Read-only independent exact rescore of saved mixed-package results; no optimizer.

Writes only the two named independent audit outputs in qa/. All source and
production artifacts remain immutable. Run with Python -B -X utf8.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAMES = ('supported_fractions', 'six_chapters', 'full_prealgebra')
ALPHAS = {'lower_focused_yield': (F(7, 20), F(14, 20), F(1)),
          'higher_focused_yield': (F(13, 20), F(18, 20), F(1))}
EXPECTED = {
    'structured/GLOBAL_BUDGET_SCENARIOS_v1.json': 'CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57',
    'structured/OPENSTAX_PACKAGE_SCALE_20260904.json': 'F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16',
    'structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json': '61088618CCF3C3C1A32E4D68EB4F9BAC115D354CB74DAE675E6816475A98CD86',
}
CHECKS = Counter()
FAILURES = []
IDENTITIES = {}


def check(ok, group, detail):
    CHECKS[group] += 1
    if not ok:
        FAILURES.append({'check': group, 'detail': detail})
    return bool(ok)


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def read(rel, as_json=True):
    raw = (ROOT / rel).read_bytes()
    IDENTITIES[rel] = {'path': rel, 'bytes': len(raw), 'sha256': sha(raw)}
    return json.loads(raw) if as_json else raw


def rat(x):
    return F(x['numerator'], x['denominator']) if isinstance(x, dict) else F(str(x))


def exact(x):
    x = F(x)
    return {'numerator': x.numerator, 'denominator': x.denominator, 'decimal': float(x)}


def same_exact(saved, computed, where):
    check(rat(saved) == computed, 'exact_rational_fields', where)
    check(saved['decimal'] == float(computed), 'decimal_fields', where)


def main():
    d = read('structured/MIXED_PACKAGE_ALLOCATION_v1.json')
    old = read('structured/GLOBAL_BUDGET_SCENARIOS_v1.json')
    scale = read('structured/OPENSTAX_PACKAGE_SCALE_20260904.json')
    support = read('structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json')
    cache = read('qa/MIXED_PACKAGE_SOLVE_CACHE_v1.json')
    qa = read('qa/MIXED_PACKAGE_ALLOCATION_QA_v1.json')
    report = read('MIXED_PACKAGE_ALLOCATION_v1.md', False).decode('utf-8').replace('\r\n', '\n')
    read('scripts/build_mixed_package_allocation_v1.py', False)
    read('scripts/audit_mixed_package_allocation_v1.py', False)
    for rel, expected in EXPECTED.items():
        check(IDENTITIES[rel]['sha256'] == expected, 'input_hash_bindings', rel)
    for binding in d['source_bindings'] + qa['outputs']:
        check(binding == IDENTITIES[binding['path']], 'input_hash_bindings', binding['path'])
    check(qa['status'] == 'PASS' and all(qa['checks'].values()), 'production_qa_receipt', 'Declared QA PASS')

    rows = old['candidate_rows']
    by_id = {r['row_id']: r for r in rows}
    known = [r for r in rows if r['population_coefficient'] is not None]
    unknown = [r for r in rows if r['population_coefficient'] is None]
    check(d['candidate_rows'] == rows and len(rows) == len(by_id) == 775,
          'population_universe', 'All 775 complete row objects equal the bound baseline')
    check(len(known) == d['numeric_rows'] == 750 and len(unknown) == d['symbolic_rows'] == 25,
          'population_universe', '750 numeric and 25 null audiences')
    pop = {r['row_id']: rat(r['population_coefficient']) for r in known}
    bases = {r['row_id']: rat(r['base_100k_cost_fecu']) for r in rows}
    check(all(p.denominator == 1 and p >= 0 for p in pop.values()), 'objective_lattice', 'Every numeric audience is a nonnegative integer')
    check(d['case_study_need_adjustment'] == 0 and d['scenario_parameters_are_measurements'] is False,
          'interpretation_contract', 'No needs discount or empirical scenario claim')
    check('not substituted' in d['endpoint']['world_population_replacement'],
          'interpretation_contract', 'PISA context counts explicitly not substituted')

    modules = {m['module_id']: m for m in scale['modules']}
    archive_rel = scale['source_archive']['path']
    archive_raw = read(archive_rel, False)
    check(IDENTITIES[archive_rel] == scale['source_archive'] == support['source_archive'],
          'source_archive', 'Pinned archive byte count and SHA-256')
    check(scale['commit'] == support['source_commit'] == '38cae454e644abf9f0a623e876994553881597c9',
          'source_archive', 'Pinned commit')
    source_file_checks = []
    with zipfile.ZipFile(ROOT / archive_rel) as z:
        for entry in scale['source_files']:
            raw = z.read(entry['path'])
            check(len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], 'source_file_hashes', entry['path'])
        for mid, m in modules.items():
            raw = z.read(m['path'])
            check(sha(raw) == m['sha256'] and len(raw) == m['bytes'], 'module_identity', mid)
            content = ET.fromstring(raw).find('{http://cnx.rice.edu/cnxml}content')
            extracted = unicodedata.normalize('NFC', ' '.join(' '.join(content.itertext()).split()))
            check(sha(extracted.encode('utf-8')) == m['extracted_content_text_sha256'] and
                  len(extracted) == m['extracted_text_codepoints'], 'source_text_reconstruction', mid)
            source_file_checks.append({'module_id': mid, 'sha256': sha(raw),
                                       'content_text_sha256': sha(extracted.encode('utf-8'))})
        fractions = set(scale['candidates']['fractions_chapter_only']['module_ids'])
        direct_external = set()
        for mid in fractions:
            content = ET.fromstring(z.read(modules[mid]['path'])).find('{http://cnx.rice.edu/cnxml}content')
            for element in content.iter():
                if element.tag == '{http://cnx.rice.edu/cnxml}link':
                    document = element.get('document')
                    if document and document not in fractions:
                        direct_external.add(document)
    check(direct_external == set(support['linked_modules_outside_package']),
          'source_support_links', 'Direct CNXML outside module links match the support set')
    for m in support['modules'] + support['one_hop_padding_scenario']['modules']:
        check(m['sha256'] == modules[m['module_id']]['sha256'] and
              m['content_tokens'] == modules[m['module_id']]['tokens']['cl100k_base']['content_text'],
              'support_module_identity', m['module_id'])
    sets = [fractions | direct_external,
            set(scale['candidates']['selected_quantitative_units_scenario']['module_ids']),
            set(scale['candidates']['complete_source_collection']['module_ids'])]
    token_sum = lambda ms: sum(modules[m]['tokens']['cl100k_base']['content_text'] for m in ms)
    tokens = [token_sum(s) for s in sets]
    check([len(s) for s in sets] == [16, 36, 75] and tokens == [87655, 173958, 364270],
          'source_packages', 'All three package module and token totals')
    check(d['module_identities'] == [modules[m] for m in sorted(sets[2])], 'module_identity', 'All 75 module objects retained')
    unions = []
    for mask in range(8):
        union = set().union(*(sets[k] for k in range(3) if mask & (1 << k)))
        reconstructed = {'mask': mask, 'packages': [NAMES[k] for k in range(3) if mask & (1 << k)],
                         'modules': sorted(union), 'source_tokens': token_sum(union)}
        check(reconstructed == d['module_union_masks'][mask], 'source_union_masks', str(mask))
        unions.append(reconstructed)
    check(unions[3]['source_tokens'] == 198477 and len(unions[3]['modules']) == 40 and
          not sets[0] <= sets[1] and not sets[1] <= sets[0], 'source_union_masks', 'Non-nested union')
    extras = (F(1, 20), F(1, 50), F(0))
    factors = [(F(tokens[k], 100000) + extras[k] * F(364270, 100000)) for k in range(3)]
    cost = {rid: [base * factor for factor in factors] for rid, base in bases.items()}
    for k, p in enumerate(d['packages']):
        check(p['name'] == NAMES[k] and p['modules'] == sorted(sets[k]) and p['tokens'] == tokens[k],
              'source_packages', p['name'])
        same_exact(p['extra_ratio'], extras[k], 'extra ratio '+p['name'])
    unknown_bases = {bases[r['row_id']] for r in unknown}
    check(len(unknown_bases) == 1, 'unknowns', 'Equal-cost symbolic profiles')
    unknown_cost = [next(iter(unknown_bases)) * factor for factor in factors]

    # This independently builds the entire transitive, acyclic weak-dominance order.
    ids = [r['row_id'] for r in known]
    dominates = {j: [i for i in ids if i != j and pop[i] >= pop[j] and bases[i] <= bases[j]
                      and (pop[i] > pop[j] or bases[i] < bases[j] or i < j)] for j in ids}
    certificates = {}

    def dominance_certificate(K):
        if K in certificates:
            return certificates[K]
        dropped = [j for j in ids if K == 0 or len(dominates[j]) >= K]
        retained = set(ids) - set(dropped)
        witness_proof = []
        for j in dropped:
            witnesses = [i for i in dominates[j] if i in retained][:K]
            check(len(witnesses) == K, 'simultaneous_pruning_retained_witnesses', f'K={K}, {j}')
            witness_proof.append({'row_id': j, 'retained_witness_ids': witnesses})
        certificate = {'K': K, 'retained_ids': sorted(retained), 'pruned_rows': len(dropped),
                       'all_pruned_rows_have_K_retained_dominators': all(len(w['retained_witness_ids']) == K for w in witness_proof),
                       'retained_witnesses': witness_proof}
        certificates[K] = certificate
        return certificate

    cached_results = {}
    audit_results = []
    lattice = F(1, 20)
    for key, r in cache.items():
        version, budget, alpha_strings, rate, allowed, forced_type, forced_cost_string, bindings = json.loads(key)
        alpha = tuple(map(F, alpha_strings))
        forced_cost = F(forced_cost_string)
        label = r['solver']['label']
        check(version == 'dominance-safe-v1' and bindings == EXPECTED, 'cache_parameter_binding', label)
        check(alpha in tuple(ALPHAS.values()) + ((F(1),) * 3,), 'cache_parameter_binding', label+' yields')
        check(rate in (0, 2) and budget in (5000000, 10000000, 20000000) and
              (allowed == [0, 1, 2] or allowed in [[0], [1], [2]]), 'cache_parameter_binding', label+' domain')
        check(forced_cost == (unknown_cost[forced_type] if forced_type is not None else 0),
              'cache_parameter_binding', label+' forced cost')
        params = (budget, alpha, rate, tuple(allowed), forced_type, forced_cost)
        check(params not in cached_results, 'cache_parameter_binding', label+' unique')
        cached_results[params] = r
        solver = r['solver']
        check(solver['time_limit_seconds'] == 20 and solver['threads'] == 1,
              'solver_resource_declarations', label)
        result = {'label': label, 'budget': budget, 'relative_yields': [exact(a) for a in alpha],
                  'setup_rate': rate, 'allowed_packages': [NAMES[k] for k in allowed],
                  'forced_package': NAMES[forced_type] if forced_type is not None else None,
                  'forced_variable_cost': exact(forced_cost), 'feasible': r['feasible']}
        if not r['feasible']:
            floor_cost = forced_cost + (rate * tokens[forced_type] if forced_type is not None else 0)
            check(solver['status'] == 2 and solver['success'] is False and forced_type is not None and floor_cost > budget,
                  'infeasibility_exact_proof', label)
            result['unavoidable_forced_cost_plus_setup'] = exact(floor_cost)
            result['budget_excess'] = exact(floor_cost - budget)
            audit_results.append(result)
            continue
        check(solver['status'] == 0 and solver['success'] is True and solver['relative_gap'] == 0,
              'solver_terminal_status_and_gap', label)
        picks = [(x['row_id'], NAMES.index(x['package'])) for x in r['selected']]
        check(len({rid for rid, k in picks}) == len(picks), 'selection_feasibility', label+' one package per row')
        check(all(rid in pop and k in allowed for rid, k in picks), 'selection_feasibility', label+' allowed known rows')
        used = {k for rid, k in picks} | ({forced_type} if forced_type is not None else set())
        mask = sum(1 << k for k in used)
        check(r['mask'] == mask and r['union_source_modules'] == unions[mask]['modules'] and
              r['union_source_tokens'] == unions[mask]['source_tokens'], 'selected_union_setup', label)
        variable = forced_cost + sum((cost[rid][k] for rid, k in picks), F(0))
        setup = F(rate * unions[mask]['source_tokens'])
        spent = variable + setup
        value = sum((pop[rid] * alpha[k] for rid, k in picks), F(0))
        check(spent <= budget and spent >= 0, 'exact_budget_feasibility', label)
        for name, computed in [('variable_workload_including_forced', variable),
                               ('shared_preparation_workload', setup), ('total_workload', spent),
                               ('unspent_workload', budget-spent), ('known_additive_coefficient', value)]:
            same_exact(r[name], computed, label+' '+name)
        for x, (rid, k) in zip(r['selected'], picks):
            check(x['edition'] == by_id[rid]['edition'] and rat(x['population_coefficient']) == pop[rid],
                  'selected_row_identity', label+' '+rid)
            same_exact(x['relative_yield'], alpha[k], label+' '+rid+' yield')
            same_exact(x['variable_cost'], cost[rid][k], label+' '+rid+' cost')
            same_exact(x['opportunity_coefficient'], pop[rid]*alpha[k], label+' '+rid+' objective')
        # Independent layer cake over yield rather than the production audience breakpoints.
        nested = F(0)
        previous = F(0)
        layers = []
        for level in sorted({alpha[k] for rid, k in picks}):
            audience = max(pop[rid] for rid, k in picks if alpha[k] >= level)
            contribution = (level - previous) * audience
            nested += contribution
            layers.append({'yield_lower': exact(previous), 'yield_upper': exact(level),
                           'union_audience': exact(audience), 'contribution': exact(contribution)})
            previous = level
        largest = max((pop[rid] * alpha[k] for rid, k in picks), default=F(0))
        check(largest <= nested <= value, 'overlap_bounds', label)
        same_exact(r['largest_single_coefficient_lower_bound'], largest, label+' largest single')
        same_exact(r['selected_set_nested_max_yield_coefficient'], nested, label+' nested layer cake')
        bound = rat(solver['objective_upper_bound'])
        gap = bound-value
        check((value/lattice).denominator == 1, 'objective_lattice', label)
        check(abs(gap) <= F(1, 10000), 'reported_numerical_dual_consistency', label)
        check(bound < value+lattice, 'next_lattice_point_excluded_by_reported_bound', label)
        minimum_cost = min(cost[rid][k] for rid in ids for k in allowed)
        K = max(0, int((F(budget)-forced_cost)//minimum_cost))
        presolve = r['scenario_specific_dominance_presolve']
        proof = dominance_certificate(K)
        check(K == presolve['maximum_known_editions'] and len(picks) <= K,
              'dominance_cardinality_bound', label)
        same_exact(presolve['minimum_available_variable_cost'], minimum_cost, label+' minimum variable cost')
        expected_witnesses = [{'row_id': j, 'witness_ids': dominates[j][:K]} for j in ids
                              if K == 0 or len(dominates[j]) >= K]
        check(presolve['witnesses'] == expected_witnesses, 'saved_dominance_witnesses', label)
        check(presolve['retained_solver_profiles'] == len(proof['retained_ids']) and
              all(rid in proof['retained_ids'] for rid, k in picks), 'presolve_retained_selection', label)
        result.update({'selected_ids_and_packages': [{'row_id': rid, 'package': NAMES[k]} for rid, k in picks],
                       'mask': mask, 'variable_workload': exact(variable), 'shared_setup': exact(setup),
                       'total_workload': exact(spent), 'unspent_workload': exact(budget-spent),
                       'objective': exact(value), 'reported_numerical_upper_bound': exact(bound),
                       'reported_bound_minus_exact_incumbent': exact(gap),
                       'next_objective_lattice_point': exact(value+lattice),
                       'margin_to_next_lattice_point': exact(value+lattice-bound),
                       'largest_single': exact(largest), 'nested_layer_cake': exact(nested), 'layers': layers,
                       'dominance_certificate_K': K, 'retained_profiles': len(proof['retained_ids'])})
        audit_results.append(result)

    check(len(cache) == 66 and len(d['solver_calls']) == 66 and qa['solver_calls'] == 66,
          'scenario_completeness', '66 distinct solve records')
    status_counts = Counter(r['solver']['status'] for r in cache.values())
    check(status_counts == {0: 62, 2: 4}, 'scenario_completeness', '62 feasible optimal status, four infeasible')
    calls_by_label = {c['label']: c for c in d['solver_calls']}
    check(len(calls_by_label) == 66, 'solver_call_mirror', 'Unique call labels')
    for r in cache.values():
        label = r['solver']['label']
        mirrored = {k: v for k, v in calls_by_label[label].items() if k != 'cache_reuse'}
        check(mirrored == r['solver'], 'solver_call_mirror', label)
    expected_sids = {f'{name}::setup{rate}::B{budget}' for name in ALPHAS
                     for rate in (0, 2) for budget in (5000000, 10000000, 20000000)}
    check(len(d['scenarios']) == 12 and {s['scenario_id'] for s in d['scenarios']} == expected_sids,
          'scenario_completeness', 'Complete scenario Cartesian product')
    scenario_audits = []
    referenced = set()
    for s in d['scenarios']:
        sid = s['scenario_id']
        alpha = ALPHAS[s['yield_profile']]
        budget, rate = s['budget'], s['shared_setup_rate_per_union_token']
        check(sid == f"{s['yield_profile']}::setup{rate}::B{budget}" and
              [rat(x) for x in s['relative_yields']] == list(alpha), 'scenario_parameter_mirror', sid)
        main_params = (budget, alpha, rate, (0, 1, 2), None, F(0))
        best = cached_results[main_params]
        referenced.add(main_params)
        check(best == s['solution'], 'solution_cache_mirror', sid)
        value = rat(best['known_additive_coefficient'])
        uniform_audits = []
        check(len(s['uniform_package_comparators']) == 3, 'uniform_comparators', sid)
        for k, u in enumerate(s['uniform_package_comparators']):
            params = (budget, (F(1),)*3, rate, (k,), None, F(0))
            result = cached_results[params]
            referenced.add(params)
            comparator = rat(result['known_additive_coefficient']) * alpha[k]
            check(u['package'] == NAMES[k] and u['feasible'] == result['feasible'] and
                  u['selected_ids'] == [x['row_id'] for x in result['selected']] and
                  u['total_workload'] == result['total_workload'] and u['solver'] == result['solver'],
                  'uniform_comparators', sid+' '+NAMES[k])
            check(abs(rat(u['coefficient'])-comparator) <= F(1, 1000000) and value >= comparator,
                  'uniform_comparators', sid+' '+NAMES[k]+' exact value and mixed dominance')
            uniform_audits.append({'package': NAMES[k], 'coefficient': exact(comparator),
                                   'total_workload': result['total_workload'], 'selected_ids': u['selected_ids']})
        gain = 100*(value/max(rat(u['coefficient']) for u in uniform_audits)-1)
        check(abs(rat(s['gain_over_best_uniform_percent'])-gain) < F(1, 100000000),
              'uniform_gain', sid)
        insertions = []
        check(len(s['symbolic_insertions']) == 3, 'unknowns', sid+' three insertions')
        for k, insertion in enumerate(s['symbolic_insertions']):
            params = (budget, alpha, rate, (0, 1, 2), k, unknown_cost[k])
            residual = cached_results[params]
            referenced.add(params)
            check(insertion['package'] == NAMES[k] and insertion['residual_known_portfolio'] == residual,
                  'symbolic_residual_cache_mirror', sid+' '+NAMES[k])
            same_exact(insertion['forced_variable_workload'], unknown_cost[k], sid+' unknown forced cost')
            entry = {'package': NAMES[k], 'feasible': residual['feasible']}
            if residual['feasible']:
                threshold = value-rat(residual['known_additive_coefficient'])
                check(threshold >= 0, 'unknown_thresholds', sid+' '+NAMES[k])
                same_exact(insertion['minimum_unknown_benefit_coefficient_for_strict_improvement'], threshold, sid+' benefit threshold')
                same_exact(insertion['minimum_unknown_audience_under_same_yield_scenario'], threshold/alpha[k], sid+' audience threshold')
                # At equality the portfolio ties. A strict gain requires crossing the boundary.
                entry.update({'benefit_boundary_equality_ties': exact(threshold),
                              'audience_boundary_equality_ties': exact(threshold/alpha[k]),
                              'least_integer_audience_for_strict_improvement': math.floor(threshold/alpha[k])+1})
            else:
                check(insertion['minimum_unknown_benefit_coefficient_for_strict_improvement'] is None and
                      insertion['minimum_unknown_audience_under_same_yield_scenario'] is None,
                      'unknown_thresholds', sid+' infeasible null thresholds')
            insertions.append(entry)
        symbolic = s['symbolic_rows']
        check(len(symbolic) == 25 and {x['row_id'] for x in symbolic} == {x['row_id'] for x in unknown} and
              all(x['audience'] is None and x['edition'] == by_id[x['row_id']]['edition'] and
                  x['insertion_scenarios_shared_by_equal_cost'] == list(NAMES) for x in symbolic),
              'unknowns', sid+' all unknowns remain named and null')
        check(s['observed_people_helped'] is None, 'interpretation_contract', sid+' no observed people claim')
        counts = [sum(x['package'] == name for x in best['selected']) for name in NAMES]
        row = (f"| {'Lower' if s['yield_profile'].startswith('lower') else 'Higher'} | {rate} | {budget/1e6:.0f} | "
               f"{' / '.join(map(str, counts))} | {rat(best['total_workload'])/1000000:.3f} | "
               f"{float(value)/1e6:,.1f} | {float(gain):.2f}% |")
        check(row in report, 'human_report_table', sid)
        section = report.split('### '+sid+'\n', 1)[1].split('\n### ', 1)[0].split('\n## ', 1)[0]
        check(all(x['edition'] in section for x in best['selected']), 'human_report_selections', sid)
        scenario_audits.append({'scenario_id': sid, 'counts_fractions_six_full': counts,
                                'objective': exact(value), 'total_workload': best['total_workload'],
                                'nested_layer_cake': best['selected_set_nested_max_yield_coefficient'],
                                'uniform_comparators': uniform_audits, 'gain_over_best_uniform_percent': exact(gain),
                                'symbolic_insertion_thresholds': insertions})
    check(referenced == set(cached_results), 'scenario_completeness', 'Every cache record referenced exactly by expected task domain')
    for rel, identity in list(IDENTITIES.items()):
        raw = (ROOT/rel).read_bytes()
        check(len(raw) == identity['bytes'] and sha(raw) == identity['sha256'], 'inputs_unchanged_during_audit', rel)

    limitations = [
        'No large or small optimization was rerun. Saved terminal solver outputs were independently rescored and compared with their reported numerical dual bounds.',
        'All exact incumbent arithmetic, feasibility, source unions, forced insertion floors, and dominance replacement proofs are deterministic. Reported HiGHS bounds are numerical, not formally checked exact dual certificates.',
        'Integer audiences and the declared rational yields imply an enclosing objective lattice of 1/20. Every reported numerical upper bound lies below the next lattice point; this supports the saved optimal statuses but does not convert numerical bounds into a formal global-optimality proof.',
        'The pinned archive, all 78 source-file hashes, and all 75 normalized content-text hashes were independently checked. Token totals were independently summed from hash-bound module counts; the tokenizer was unavailable in this numerical Python environment and tokenization itself was not rerun.',
        'A symbolic threshold is a boundary: equality ties, strictly greater benefit improves. With continuous audience coefficients there is no attained minimum strictly improving value. An additional least-integer-audience field makes the discrete interpretation explicit.',
        'Overlap layer cake only rescores each additive-optimal selected set. It is neither an empirical overlap estimate nor an optimum under a different overlap objective.',
        'The 775-row baseline is treated as the pinned input population basis; this audit establishes exact inheritance, not a fresh demographic evidence audit. No PISA cohort replacement is introduced.',
    ]
    proof_text = ('Every known choice has variable cost at least c_min>0. After paying a forced symbolic variable cost, '
                  'at most K=floor((B-forced_cost)/c_min) known rows fit, because setup costs are nonnegative. '
                  'For each pruned row j this audit supplies K distinct retained rows with audience at least P_j and '
                  'base cost at most base_j. If j appears in a feasible selection of at most K rows, at most K-1 '
                  'of those witnesses can already appear. An unused retained witness replaces j in the same package, '
                  'preserving the package mask and setup and weakly improving cost and benefit. Each replacement '
                  'removes one pruned selected row and adds a retained row, so simultaneous pruning terminates after '
                  'at most the original number of pruned selections. For K=0 no known row can fit. Deterministic '
                  'identity ordering makes equal-audience/equal-cost dominance acyclic. This is an optimization '
                  'reduction, not an eligibility or needs judgment.')
    feasible_results = [r for r in audit_results if r['feasible']]
    maximum_gap = max(abs(rat(r['reported_bound_minus_exact_incumbent'])) for r in feasible_results)
    minimum_margin = min(rat(r['margin_to_next_lattice_point']) for r in feasible_results)
    audit = {'schema': 'mixed-package-independent-audit/1.0',
             'status': 'PASS_WITH_NUMERICAL_CERTIFICATE_SCOPE' if not FAILURES else 'FAIL',
             'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'input_identities': list(IDENTITIES.values()),
             'method': 'Independent source reconstruction and exact rational rescore; production code was read but never imported or executed.',
             'checks_by_group': dict(CHECKS), 'check_count': sum(CHECKS.values()), 'failures': FAILURES,
             'solver_counts': {'feasible_saved_optimal_status': status_counts[0], 'exactly_infeasible': status_counts[2]},
             'objective_lattice_step': exact(lattice), 'maximum_absolute_reported_bound_discrepancy': exact(maximum_gap),
             'minimum_reported_bound_margin_to_next_lattice_point': exact(minimum_margin),
             'dominance_proof': proof_text, 'dominance_certificates_by_K': certificates,
             'source_module_hash_reconstruction': source_file_checks, 'source_union_masks': unions,
             'independent_solve_rescores': audit_results, 'scenario_summary_and_comparators': scenario_audits,
             'limitations_and_interpretation': limitations}
    out_json = ROOT/'qa/MIXED_PACKAGE_ALLOCATION_INDEPENDENT_AUDIT_v1.json'
    out_json.write_text(json.dumps(audit, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    lines = ['# Independent audit of the mixed-package allocation', '',
             '**'+audit['status']+'**', '',
             f"All 12 scenarios and all 66 saved solve records were checked without running an optimizer. "
             f"The {sum(CHECKS.values()):,} deterministic checks produced {len(FAILURES)} failures. "
             'All 775 original row objects are unchanged: 750 numeric profiles and 25 named null-audience profiles.', '',
             '## Result and certificate scope', '',
             'All 62 feasible records have exact feasible selected costs, source-union setup, objectives, single-package comparisons, '
             'and overlap rescores. The four infeasible insertions are full-book symbolic editions under the five-million budget: '
             'their forced variable cost alone exceeds the budget. No optimizer was rerun.', '',
             f"All feasible saved solver records report optimal status and zero relative gap. Integer audiences and yields "
             f"7/20, 14/20, 20/20 or 13/20, 18/20, 20/20 place objectives on an enclosing 0.05 lattice. "
             f"The largest absolute reported-bound discrepancy is {float(maximum_gap):.8f}; "
             f"the smallest margin below the next lattice point is {float(minimum_margin):.8f}. "
             'This is numerical consistency evidence, not a formally checked exact global-optimality certificate.', '',
             '## Scenario rescore', '',
             '| Scenario | Fractions / six / full | Exact additive coefficient | Exact nested coefficient | Best uniform gain |',
             '|---|---|---:|---:|---:|']
    for s in scenario_audits:
        lines.append(f"| {s['scenario_id']} | {' / '.join(map(str,s['counts_fractions_six_full']))} | "
                     f"{rat(s['objective'])} | {rat(s['nested_layer_cake'])} | {float(rat(s['gain_over_best_uniform_percent'])):.6f}% |")
    lines += ['', 'All 36 scenario-level uniform comparator values were reconstructed from the 18 distinct saved '
              'uniform optimizations and the exact scenario yield. The JSON audit records their exact values, costs '
              'and selected IDs, along with every one of the 36 symbolic insertion cases.', '',
              '## Dominance and simultaneous pruning', '', proof_text, '',
              '| K | Retained profiles | Pruned profiles | K retained witnesses for every pruned row |',
              '|---:|---:|---:|---|']
    for K, c in sorted(certificates.items()):
        lines.append(f"| {K} | {len(c['retained_ids'])} | {c['pruned_rows']} | {'PASS' if c['all_pruned_rows_have_K_retained_dominators'] else 'FAIL'} |")
    lines += ['', 'The machine-readable audit includes the actual retained witness IDs for each pruned row and maps '
              'each feasible solve to its K certificate. Saved production witness lists were also checked exactly.', '',
              '## Source and interpretation checks', '',
              'The package sets contain 16, 36 and 75 modules with 87,655, 173,958 and 364,270 hash-bound content tokens. '
              'All eight masks were rebuilt from sets. Supported fractions and six chapters are non-nested; '
              'their union has 40 modules and 198,477 tokens. The eight outside support links were reconstructed '
              'directly from pinned CNXML. Archive and normalized-text identities were checked independently.', '',
              'Nested maximum-yield benefit was independently reconstructed by integrating over yield levels '
              '(rather than the production code\'s audience breakpoints). Every selected set satisfies '
              'largest-single ≤ nested max-yield ≤ additive coefficient.', '',
              'For an inserted symbolic package, let V be the unforced optimum and R the reoptimized known '
              'coefficient with its variable cost and source setup forced. The benefit boundary is V−R; the audience '
              'boundary is (V−R)/yield. Equality ties, and strict improvement requires exceeding it. The production '
              'JSON\'s “minimum … for strict improvement” fields should be read as these boundaries, as its explicit '
              'unknown contract already states. The audit additionally supplies the least improving integer audience. '
              'None of the 25 unknowns is converted to zero, and joint unknown insertions are not claimed solved.', '',
              '## Limitations', '']
    lines.extend('- '+limitation for limitation in limitations)
    lines += ['', '## Exact input identities', '', '| Relative path | Bytes | SHA-256 |', '|---|---:|---|']
    for identity in IDENTITIES.values():
        lines.append(f"| {identity['path']} | {identity['bytes']} | {identity['sha256']} |")
    lines += ['', '## Failures', '', 'None.' if not FAILURES else json.dumps(FAILURES, indent=2), '']
    (ROOT/'qa/MIXED_PACKAGE_ALLOCATION_INDEPENDENT_AUDIT_v1.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'status': audit['status'], 'checks': sum(CHECKS.values()), 'failures': FAILURES,
                      'feasible': status_counts[0], 'infeasible': status_counts[2],
                      'max_abs_bound_discrepancy': str(maximum_gap), 'min_lattice_margin': str(minimum_margin)}))


if __name__ == '__main__':
    main()
