"""Bounded overlap/shared-cost sensitivity; no empirical learning-effect claim."""
from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
import sys
import warnings

sys.dont_write_bytecode = True
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json'
QA = ROOT / 'qa/HINDI_URDU_BUDGET_ENTRY_FRONTIER_QA_v1.json'
REPORT = ROOT / 'HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.md'
EXPECTED = {
 'SHARED_REGISTER_PORTFOLIO_COMPARISONS_v1.md':'799CCBBDDA93A963D49A3C7D74926B1B226CEE09B0E09B42B54C519C37187555',
 'INTERVENTION_EFFECT_EVIDENCE_v1.md':'41FDFE5DA38DD1E1E46D04B801441978809639311AAC8A01BC6B4E7300C4C510',
 'GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md':'55EF5B56897BF2731CE9FF8E9B10BAB865AA9AB17A677A305370F25A991898E2',
 'structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json':'0C55B90034DCF6034540815F2B4D399E1FD13B75A4C015B0748032228197BB2F',
 'structured/GLOBAL_BUDGET_SCENARIOS_v1.json':'CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57',
 'scripts/build_global_budget_scenarios_v1.py':'407FB5DD00329E557DC0034C6F7D3164A0F15D99FB043D2BE15A82EA527415CF',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def require(test, label):
    if not test:
        raise AssertionError(label)

def frac(value):
    return Fraction(str(value))

def exact(value):
    return {'numerator':value.numerator,'denominator':value.denominator,'decimal':float(value)}

def load(rel):
    return json.loads((ROOT / rel).read_text(encoding='utf-8'))

def main():
    bindings=[]
    for rel, expected in EXPECTED.items():
        path=ROOT/rel
        require(sha(path)==expected,'Source changed: '+rel)
        bindings.append({'path':rel,'bytes':path.stat().st_size,'sha256':expected})
    global_data=load('structured/GLOBAL_BUDGET_SCENARIOS_v1.json')
    bridge_data=load('structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json')
    profile=next(p for p in bridge_data['profiles'] if p['id']=='HINDUSTANI')
    rows=global_data['candidate_rows']
    require(len(rows)==775 and len({r['row_id'] for r in rows})==775,'All source rows retained')
    by_id={r['row_id']:r for r in rows}
    H='COMMON100K:hi-Deva'; U='COMMON100K:ur-Arab'
    ch=frac(by_id[H]['base_100k_cost_fecu']); cu=frac(by_id[U]['base_100k_cost_fecu'])
    ph=frac(by_id[H]['population_coefficient']); pu=frac(by_id[U]['population_coefficient'])
    require(ph>=pu>0 and ph.denominator==pu.denominator==1,'Pair coefficient assumptions')
    numeric=[r for r in rows if r['population_coefficient'] is not None and r['population_coefficient']>0]
    unknown=[{**r,'status':'SYMBOLIC_CHALLENGER_NOT_ZERO_NEED'} for r in rows if r['population_coefficient'] is None or r['population_coefficient']<=0]
    residual=[r for r in numeric if r['row_id'] not in (H,U)]
    require(len(numeric)==750 and len(unknown)==25,'Expected source classifications')
    require(all(frac(r['population_coefficient']).denominator==1 for r in numeric),'Integer objective coefficients')
    budget=Fraction(5_000_000)
    spec=importlib.util.spec_from_file_location('saved_budget_solver',ROOT/'scripts/build_global_budget_scenarios_v1.py')
    solver=importlib.util.module_from_spec(spec); spec.loader.exec_module(solver)
    original_milp=solver.milp
    # Preserve the saved objective/constraints while explicitly limiting HiGHS.
    def single_thread_milp(*args,**kwargs):
        kwargs['options']={**kwargs.get('options',{}),'threads':1,'parallel':False}
        return original_milp(*args,**kwargs)
    solver.milp=single_thread_milp
    captured_warnings=[]; solve_count=0

    def optimize(costs, cap):
        nonlocal solve_count
        require(cap>=0,'Infeasible state cannot enter solver')
        with warnings.catch_warnings(record=True) as notes:
            warnings.simplefilter('always')
            result=solver.solve(np.array([float(c) for c in costs]),
                np.array([r['population_coefficient'] for r in residual]),float(cap))
        captured_warnings.extend(str(n.message) for n in notes)
        solve_count+=1
        picks, _, _, gap, bound=result
        spent=sum((costs[i] for i in picks),Fraction(0))
        benefit=sum(int(residual[i]['population_coefficient']) for i in picks)
        require(spent<=cap,'Selected portfolio fails exact rational budget feasibility')
        require(bound+1e-4>=benefit and bound<benefit+1-1e-4,'Integer objective optimum not separated by dual bound')
        return {'selected_ids':[residual[i]['row_id'] for i in picks],
                'selected_editions':[residual[i]['edition'] for i in picks],
                'variable_cost':exact(spent),'variable_budget':exact(cap),'coefficient':benefit,
                'floating_solver_gap':gap,'floating_solver_upper_bound':bound,
                'upper_bound_below_next_integer':True,'exact_source_cost_feasible':True}

    results=[]; all_checks={}
    for sc in bridge_data['scenarios']:
        F,D,A,Q=(frac(sc[k]) for k in ('shared_setup','bridge_design','extra_format','per_community_check'))
        scale=(ch+cu)/(2*(F+1+Q)); setup=scale*F
        bridge_cost=scale*(F+1+D+A+2*Q); bridge_variable=bridge_cost-setup
        native_variable={r['row_id']:frac(r['base_100k_cost_fecu'])-setup for r in rows}
        require(all(v>0 for v in native_variable.values()),'Invalid calibrated variable cost')
        require(setup+native_variable[H]==ch and setup+native_variable[U]==cu,'Standalone native costs changed')
        require(ch+cu-setup==scale*(F+2*(1+Q)),'Native shared-cost formula mismatch')
        costs=[native_variable[r['row_id']] for r in residual]
        states=[]
        for label, members in (('neither',[]),('H',[H]),('U',[U]),('HU',[H,U])):
            selected_cost=sum((native_variable[i] for i in members),Fraction(0))
            cap=budget-setup-selected_cost
            if cap<0:
                states.append({'state':label,'feasible':False,'reason':'Fixed members exceed budget'})
                continue
            opt=optimize(costs,cap)
            intercept=opt['coefficient']+sum(int(by_id[i]['population_coefficient']) for i in members)
            states.append({'state':label,'feasible':True,'native_pair_members':members,
                           'overlap_slope':-int(label=='HU'),'intercept':intercept,
                           'residual':opt,'total_cost':exact(setup+selected_cost+frac_from_exact(opt['variable_cost']) if members or opt['selected_ids'] else Fraction(0))})
        require(all(s['feasible'] for s in states),'This bounded result requires all four pair states')
        accompanying=optimize(costs,budget-setup-bridge_variable)
        M=max(s['intercept'] for s in states if s['state']!='HU')
        L=next(s['intercept'] for s in states if s['state']=='HU')
        W=accompanying['coefficient']; switch=Fraction(L-M)
        points=sorted({Fraction(0),pu} | ({switch} if 0<switch<pu else set()))
        def threshold(o): return max(Fraction(M),Fraction(L)-o)-W
        samples=[]
        for o in points:
            t=threshold(o); native_best=t+W
            winners=[s['state'] for s in states if s['intercept']+s['overlap_slope']*o==native_best]
            require(t>=0,'Negative opportunity-cost threshold')
            require(t==max(Fraction(s['intercept'])+s['overlap_slope']*o for s in states)-W,'Envelope identity failed')
            samples.append({'overlap':exact(o),'threshold':exact(t),'native_winning_states':winners,
                            'required_retention':exact(t/(ph+pu-o))})
        segments=[]
        for a,b in zip(points,points[1:]):
            mid=(a+b)/2; hu=(L-mid)>M
            slope=-1 if hu else 0; intercept=L-W if hu else M-W
            require(threshold(b)-threshold(a)==slope*(b-a),'Segment slope mismatch')
            deriv_sign=sign(Fraction(L-W)-ph-pu) if hu else sign(Fraction(M-W))
            segments.append({'overlap_start':exact(a),'overlap_end':exact(b),'threshold_intercept':intercept,
                             'threshold_slope':slope,'retention_derivative_sign':deriv_sign})
        checks={
            'all_775_positive_variable_costs':all(v>0 for v in native_variable.values()),
            'native_standalone_costs_preserved':setup+native_variable[H]==ch and setup+native_variable[U]==cu,
            'setup_once_both_sides':bridge_cost==setup+bridge_variable,
            'four_native_states':len(states)==4,
            'all_state_budgets_exactly_feasible':all(frac_from_exact(s['total_cost'])<=budget for s in states),
            'bridge_plus_remainder_budget_exactly_feasible':bridge_cost+frac_from_exact(accompanying['variable_cost'])<=budget,
            'residual_never_contains_hindi_or_urdu':all(H not in s['residual']['selected_ids'] and U not in s['residual']['selected_ids'] for s in states) and H not in accompanying['selected_ids'] and U not in accompanying['selected_ids'],
            'nonincreasing_threshold':all(samples[i]['threshold']['decimal']>=samples[i+1]['threshold']['decimal'] for i in range(len(samples)-1)),
            'at_most_one_interior_breakpoint':len(points)<=3,
        }
        # Unit retention can cross a constant segment; preserve every solution.
        unit_crossings=[]
        for seg in segments:
            a=frac_from_exact(seg['overlap_start']); b=frac_from_exact(seg['overlap_end'])
            if seg['threshold_slope']==0:
                o=ph+pu-seg['threshold_intercept']
                if a<=o<=b: unit_crossings.append(exact(o))
            elif seg['threshold_intercept']==ph+pu:
                unit_crossings.append({'interval':[exact(a),exact(b)]})
        checks['unit_retention_crossings_verified']=all(
            all(0<=frac_from_exact(p)<=pu and threshold(frac_from_exact(p))==ph+pu-frac_from_exact(p)
                for p in cross['interval']) if 'interval' in cross else
            0<=frac_from_exact(cross)<=pu and threshold(frac_from_exact(cross))==ph+pu-frac_from_exact(cross)
            for cross in unit_crossings)
        checks['retention_segment_derivatives_verified']=all(
            sign(threshold(frac_from_exact(seg['overlap_end']))/(ph+pu-frac_from_exact(seg['overlap_end']))
                -threshold(frac_from_exact(seg['overlap_start']))/(ph+pu-frac_from_exact(seg['overlap_start'])))
            ==seg['retention_derivative_sign'] for seg in segments)
        checks['interior_breakpoint_equal_branches']=not (0<switch<pu) or M==L-switch
        require(all(checks.values()),'Scenario checks failed')
        all_checks[sc['id']]=checks
        results.append({'scenario_id':sc['id'],'declared_dimensionless_inputs':sc,'budget':exact(budget),
                        'scale':exact(scale),'shared_setup':exact(setup),'bridge_standalone_cost':exact(bridge_cost),
                        'minimum_native_variable_cost':exact(min(native_variable.values())),
                        'native_states':states,'bridge_accompanying_residual':accompanying,
                        'bridge_plus_remainder_total_cost':exact(bridge_cost+frac_from_exact(accompanying['variable_cost'])),
                        'M':M,'L':L,'W':W,'candidate_switch_L_minus_M':exact(switch),
                        'active_overlap_range':[exact(Fraction(0)),exact(pu)],'evaluated_endpoints_and_breakpoints':samples,
                        'piecewise_segments':segments,'unit_retention_crossings':unit_crossings,
                        'measured_comprehension':None,'measured_learning_effect':None,'measured_overlap':None})
    require(solve_count==20,'Expected exactly twenty bounded solves')
    for rel,h in EXPECTED.items(): require(sha(ROOT/rel)==h,'Source mutated during calculation')
    obj={'schema':'hindi-urdu-budget-entry-frontier/1.0','generated_utc':datetime.now(timezone.utc).isoformat(),
      'status':'CONDITIONAL_SENSITIVITY_NOT_EMPIRICAL_ALLOCATION_RANK','source_bindings':bindings,
      'source_plan':'same 100000-source-token educational benchmark','educational_endpoint':'Learning a new mathematical definition and its boundaries; not combined with reference lookup or proof checking.',
      'coefficient_unit':'Inherited potential-audience coefficient normalized by one common positive unknown educational yield, not distinct people educated.',
      'cost_unit':'Declared fresh-equivalent token-event workload calibration; not physical compute, energy, money or observed bridge cost.',
      'profile_id':profile['id'],'native_rows':[H,U],'bridge_formats':profile['bridge_formats'],
      'hindi_coefficient':int(ph),'urdu_coefficient':int(pu),'formula':'T(O)=max(M,L-O)-W; bridge insertion improves numeric native optimum iff G_bridge>T(O)',
      'retention_formula':'rho>T(O)/(P_H+P_U-O) only under a declared positive common-yield normalization',
      'all_stage_eligibility':['P','F','S','V','U','R'],'numeric_native_rows':750,'all_source_rows':775,
      'unknown_audience_challengers':unknown,'measured_bridge_audience':None,
      'hybrid_bridge_plus_native_alternatives':'Retained unresolved. Adding Hindi/Urdu editions to a bridge requires their incremental benefit and overlap; neither is assumed redundant.',
      'other_audience_overlap':'Remaining editions retain the source additive-coefficient scenario; overlaps with them are not estimated. This is not a global unique-person optimum.',
      'bridge_residual_independence_assumption':'The bridge benefit G is additive with the selected residual, or is the same incremental benefit for every feasible residual. If G depends on residual selection, jointly optimize bridge-plus-residual benefit; the current native-only residual optimizer does not establish that optimum.',
      'empty_portfolio_cost':0,
      'case_study_need_adjustment':0,'scenario_cost_calibration':'Each anchor recalibrates lambda to preserve native standalone proxies; comparisons across anchors are not a measured ceteris-paribus experiment.',
      'scenarios':results,'solver':{'calls':solve_count,'seconds_per_call_limit':15,'threads':1,'warnings':sorted(set(captured_warnings)),
       'python_version':sys.version.split()[0],'numpy_version':np.__version__,'scipy_version':scipy.__version__,
       'numerical_scope':'Selected costs and coefficient arithmetic recomputed as exact source rationals/integers. Optimality uses floating-point MILP upper bounds separated from the next integer objective, not a formal exact-arithmetic solver certificate.'}}
    OUT.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# When does a Hindi-Urdu bridge improve a fixed-budget portfolio?','',
      'A conditional research calculation, not a recommendation to replace native-language editions. No comprehension or learning rate is invented.','',
      'The comparison uses the same 100,000-source-token package and a budget of five million declared workload units. Both bridge and native portfolios pay common source preparation once. The optimizer can select Hindi, Urdu, both or neither, alongside the other numeric edition profiles.','',
      '| Declared cost scenario | Bridge workload, millions | Retention with no overlap | Retention with fully nested audiences | Lowest retention across overlap |',
      '|---|---:|---:|---:|---:|']
    for r in results:
        s=r['evaluated_endpoints_and_breakpoints']; interior=[x for x in s if x['overlap']['decimal'] not in (0,float(pu))]
        label={'low_shared_setup':'Low preparation cost','large_shared_setup':'High shared preparation','community_check_intensive':'Extensive profile checking','design_intensive':'Expensive bridge design'}[r['scenario_id']]
        lines.append(f"| {label} | {r['bridge_standalone_cost']['decimal']/1e6:.3f} | {100*s[0]['required_retention']['decimal']:.2f}% | {100*s[-1]['required_retention']['decimal']:.2f}% | {100*min(x['required_retention']['decimal'] for x in s):.2f}% |")
    lines += ['', 'Retention here is normalized educational benefit relative to the assumed native-route opportunity, not a reading-comprehension percentage. Above 100% requires extra benefit relative to that normalization; it is not automatically impossible, but extra benefit has not been established. The endpoints are declared scenarios, not confidence intervals.', '',
      '## The allocation result', '',
      'For each cost anchor, all native states reduce to two competing lines: `T(O) = max(M, L - O) - W`. Here M is the best Hindi-only, Urdu-only or neither coefficient; L is the both-editions coefficient before subtracting overlap; W is the best affordable remainder alongside the bridge. The bridge is better only when its additional normalized benefit exceeds T. There is at most one interior breakpoint. The threshold cannot rise with overlap, but its ratio to the shrinking pair audience can fall and then rise.', '',
      f"At the low-setup anchor, the entry threshold is {results[0]['evaluated_endpoints_and_breakpoints'][0]['threshold']['decimal']:,.0f} normalized benefit units. The result compares against the best affordable native portfolio, not against an unnecessarily expensive promise to translate every native edition.", '',
      'In that first scenario, the best native mix is Chinese, Hindi, Spanish, Portuguese and Indonesian. Buying the bridge instead leaves room for Chinese, Spanish and Arabic. The bridge must therefore earn back the difference between those two portfolios; saving on Hindi and Urdu in isolation is not enough.', '',
      'The high-shared-preparation scenario has an interior minimum: the required retention falls from 89.66% to 87.41%, then rises to 110.55%. Its native comparator switches from including both Hindi and Urdu to including Hindi alone at overlap coefficient 142,848,211. This coefficient is a hypothetical shared opportunity, not a measured count of bilingual people.', '',
      'A useful provisional decision rule follows. At low preparation cost and no pair overlap, benefit above 78.29% of the normalized native opportunity makes the bridge preferable in this declared budget scenario. At full nesting, 120.54% would be needed. Neither endpoint establishes where real readers lie. Under the more expensive checking or design assumptions, cost savings alone are insufficient at every modeled overlap; that is a finding about those cost assumptions, not a dismissal of bridges.', '',
      '## Exact scope and interpretation', '',
      'The inherited Hindi and Urdu audience coefficients are 519,812,678 and 280,449,183. They are screening inputs, not verified new learners or assignments of entire language groups to a standard register. Their sum is 800,261,861 before overlap. No country population is substituted for either audience.', '',
      'The educational endpoint is learning a new mathematical definition and its boundaries. Familiar-result lookup, following a proof and applying a worked example remain separate endpoints. Formal mathematical structure may help some of these tasks more than others; this calculation does not presume that prose-comprehension scores determine mathematical learning.', '',
      'The bridge contribution must be additive with the selected remainder, or its incremental benefit must not depend on which remaining editions are chosen. If it does depend on them, the bridge and its remainder must be optimized jointly. This sensitivity does not identify a global unique-person optimum.', '',
      '## What remains unknown', '',
      'Hindi-Urdu audience overlap, script literacy, bridge comprehension and educational yield remain unmeasured. The Urdu workload proxy is generic Arabic-script traffic, not a Nastaliq-specific measurement. Other multilingual overlaps remain outside this pairwise sensitivity. All 25 unmeasured-audience native rows and bridge-plus-native hybrids remain explicit alternatives, not zero-need cases. Earlier programme output does not reduce global need.', '',
      'The next substantive test is to bind a specified educational package and exact reader/register profiles to these thresholds. The calculation does not require new participant data to remain usable as a transparent provisional comparison.', '',
      '## Reproducibility', '',
      'The accompanying JSON preserves the four native subset states, all selected row IDs, exact rational selected costs, integer coefficients, twenty bounded solver results, overlap segments and source hashes. A separate QA file records deterministic checks. Floating-point optimization is not a formal exact-arithmetic proof.', '']
    REPORT.write_text('\n'.join(lines),encoding='utf-8')
    qa={'status':'PASS_BOUNDED_ARITHMETIC_AND_SCOPE_CHECKS','checks':all_checks,'solver_calls':solve_count,
        'missing_audiences_retained':len(unknown),'measured_bridge_comprehension':None,'full_goal_complete':False,
        'artifacts':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in (OUT,REPORT,Path(__file__))]}
    QA.write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':qa['status'],'scenarios':len(results),'solves':solve_count,'outputs':[str(p.relative_to(ROOT)) for p in (OUT,REPORT,QA)]}))

def frac_from_exact(value):
    return Fraction(value['numerator'],value['denominator'])

def sign(x):
    return (x>0)-(x<0)

if __name__=='__main__':
    main()
