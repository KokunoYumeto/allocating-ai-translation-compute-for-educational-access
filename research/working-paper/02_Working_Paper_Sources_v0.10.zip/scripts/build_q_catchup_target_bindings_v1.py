#!/usr/bin/env python3
"""Bind current supply and delivery evidence to the nine Q-CATCHUP routes.

The output is a decision-discriminating evidence plan.  It does not assign a
target-specific q, educational-worth rank, or funding rank.
"""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any


BASE = Path(__file__).resolve().parents[1]
STRUCTURED = BASE / "structured"
QA_DIR = BASE / "qa"

FRONTIER_PATH = STRUCTURED / "TARGET_SPECIFIC_ALLOCATION_FRONTIER_v1.csv"
EFFECT_MAP_PATH = STRUCTURED / "INTERVENTION_EFFECT_ROUTE_MAP_v1.csv"
PACKAGE_SCALE_PATH = STRUCTURED / "OPENSTAX_PACKAGE_SCALE_20260904.json"
PACKAGE_SIZE_COMPARISON_PATH = STRUCTURED / "COMPLETE_VS_SMALLER_PACKAGES_20260904.json"

SOURCE_PATHS = {
    "ID-S": STRUCTURED / "IDN_SECONDARY_SUPPLY_AND_PACKAGE_v1.json",
    "PTBR-S": STRUCTURED / "BRA_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.json",
    "FIL-S": STRUCTURED / "PHL_SECONDARY_SUPPLY_AND_PACKAGE_v1.json",
    "VI-S": STRUCTURED / "MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.json",
    "TH-S": STRUCTURED / "MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.json",
    "KM-S": STRUCTURED / "MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.json",
    "MS-S": BASE / "agent_reports" / "GLOBAL_NEED_CONTENT_AUDIT_20260901.md",
    "JA-S": STRUCTURED / "JPN_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.json",
    "UK-S": STRUCTURED / "UKR_RUS_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.json",
}

OUT_CSV = STRUCTURED / "Q_CATCHUP_TARGET_BINDINGS_v1.csv"
OUT_JSON = STRUCTURED / "Q_CATCHUP_TARGET_BINDINGS_v1.json"
OUT_MD = BASE / "Q_CATCHUP_TARGET_BINDINGS_v1.md"
QA_PATH = QA_DIR / "Q_CATCHUP_TARGET_BINDINGS_QA_v1.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def canonical_hash(row: dict[str, Any]) -> str:
    raw = compact(row).encode("utf-8")
    return hashlib.sha256(raw).hexdigest().upper()


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )


def source_relative(path: Path) -> str:
    return str(path.relative_to(BASE)).replace("\\", "/")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def get_stage(rows: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    return next(row for row in rows if row["stage"] == stage)


def extract_binding(route_id: str) -> dict[str, Any]:
    path = SOURCE_PATHS[route_id]
    if route_id == "ID-S":
        data = load_json(path)
        package = next(
            row
            for row in data["package_alternatives"]
            if row["package_id"] == "IDN-S-AUTONOMOUS-FOUNDATION-COMPANIONS"
        )
        delivery = data["delivery_context"]
        return {
            "package_alignment_status": "DIRECT_STAGE_AND_AUTONOMOUS_CATCHUP_ENDPOINT_NEAR_MATCH",
            "observed_supply": data["plain_language_result"],
            "aligned_package_id": package["package_id"],
            "aligned_package_scope": package["scope"],
            "aligned_package_endpoint": package["common_endpoint"],
            "delivery_context": delivery,
            "exact_language_fit_evidence": data["indonesian_audience_context"],
            "binding_limit": (
                "The oral Indonesian capability estimate is not written or academic proficiency, and national "
                "internet/phone/computer marginals are not learner cross-tabs. Existing official books mean the "
                "incremental package must be compared with current supply rather than a no-material baseline."
            ),
        }
    if route_id == "FIL-S":
        data = load_json(path)
        package = next(
            row
            for row in data["package_alternatives"]
            if row["package_id"] == "PHL-S-EXACT-LANGUAGE-AUTONOMOUS-FOUNDATION-COMPANIONS"
        )
        return {
            "package_alignment_status": "DIRECT_STAGE_AND_AUTONOMOUS_CATCHUP_ENDPOINT_NEAR_MATCH",
            "observed_supply": data["plain_language_result"],
            "aligned_package_id": package["package_id"],
            "aligned_package_scope": package["scope"],
            "aligned_package_endpoint": package["common_endpoint"],
            "delivery_context": data["delivery_context"],
            "exact_language_fit_evidence": data["language_identity_and_audience_context"],
            "binding_limit": (
                "The national learning burden is not distributable among Filipino, English or exact local-language "
                "routes. Internet and cellphone figures are separate marginals, and current official records do not "
                "prove a coherent independently usable path or its absence."
            ),
        }
    if route_id == "PTBR-S":
        data = load_json(path)
        stage = get_stage(data["stage_comparisons"], "S")
        return {
            "package_alignment_status": "STAGE_MATCHED_BROAD_COMPLETE_AND_BOUNDED_ALTERNATIVES",
            "observed_supply": stage["observed_supply"],
            "aligned_package_id": "BRA-S-BOUNDED-PREREQUISITE-OR-COMPLETE-PATHWAY",
            "aligned_package_scope": stage["bounded_alternative"],
            "aligned_package_endpoint": stage["next_effect_test"],
            "delivery_context": {
                "internet_use_percent_2024": data["national_context"]["internet_use_percent_2024"],
                "electricity_access_percent_2024": data["national_context"]["electricity_access_percent_2024"],
                "interpretation": data["national_context"]["interpretation"],
            },
            "exact_language_fit_evidence": {
                "status": "UNMEASURED_FOR_THIS_ROUTE",
                "context": stage["context_counts"],
            },
            "binding_limit": (
                "The stage evidence identifies a large represented proficiency context but not whether language, "
                "prerequisites, pedagogy or access is the binding mechanism. The current alternative is broader than "
                "the exact Q-CATCHUP endpoint and requires a common assessment."
            ),
        }
    if route_id == "JA-S":
        data = load_json(path)
        stage = get_stage(data["stage_comparisons"], "S")
        return {
            "package_alignment_status": "STAGE_MATCHED_BROAD_TRANSITION_AND_PREREQUISITE_ALTERNATIVES",
            "observed_supply": stage["observed_supply"],
            "aligned_package_id": "JPN-S-TRANSITION-OR-PREREQUISITE-PACKAGE",
            "aligned_package_scope": stage["bounded_alternative"],
            "aligned_package_endpoint": stage["next_effect_test"],
            "delivery_context": {
                "internet_use_percent_2024": data["national_context"]["internet_use_percent_2024"],
                "electricity_access_percent_2024": data["national_context"]["electricity_access_percent_2024"],
                "interpretation": data["national_context"]["interpretation"],
            },
            "exact_language_fit_evidence": {
                "status": "UNMEASURED_FOR_MAINSTREAM_JAPANESE_Q_CATCHUP_ROUTE",
                "academic_japanese_transition_context": stage["context_counts"],
            },
            "binding_limit": (
                "Strong aggregate supply and outcomes neither exclude Japan nor establish an incremental mainstream "
                "Q-CATCHUP effect. The most concrete current evidence concerns an academic-Japanese transition cohort, "
                "which is not identical to the PISA-derived need context."
            ),
        }
    if route_id == "UK-S":
        data = load_json(path)
        stage = get_stage(data["stage_comparisons"], "S")
        context = data["country_context"]["Ukraine"]
        return {
            "package_alignment_status": "STAGE_MATCHED_BOUNDED_CATCHUP_BRIDGE_NEAR_MATCH",
            "observed_supply": stage["Ukraine"]["observed_context"],
            "aligned_package_id": "UKR-S-FRACTIONS-TO-ALGEBRA-SCIENTIFIC-READING-BRIDGE",
            "aligned_package_scope": stage["Ukraine"]["bounded_alternative"],
            "aligned_package_endpoint": stage["same_endpoint_question"],
            "delivery_context": context["infrastructure_context"],
            "exact_language_fit_evidence": {
                "historical_census_language_context": context["historical_census_language_context"],
                "current_home_use_sample_context": context["current_home_use_sample_context"],
                "displacement_context": context["displacement_context"],
            },
            "binding_limit": (
                "PISA covers 18 of 27 regions and is not a national Ukrainian-language audience. Historical language, "
                "current home-use and displacement figures use different frames. Russian knowledge is not automatic "
                "socially acceptable substitute access."
            ),
        }
    if route_id in {"VI-S", "TH-S", "KM-S"}:
        data = load_json(path)
        profile_id = {"VI-S": "vie_Latn", "TH-S": "tha_Thai", "KM-S": "khm_Khmr"}[route_id]
        profile = next(row for row in data["profiles"] if row["id"] == profile_id)
        package = profile["packages"][0]
        aligned = route_id == "VI-S" and package["stage"] == "secondary"
        return {
            "package_alignment_status": (
                "RELATED_SECONDARY_SCIENCE_READING_PACKAGE_NOT_EXACT_Q_CATCHUP"
                if aligned
                else "NO_STAGE_ENDPOINT_ALIGNED_Q_CATCHUP_PACKAGE_IN_SELECTED_SOURCE"
            ),
            "observed_supply": package["counterevidence"],
            "aligned_package_id": package["id"] if aligned else "",
            "aligned_package_scope": package["title"] if aligned else "",
            "aligned_package_endpoint": package["additionality_status"] if aligned else "",
            "delivery_context": {
                "country_context": profile["country_context"],
                "indicator_frame": profile["indicator_frame"],
                "package_delivery_limitations": package["limitations"],
            },
            "exact_language_fit_evidence": {
                "operational_scope": profile["operational_scope"],
                "boundary": profile["boundary"],
                "language_matched_population": profile["language_matched_population"],
            },
            "binding_limit": (
                "The selected source contains no exact Q-CATCHUP matched-audience or effect estimate. A related "
                "package may inform design but cannot populate q for this route."
            ),
        }
    if route_id == "MS-S":
        return {
            "package_alignment_status": "NO_TARGET_SPECIFIC_Q_CATCHUP_SUPPLY_CARD_BOUND",
            "observed_supply": (
                "The current audit preserves Malaysian, Bruneian and Singaporean Malay profiles and rejects a pooled "
                "Malay-Indonesian bridge count without comprehension evidence."
            ),
            "aligned_package_id": "",
            "aligned_package_scope": "",
            "aligned_package_endpoint": "",
            "delivery_context": {"status": "UNMEASURED_FOR_THIS_ROUTE_IN_SELECTED_SOURCE"},
            "exact_language_fit_evidence": {
                "status": "UNMEASURED",
                "identity_rule": "Standard Malay and Indonesian are related but not interchangeable.",
            },
            "binding_limit": (
                "No target-specific secondary Q-CATCHUP supply, delivery, audience or effect card is bound. Shared "
                "Malay-Indonesian production remains a separate overlap/reuse hypothesis."
            ),
        }
    raise KeyError(route_id)


def main() -> None:
    generated_at = datetime.now(timezone.utc).isoformat()
    frontier = [row for row in read_csv(FRONTIER_PATH) if row["package_id"] == "Q-CATCHUP"]
    effect_map = read_csv(EFFECT_MAP_PATH)
    package_scale = load_json(PACKAGE_SCALE_PATH)
    size_comparison = load_json(PACKAGE_SIZE_COMPARISON_PATH)
    content_plans = {
        plan_id: {
            "module_count": plan["module_count"],
            "content_text_tokens_cl100k": plan["tokens"]["cl100k_base"]["content_text"],
            "whole_cnxml_tokens_cl100k": plan["tokens"]["cl100k_base"]["whole_cnxml"],
            "selected_chapters": plan.get("selected_chapters", []),
        }
        for plan_id, plan in package_scale["candidates"].items()
    }
    content_text_break_even = [
        row
        for row in size_comparison["same_endpoint_break_even"]
        if row["source_representation"] == "content_text"
    ]
    mappings_by_route: dict[str, list[str]] = {}
    for row in effect_map:
        mappings_by_route.setdefault(row["route_id"], []).append(row["mapping_id"])

    rows: list[dict[str, Any]] = []
    for source in frontier:
        threshold = Decimal(source["q_ratio_required_to_beat_equal_q_leader_base"])
        if source["route_id"] == "ID-S" or threshold <= Decimal(3):
            measurement_tier = "A_ORDER_SENSITIVE_THRESHOLD_AT_MOST_3"
        elif threshold <= Decimal(15):
            measurement_tier = "B_ORDER_REVERSAL_REQUIRES_LARGE_RELATIVE_Q"
        else:
            measurement_tier = "C_ORDER_REVERSAL_REQUIRES_VERY_LARGE_RELATIVE_Q"
        binding = extract_binding(source["route_id"])
        row: dict[str, Any] = {
            "route_id": source["route_id"],
            "language_profile": source["language_profile"],
            "stage": source["stage"],
            "package_id": source["package_id"],
            "endpoint_id": source["endpoint_id"],
            "need_context_base": source["need_context_base"],
            "context_coefficient_per_million_fecu_base": source[
                "context_coefficient_per_million_fecu_base"
            ],
            "conditional_equal_q_position": source["conditional_rank_within_comparable_set"],
            "q_ratio_required_to_beat_equal_q_leader_base": source[
                "q_ratio_required_to_beat_equal_q_leader_base"
            ],
            "leader_q_ceiling_if_candidate_q_equals_one": source[
                "leader_q_ceiling_if_candidate_q_equals_one"
            ],
            "decision_discriminating_measurement_tier": measurement_tier,
            "measurement_tier_is_funding_priority": "False",
            "package_alignment_status": binding["package_alignment_status"],
            "supply_source_path": source_relative(SOURCE_PATHS[source["route_id"]]),
            "supply_source_sha256": sha(SOURCE_PATHS[source["route_id"]]),
            "observed_supply_summary": compact(binding["observed_supply"]),
            "aligned_package_id": binding["aligned_package_id"],
            "aligned_package_scope": binding["aligned_package_scope"],
            "aligned_package_endpoint": binding["aligned_package_endpoint"],
            "delivery_context_json": compact(binding["delivery_context"]),
            "exact_language_fit_evidence_json": compact(binding["exact_language_fit_evidence"]),
            "binding_limit": binding["binding_limit"],
            "p_exact_audience_status": "UNMEASURED_NOT_ZERO",
            "p_reached_status": "UNMEASURED_TARGET_SPECIFIC_NOT_REPLACED_BY_NATIONAL_MARGINAL",
            "p_acquired_status": "UNMEASURED_TARGET_SPECIFIC",
            "p_usable_status": "UNMEASURED_TARGET_SPECIFIC",
            "p_active_use_status": "UNMEASURED_TARGET_SPECIFIC",
            "p_endpoint_gain_status": "LITERATURE_SCENARIO_MAPPED_TARGET_SPECIFIC_UNMEASURED",
            "p_endpoint_loss_status": "UNMEASURED_NOT_ASSUMED_ZERO_EXCEPT_DECLARED_NO_LOSS_SCENARIO",
            "q_status": "UNMEASURED_NOT_ZERO",
            "q_decomposition": (
                "q_net = p_exact_audience * p_reached * p_acquired * p_usable * p_active_use * "
                "p_new_endpoint_gain_given_active - p_endpoint_loss"
            ),
            "effect_mapping_ids_json": compact(sorted(mappings_by_route[source["route_id"]])),
            "portfolio_overlap_status": source["overlap_status"],
            "funding_rank": "",
            "possible_outranker": "True",
            "exclusion_allowed": "False",
            "next_measurement": (
                "Bind one exact learner frame, current independently usable package, identical endpoint and horizon; "
                "estimate each q component under passive, active-static, offline and supported scenarios; measure "
                "complete and bounded package reference physical work."
            ),
        }
        row["row_sha256"] = canonical_hash(row)
        rows.append(row)

    rows.sort(key=lambda row: int(row["conditional_equal_q_position"]))
    write_csv(OUT_CSV, rows)
    source_hashes = {
        source_relative(path): sha(path)
        for path in sorted(
            set(SOURCE_PATHS.values())
            | {FRONTIER_PATH, EFFECT_MAP_PATH, PACKAGE_SCALE_PATH, PACKAGE_SIZE_COMPARISON_PATH}
        )
    }
    payload = {
        "schema": "interlanguage/q-catchup-target-bindings/1.0.0",
        "generated_at_utc": generated_at,
        "purpose": (
            "Bind current supply and delivery evidence to the same-endpoint Q-CATCHUP frontier and identify "
            "which q measurements can most readily reverse its conditional order."
        ),
        "q_definition": (
            "Average net additional probability of usable access to the endpoint within the recorded need/context "
            "population, relative to independently usable current alternatives."
        ),
        "q_decomposition_rule": (
            "The displayed multiplicative chain is a measurement plan, not an independence assumption. Joint "
            "measurement or ITT estimates supersede factor multiplication when available."
        ),
        "measurement_tier_rule": (
            "Tier A means an effect-ratio measurement can plausibly change the point order with a ratio at most 3; "
            "tiers are value-of-information labels, never educational-worth or funding ranks."
        ),
        "controlled_package_size_sensitivity": {
            "source_repository": package_scale["source_repository"],
            "source_commit": package_scale["commit"],
            "license": package_scale["license"],
            "content_plans": content_plans,
            "same_endpoint_content_text_break_even": content_text_break_even,
            "interpretation": (
                "These are measured source-representation sizes and conditional linear token-workload thresholds. "
                "They are not target-specific educational effects or physical compute. Fractions-only is a narrower "
                "endpoint and cannot silently substitute for the complete Q-CATCHUP endpoint."
            ),
        },
        "source_sha256": source_hashes,
        "row_count": len(rows),
        "rows": rows,
    }
    write_json(OUT_JSON, payload)

    tier_a = [row for row in rows if row["decision_discriminating_measurement_tier"].startswith("A_")]
    md = [
        "# Binding target-specific evidence to the secondary catch-up frontier — v1",
        "",
        "## Why this exists",
        "",
        "The equal-`q` frontier is only a placeholder. This checkpoint asks which existing-supply, language-fit, delivery and effect facts are already bound to each route, and which missing fact is most likely to change the conditional order.",
        "",
        "`q` means the average net additional probability that a person inside the recorded need/context population gains usable access to the exact educational endpoint because of the intervention, relative to current independently usable alternatives. The measurement plan is:",
        "",
        "`q = language/audience fit × reached × acquired × usable × active use × new endpoint gain − endpoint loss`",
        "",
        "This factorization organizes evidence. It is not an independence assumption; a directly comparable intent-to-treat estimate replaces the product.",
        "",
        "## Where one additional measurement can change the current order",
        "",
        "| Measurement tier | Route | Equal-q position | q relative to Indonesia needed to lead | If candidate q=1, Indonesia q must be below | Package-evidence alignment |",
        "|---|---|---:|---:|---:|---|",
    ]
    for row in rows:
        tier = row["decision_discriminating_measurement_tier"].split("_", 1)[0]
        md.append(
            "| {tier} | {language} | {position} | {ratio:.2f}× | {ceiling:.3f} | {alignment} |".format(
                tier=tier,
                language=row["language_profile"],
                position=row["conditional_equal_q_position"],
                ratio=Decimal(row["q_ratio_required_to_beat_equal_q_leader_base"]),
                ceiling=Decimal(row["leader_q_ceiling_if_candidate_q_equals_one"]),
                alignment=row["package_alignment_status"].replace("_", " ").lower(),
            )
        )
    md += [
        "",
        "Tier A contains Indonesia as the comparison anchor plus Brazilian Portuguese and Filipino. Brazilian Portuguese overtakes the point leader if its target-specific `q` is more than about 1.85 times Indonesia's; Filipino overtakes at about 2.42 times. These are the first three routes to align on exactly the same package, learner frame, horizon and delivery scenario because the result can change without an extreme effect difference.",
        "",
        "This measurement tier is a value-of-information ordering: it says where one additional matched estimate is most likely to change the current conditional comparison. It is not a ranking of people, languages, educational need or production entitlement.",
        "",
        "The lower tiers remain possible outrankers. A larger reversal ratio means only that, under the current need and token-workload point scenarios, a larger target-specific effect difference is required. It says nothing about a language community's educational worth and is not a reason to exclude research or production in another endpoint.",
        "",
        "## What the existing evidence changes",
        "",
        "- **Indonesia:** current official Grade VII student books and separate teacher guides exist. The strongest matched hypothesis is therefore an autonomous diagnostic, worked-feedback, remediation and offline companion versus a complete independent sequence—not a claim that Indonesian materials are absent.",
        "- **Brazilian Portuguese:** the represented secondary proficiency context is large, but current evidence does not identify whether language, prerequisites, pedagogy or delivery is the binding mechanism. A bounded prerequisite package and a complete pathway must be tested against the same endpoint.",
        "- **Filipino:** extensive official K–12 and ALS records coexist with fragmented paths, an observed anonymous-download barrier, non-universal connectivity and unresolved allocation of national burden among Filipino, English and exact local languages. The exact audience is therefore especially decision-critical.",
        "- **Japanese and Ukrainian:** both have stage-matched bounded package hypotheses, but their most specific local evidence frames do not equal the PISA-derived Q-CATCHUP context. They remain unmeasured rather than being penalized.",
        "- **Vietnamese:** one related secondary science-reading companion exists, but it is not the exact quantitative catch-up endpoint.",
        "- **Thai, Central Khmer and Standard Malay:** the selected current evidence does not yet bind a stage-and-endpoint-matched Q-CATCHUP package. This is a research gap, not zero need.",
        "",
        "## Current delivery observations",
        "",
        "Indonesia's 2024 national marginals report 72.78% internet use, 68.65% mobile-phone ownership and 18.52% household computer ownership. The Philippines reports 67.3% internet use among people aged 10+, 48.8% household home internet, and large regional differences; its 98.8% cellphone figure is conditional on internet users. Brazil and Japan have higher national internet-use contexts, while Ukraine's current evidence includes internet, electricity, mobile-subscription and displacement frames. None is a learner-language-device cross-tab, so none is multiplied into `q`. Collectively they support simultaneous phone-readable, printable, download-once and offline routes rather than a web-only assumption.",
        "",
        "## Complete course versus smaller package",
        "",
        "The pinned OpenStax Prealgebra 2e source contains 364,270 measured `cl100k_base` content-text tokens across 75 modules. A six-chapter quantitative selection contains 173,958 tokens across 36 modules (47.755% of the complete source); a fractions-only chapter contains 41,336 tokens across eight modules (11.348%). These are source-representation measurements, not physical compute.",
        "",
        "If a smaller package and the complete package genuinely produce the same endpoint, use the ratio of their positive target-specific yields rather than choosing by length alone:",
        "",
        "| Smaller source plan | Shared setup as fraction of full variable cost | Smaller package must deliver more than this share of full-package positive yield |",
        "|---|---:|---:|",
    ]
    for item in content_text_break_even:
        md.append(
            "| {plan} | {setup:.1f} | {threshold:.3f} |".format(
                plan=item["small"].replace("_", " "),
                setup=Decimal(str(item["common_setup_as_fraction_of_full_variable_cost"])),
                threshold=Decimal(str(item["small_over_full_positive_yield_threshold"])),
            )
        )
    md += [
        "",
        "With no common setup, the six-chapter package is more efficient if it delivers more than 47.755% of the complete package's positive yield. If shared setup equals the complete package's variable translation workload, that threshold rises to 73.878%. The fractions-only thresholds are mathematically valid only for an explicitly narrow common endpoint; one fractions chapter cannot be credited with the complete catch-up endpoint.",
        "",
        "For a fixed source plan, equal target-specific yield leaves the current cross-language order unchanged because every route is scaled by the same source size. Package design can change that order only through target-specific yield, unequal extra work, shared setup/reuse, delivery, or physical-compute differences.",
        "",
        "## Next discriminating comparison",
        "",
        "For Indonesia, Brazil and the Philippines, specify one identical quantitative endpoint and horizon; compare a bounded prerequisite/feedback companion with a complete autonomous sequence; retain current independently usable supply as the baseline; model passive, active-static, offline and supported use separately; and measure full reference production work. This produces evidence capable of replacing the equal-`q` placeholder without pretending that source availability itself is educational effect.",
        "",
        "## Machine-readable outputs",
        "",
        "- `structured/Q_CATCHUP_TARGET_BINDINGS_v1.csv`",
        "- `structured/Q_CATCHUP_TARGET_BINDINGS_v1.json`",
        "- `qa/Q_CATCHUP_TARGET_BINDINGS_QA_v1.json`",
        "",
    ]
    OUT_MD.write_text("\n".join(md), encoding="utf-8")

    csv_rows = read_csv(OUT_CSV)
    json_payload = load_json(OUT_JSON)
    checks = {
        "exactly_nine_routes": len(rows) == 9,
        "all_frontier_routes_preserved": {row["route_id"] for row in rows}
        == {row["route_id"] for row in frontier},
        "tier_a_is_anchor_brazil_philippines": {row["route_id"] for row in tier_a}
        == {"ID-S", "PTBR-S", "FIL-S"},
        "every_route_has_source_hash": all(row["supply_source_sha256"] for row in rows),
        "every_source_hash_matches_manifest": all(
            row["supply_source_sha256"] == source_hashes[row["supply_source_path"]] for row in rows
        ),
        "all_q_values_unmeasured_not_zero": all(row["q_status"] == "UNMEASURED_NOT_ZERO" for row in rows),
        "no_funding_ranks": all(not row["funding_rank"] for row in rows),
        "all_possible_outrankers": all(row["possible_outranker"] == "True" for row in rows),
        "no_exclusions": all(row["exclusion_allowed"] == "False" for row in rows),
        "every_route_has_effect_mappings": all(json.loads(row["effect_mapping_ids_json"]) for row in rows),
        "csv_json_counts_match": len(csv_rows) == json_payload["row_count"],
        "package_scale_source_is_pinned": package_scale["commit"] == "38cae454e644abf9f0a623e876994553881597c9",
        "package_content_token_counts_preserved": {
            plan: item["content_text_tokens_cl100k"] for plan, item in content_plans.items()
        }
        == {
            "complete_source_collection": 364270,
            "selected_quantitative_units_scenario": 173958,
            "fractions_chapter_only": 41336,
        },
        "six_content_text_break_even_scenarios_retained": len(content_text_break_even) == 6,
        "row_hashes_verify": all(
            row["row_sha256"]
            == canonical_hash({key: value for key, value in row.items() if key != "row_sha256"})
            for row in csv_rows
        ),
        "human_report_names_research_question": "equal-`q` frontier is only a placeholder" in OUT_MD.read_text(encoding="utf-8"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    result = "PASS" if not failed else "FAIL"
    write_json(
        QA_PATH,
        {
            "schema": "interlanguage/q-catchup-target-bindings-qa/1.0.0",
            "generated_at_utc": generated_at,
            "result": result,
            "checks": checks,
            "failed_checks": failed,
            "source_sha256": source_hashes,
            "artifact_sha256": {
                source_relative(path): {"bytes": path.stat().st_size, "sha256": sha(path)}
                for path in [OUT_CSV, OUT_JSON, OUT_MD]
            },
            "boundary": (
                "PASS verifies evidence binding and preservation of unknowns. It does not estimate q or establish "
                "a physical-compute funding order."
            ),
        },
    )
    print(json.dumps({"result": result, "failed": failed, "rows": len(rows), "qa": str(QA_PATH)}, indent=2))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
