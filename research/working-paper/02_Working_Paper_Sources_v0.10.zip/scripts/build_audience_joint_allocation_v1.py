"""Exact synthetic audience-intersection and allocation results, not survey estimates.

No network, source-data downloads, census-code guessing, or global-rank mutation.
Running this script writes one deterministic result JSON and one QA JSON.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Margin:
    n: int
    unit: str = "persons"
    universe: str = "synthetic resident population"
    period: str = "synthetic single date"


def bounds(total, a, b):
    if len({(m.unit, m.universe, m.period) for m in (total, a, b)}) != 1:
        raise ValueError("Incompatible unit, universe, or reference period")
    if any(type(m.n) is not int or m.n < 0 for m in (total, a, b)):
        raise ValueError("Exact nonnegative integer counts required")
    if a.n > total.n or b.n > total.n:
        raise ValueError("A marginal count exceeds its total")
    return max(0, a.n + b.n - total.n), min(a.n, b.n)


def independence(total, a, b):
    bounds(total, a, b)
    return Q(a.n * b.n, total.n) if total.n else None


def cells(n, a, b, x):
    if type(x) is not int:
        raise ValueError("Integer intersection required for a finite-population witness")
    low, high = bounds(Margin(n), Margin(a), Margin(b))
    if not low <= x <= high:
        raise ValueError("Infeasible intersection")
    return [x, a - x, b - x, n - a - b + x]


def stratified(rows, *, disjoint_exhaustive):
    # This is an explicit input assertion, not a proof of source coverage.
    if disjoint_exhaustive is not True:
        raise ValueError("Disjoint exhaustive coverage is not declared")
    if len({key for key, *_ in rows}) != len(rows):
        raise ValueError("Repeated stratum key")
    low = high = 0
    scenario = Q(0)
    totals = [0, 0, 0]
    for _, n, a, b in rows:
        l, u = bounds(Margin(n), Margin(a), Margin(b))
        low += l
        high += u
        scenario += independence(Margin(n), Margin(a), Margin(b)) or Q(0)
        totals = [x + y for x, y in zip(totals, (n, a, b))]
    return (low, high), scenario, totals


def weighted_share(records):
    """Already decoded unique persons, with known binary cohort membership.

    Keys must be nonblank canonical strings from an upstream validated linkage.
    Weights here are relative masses, NOT certified population expansion factors.
    The function cannot accept raw household or business-slot records.
    """
    keys = [r["person_key"] for r in records]
    if any(not isinstance(key, str) or not key.strip() for key in keys):
        raise ValueError("Nonblank canonical person keys required")
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate person key")
    if any(r["unit"] != "person" for r in records):
        raise ValueError("Person records required")
    if any(type(r["selected"]) is not bool for r in records):
        raise ValueError("Unknown membership must be bounded, not recoded false")
    weights = [Q(str(r["weight"])) for r in records]
    if any(w <= 0 for w in weights):
        raise ValueError("Positive documented weights required")
    total = sum(weights, Q(0))
    if not total:
        raise ValueError("Empty weighted universe")
    selected = sum((w for r, w in zip(records, weights) if r["selected"]), Q(0))
    return selected, total, selected / total


def feasible_portfolios(x, budget=3):
    # Hypothetical fixed costs; disjoint actual beneficiaries; equal extra benefit
    # per reached cohort member; common reach-times-benefit normalized to one.
    # Not a country- or language-specific calibration.
    options = [("targeted_resource", 2, x), ("alternative_resource", 2, 20),
               ("third_resource", 1, 6)]
    out = []
    for mask in itertools.product((False, True), repeat=3):
        picked = [o for o, flag in zip(options, mask) if flag]
        cost = sum(o[1] for o in picked)
        if cost <= budget:
            out.append({"selection": [o[0] for o in picked], "cost": cost,
                        "benefit": sum(o[2] for o in picked)})
    best = max(row["benefit"] for row in out)
    return [row for row in out if row["benefit"] == best]


def encode(value):
    if isinstance(value, Q):
        return {"exact": str(value), "decimal": float(value)}
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def run():
    checks = []

    def check(label, truth):
        if not truth:
            raise AssertionError(label)
        checks.append(label)

    def rejects(label, action):
        try:
            action()
        except ValueError:
            checks.append(label)
        else:
            raise AssertionError(label)

    # Exhaustive finite population tables verify sharpness, not survey coverage.
    cases = 0
    for n in range(13):
        for a in range(n + 1):
            for b in range(n + 1):
                low, high = bounds(Margin(n), Margin(a), Margin(b))
                valid = [x for x in range(n + 1)
                         if min(x, a - x, b - x, n - a - b + x) >= 0]
                if valid != list(range(low, high + 1)):
                    raise AssertionError((n, a, b))
                if n and not low <= independence(Margin(n), Margin(a), Margin(b)) <= high:
                    raise AssertionError("Independence outside feasible bounds")
                cases += 1
    check("Sharp compatible-count bounds for every N<=12", cases == 819)
    check("Empty universe has no defined independence fraction",
          independence(Margin(0), Margin(0), Margin(0)) is None)
    for field, value in [("unit", "households"), ("universe", "another population"),
                         ("period", "another year")]:
        args = {field: value}
        rejects("Reject incompatible " + field,
                lambda args=args: bounds(Margin(100), Margin(40, **args), Margin(30)))
    rejects("Reject impossible margin", lambda: bounds(Margin(5), Margin(6), Margin(1)))
    rejects("Reject negative count", lambda: bounds(Margin(5), Margin(-1), Margin(1)))
    rejects("Reject noninteger exact count", lambda: bounds(Margin(5), Margin(1.5), Margin(1)))
    rejects("Reject fractional finite-population witness", lambda: cells(3, 1, 1, Q(1, 3)))

    rows = [("region_1", 50, 35, 20), ("region_2", 50, 5, 10)]
    interval, within_scenario, totals = stratified(rows, disjoint_exhaustive=True)
    check("Stratified interval", interval == (5, 25))
    check("Same global margins", totals == [100, 40, 30])
    check("Within-stratum independence is 15, not 12", within_scenario == 15)
    rejects("No assumed exhaustive partition", lambda: stratified(rows, disjoint_exhaustive=False))
    rejects("No repeated stratum", lambda: stratified([rows[0], rows[0]], disjoint_exhaustive=True))
    endpoints = {"low": [cells(50, 35, 20, 5), cells(50, 5, 10, 0)],
                 "high": [cells(50, 35, 20, 20), cells(50, 5, 10, 5)]}
    check("Two feasible endpoints reverse equal-cost selection",
          feasible_portfolios(5)[0]["selection"] == ["alternative_resource", "third_resource"]
          and feasible_portfolios(25)[0]["selection"] == ["targeted_resource", "third_resource"])
    check("Tie is retained", len(feasible_portfolios(20)) == 2)

    # Every pair of small strata: exact finite enumeration of stratification result.
    small = [(n, a, b) for n in range(5) for a in range(n + 1) for b in range(n + 1)]
    stratum_cases = 0
    for first, second in itertools.product(small, repeat=2):
        local, _, total = stratified([("a", *first), ("b", *second)], disjoint_exhaustive=True)
        broad = bounds(*(Margin(z) for z in total))
        if not broad[0] <= local[0] <= local[1] <= broad[1]:
            raise AssertionError((first, second))
        stratum_cases += 1
    check("Disjoint exhaustive stratification never widens bounds", stratum_cases == 3025)

    people = [{"person_key": "A", "weight": 2, "selected": True, "unit": "person"},
              {"person_key": "B", "weight": 3, "selected": True, "unit": "person"},
              {"person_key": "C", "weight": 7, "selected": False, "unit": "person"}]
    mass, total, share = weighted_share(people)
    scaled = weighted_share([{**p, "weight": p["weight"] * 100} for p in people])
    check("Weight-rescaling invariance of share", share == scaled[2] == Q(5, 12))
    check("Weighted mass is not scale-invariant", scaled[0] == mass * 100)
    rejects("No duplicate business-slot person weights", lambda: weighted_share(people + [people[0]]))
    rejects("No missing person key", lambda: weighted_share([{**people[0], "person_key": None}]))
    rejects("No blank person key", lambda: weighted_share([{**people[0], "person_key": " "}]))
    rejects("Unknown language membership not false", lambda: weighted_share([{**people[0], "selected": None}]))
    rejects("No household-unit row in person-share helper", lambda: weighted_share([{**people[0], "unit": "household"}]))
    rejects("No empty weighted universe", lambda: weighted_share([]))

    witness = ROOT / "sources/ihds_audience_20260908/IHDS2_Income_Social_Capital_Questionnaire.pdf"
    witness_bytes = witness.read_bytes()
    check("Pinned original questionnaire", hashlib.sha256(witness_bytes).hexdigest() ==
          "0caf5e6609048a5774a29911433068089f12194b2f5876c736036a7f5df24354")
    outputs = {
        "schema": "educational-access/joint-audience-allocation/1.0",
        "status": "EXACT_SYNTHETIC_RESULTS_AND_PRIMARY_SURVEY_FIELD_CONTRACT_NOT_POPULATION_ESTIMATES",
        "questionnaire": {"path": str(witness.relative_to(ROOT)).replace('\\', '/'),
                          "bytes": len(witness_bytes),
                          "sha256": hashlib.sha256(witness_bytes).hexdigest()},
        "synthetic_margins": {"N": 100, "language_A": 40, "occupation_B": 30,
                              "aggregate_bounds": bounds(Margin(100), Margin(40), Margin(30)),
                              "unconditional_independence": independence(Margin(100), Margin(40), Margin(30)),
                              "strata": rows, "stratified_bounds": interval,
                              "stratified_independence": within_scenario,
                              "endpoint_tables": endpoints,
                              "cell_order": ["both", "A_only", "B_only", "neither"]},
        "synthetic_budget_scenarios": [{"audience": x, "optimal": feasible_portfolios(x)}
                                       for x in (5, 12, 15, 20, 25)],
        "synthetic_weight_result": {"selected_weight_mass": mass, "total_weight_mass": total,
                                     "share": share, "scaled_selected_mass": scaled[0],
                                     "scale_invariant_share": scaled[2],
                                     "absolute_population": None},
        "benefit_normalization": "Common positive reach-times-additional-benefit factor normalized to one; disjoint beneficiaries in the synthetic example.",
        "eligibility_policy": "All communities remain eligible. This component does not test a global inventory. A zero lower bound is not zero need; scenarios include possible winners.",
        "real_population_estimates_calculated": False,
        "global_rankings_changed": False,
        "unfinished": ["Released joint records and exact codes", "Verified population weight expansion or calibration",
                       "Current audience estimates", "Target-specific reach and additional learning",
                       "Measured standardized physical compute"]
    }
    target = ROOT / "structured/AUDIENCE_JOINT_ALLOCATION_v1.json"
    target.write_text(json.dumps(encode(outputs), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    qa = {"status": "PASS_EXACT_SYNTHETIC_ARITHMETIC_NOT_SURVEY_VALIDATION",
          "checks": checks, "count": len(checks), "finite_count_cases": cases,
          "finite_stratification_cases": stratum_cases,
          "result_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT / "qa/AUDIENCE_JOINT_ALLOCATION_QA_v1.json").write_text(
        json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": qa["status"], "checks": len(checks), "result_sha256": qa["result_sha256"]}))


if __name__ == "__main__":
    run()
