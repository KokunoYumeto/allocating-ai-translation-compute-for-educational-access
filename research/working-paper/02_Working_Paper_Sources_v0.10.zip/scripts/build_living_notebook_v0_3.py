"""Build the v0.3 readable working paper and a source-bound publication payload."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, html, json, re, zipfile
import reportlab.rl_config
reportlab.rl_config.invariant = 1
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, PageBreak, ListFlowable, ListItem
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'publication/living_notebook_v0_3'
PDF='00_START_HERE__Current_Working_Paper_v0.3.pdf'
ZIP='02_Working_Paper_Sources_v0.3.zip'
MANIFEST='01_SNAPSHOT_MANIFEST_v0.3.json'
HTML='03_READABLE_WORKING_PAPER_v0.3.html'
STAMP='6 September 2026'
STATUS='WORK IN PROGRESS - ONGOING - NON-EXHAUSTIVE - NOT THE FINAL PRODUCT'
SOURCES=[
 'PAPER_CURRENT_DRAFT.md','ACADEMIC_REGISTER_TRANSLATION_RESEARCH_v1.md',
 'HYBRID_LANGUAGE_REACH_BASELINE_v1.md','HEGEMONY_BIAS_AUDIT_v1.md',
 'METHODS_GLOBAL_COMPARABILITY_v3.md','EDUCATIONAL_PACKAGE_PORTFOLIO_v1.md','EXPECTED_CANDIDATE_COVERAGE_v1.md',
 'HYPOTHESES_AND_EXPECTED_CANDIDATES_v1.md','HYPOTHESIS_TEST_PLAN_v1.md','HYPOTHESIS_OUTCOMES_v2.md',
 'AFRICAN_PACKAGE_NEEDS_20260904.md','agent_reports/ARABIC_IRANIC_PACKAGE_NEEDS_20260904.md',
 'agent_reports/SIGNED_LANGUAGE_PACKAGE_NEEDS_20260904.md','agent_reports/MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.md',
 'agent_reports/PORTUGUESE_SPANISH_PACKAGE_NEEDS_20260904.md','SHARED_REGISTER_PORTFOLIO_COMPARISONS_v1.md',
 'structured/COMPLETE_VS_SMALLER_PACKAGES_20260904.json','structured/OPENSTAX_PACKAGE_SCALE_20260904.json',
 'structured/HYBRID_LANGUAGE_REACH_BASELINE_v1.json','structured/HYBRID_LANGUAGE_REACH_BASELINE_v1.csv',
 'structured/ACADEMIC_REGISTER_TRANSLATION_EVIDENCE_v1.json','structured/ACADEMIC_REGISTER_TRANSLATION_EVIDENCE_v1.csv',
 'structured/EXPECTED_CANDIDATE_COVERAGE_v1.json','structured/HYPOTHESIS_CANDIDATE_REGISTER_v1.json',
 'structured/INTERVENTION_COMPARISONS_v1.json','structured/UNIVERSAL_LANGUAGE_INCLUSION_REGISTER_v1.csv',
 'qa/HYBRID_LANGUAGE_REACH_BASELINE_QA_v1.json','qa/HYBRID_REACH_HEGEMONY_AUDIT_v1.json',
 'qa/ACADEMIC_REGISTER_TRANSLATION_RESEARCH_QA_v1.json','LICENSE']
def digest(b):return hashlib.sha256(b).hexdigest().upper()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b.encode('utf-8') if isinstance(b,str) else b)
def clean_pdf_text(s):
    # The public Markdown retains the exact Bengali-script title. ReportLab lacks shaping;
    # the PDF presents a faithful English description rather than broken glyphs.
    return (s.replace('\u2011','-').replace('\u2013','-').replace('\u2014','-').replace('\u2212','-').replace('\u2192',' -> ')
        .replace('প্রাথমিক গণিত, দ্বিতীয় শ্রেণি','Primary mathematics, grade 2')
        .replace('Pythonプログラミング入門','Introduction to Python programming')
        .replace('概率统计与Python解法','Probability and statistics with Python solutions'))
def inline(s):
    s=html.escape(clean_pdf_text(s.strip()))
    s=re.sub(r'\[([^\]]+)\]\((https?://[^\s)]+)\)',r'<a href="\2" color="#075c75"><u>\1</u></a>',s)
    s=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<b>\1</b> (source file: <font name="NotoMono">\2</font>)',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)',r'<i>\1</i>',s)
    s=re.sub(r'`([^`]+)`',r'<font name="NotoMono">\1</font>',s)
    return s

def font_source(filename, legacy_filename=None):
    local = ROOT / 'assets' / 'fonts' / filename
    if local.is_file():
        return str(local)
    legacy = Path(r'C:\Windows\Fonts') / (legacy_filename or filename)
    if legacy.is_file():
        return str(legacy)
    raise FileNotFoundError('Required font asset missing: ' + filename)

pdfmetrics.registerFont(TTFont('Noto',font_source('NotoSans-Regular.ttf')))
pdfmetrics.registerFont(TTFont('Noto-Bold',font_source('NotoSans-Bold.ttf')))
pdfmetrics.registerFont(TTFont('Noto-Serif',font_source('NotoSerif-Regular.ttf')))
pdfmetrics.registerFont(TTFont('Noto-Serif-Bold',font_source('NotoSerif-Bold.ttf')))
pdfmetrics.registerFont(TTFont('NotoMono',font_source('NotoSansMono-Regular.ttf','consola.ttf')))
if (ROOT / 'assets/fonts/NotoSans-Italic.ttf').is_file():
    pdfmetrics.registerFont(TTFont('Noto-Italic',font_source('NotoSans-Italic.ttf')))
    pdfmetrics.registerFont(TTFont('Noto-BoldItalic',font_source('NotoSans-BoldItalic.ttf')))
    pdfmetrics.registerFontFamily('Noto',normal='Noto',bold='Noto-Bold',italic='Noto-Italic',boldItalic='Noto-BoldItalic')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='PaperBody',fontName='Noto',fontSize=9.6,leading=14.2,spaceAfter=8,splitLongWords=True,textColor=colors.HexColor('#1d2a31')))
styles.add(ParagraphStyle(name='PaperSmall',parent=styles['PaperBody'],fontSize=8.1,leading=11,spaceAfter=5))
styles.add(ParagraphStyle(name='PaperH1',fontName='Noto-Serif-Bold',fontSize=21,leading=25,spaceBefore=5,spaceAfter=14,textColor=colors.HexColor('#183f48'),keepWithNext=True))
styles.add(ParagraphStyle(name='PaperH2',fontName='Noto-Bold',fontSize=15,leading=19,spaceBefore=17,spaceAfter=9,textColor=colors.HexColor('#174d59'),keepWithNext=True))
styles.add(ParagraphStyle(name='PaperH3',fontName='Noto-Bold',fontSize=11.5,leading=15,spaceBefore=12,spaceAfter=7,textColor=colors.HexColor('#285d66'),keepWithNext=True))
styles.add(ParagraphStyle(name='CoverTitle',fontName='Noto-Serif-Bold',fontSize=27,leading=32,alignment=TA_CENTER,textColor=colors.HexColor('#183f48'),spaceAfter=20))
styles.add(ParagraphStyle(name='CoverSub',fontName='Noto',fontSize=12,leading=18,alignment=TA_CENTER,spaceAfter=16))
styles.add(ParagraphStyle(name='Status',fontName='Noto-Bold',fontSize=9.5,leading=14,alignment=TA_CENTER,textColor=colors.HexColor('#6a4b00'),backColor=colors.HexColor('#fff0ba'),borderPadding=10,spaceAfter=20))

class Doc(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(path,pagesize=A4,rightMargin=45,leftMargin=45,topMargin=48,bottomMargin=45,
          title='Allocating AI-assisted educational publishing for greater access - working paper',author='KokunoYumeto',subject=STATUS)
        frame=Frame(self.leftMargin,self.bottomMargin,self.width,self.height,id='main')
        self.addPageTemplates(PageTemplate(id='paper',frames=frame,onPage=self.decorate))
    def decorate(self,canvas,doc):
        canvas.saveState();canvas.setFont('Noto',7.7);canvas.setFillColor(colors.HexColor('#52646b'))
        canvas.drawString(45,A4[1]-27,'ONGOING, NON-EXHAUSTIVE WORKING PAPER - '+STAMP)
        canvas.drawRightString(A4[0]-45,25,'Page '+str(doc.page));canvas.restoreState()
    def afterFlowable(self,f):
        if not isinstance(f,Paragraph) or f.style.name not in ('PaperH1','PaperH2','PaperH3'):return
        level={'PaperH1':0,'PaperH2':0,'PaperH3':1}[f.style.name]
        title=re.sub('<[^>]+>','',f.getPlainText()).strip()
        key='section-'+hashlib.sha1(f'{level}|{title}|{self.page}'.encode()).hexdigest()[:16]
        self.canv.bookmarkPage(key);self.canv.addOutlineEntry(title,key,level=level,closed=False)
        self.notify('TOCEntry',(level,title,self.page,key))
def P(s,style='PaperBody'):return Paragraph(inline(s),styles[style])

def parse_markdown(source):
    lines=source.splitlines();story=[];i=0;para=[]
    def flush():
        nonlocal para
        if para:
            story.append(P(' '.join(x.strip() for x in para)));para=[]
    while i<len(lines):
        line=lines[i]
        if not line.strip():flush();i+=1;continue
        if line.startswith('# '):flush();story.append(P(line[2:],'PaperH1'));i+=1;continue
        if line.startswith('## '):flush();story.append(P(line[3:],'PaperH2'));i+=1;continue
        if line.startswith('### '):flush();story.append(P(line[4:],'PaperH3'));i+=1;continue
        if re.match(r'^#{4,6} ',line):
            flush();story.append(P(re.sub(r'^#{4,6} ','',line),'PaperH3'));i+=1;continue
        if line.startswith('|'):
            flush();raw=[]
            while i<len(lines) and lines[i].startswith('|'):
                raw.append([x.strip() for x in lines[i].strip().strip('|').split('|')]);i+=1
            raw=[r for r in raw if not all(re.fullmatch(r':?-{2,}:?',c or '') for c in r)]
            if not raw:continue
            n=max(map(len,raw));raw=[r+['']*(n-len(r)) for r in raw]
            table=[[P(c,'PaperSmall') for c in r] for r in raw]
            if n==2: widths=[doc_width*.34,doc_width*.66]
            elif n==3: widths=[doc_width*.18,doc_width*.41,doc_width*.41]
            elif n==4: widths=[doc_width*.13,doc_width*.30,doc_width*.40,doc_width*.17]
            else: widths=[doc_width/n]*n
            t=Table(table,colWidths=widths,repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6f0f1')),('FONTNAME',(0,0),(-1,0),'Noto-Bold'),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#aebfc2')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
            story.extend([Spacer(1,4),t,Spacer(1,7)]);continue
        if re.match(r'^[-*] ',line):
            flush();items=[]
            while i<len(lines) and re.match(r'^[-*] ',lines[i]):items.append(ListItem(P(lines[i][2:]),leftIndent=10));i+=1
            story.append(ListFlowable(items,bulletType='bullet',leftIndent=22,bulletFontName='Noto'));continue
        if re.match(r'^\d+\. ',line):
            flush();story.append(P(line));i+=1;continue
        if line.startswith('```'):
            flush();i+=1;code=[]
            while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
            i+=1;story.append(P(' '.join(code),'PaperSmall'));continue
        para.append(line);i+=1
    flush();return story

def build_html(hybrid,coverage):
    rows=[r for r in hybrid['rows'] if r.get('displayed_non_english_reference_order')]
    rows=sorted(rows,key=lambda r:r['displayed_non_english_reference_order'])[:10]
    def compact(n):
        return f'{n/1_000_000_000:.3f} billion' if n>=1_000_000_000 else f'{n/1_000_000:.1f} million'
    body=[]
    for r in rows:
        body.append('<tr><td>{}</td><td>{}</td><td>{}</td><td>{} - {}</td></tr>'.format(
            r['displayed_non_english_reference_order'],html.escape(r['edition_profile']),
            compact(r['population_plausibly_helped_point']),
            compact(r['population_plausibly_helped_low']),compact(r['population_plausibly_helped_high'])))
    counts=coverage['counts']
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Allocating AI-assisted educational publishing - working paper v0.3</title>
<style>
:root{{--ink:#17262c;--muted:#53656b;--teal:#0f5968;--pale:#eaf4f4;--gold:#fff0ba;--line:#b7c8cb}}
*{{box-sizing:border-box}}body{{margin:0;background:#f5f7f6;color:var(--ink);font:18px/1.58 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:1060px;margin:auto;background:#fff;min-height:100vh;padding:clamp(22px,5vw,72px)}}h1,h2{{font-family:Georgia,serif;color:#183f48;line-height:1.16}}
h1{{font-size:clamp(2rem,5vw,3.7rem);margin:.3em 0}}h2{{margin-top:2.2em}}.status{{background:var(--gold);border:1px solid #d8ba5b;padding:1rem;font-weight:750}}
.lead{{font-size:1.2em;max-width:76ch}}.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1rem}}.card{{background:var(--pale);border:1px solid var(--line);border-radius:10px;padding:1rem}}
table{{width:100%;border-collapse:collapse;font-size:.91em}}th,td{{border:1px solid var(--line);padding:.55rem;vertical-align:top;text-align:left}}th{{background:var(--pale)}}a{{color:var(--teal)}}.note{{color:var(--muted);border-left:5px solid var(--teal);padding-left:1rem}}
@media(max-width:700px){{body{{font-size:16px}}table{{display:block;overflow-x:auto}}main{{padding:20px}}}}
</style></head><body><main>
<p class="status">{STATUS}</p>
<h1>Allocating AI-assisted educational publishing for greater access</h1>
<p class="lead">This version keeps researched evidence and uses one disclosed baseline where equivalent evidence is missing. It also treats academic-to-nonacademic English as full-content translation rather than content reduction.</p>
<div class="cards">
<div class="card"><strong>Read the paper</strong><br><a href="{PDF}">Open the current readable PDF.</a></div>
<div class="card"><strong>Inspect the evidence</strong><br><a href="{MANIFEST}">Snapshot manifest</a> and <a href="{ZIP}">source archive</a>.</div>
<div class="card"><strong>Coverage state</strong><br>{counts['expected_candidates']} forecast profiles; {counts['expected_candidates_with_at_least_one_route']} currently have a route; every missing route remains open.</div>
</div>
<h2>What the current high-reach table means</h2>
<p>It estimates the population plausibly helped under one equal missing-data assumption. It is not a funding league table and does not rank the worth of communities. The point multiplier is 89.57%; the 70%-99% sensitivity interval is deliberately wide. Its input measures reported language use in 17 India Census rows, not academic-English proficiency, so these are planning references rather than observed global need.</p>
<table><thead><tr><th>Reference order</th><th>Language / first profile</th><th>Point reference</th><th>Sensitivity range</th></tr></thead><tbody>{''.join(body)}</tbody></table>
<p class="note">Simplified Standard Written Chinese is the first profile for the Mandarin row. Indonesian is eighth at about 228.2 million under the common point assumption. Ukrainian remains visible at about 27.6 million even though it falls outside this ten-row view. No language disappears because a preferred measurement is missing.</p>
<h2>Academic English is also a translation target</h2>
<p>Ordinary English use does not prove that a reader can independently use dense academic English for a particular task. The governing premise is that inherited academic-register familiarity is one institutionally distributed advantage and that any credible nonzero benefit makes a faithful adult register edition eligible.</p>
<p>The method is <strong>full-content diaphasic intralingual translation</strong>. It can define, unpack, split, resolve references, make logic explicit, reorder with tracked dependencies, and add labeled scaffolding. It cannot summarize, abridge, delete, generalize, change epistemic force, or replace proof with intuition.</p>
<p>There is no universal Plain English. Target profiles include international/ELF-friendly adult English, educated non-specialist English, profession-adjacent novice English, localized adult Englishes, an academic-convention companion, and separately commissioned accessibility editions.</p>
<h2>What is protected</h2>
<p>Every proposition, definition, quantifier, condition, exception, number, unit, term distinction, symbol, type, proof dependency, cross-reference, attribution, prerequisite, and uncertainty marker is reconciled against the source. Critical fidelity errors allowed: zero. Readability and similarity scores are diagnostics, not semantic certificates.</p>
<h2>Anti-hegemony rule</h2>
<p>Wealth, schooling, test performance, data abundance, colonial-language exposure, national standard status, prestige-register conformity, and current publication volume cannot reduce eligibility or stand in for intellectual capacity. Another language counts as coverage only when the same material is technically usable, intelligible, materially equivalent, voluntarily and politically acceptable, accessible, affordable, safe, and actually available.</p>
<h2>What remains unfinished</h2>
<p>The worldwide language, subject, stage, format, interlanguage, and cost synthesis remains ongoing. This snapshot contains a readable method and high-reach reference, not the final Top 10 or Top 100. Missing communities, varieties, scripts, signed languages, and accessibility formats remain eligible.</p>
<p><a href="https://github.com/KokunoYumeto/allocating-ai-translation-compute-for-educational-access">Public repository</a> · <a href="https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/">Living research site</a></p>
</main></body></html>'''

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    for rel in SOURCES:
        if not (ROOT/rel).is_file():raise FileNotFoundError(rel)
    paper=(ROOT/'PAPER_CURRENT_DRAFT.md').read_text(encoding='utf-8')
    coverage=json.loads((ROOT/'structured/EXPECTED_CANDIDATE_COVERAGE_v1.json').read_text(encoding='utf-8'))
    hybrid=json.loads((ROOT/'structured/HYBRID_LANGUAGE_REACH_BASELINE_v1.json').read_text(encoding='utf-8'))
    academic=json.loads((ROOT/'structured/ACADEMIC_REGISTER_TRANSLATION_EVIDENCE_v1.json').read_text(encoding='utf-8'))
    hegemony=json.loads((ROOT/'qa/HYBRID_REACH_HEGEMONY_AUDIT_v1.json').read_text(encoding='utf-8'))
    assert len(coverage['rows'])==100 and all(r.get('funding_rank') is None for r in coverage['rows'])
    assert coverage['counts']['expected_candidates_with_at_least_one_route']==63
    assert len(hybrid['rows'])==21
    assert len(academic['evidence'])==42 and academic['is_go_no_go_hypothesis'] is False
    assert hegemony['status']=='PASS' and hegemony['hard_failure_count']==0
    intro=['This working paper asks where AI-assisted publishing could create additional educational access. It does not rank the worth of languages or communities.',
      'Version 0.3 keeps target-comparable research and uses one disclosed baseline where equivalent evidence is missing, so missing data never make a language disappear or look less important.',
      'Under that common assumption, Mandarin Chinese with a Simplified Standard Written Chinese first profile leads the current non-English display; Indonesian is eighth. English register translation is a separate large, currently unmeasured frontier.',
      'Version 0.3 also establishes full-content diaphasic intralingual translation: a change of adult register with no loss of propositions, definitions, mathematics, proof dependencies, citations or uncertainty.',
      'The worldwide synthesis remains ongoing. Candidate identifiers are not ranks, and no absent or unfinished target has been judged less important.']
    cover=[Spacer(1,45),P(STATUS,'Status'),P('Allocating AI-assisted educational publishing for greater access','CoverTitle'),P('A living research paper on populations plausibly helped, educational needs, language registers, open materials and production effort','CoverSub'),P('Working snapshot 0.3.0 | '+STAMP,'CoverSub')]
    cover += [P(x,'CoverSub') for x in intro]
    cover += [Spacer(1,10),P('Living reader: https://kokunoyumeto.github.io/allocating-ai-translation-compute-for-educational-access/','PaperSmall'),PageBreak()]
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle(name='Toc0',fontName='Noto',fontSize=10,leading=15,leftIndent=0,firstLineIndent=0,spaceBefore=4),ParagraphStyle(name='Toc1',fontName='Noto',fontSize=9,leading=13,leftIndent=18,firstLineIndent=0)]
    story=cover+[P('Contents','PaperH1'),P('This table describes the present working paper; later versions may add or revise findings.'),toc,PageBreak()]
    global doc_width
    doc_width=A4[0]-90
    story += parse_markdown(paper)
    for label,rel in [
        ('Appendix A - Full-content academic-register translation','ACADEMIC_REGISTER_TRANSLATION_RESEARCH_v1.md'),
        ('Appendix B - Hybrid population-plausibly-helped reference','HYBRID_LANGUAGE_REACH_BASELINE_v1.md'),
        ('Appendix C - Anti-hegemony model audit','HEGEMONY_BIAS_AUDIT_v1.md')]:
        story += [PageBreak(),P(label,'PaperH1')]
        story += parse_markdown((ROOT/rel).read_text(encoding='utf-8'))
    story += [P('Publication status','PaperH1'),P(STATUS),P('This PDF is the human-readable presentation file. The accompanying source archive preserves the current Markdown, evidence tables and machine-readable calculations. Missing communities remain eligible; unfinished investigation is not evidence of low need.')]
    doc=Doc(str(OUT/PDF));doc.multiBuild(story)
    reader=PdfReader(OUT/PDF);text='\n'.join(p.extract_text() or '' for p in reader.pages)
    required=['Mandarin Chinese','Simplified Standard Written Chinese','1.075 billion','Indonesian','228.2 million','Ukrainian','27.6 million','full-content diaphasic intralingual translation','sufficiently plausible access thesis','There is no single universal Plain English','not a funding league table','not the final','non-exhaustive']
    assert all(x.casefold() in text.casefold() for x in required),[x for x in required if x.casefold() not in text.casefold()]
    assert len(reader.pages)>=30
    public_status='# Publication status\n\n**'+STATUS+'**\n\nThis is a dated working snapshot. It reports populations plausibly helped under explicit assumptions; it does not rank the worth of languages or communities. Missing or not-yet-investigated targets remain eligible. The PDF is the human-readable entry point, the HTML is a compact accessible reader, and the ZIP preserves source and evidence files.\n'
    write(OUT/'PUBLICATION_STATUS.md',public_status)
    write(OUT/HTML,build_html(hybrid,coverage))
    bindings=[]
    for rel in SOURCES:
        b=(ROOT/rel).read_bytes();bindings.append({'path':rel,'bytes':len(b),'sha256':digest(b)})
        if Path(rel).suffix.lower() in {'.md','.json','.csv','.txt'}:
            s=b.decode('utf-8-sig');assert Path.home().name not in s and not re.search(r'[A-Z]:[\\/]',s),rel
    fixed_time=(2026,9,6,0,0,0)
    with zipfile.ZipFile(OUT/ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel in SOURCES:
            info=zipfile.ZipInfo(rel,date_time=fixed_time);info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,(ROOT/rel).read_bytes())
        info=zipfile.ZipInfo('PUBLICATION_STATUS.md',date_time=fixed_time);info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,public_status.encode('utf-8'))
    with zipfile.ZipFile(OUT/ZIP) as z:
        assert z.testzip() is None and len(z.namelist())==len(SOURCES)+1
    manifest={'schema':'living-educational-access-working-paper/0.3.0','snapshot_date':'2026-09-06','version':'0.3.0-working-paper','status':STATUS,'final_product':False,'exhaustive':False,'moral_or_funding_rank':False,'candidate_identifiers_are_ranks':False,'missing_language_means_lower_need':False,'local_programme_changes_global_need':False,'go_no_go_register_hypothesis':False,
      'paper':{'name':PDF,'bytes':(OUT/PDF).stat().st_size,'sha256':digest((OUT/PDF).read_bytes()),'pages':len(reader.pages),'entry_point':True,'text_checks':required},
      'html_reader':{'name':HTML,'bytes':(OUT/HTML).stat().st_size,'sha256':digest((OUT/HTML).read_bytes()),'entry_point':True},
      'source_archive':{'name':ZIP,'bytes':(OUT/ZIP).stat().st_size,'sha256':digest((OUT/ZIP).read_bytes()),'entries':len(SOURCES)+1,'integrity':'PASS'},'source_bindings':bindings,
      'research_coverage':{'forecast_profiles':100,'profiles_with_route':63,'profiles_without_route':37,'additional_challengers':169,'hybrid_reference_rows':21,'register_translation_evidence_rows':42,'adult_english_target_profiles':6,'protected_content_classes':13,'stages':['P','F','S','V','U','R']},
      'limits':['This working paper is not an exhaustive worldwide needs assessment or final Top 10/Top 100.','The high-reach values are planning references under a common missing-data assumption, not observed global academic-English mismatch.','Population plausibly helped is not realized learning, moral worth, a funding rank, or a claim that smaller communities matter less.','The English register-translation thesis governs production; current evidence does not quantify its worldwide benefit.','Source-token traffic scenarios are not money, electricity, or physical compute.']}
    write(OUT/MANIFEST,json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    qa={'schema':'living-working-paper-build-qa/0.3.0','built_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_STRUCTURAL_TEXT_HTML_AND_ARCHIVE_CHECKS_VISUAL_REVIEW_PENDING','pdf_pages':len(reader.pages),'pdf_bytes':(OUT/PDF).stat().st_size,'pdf_sha256':manifest['paper']['sha256'],'html_bytes':(OUT/HTML).stat().st_size,'html_sha256':manifest['html_reader']['sha256'],'source_archive_sha256':manifest['source_archive']['sha256'],'source_bindings':len(bindings),'required_text_checks':required,'zip_integrity':'PASS','hybrid_reach_qa':'PASS','hegemony_audit':'PASS','academic_register_research_qa':'PASS','public_mutation':False}
    write(ROOT/'qa/LIVING_WORKING_PAPER_BUILD_QA_v0_3.json',json.dumps(qa,indent=2)+'\n')
    print(json.dumps(qa,indent=2))
if __name__=='__main__':main()
