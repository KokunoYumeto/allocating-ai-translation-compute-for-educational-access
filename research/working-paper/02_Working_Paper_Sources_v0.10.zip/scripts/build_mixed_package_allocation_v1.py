"""Finite-budget mixed educational packages with exact union setup accounting.

Scenario analysis, not observed learning or physical-compute measurement.
All numerical optimizers are bounded and use one HiGHS worker.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product
from datetime import datetime, timezone
import hashlib
import json
import os
import warnings

os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix, csc_array

ROOT = Path(__file__).resolve().parents[1]
INPUTS = {
    'structured/GLOBAL_BUDGET_SCENARIOS_v1.json': 'CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57',
    'structured/OPENSTAX_PACKAGE_SCALE_20260904.json': 'F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16',
    'structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json': '61088618CCF3C3C1A32E4D68EB4F9BAC115D354CB74DAE675E6816475A98CD86',
}
NAMES = ['supported_fractions', 'six_chapters', 'full_prealgebra']
LABELS = ['Fractions with linked support', 'Six chapters', 'Complete prealgebra']
EXTRA = [Q(1, 20), Q(1, 50), Q(0)]
YIELDS = {'lower_focused_yield': [Q(35, 100), Q(70, 100), Q(1)],
          'higher_focused_yield': [Q(65, 100), Q(90, 100), Q(1)]}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def identity(rel):
    p = ROOT / rel
    return {'path': rel, 'bytes': p.stat().st_size, 'sha256': sha(p)}


def exact(q):
    q = Q(q)
    return {'numerator': q.numerator, 'denominator': q.denominator, 'decimal': float(q)}


def save(rel, obj):
    (ROOT / rel).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


class Model:
    def __init__(self, candidates, plans, mask_rows):
        self.rows = [r for r in candidates if r['population_coefficient'] is not None]
        self.unknown = [r for r in candidates if r['population_coefficient'] is None]
        self.plans, self.masks = plans, mask_rows
        self.n = len(self.rows)
        self.costs = [[Q(str(r['base_100k_cost_fecu'])) * (Q(p['tokens'], 100000) + p['extra_ratio'] * Q(364270, 100000))
                       for p in plans] for r in self.rows]
        self.pop = [Q(str(r['population_coefficient'])) for r in self.rows]
        self.calls = []
        self.cache_path = ROOT / 'qa/MIXED_PACKAGE_SOLVE_CACHE_v1.json'
        self.cache = json.loads(self.cache_path.read_text(encoding='utf-8')) if self.cache_path.exists() else {}

    def solve(self, budget, alpha, setup_rate, allowed=(0, 1, 2), forced_type=None, forced_cost=Q(0), label=''):
        cache_key = json.dumps(['dominance-safe-v1', budget, list(map(str, alpha)), setup_rate,
                                list(allowed), forced_type, str(forced_cost), INPUTS], sort_keys=True)
        if cache_key in self.cache:
            cached = self.cache[cache_key]
            self.calls.append({**cached['solver'], 'cache_reuse': True, 'label': label})
            return cached
        n, nx = self.n, self.n * 3
        nv = nx + 8
        # Profile constraints, exact type-mask equivalence, one-hot mask, budget.
        A = lil_matrix((n + 8, nv), dtype=float)
        lo = np.full(n + 8, -np.inf)
        hi = np.full(n + 8, np.inf)
        for i in range(n):
            A[i, 3*i:3*i+3] = 1
            hi[i] = 1
        for k in range(3):
            up, down = n + 2*k, n + 2*k + 1
            A[up, k:nx:3] = 1
            A[down, k:nx:3] = 1
            for mask in range(8):
                bit = (mask >> k) & 1
                A[up, nx+mask] = -n * bit
                A[down, nx+mask] = -bit
            hi[up] = 0
            lo[down] = -1 if forced_type == k else 0
        A[n+6, nx:] = 1
        lo[n+6] = hi[n+6] = 1
        flat_cost = [c for row in self.costs for c in row]
        A[n+7, :nx] = np.array([float(c)/1e6 for c in flat_cost])
        A[n+7, nx:] = [setup_rate * m['source_tokens']/1e6 for m in self.masks]
        hi[n+7] = float(Q(budget)-forced_cost)/1e6
        lower = np.zeros(nv)
        upper = np.ones(nv)
        residual_budget = Q(budget)-forced_cost
        minimum_cost = min(self.costs[i][k] for i in range(n) for k in allowed)
        cardinality_bound = max(0, int(residual_budget // minimum_cost))
        bases = [Q(str(r['base_100k_cost_fecu'])) for r in self.rows]
        dominance = []
        for j in range(n):
            witnesses = [i for i in range(n) if i != j and self.pop[i] >= self.pop[j] and bases[i] <= bases[j]
                         and (self.pop[i] > self.pop[j] or bases[i] < bases[j] or self.rows[i]['row_id'] < self.rows[j]['row_id'])]
            if cardinality_bound == 0 or len(witnesses) >= cardinality_bound:
                upper[3*j:3*j+3] = 0
                dominance.append({'row_id':self.rows[j]['row_id'], 'witness_ids':[self.rows[i]['row_id'] for i in witnesses[:cardinality_bound]]})
        for k in range(3):
            if k not in allowed:
                upper[k:nx:3] = 0
        for mask in range(8):
            if any((mask >> k) & 1 and k not in allowed for k in range(3)):
                upper[nx+mask] = 0
            if forced_type is not None and not ((mask >> forced_type) & 1):
                upper[nx+mask] = 0
        values = [p*a for p in self.pop for a in alpha]
        objective = -np.array([float(v)/1e6 for v in values] + [0.0]*8)
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected.*')
            ans = milp(objective, integrality=np.ones(nv), bounds=Bounds(lower, upper),
                       constraints=LinearConstraint(csc_array(A), lo, hi),
                       options={'time_limit': 20, 'mip_rel_gap': 1e-8, 'threads': 1})
        call = {'label': label, 'status': int(ans.status), 'message': str(ans.message),
                'success': bool(ans.success), 'time_limit_seconds': 20, 'threads': 1}
        self.calls.append(call)
        if ans.x is None or ans.status == 2:
            if ans.status != 2:
                raise RuntimeError('No bounded solver incumbent: '+label+' '+str(ans.message))
            result = {'feasible': False, 'solver': call}
            self.cache[cache_key] = result
            self.cache_path.write_text(json.dumps(self.cache, indent=2)+'\n', encoding='utf-8')
            return result
        if not ans.success:
            # Never turn a time-limited incumbent into an optimum.
            save('qa/MIXED_PACKAGE_INTERRUPTED_v1.json', {'calls': self.calls, 'failing_label': label})
            raise RuntimeError('Bounded mixed-package solve incomplete: '+label+' '+str(ans.message))
        assert max(abs(ans.x - np.rint(ans.x))) < 1e-6
        picks = [(j//3, j%3) for j in np.flatnonzero(ans.x[:nx] > .5)]
        chosen_masks = np.flatnonzero(ans.x[nx:] > .5).tolist()
        assert len(chosen_masks) == 1
        mask = chosen_masks[0]
        real_mask = sum(1 << k for k in ({k for _, k in picks} | ({forced_type} if forced_type is not None else set())))
        assert real_mask == mask
        assert len({i for i, _ in picks}) == len(picks)
        variable = sum((self.costs[i][k] for i, k in picks), Q(0)) + forced_cost
        setup = Q(setup_rate * self.masks[mask]['source_tokens'])
        spent = variable + setup
        value = sum((self.pop[i]*alpha[k] for i, k in picks), Q(0))
        assert spent <= Q(budget), (label, float(spent), budget)
        assert abs(float(value)/1e6 + ans.fun) < 1e-5
        call.update({'relative_gap': float(ans.mip_gap), 'objective_upper_bound': -float(ans.mip_dual_bound)*1e6})
        selections = [{'row_id': self.rows[i]['row_id'], 'edition': self.rows[i]['edition'],
                       'package': NAMES[k], 'population_coefficient': float(self.pop[i]),
                       'relative_yield': exact(alpha[k]), 'variable_cost': exact(self.costs[i][k]),
                       'opportunity_coefficient': exact(self.pop[i]*alpha[k])} for i, k in picks]
        selections.sort(key=lambda r: (-r['opportunity_coefficient']['decimal'], r['row_id']))
        # Common-anchor nested sets [0,P_i], compatible benefit=max available yield.
        breakpoints = sorted({self.pop[i] for i, k in picks})
        nested, previous = Q(0), Q(0)
        for end in breakpoints:
            best = max(alpha[k] for i, k in picks if self.pop[i] >= end)
            nested += (end - previous) * best
            previous = end
        largest = max((self.pop[i]*alpha[k] for i, k in picks), default=Q(0))
        assert largest <= nested <= value
        result = {'feasible': True, 'selected': selections, 'mask': mask,
                'variable_workload_including_forced': exact(variable), 'shared_preparation_workload': exact(setup),
                'total_workload': exact(spent), 'unspent_workload': exact(Q(budget)-spent),
                'known_additive_coefficient': exact(value), 'largest_single_coefficient_lower_bound': exact(largest),
                'selected_set_nested_max_yield_coefficient': exact(nested),
                'union_source_modules': self.masks[mask]['modules'], 'union_source_tokens': self.masks[mask]['source_tokens'],
                'solver': call,
                'scenario_specific_dominance_presolve':{'maximum_known_editions':cardinality_bound,
                    'minimum_available_variable_cost':exact(minimum_cost), 'witnesses':dominance,
                    'retained_solver_profiles':n-len(dominance),
                    'proof':'At most K known editions fit. If K other profiles weakly dominate P and base cost, one is unused whenever this profile is selected; replacing it with that unused profile in the same package preserves the source union and cannot worsen benefit or cost. Deterministic identity breaks exact ties. This is not a needs or eligibility disposition.'}}
        self.cache[cache_key] = result
        self.cache_path.write_text(json.dumps(self.cache, indent=2)+'\n', encoding='utf-8')
        return result


def main():
    for rel, expected in INPUTS.items():
        assert sha(ROOT / rel) == expected, rel
    old = json.loads((ROOT / list(INPUTS)[0]).read_text(encoding='utf-8'))
    scale = json.loads((ROOT / list(INPUTS)[1]).read_text(encoding='utf-8'))
    support = json.loads((ROOT / list(INPUTS)[2]).read_text(encoding='utf-8'))
    rows = old['candidate_rows']
    assert len(rows) == len({r['row_id'] for r in rows}) == 775
    modules = {r['module_id']: r for r in scale['modules']}
    sets = [set(scale['candidates']['fractions_chapter_only']['module_ids']) | set(support['linked_modules_outside_package']),
            set(scale['candidates']['selected_quantitative_units_scenario']['module_ids']),
            set(scale['candidates']['complete_source_collection']['module_ids'])]
    def token_count(s):
        return sum(modules[m]['tokens']['cl100k_base']['content_text'] for m in s)
    assert [len(s) for s in sets] == [16, 36, 75]
    assert [token_count(s) for s in sets] == [87655, 173958, 364270]
    masks = []
    for mask in range(8):
        union = set().union(*(sets[k] for k in range(3) if mask >> k & 1))
        masks.append({'mask': mask, 'packages': [NAMES[k] for k in range(3) if mask >> k & 1],
                      'modules': sorted(union), 'source_tokens': token_count(union)})
    assert masks[3]['source_tokens'] == 198477 and len(masks[3]['modules']) == 40
    plans = [{'name': name, 'label': LABELS[k], 'tokens': token_count(sets[k]),
              'modules': sorted(sets[k]), 'extra_ratio': EXTRA[k]} for k, name in enumerate(NAMES)]
    model = Model(rows, plans, masks)
    assert len(model.rows) == 750 and len(model.unknown) == 25
    unknown_bases = {Q(str(r['base_100k_cost_fecu'])) for r in model.unknown}
    assert len(unknown_bases) == 1
    unknown_base = next(iter(unknown_bases))
    unknown_costs = [unknown_base*(Q(p['tokens'],100000)+p['extra_ratio']*Q(364270,100000)) for p in plans]
    scenarios, uniform_cache = [], {}
    for (yield_name, alpha), setup_rate, budget in product(YIELDS.items(), (0, 2), (5000000, 10000000, 20000000)):
        sid = f'{yield_name}::setup{setup_rate}::B{budget}'
        best = model.solve(budget, alpha, setup_rate, label=sid)
        assert best['feasible']
        uniform = []
        for k in range(3):
            key = (setup_rate, budget, k)
            if key not in uniform_cache:
                uniform_cache[key] = model.solve(budget, [Q(1)]*3, setup_rate, allowed=(k,), label=f'uniform:{key}')
            r = uniform_cache[key]
            coefficient = r['known_additive_coefficient']['decimal'] * float(alpha[k]) if r['feasible'] else 0
            uniform.append({'package': NAMES[k], 'feasible': r['feasible'], 'coefficient': coefficient,
                            'selected_ids': [x['row_id'] for x in r.get('selected', [])],
                            'total_workload': r.get('total_workload'), 'solver': r['solver']})
        assert best['known_additive_coefficient']['decimal'] >= max(r['coefficient'] for r in uniform)-1e-3
        insertion = []
        for k, cost in enumerate(unknown_costs):
            residual = model.solve(budget, alpha, setup_rate, forced_type=k, forced_cost=cost, label=sid+'::symbolic:'+NAMES[k])
            threshold = None
            if residual['feasible']:
                v = best['known_additive_coefficient']
                rv = residual['known_additive_coefficient']
                threshold = Q(v['numerator'],v['denominator'])-Q(rv['numerator'],rv['denominator'])
                assert threshold >= 0, 'Residual known portfolio exceeds unforced optimum'
            insertion.append({'package': NAMES[k], 'forced_variable_workload': exact(cost),
                              'residual_known_portfolio': residual,
                              'minimum_unknown_benefit_coefficient_for_strict_improvement': exact(threshold) if threshold is not None else None,
                              'minimum_unknown_audience_under_same_yield_scenario': exact(threshold/alpha[k]) if threshold is not None else None})
        scenarios.append({'scenario_id': sid, 'yield_profile': yield_name, 'relative_yields': [exact(a) for a in alpha],
                          'shared_setup_rate_per_union_token': setup_rate, 'budget': budget, 'solution': best,
                          'uniform_package_comparators': uniform,
                          'gain_over_best_uniform_percent': 100*(best['known_additive_coefficient']['decimal']/max(r['coefficient'] for r in uniform)-1),
                          'symbolic_insertions': insertion,
                          'symbolic_rows': [{'row_id': r['row_id'], 'edition': r['edition'], 'audience': None,
                                             'insertion_scenarios_shared_by_equal_cost': [x['package'] for x in insertion]} for r in model.unknown],
                          'observed_people_helped': None})
        save('qa/MIXED_PACKAGE_PROGRESS_v1.json', {'status':'RUNNING_BOUNDED_FINITE_SOLVES', 'completed_scenarios':len(scenarios),
                                                 'last_scenario':sid, 'solver_calls':len(model.calls)})
        print(json.dumps({'scenario':sid, 'editions':len(best['selected']), 'packages':sorted({r['package'] for r in best['selected']}),
                          'coefficient_millions':best['known_additive_coefficient']['decimal']/1e6,
                          'gain_over_best_uniform_percent':scenarios[-1]['gain_over_best_uniform_percent']}), flush=True)
    data = {'schema':'mixed-package-worldwide-allocation/1.0',
            'status':'BOUNDED_CONDITIONAL_OPTIMIZATION_NOT_OBSERVED_LEARNING_OR_GLOBAL_COMPLETION',
            'generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'source_bindings':[identity(p) for p in INPUTS] + [identity('scripts/build_mixed_package_allocation_v1.py')],
            'candidate_rows':rows, 'numeric_rows':750, 'symbolic_rows':25,
            'retained_universe_scope':'Inherited 775 edition profiles. Wider universal register and signed/register/interlanguage options remain eligible but are not all numerical rows in this bounded calculation.',
            'case_study_need_adjustment':0,
            'endpoint': {'id':'EP-FRAC-TRANSFER-6W-V1', 'status':'PROPOSED_COMPARISON_ENDPOINT_NOT_VALIDATED_TEST',
                         'domains':['fraction magnitude and equivalence','fraction arithmetic','novel fraction applications with justified operation'],
                         'score':'Equal planned domain weights; normalized 0-1 assessment score; six weeks after offer.',
                         'comparator':'Same frame and currently usable alternative, horizon and offer conditions.',
                         'not_credited':['whole prealgebra attainment','PISA Level 2 crossing','science reading','research mathematics'],
                         'world_population_replacement':'None. Nine secondary proficiency context counts are not substituted into worldwide audiences.'},
            'objective':'Maximize sum(P_i * relative_offer_level_incremental_score[k]) under budget and one package per profile. Actual gain equals this coefficient times common unknown Gamma > 0 only in this declared additive scenario.',
            'Gamma':'Common endpoint-relevant share times full-book offer-level incremental mean score versus current usable alternatives; voluntary uptake is already inside offer-level effect, not multiplied again.',
            'cost_unit':'Declared standardized fresh-equivalent token-event workload; not GPU time, electricity, money or subscription usage.',
            'cost_equation':'C(i,k)=base100k(i)*(source_tokens(k)/100000 + extra_full_variable_ratio(k)*364270/100000); plus setup_rate*source_tokens(actual module union) once.',
            'shared_preparation_scope':'Additional reusable source preparation. Translation/review source reading is not removed from per-edition costs. No pre-existing local program credit is used.',
            'packages':[{**p, 'extra_ratio':exact(p['extra_ratio'])} for p in plans],
            'module_union_masks':masks, 'module_identities':[modules[m] for m in sorted(sets[2])],
            'scenario_parameters_are_measurements':False,
            'scenario_scope':'Two illustrative yield profiles, two additional-source-preparation rates and three budgets; not a fitted posterior or exhaustive parameter exploration.',
            'overlap_contract':'Additive optimum is not claimed optimal under overlap. For each selected set, largest-single is a conservative bound; common-anchor nested max-yield is calculated by layer cake; disjoint sum is upper bound under compatible nonnegative max-per-person benefits. No geometry is asserted empirical.',
            'unknown_contract':'Each symbolic option is inserted singly and the known portfolio is reoptimized with forced source setup. Equality ties; strictly greater contribution improves. Concurrent symbolic entries need joint optimization.',
            'scenarios':scenarios, 'solver_calls':model.calls,
            'solver_certificate_scope':'HiGHS numerical optimal status/gap plus exact rational recomputation of selected costs/objectives. Not a formal exact global-optimality proof.'}
    out = 'structured/MIXED_PACKAGE_ALLOCATION_v1.json'
    save(out, data)
    lines = ['# Choosing focused resources and complete books within the same budget', '',
             'This calculation chooses both the language edition and the size of its educational package. It retains the same worldwide audience basis for every profile. Its new result is a set of mixed-package allocations, not a claim that a fraction of the world has been educated.', '',
             '## What is compared', '',
             'All options target the same six-week fraction-understanding outcome. Full prealgebra has other valuable outcomes, but these are not silently counted against a fractions-only package. The wider paper retains other subjects, stages, research mathematics, registers and accessibility routes.', '',
             '| Package | Source modules | Content tokens | Extra edition work as share of full variable work |',
             '|---|---:|---:|---:|']
    for k,p in enumerate(plans):
        lines.append(f"| {LABELS[k]} | {len(p['modules'])} | {p['tokens']:,} | {float(EXTRA[k]):.0%} |")
    lines += ['', 'The source is OpenStax Prealgebra 2e at commit 38cae454e644abf9f0a623e876994553881597c9. Source-length counts are reproduced from its pinned CNXML. The support package follows eight direct outside links, not a claim of complete prerequisite closure. Six chapters and supported fractions are not nested: their union is 40 modules and 198,477 tokens. Common preparation is charged for that union once, not once per edition.', '',
              'The extra-work rates, budgets, source-preparation rates and learning ratios below are declared scenarios, not measurements. In the lower-focused-yield scenario, supported fractions and six chapters retain 35% and 70% of the full book\'s incremental offer-level benefit on the same outcome. In the higher-focused-yield scenario they retain 65% and 90%. Full-book benefit is positive but unmeasured; the common multiplier is not assigned a fabricated empirical value.', '',
              '## Budget results', '',
              'The score column is the audience-weighted relative-benefit coefficient, expressed in millions for legibility. It is not unique people, learners reached or observed score gains. A common unknown relevant-audience and offer-level-benefit factor converts it to a conditional gain. Shared preparation rates are additional workload units per distinct source-content token.', '',
              '| Focused benefit scenario | Setup rate | Budget millions | Fractions / six / full editions | Work used millions | Relative opportunity score millions | Improvement over best one-package-size policy |',
              '|---|---:|---:|---|---:|---:|---:|']
    for s in scenarios:
        sol = s['solution']
        counts = [sum(r['package']==p for r in sol['selected']) for p in NAMES]
        lines.append(f"| {'Lower' if s['yield_profile'].startswith('lower') else 'Higher'} | {s['shared_setup_rate_per_union_token']} | {s['budget']/1e6:.0f} | {' / '.join(map(str,counts))} | {sol['total_workload']['decimal']/1e6:.3f} | {sol['known_additive_coefficient']['decimal']/1e6:,.1f} | {s['gain_over_best_uniform_percent']:.2f}% |")
    lines += ['', 'A single package-size policy means every selected language receives the same size, with its own optimal language selection. The mixed policy may give different sizes to different languages; every language had the same three choices and yield assumptions. The result does not impose country-specific learning assumptions or deduct local translations from need.', '',
              '## Exact portfolio selections', '']
    for s in scenarios:
        lines += [f"### {s['scenario_id']}", '']
        for name,label in zip(NAMES,LABELS):
            found = [r['edition'] for r in s['solution']['selected'] if r['package']==name]
            if found:
                lines.append(f"- {label}: " + '; '.join(found) + '.')
        lines.append('')
    lines += ['## Unknown audiences and overlap', '',
              'All 25 unknown-audience profiles remain named with null audiences. For each of their three packages, every budget scenario reoptimizes the known portfolio with that option forced into the source union. The saved threshold states the contribution needed to improve the allocation, not a zero-need assignment. One-at-a-time thresholds do not solve combinations of multiple unknowns.', '',
              'The solver maximizes additive edition opportunities. The same person may benefit from more than one edition, so the sum is not unique people. The output additionally evaluates each selected set with nested audiences and maximum available package benefit per person. With unequal package benefits, nested audiences do not reduce to the largest single audience-weighted score. None of these geometries is assumed to describe real multilingual populations.', '',
              '## Scope and reproducibility', '',
              'The 750 numeric profiles and 25 symbolic alternatives come unchanged from the worldwide baseline. The much larger inclusion register remains in the paper; this bounded solve does not claim to estimate every language, signed language or register. Nine PISA-related need-context counts remain separate and are not substituted for the corresponding worldwide language audiences.', '',
              'The JSON records all profile identities, all selected options, exact rational selected costs and coefficients, actual source unions, all single-size comparators and symbolic insertion portfolios. Every finite solve has a 20-second cap and one worker. Successful numerical solver bounds are not formal mathematical certificates. Empty choices are allowed; no community is presumed to have negative benefit because evidence is missing.', '']
    report = 'MIXED_PACKAGE_ALLOCATION_v1.md'
    (ROOT/report).write_text('\n'.join(lines), encoding='utf-8')
    checks = {'all_original_ids_unchanged':rows==old['candidate_rows'], 'twelve_scenarios':len(scenarios)==12,
              'all_numerical_calls_optimal_or_infeasible':all(c['status'] in (0,2) for c in model.calls),
              'all_25_unknowns_visible_each_scenario':all(len(s['symbolic_rows'])==25 for s in scenarios),
              'non_nested_source_union_correct':masks[3]['source_tokens']==198477,
              'no_observed_people_fabricated':all(s['observed_people_helped'] is None for s in scenarios),
              'no_case_study_discount':data['case_study_need_adjustment']==0}
    save('qa/MIXED_PACKAGE_ALLOCATION_QA_v1.json', {'status':'PASS' if all(checks.values()) else 'FAIL',
                                                  'checks':checks, 'solver_calls':len(model.calls),
                                                  'outputs':[identity(out),identity(report)]})
    save('qa/MIXED_PACKAGE_PROGRESS_v1.json', {'status':'COMPLETED', 'completed_scenarios':12, 'solver_calls':len(model.calls)})
    assert all(checks.values())


if __name__ == '__main__':
    main()
