#!/usr/bin/env python3
"""Independent readback review for Q_CATCHUP_TARGET_BINDINGS_v1."""

from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any


BASE = Path(__file__).resolve().parents[1]
STRUCTURED = BASE / "structured"
FRONTIER = STRUCTURED / "TARGET_SPECIFIC_ALLOCATION_FRONTIER_v1.csv"
BINDINGS_CSV = STRUCTURED / "Q_CATCHUP_TARGET_BINDINGS_v1.csv"
BINDINGS_JSON = STRUCTURED / "Q_CATCHUP_TARGET_BINDINGS_v1.json"
REPORT = BASE / "Q_CATCHUP_TARGET_BINDINGS_v1.md"
OUT = BASE / "qa" / "Q_CATCHUP_TARGET_BINDINGS_INDEPENDENT_REVIEW_v1.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def row_hash(row: dict[str, Any]) -> str:
    payload = {key: value for key, value in row.items() if key != "row_sha256"}
    raw = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest().upper()


def main() -> None:
    frontier = {
        row["route_id"]: row
        for row in read_csv(FRONTIER)
        if row["package_id"] == "Q-CATCHUP"
    }
    rows = read_csv(BINDINGS_CSV)
    payload = json.loads(BINDINGS_JSON.read_text(encoding="utf-8"))
    package_sensitivity = payload["controlled_package_size_sensitivity"]
    by_id = {row["route_id"]: row for row in rows}
    tier_a_expected = {"ID-S", "PTBR-S", "FIL-S"}
    tier_a_actual = {
        row["route_id"]
        for row in rows
        if row["decision_discriminating_measurement_tier"].startswith("A_")
    }
    tier_formula_ok = True
    for row in rows:
        ratio = Decimal(row["q_ratio_required_to_beat_equal_q_leader_base"])
        expected = (
            "A_ORDER_SENSITIVE_THRESHOLD_AT_MOST_3"
            if row["route_id"] == "ID-S" or ratio <= Decimal(3)
            else "B_ORDER_REVERSAL_REQUIRES_LARGE_RELATIVE_Q"
            if ratio <= Decimal(15)
            else "C_ORDER_REVERSAL_REQUIRES_VERY_LARGE_RELATIVE_Q"
        )
        if row["decision_discriminating_measurement_tier"] != expected:
            tier_formula_ok = False

    source_hash_ok = True
    for row in rows:
        path = BASE / Path(row["supply_source_path"])
        if not path.is_file() or sha(path) != row["supply_source_sha256"]:
            source_hash_ok = False

    report = REPORT.read_text(encoding="utf-8")
    checks = {
        "exactly_nine_unique_routes": len(rows) == len(by_id) == 9,
        "same_routes_as_frontier": set(by_id) == set(frontier),
        "frontier_positions_and_thresholds_preserved": all(
            row["conditional_equal_q_position"]
            == frontier[row["route_id"]]["conditional_rank_within_comparable_set"]
            and row["q_ratio_required_to_beat_equal_q_leader_base"]
            == frontier[row["route_id"]]["q_ratio_required_to_beat_equal_q_leader_base"]
            for row in rows
        ),
        "measurement_tier_formula_recomputed": tier_formula_ok,
        "tier_a_exactly_anchor_brazil_philippines": tier_a_actual == tier_a_expected,
        "all_bound_source_bytes_verify": source_hash_ok,
        "csv_json_row_counts_match": len(rows) == payload["row_count"] == len(payload["rows"]),
        "package_token_counts_exact": {
            plan_id: plan["content_text_tokens_cl100k"]
            for plan_id, plan in package_sensitivity["content_plans"].items()
        }
        == {
            "complete_source_collection": 364270,
            "selected_quantitative_units_scenario": 173958,
            "fractions_chapter_only": 41336,
        },
        "package_break_even_has_six_content_text_scenarios": len(
            package_sensitivity["same_endpoint_content_text_break_even"]
        )
        == 6,
        "package_break_even_never_claims_empirical_effect": all(
            item["empirical_effect_claim"] is False
            for item in package_sensitivity["same_endpoint_content_text_break_even"]
        ),
        "row_hashes_verify": all(row["row_sha256"] == row_hash(row) for row in rows),
        "q_is_never_numeric_or_zero": all(row["q_status"] == "UNMEASURED_NOT_ZERO" for row in rows),
        "all_component_statuses_are_explicit": all(
            row[field]
            for row in rows
            for field in [
                "p_exact_audience_status",
                "p_reached_status",
                "p_acquired_status",
                "p_usable_status",
                "p_active_use_status",
                "p_endpoint_gain_status",
                "p_endpoint_loss_status",
            ]
        ),
        "unaligned_routes_remain_visible": {
            row["route_id"]
            for row in rows
            if row["package_alignment_status"]
            in {
                "NO_STAGE_ENDPOINT_ALIGNED_Q_CATCHUP_PACKAGE_IN_SELECTED_SOURCE",
                "NO_TARGET_SPECIFIC_Q_CATCHUP_SUPPLY_CARD_BOUND",
            }
        }
        == {"TH-S", "KM-S", "MS-S"},
        "no_funding_rank_or_exclusion": all(
            row["funding_rank"] == ""
            and row["possible_outranker"] == "True"
            and row["exclusion_allowed"] == "False"
            and row["measurement_tier_is_funding_priority"] == "False"
            for row in rows
        ),
        "report_states_value_of_information_boundary": "value-of-information" in report,
        "report_preserves_unaligned_routes_as_research_gaps": (
            "research gap, not zero need" in report
        ),
        "report_does_not_claim_physical_compute": "full reference production work" in report,
        "report_rejects_fractions_as_complete_endpoint": (
            "cannot be credited with the complete catch-up endpoint" in report
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    result = "PASS" if not failed else "FAIL"
    review = {
        "schema": "interlanguage/q-catchup-target-bindings-independent-review/1.0.0",
        "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
        "result": result,
        "checks": checks,
        "failed_checks": failed,
        "reviewed_artifact_sha256": {
            str(path.relative_to(BASE)).replace("\\", "/"): sha(path)
            for path in [BINDINGS_CSV, BINDINGS_JSON, REPORT]
        },
        "interpretation": (
            "The review verifies source-byte bindings, frontier inheritance, tier arithmetic and preservation of "
            "unknowns. It does not estimate q, educational effect or physical compute."
        ),
    }
    OUT.write_text(json.dumps(review, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": result, "failed": failed, "receipt": str(OUT)}, indent=2))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
