"""Bounded primary-evidence arithmetic; no network, publication or ranking edits."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def identity(rel):
    path = ROOT / rel
    return {"path": rel, "bytes": path.stat().st_size, "sha256": digest(path)}

def main():
    mobile_path = "structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json"
    course_path = "structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json"
    mobile = json.loads((ROOT/mobile_path).read_text(encoding="utf-8"))
    course = json.loads((ROOT/course_path).read_text(encoding="utf-8"))
    tests = []
    def check(name, condition):
        tests.append({"check": name, "pass": bool(condition)})
        if not condition:
            raise AssertionError(name)
    sources = [mobile["study"]] + course["sources"]
    for source in sources:
        rel = source.get("local_pdf", source.get("relative_file"))
        expected = source.get("pdf_sha256", source.get("sha256"))
        check("primary bytes " + rel, digest(ROOT/rel) == expected.upper())
    for site in mobile["sites"]:
        check("attrition arithmetic " + site["site_id"], site["recruited"] - site["endline"] == site["attrited_treatment"] + site["attrited_control"])
    check("Dominican assignment total", sum(course["design"]["assignment"].values()) == 1193)
    check("Dominican followup total", sum(v for k,v in course["attrition"]["endline_reached"].items() if k != "total") == 1032)
    check("no assumed verified Spanish delivery", course["language"]["delivery_language"] is None)
    audio = []
    for site in mobile["sites"]:
        for recording in site["audio"]:
            minutes = recording["minutes"]
            sizes = {str(k): float(Fraction(minutes*60*k*1000, 8*1000000)) for k in [16,24,32]}
            check("audio sizes monotone " + recording["language"], sizes["16"] < sizes["24"] < sizes["32"])
            audio.append({"site": site["site_id"], "language": recording["language"],
                "minutes": minutes, "historical_complete_listening_airtime_usd": recording["full_listening_airtime_usd"],
                "decimal_MB_by_kbps_scenario": sizes,
                "size_scope": "Constant-bitrate payload only; excludes container headers, artwork, transcripts and other files. No codec quality or intelligibility claim."})
    check("only explicitly costed audio languages", {a["language"] for a in audio} == {"hil","hi","kn"})
    check("Hindi payload size", next(a for a in audio if a["language"]=="hi")["decimal_MB_by_kbps_scenario"]["24"] == 13.14)
    check("Hiligaynon payload size", next(a for a in audio if a["language"]=="hil")["decimal_MB_by_kbps_scenario"]["24"] == 14.58)
    check("Kannada payload size", next(a for a in audio if a["language"]=="kn")["decimal_MB_by_kbps_scenario"]["24"] == 15.30)
    # A common endpoint and an offer-level effect are required. This is a
    # decision boundary, not a transfer of the business-practice trial effect.
    delivery_frontier = []
    for multiplier in [1,2,3,5,10]:
        threshold = Fraction(1,multiplier)
        delivery_frontier.append({"distinct_audience_multiplier": multiplier,
            "minimum_relative_offer_effect_for_equal_total_benefit": float(threshold),
            "exact_fraction": str(threshold), "empirical": False})
        check("delivery benefit boundary " + str(multiplier), threshold*multiplier == 1)
    # For a supported/independent alternative reaching a subset of the same
    # people, the extra value of both is only the supported incremental effect.
    overlap_cases = []
    for supported_share in [Fraction(1,10), Fraction(1,2), Fraction(1,1)]:
        r = Fraction(2,5)  # disclosed scenario, not study estimate
        baseline = r
        extra = supported_share * (1-r)
        combined = baseline + extra
        naive = baseline + supported_share
        check("nested delivery double-count removal " + str(supported_share), naive-combined == supported_share*r)
        overlap_cases.append({"supported_share_of_download_audience": float(supported_share),
            "download_offer_effect_relative_to_supported": float(r),
            "combined_benefit_per_total_audience_unit": float(combined),
            "naive_sum": float(naive), "overcount": float(naive-combined), "empirical": False})
    r = Fraction(2,5)
    other_yield = Fraction(3,4)
    thresholds = []
    # Additional supported delivery to people already served by download
    # versus creating an independent edition for another disjoint audience.
    # n_support*(1-r)/C_support > n_new*other_yield/C_new.
    for cost_ratio in [Fraction(1,2),Fraction(1),Fraction(2)]:
        threshold = other_yield*cost_ratio/(1-r)
        check("portfolio marginal boundary " + str(cost_ratio), threshold*(1-r)/cost_ratio == other_yield)
        thresholds.append({"comparison_kind": "incremental benefit per production-workload unit, not constrained total-benefit optimum", "additional_support_to_new_edition_workload_ratio": float(cost_ratio),
            "minimum_supported_to_new_distinct_audience_ratio": float(threshold),
            "exact_fraction": str(threshold), "empirical": False})
    # Exhaust all four portfolios in a transparent two-resource example.
    # Incremental benefits are relative to existing hypothetical offers;
    # the support cohort and the new-language cohort are disjoint.
    actions = [
        {"name":"add_support", "work":Fraction(1,2), "delivery":Fraction(1), "benefit":Fraction(9,20)},
        {"name":"new_edition", "work":Fraction(1), "delivery":Fraction(1,4), "benefit":Fraction(3,4)}]
    portfolios=[]
    for work_budget,delivery_budget in [(Fraction(1,2),Fraction(1)),(Fraction(1),Fraction(1)),(Fraction(3,2),Fraction(1)),(Fraction(3,2),Fraction(5,4))]:
        candidates=[]
        for mask in range(4):
            selected=[a for i,a in enumerate(actions) if mask & (1<<i)]
            work=sum((a['work'] for a in selected),Fraction(0))
            delivery=sum((a['delivery'] for a in selected),Fraction(0))
            benefit=sum((a['benefit'] for a in selected),Fraction(0))
            candidates.append({"actions":[a['name'] for a in selected],"work":work,"delivery":delivery,"benefit":benefit,"feasible":work<=work_budget and delivery<=delivery_budget})
        best=max((a for a in candidates if a['feasible']),key=lambda a:a['benefit'])
        check("finite budget optimum "+str(work_budget)+"/"+str(delivery_budget),all(not a['feasible'] or a['benefit']<=best['benefit'] for a in candidates))
        portfolios.append({"work_budget":float(work_budget),"delivery_budget":float(delivery_budget),
            "best_actions":best['actions'],"best_incremental_benefit":float(best['benefit']),
            "all_four_portfolios":[{k:float(v) if isinstance(v,Fraction) else v for k,v in a.items()} for a in candidates],"empirical":False})
    check("efficiency not total optimum",portfolios[1]['best_actions']==['new_edition'])
    check("delivery budget changes portfolio",portfolios[2]['best_actions']==['new_edition'] and portfolios[3]['best_actions']==['add_support','new_edition'])
    derived_hours = course["design"]["derived_scheduled_hours"]
    check("teaching duration", derived_hours == {"standard_accounting":18,"rules_of_thumb":15})
    check("scheduled duration saving", Fraction(18-15,18)==Fraction(1,6))
    immutable = [identity(p) for p in [
        "structured/GLOBAL_EDITION_REACH_BASELINE_v3.csv",
        "structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv",
        "publication/living_notebook_v0_9/00_START_HERE__Current_Working_Paper_v0.9.pdf"]]
    result = {"schema":"educational-access/vocational-package-allocation/1.0",
        "status":"PRIMARY_FACTS_AND_EXACT_CONDITIONAL_ARITHMETIC",
        "date":"2026-09-08", "input_evidence":[identity(mobile_path),identity(course_path)],
        "audio_delivery":audio,
        "course_hours":{"standard_accounting":18,"practical_rules":15,"proportional_saving":float(Fraction(1,6)),"interpretation":"Scheduled learner contact time, not AI workload or isolated duration effect."},
        "delivery_frontier":delivery_frontier,"nested_audience_cases":overlap_cases,
        "support_vs_new_edition_thresholds":thresholds,
        "finite_two_resource_example":{"normalized_units_not_money_or_measured_compute":True,
            "actions":[{k:float(v) if isinstance(v,Fraction) else v for k,v in a.items()} for a in actions],"scenarios":portfolios,
            "interpretation":"Anonymous illustrative cohorts; not a recommended allocation for a named country/language. Enumerated all four subsets under both constraints; no scalar efficiency ranking substituted for feasible total-benefit maximization."},
        "decision_model":{
            "objective":"Sum over distinct learner groups of audience times additional offer-level benefit on one specified educational endpoint.",
            "baseline":"The best currently usable learning option for that same population and endpoint, not a local project inventory.",
            "production_constraint":"Shared source preparation once plus edition/format construction and auditing within an AI workload budget.",
            "delivery_constraint":"Separate per-recipient dissemination/support expenditure within a delivery budget; never convert study-era airtime dollars directly to AI tokens.",
            "overlap":"For alternative editions of the same content, use highest accessible benefit within an atomic audience, not a sum over duplicate readers. Complementary learning outcomes require a separate model.",
            "unknowns":"Eligible occupational audiences, direct comprehension effects, independent-download effect and physical-compute costs are explicit parameters. They neither delete an edition nor reduce the worldwide language baseline.",
            "effect_transport":"Trial practice outcomes guide content and provisional design; their point estimates are not assigned to another population or converted into unique people understanding."},
        "public_source_policy":"Cite primary articles; do not redistribute article PDFs, rendered pages or scripts in this original analysis package.",
        "unchanged_global_artifacts":immutable,"checks":tests,"full_goal_complete":False}
    out=ROOT/'structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json'
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for row in immutable:
        check("global artifact unchanged "+row['path'], digest(ROOT/row['path'])==row['sha256'])
    qa={"schema":"educational-access/vocational-package-qa/1.0","status":"PASS_EXACT_CALCULATIONS_NOT_EMPIRICAL_GLOBAL_COMPLETENESS",
        "output":identity('structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json'),"checks":tests,
        "failed":sum(not x['pass'] for x in tests),"independent_review_pending":True,"full_goal_complete":False}
    (ROOT/'qa/VOCATIONAL_PACKAGE_ALLOCATION_QA_v1.json').write_text(json.dumps(qa,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({"checks":len(tests),"failures":qa['failed'],"output":qa['output']}))

if __name__=='__main__':
    main()
