"""Prepare/build the consolidated v0.9 paper; importing this module is read-only.

The v0.5 visual template and v0.8 source list are read as data, never imported.
Use --check-inputs for a standard-library-only, non-writing readiness check.
The parent task fills the two MIXED_* tuples after its calculation/audit finish.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "publication/living_notebook_v0_9"
SECTION = "MIXED_PACKAGE_ALLOCATION_SECTION_v1.md"

# Exact final calculation/report/builder filenames are supplied by the parent.
# These must be substantive result inputs, not task state or publication receipts.
MIXED_RESULT_SOURCES: tuple[str, ...] = (
    'structured/MIXED_PACKAGE_ALLOCATION_v1.json', 'MIXED_PACKAGE_ALLOCATION_v1.md',
    'scripts/build_mixed_package_allocation_v1.py', 'scripts/build_mixed_package_manuscript_section_v1.py',
    'qa/MIXED_PACKAGE_SOLVE_CACHE_v1.json', 'scripts/audit_mixed_package_allocation_v1.py',
)
MIXED_AUDIT_SOURCES: tuple[str, ...] = (
    'qa/MIXED_PACKAGE_ALLOCATION_QA_v1.json',
    'qa/MIXED_PACKAGE_ALLOCATION_INDEPENDENT_AUDIT_v1.md',
    'qa/MIXED_PACKAGE_ALLOCATION_INDEPENDENT_AUDIT_v1.json',
)

NEW_SOURCES = (
    SECTION,
    'PUBLIC_SOURCE_LICENSES_v0_9.md',
    "FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.md",
    "FOCUSED_PACKAGE_ALLOWANCE_TABLE_v1.md",
    "structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json",
    "structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json",
    "sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip",
    "qa/FOCUSED_PACKAGE_WORK_ALLOWANCE_QA_v1.json",
    "qa/FOCUSED_PACKAGE_ALLOWANCE_INDEPENDENT_AUDIT_20260908.md",
    "scripts/build_focused_package_allowance_v1.py",
    "HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.md",
    "structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json",
    "structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json",
    "scripts/build_hindi_urdu_budget_entry_frontier_v1.py",
    "qa/HINDI_URDU_BUDGET_ENTRY_FRONTIER_QA_v1.json",
    "qa/HINDI_URDU_FORMULA_INDEPENDENT_AUDIT_20260908.md",
    "qa/HINDI_URDU_FRONTIER_RESULT_INDEPENDENT_AUDIT_20260908.md",
    "Q_CATCHUP_TARGET_BINDINGS_v1.md",
    "structured/Q_CATCHUP_TARGET_BINDINGS_v1.json",
    "structured/Q_CATCHUP_TARGET_BINDINGS_v1.csv",
    "scripts/build_q_catchup_target_bindings_v1.py",
    "scripts/review_q_catchup_target_bindings_v1.py",
    "qa/Q_CATCHUP_TARGET_BINDINGS_QA_v1.json",
    "qa/Q_CATCHUP_TARGET_BINDINGS_INDEPENDENT_REVIEW_v1.json",
    "agent_reports/SELF_STUDY_MATH_PACKAGE_EVIDENCE_20260908.md",
    "agent_reports/MIXED_PACKAGE_FRAME_AND_SUPPLY_CROSSWALK_20260908.md",
    "scripts/build_living_notebook_v0_3.py",
    "scripts/build_living_notebook_v0_5.py",
    "scripts/build_living_notebook_v0_8.py",
    "scripts/build_living_notebook_v0_9.py",
    "scripts/build_html_v1.py",
    "scripts/build_research_artifacts_v1.py",
)

# Archive these reports' substantive evidence only, without changing originals.
PUBLIC_EXCERPTS = {
    "agent_reports/SELF_STUDY_MATH_PACKAGE_EVIDENCE_20260908.md":
        "## Delegated instruction record",
    "agent_reports/MIXED_PACKAGE_FRAME_AND_SUPPLY_CROSSWALK_20260908.md":
        "### Operative delegated input (verbatim)",
}
PUBLIC_ROOT_NORMALIZATION = "agent_reports/GLOBAL_NEED_CONTENT_AUDIT_20260901.md"
BOUND_CALCULATIONS = (
    "structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json",
    "structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json",
    "structured/Q_CATCHUP_TARGET_BINDINGS_v1.json",
)
TEXT_SUFFIXES = {".py", ".md", ".json", ".csv", ".txt", ".html"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def source_path(rel: str) -> Path:
    path = (ROOT / rel).resolve()
    if not path.is_relative_to(ROOT.resolve()) or Path(rel).is_absolute():
        raise AssertionError("Source path must remain relative to the task: " + rel)
    # No wildcard recursion, private coordination, publication workers or receipts.
    name = Path(rel).name.upper()
    forbidden = ("RAW_USER", "USER_INPUT", "TRANSCRIPT", "LOGBOOK", "CURSOR",
                 "COMPACTION", "HANDOFF", "TASK_STATE", "ZENODO_DRAFT")
    if any(token in name for token in forbidden) or name.startswith("PUBLISH_"):
        raise AssertionError("Internal/workflow artifact is not a public source: " + rel)
    return path


def source_payload(rel: str) -> bytes:
    data = source_path(rel).read_bytes()
    if rel in PUBLIC_EXCERPTS:
        text = data.decode("utf-8-sig")
        marker = PUBLIC_EXCERPTS[rel]
        if text.count(marker) != 1:
            raise AssertionError("Expected one instruction appendix in " + rel)
        data = (text.split(marker, 1)[0].rstrip() + "\n").encode("utf-8")
    if rel == PUBLIC_ROOT_NORMALIZATION:
        text = data.decode("utf-8-sig")
        text, count = re.subn(
            r"^All paths below are under `[A-Z]:[\\/][^`\r\n]+`\.[ \t]*$",
            "All paths below are relative to the source archive root.", text,
            flags=re.M,
        )
        if count != 1:
            raise AssertionError("Expected one private workspace-root declaration in " + rel)
        data = text.encode("utf-8")
    return data


def validate_source_payload(rel: str, data: bytes) -> None:
    if Path(rel).suffix.lower() not in TEXT_SUFFIXES:
        return
    text = data.decode("utf-8-sig")
    # This historical helper has one standard system-font fallback, not a
    # workspace/user path. Preserve its exact bytes and allow only that literal.
    path_check = text
    if rel == "scripts/build_living_notebook_v0_3.py":
        path_check = path_check.replace("\\".join(("C:", "Windows", "Fonts")), "SYSTEM_FONTS")
    if Path.home().name in text or re.search(r"[A-Z]:[\\/]", path_check):
        raise AssertionError("Private name or absolute Windows path in " + rel)
    if Path(rel).suffix.lower() != ".py" and any(
        marker in text for marker in PUBLIC_EXCERPTS.values()
    ):
        raise AssertionError("Instruction appendix survived archive filtering: " + rel)


def source_binding(rel: str, data: bytes) -> dict:
    item = {"path": rel, "bytes": len(data), "sha256": sha(data)}
    if rel in PUBLIC_EXCERPTS or rel == PUBLIC_ROOT_NORMALIZATION:
        transformation = (
            "Substantive report before instruction appendix; original unchanged."
            if rel in PUBLIC_EXCERPTS else
            "Private workspace-root declaration replaced by archive-relative wording; original unchanged."
        )
        item.update({
            "origin_sha256": sha(source_path(rel).read_bytes()),
            "transformation": transformation,
            "archive_contains_verbatim_original": False,
        })
    return item


def inherited_sources() -> list[str]:
    """Extract literal lists without executing either historical builder."""
    result: list[str] = []
    for filename, attribute in (("build_living_notebook_v0_5.py", False),
                                ("build_living_notebook_v0_8.py", True)):
        tree = ast.parse((ROOT / "scripts" / filename).read_text(encoding="utf-8"))
        matches = []
        for node in tree.body:
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if not attribute and isinstance(target, ast.Name) and target.id == "SOURCES":
                matches.append(ast.literal_eval(node.value))
            elif attribute and isinstance(target, ast.Attribute) and target.attr == "SOURCES":
                if not isinstance(node.value, ast.BinOp) or not isinstance(node.value.op, ast.Add):
                    raise AssertionError("Unexpected v0.8 source-list expression")
                matches.append(ast.literal_eval(node.value.right))
        if len(matches) != 1 or not all(isinstance(x, str) for x in matches[0]):
            raise AssertionError("Could not identify one literal source list in " + filename)
        result.extend(matches[0])
    return result


def collect_sources() -> list[str]:
    sources = inherited_sources() + list(NEW_SOURCES)
    sources += list(MIXED_RESULT_SOURCES) + list(MIXED_AUDIT_SOURCES)
    # Only direct, explicit bindings from named calculation files are followed.
    for rel in (*BOUND_CALCULATIONS, *MIXED_RESULT_SOURCES):
        if Path(rel).suffix.lower() != ".json" or not source_path(rel).is_file():
            continue
        data = json.loads(source_path(rel).read_text(encoding="utf-8-sig"))
        if not isinstance(data, dict):
            continue
        for entry in data.get("source_bindings", []):
            if isinstance(entry, dict) and isinstance(entry.get("path"), str):
                sources.append(entry["path"])
        sources.extend(data.get("source_sha256", {}).keys())
    result = list(dict.fromkeys(sources))
    for rel in result:
        source_path(rel)
    return result


def compose_paper() -> str:
    """Keep the complete draft; insert literal 7.13 only if not already included."""
    paper = (ROOT / "PAPER_CURRENT_DRAFT.md").read_text(encoding="utf-8")
    for number in ("7.11", "7.12"):
        if len(re.findall(r"^### " + re.escape(number) + r"\s", paper, re.M)) != 1:
            raise AssertionError("Expected one complete draft section " + number)
    for rel in ("GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md", "DIRECT_TRANSLATION_EFFECT_SECTION_v1.md"):
        if paper.count((ROOT / rel).read_text(encoding="utf-8").strip()) != 1:
            raise AssertionError("Draft differs from the generated section: " + rel)
    section = (ROOT / SECTION).read_text(encoding="utf-8").strip()
    if not section.startswith("### 7.13 ") or re.search(r"\{\{[^}]+\}\}", section):
        raise AssertionError("Mixed allocation section must be final literal section 7.13")
    if paper.count(section) == 1:
        return paper
    if re.search(r"^### 7\.13\s", paper, re.M):
        raise AssertionError("Existing section 7.13 differs from its literal source")
    reference_heading = "## References used in this draft"
    if paper.count(reference_heading) != 1:
        raise AssertionError("Cannot identify one insertion point before references")
    prefix, suffix = paper.split(reference_heading, 1)
    return prefix.rstrip() + "\n\n" + section + "\n\n" + reference_heading + suffix


def prepared_template() -> str:
    source = (ROOT / "scripts/build_living_notebook_v0_5.py").read_text(encoding="utf-8")
    source = source.replace("v0_5", "v0_9").replace("v0.5", "v0.9").replace("0.5.0", "0.9.0")
    source = source.replace("2026-09-06", "2026-09-08").replace("6 September 2026", "8 September 2026")
    source = source.replace('PUBLICATION_STATUS = "PUBLICATION_STATUS.md"', 'PUBLICATION_STATUS = "PUBLICATION_STATUS_v0.9.md"')

    def replace_one(old: str, new: str) -> None:
        nonlocal source
        if source.count(old) != 1:
            raise AssertionError("Unexpected template occurrence count: " + old[:90])
        source = source.replace(old, new, 1)

    # Retain v0.8 format policy: DOCX is built locally, not publicly distributed
    # until it has its own successful visual rendering/QA.
    replace_one("public_names = [PDF, HTML, DOCX, MARKDOWN,", "public_names = [PDF, HTML, MARKDOWN,")
    replace_one("required = [PDF, DOCX, MARKDOWN,", "required = [PDF, MARKDOWN,")
    replace_one('<a href="{DOCX}">Download the editable Word document</a>', "")
    replace_one("The HTML contains the full paper, the DOCX is editable, and the source archive preserves the evidence and deterministic receipts.",
                "The HTML contains the full paper, the Markdown source is editable, and the source archive preserves the evidence and deterministic receipts.")
    replace_one('"editable_document": {"name": DOCX, "bytes": (OUT / DOCX).stat().st_size, "sha256": digest((OUT / DOCX).read_bytes()), "source": MARKDOWN},',
                '"editable_document": {"name": MARKDOWN, "format": "Markdown", "bytes": (OUT / MARKDOWN).stat().st_size, "sha256": digest((OUT / MARKDOWN).read_bytes())},\n        "additional_format_status": {"DOCX": "Local only; independent visual rendering/QA not asserted by this builder."},')
    replace_one('paper_base = (ROOT / "PAPER_CURRENT_DRAFT.md").read_text(encoding="utf-8")',
                "paper_base = compose_paper()")
    replace_one('        "limits": [',
                '        "license_scope": {"original_analysis": "CC BY 4.0", "OpenStax_source": "CC BY-NC-SA 4.0; original credits retained", "notice": "PUBLIC_SOURCE_LICENSES_v0_9.md"},\n        "limits": [')
    replace_one("fixed_time = (2026, 9, 6, 0, 0, 0)", "fixed_time = (2026, 9, 8, 0, 0, 0)")
    replace_one('        path = ROOT / rel\n        if not path.is_file():\n            raise FileNotFoundError(rel)\n        public_text_check(path)',
                '        validate_source_payload(rel, source_payload(rel))')
    replace_one('archive.writestr(info, (ROOT / rel).read_bytes())', 'archive.writestr(info, source_payload(rel))')
    replace_one('data = (ROOT / rel).read_bytes()', 'data = source_payload(rel)')
    replace_one('source_bindings.append({"path": rel, "bytes": len(data), "sha256": digest(data)})',
                'source_bindings.append(source_binding(rel, data))')
    replace_one("The current results include two Top 100 comparisons and ten fixed-budget translation portfolios. They show how audience size and package length affect allocation under disclosed assumptions. Direct translation research helps distinguish participation from learning.",
                "The current results retain two Top 100 comparisons and fixed-budget translation portfolios, and add shared-edition, focused-package and mixed-package allocation scenarios. Direct translation research distinguishes participation from learning.")
    return source


def check_inputs() -> dict:
    sources = collect_sources()
    missing = [rel for rel in sources if not source_path(rel).is_file()]
    pending = []
    if not MIXED_RESULT_SOURCES:
        pending.append("Fill MIXED_RESULT_SOURCES with final mixed JSON/report/calculation builder paths")
    if not MIXED_AUDIT_SOURCES:
        pending.append("Fill MIXED_AUDIT_SOURCES with final mixed deterministic/independent audit paths")
    errors = []
    for rel in sources:
        if rel not in missing:
            try:
                validate_source_payload(rel, source_payload(rel))
            except (AssertionError, UnicodeError) as exc:
                errors.append(str(exc))
    if SECTION not in missing:
        try:
            compose_paper()
        except (AssertionError, OSError) as exc:
            errors.append(str(exc))
    compile(prepared_template(), "living_v09_template", "exec")
    return {"status": "READY_FOR_BUILD" if not (missing or pending or errors) else "INPUTS_PENDING",
            "source_count": len(sources), "missing": missing, "configuration": pending,
            "errors": errors, "writes_performed": False, "build_launched": False}


def create_builder():
    """Called only after preflight; loading the template cannot invoke main()."""
    spec = importlib.util.spec_from_loader("living_v09_builder", loader=None)
    module = importlib.util.module_from_spec(spec)
    module.__file__ = str(Path(__file__).resolve())
    sys.modules[spec.name] = module
    exec(compile(prepared_template(), module.__file__, "exec"), module.__dict__)
    module.SOURCES = collect_sources()
    for name in ("compose_paper", "source_payload", "source_binding", "validate_source_payload"):
        setattr(module, name, globals()[name])
    if module.OUT.resolve() != OUT.resolve() or module.OUT.name != "living_notebook_v0_9":
        raise AssertionError("Builder output escaped the separate v0.9 directory")
    original_html = module.build_html

    def build_html_with_archive_links(html_builder, paper, pdf_info):
        appendices = [
            ("Appendix A - Full-content academic-register translation", "ACADEMIC_REGISTER_TRANSLATION_RESEARCH_v1.md"),
            ("Appendix B - Anti-hegemony model audit", "HEGEMONY_BIAS_AUDIT_v1.md"),
            ("Appendix C - Intervention-effect evidence", "INTERVENTION_EFFECT_EVIDENCE_v1.md"),
            ("Appendix D - Conditional global portfolios", "CONDITIONAL_GLOBAL_PORTFOLIOS_v1.md"),
            ("Appendix E - Normalized conditional model", "CONDITIONAL_PORTFOLIO_MODEL_v1.md"),
        ]
        full_paper = paper.rstrip()
        for label, rel in appendices:
            lines = []
            fence = None
            for line in source_payload(rel).decode("utf-8-sig").splitlines():
                marker = re.match(r"^\s*(`{3,}|~{3,})", line)
                if marker:
                    token = marker.group(1)[0]
                    fence = None if fence == token else token if fence is None else fence
                if fence is None and not marker:
                    line = re.sub(r"^(#{1,6})[ \t]+", lambda m: '#' * min(6, len(m.group(1)) + 2) + ' ', line)
                lines.append(line)
            full_paper += '\n\n## ' + label + '\n\n' + '\n'.join(lines).strip()
        full_paper += '\n'
        (module.OUT / module.MARKDOWN).write_text(full_paper, encoding="utf-8")
        info = original_html(html_builder, full_paper, pdf_info)
        target = module.OUT / module.HTML
        rendered = target.read_text(encoding="utf-8")
        public = {module.PDF, module.MANIFEST, module.ZIP, module.HTML, module.MARKDOWN,
                  module.REACH_TOP100, module.COMPUTE_TOP100, module.PROFILE_INVENTORY,
                  module.PUBLICATION_STATUS}
        for rel in module.SOURCES:
            if rel not in public:
                rendered = rendered.replace(f'href="{rel}"',
                    f'href="{module.ZIP}" title="Source preserved in archive: {rel}"')
        marker = '<h2 id="abstract">Abstract</h2>'
        notice = ('<aside aria-label="Licensing"><p>Original analysis and presentation: CC BY 4.0. '
                  'Third-party OpenStax source material in the source archive retains CC BY-NC-SA 4.0, '
                  'its original licence and contributor credits. The analysis licence does not relicense '
                  'that material. See PUBLIC_SOURCE_LICENSES_v0_9.md inside the source archive.</p></aside>')
        if rendered.count(marker) != 1:
            raise AssertionError("Expected one abstract heading for the reader licence notice")
        rendered = rendered.replace(marker, notice + '\n' + marker, 1)
        target.write_text(rendered, encoding="utf-8")
        info.update(bytes=target.stat().st_size, sha256=sha(target.read_bytes()))
        return info

    module.build_html = build_html_with_archive_links
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs", action="store_true", help="Read-only; never loads document renderers")
    args = parser.parse_args()
    report = check_inputs()
    if args.check_inputs:
        print(json.dumps(report, indent=2))
        return 0 if report["status"] == "READY_FOR_BUILD" else 1
    if report["status"] != "READY_FOR_BUILD":
        raise RuntimeError(json.dumps(report, indent=2))
    # Published snapshots are immutable. A new v0.9 is isolated from every prior
    # snapshot; deterministic replays should use a separately controlled copy.
    if OUT.exists() and any(OUT.iterdir()):
        raise FileExistsError("v0.9 output is nonempty; do not overwrite an existing snapshot")
    create_builder().main()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
