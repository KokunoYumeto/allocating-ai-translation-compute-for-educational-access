"""Isolated consolidated v0.10 build; prior editions are never written."""
from pathlib import Path
import importlib.util
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

def configure():
    previous = ROOT / 'scripts/build_living_notebook_v0_9.py'
    source = previous.read_text(encoding='utf-8')
    source = source.replace('v0_9', 'v0_10').replace('v0.9', 'v0.10').replace('0.9.0', '0.10.0')
    spec = importlib.util.spec_from_loader('consolidated_v010', loader=None)
    mod = importlib.util.module_from_spec(spec)
    mod.__file__ = str(Path(__file__).resolve())
    sys.modules[spec.name] = mod
    exec(compile(source, mod.__file__, 'exec'), mod.__dict__)
    mod.NEW_SOURCES += (
        'scripts/build_living_notebook_v0_9.py',
        'VOCATIONAL_PACKAGE_ALLOCATION_v1.md',
        'VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.md',
        'OPENSTAX_SUBJECT_SOURCE_SCALE_v1.md',
        'structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json',
        'structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json',
        'structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json',
        'structured/OPENSTAX_SUBJECT_SOURCE_SCALE_v1.json',
        'scripts/build_vocational_package_allocation_v1.py',
        'scripts/build_vocational_package_supplement_v1.py',
        'qa/VOCATIONAL_PACKAGE_ALLOCATION_QA_v1.json',
        'qa/VOCATIONAL_PACKAGE_ALLOCATION_INDEPENDENT_REVIEW_v1.md',
        'qa/VOCATIONAL_PACKAGE_ALLOCATION_REVIEW_CLOSEOUT_v1.md',
        'AUDIENCE_JOINT_ALLOCATION_v1.md',
        'structured/AUDIENCE_JOINT_ALLOCATION_v1.json',
        'scripts/build_audience_joint_allocation_v1.py',
        'qa/AUDIENCE_JOINT_ALLOCATION_QA_v1.json',
        'qa/AUDIENCE_JOINT_ALLOCATION_INDEPENDENT_REVIEW_v1.md',
        'PSA_BUSINESS_JOINT_FIELD_SPEC_v1.md',
        'BUSINESS_AUDIENCE_DENOMINATOR_LEADS_v1.md',
        'qa/CONSOLIDATED_NEW_SECTIONS_INDEPENDENT_CHECK_v0_10.md',
    )
    original_compose = mod.compose_paper
    def compose():
        paper = original_compose()
        for section in ('7.14', '7.15'):
            assert len(re.findall(r'^### ' + re.escape(section) + r'\s', paper, re.M)) == 1
        return paper
    mod.compose_paper = compose
    original_create = mod.create_builder
    def create():
        builder = original_create()
        original_html = builder.build_html
        def html_with_valid_urls(html_builder, paper, pdf_info):
            info = original_html(html_builder, paper, pdf_info)
            target = builder.OUT / builder.HTML
            rendered = target.read_text(encoding='utf-8')
            # Bare-source references sometimes include sentence punctuation.
            # Restrict the transformation to external link destinations only.
            rendered = re.sub(r'href="(https://[^"<>]+)"',
                lambda m: 'href="' + m[1].rstrip('.,;:') + '"', rendered)
            target.write_text(rendered, encoding='utf-8')
            info.update(bytes=target.stat().st_size, sha256=mod.sha(target.read_bytes()))
            return info
        builder.build_html = html_with_valid_urls
        return builder
    mod.create_builder = create
    return mod

if __name__ == '__main__':
    raise SystemExit(configure().main())
