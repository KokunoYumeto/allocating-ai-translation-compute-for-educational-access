"""Independently check budget arithmetic and the generated manuscript section."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import re
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--integrate', action='store_true')
    args = parser.parse_args()
    data_path = ROOT / 'structured/GLOBAL_BUDGET_SCENARIOS_v1.json'
    section_path = ROOT / 'GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md'
    paper_path = ROOT / 'PAPER_CURRENT_DRAFT.md'
    data = json.loads(data_path.read_text(encoding='utf-8'), object_pairs_hook=unique_json)
    with (ROOT / 'structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = {r['row_id']: r for r in csv.DictReader(stream)}
    checks = {}
    checks['all_775_original_ids_retained'] = {r['row_id'] for r in data['candidate_rows']} == set(rows) and len(rows) == 775
    specifications = {
        'common_100k_benchmark': (100000, {5000000, 10000000, 25000000, 50000000}),
        'complete_source_collection': (364270, {5000000, 10000000, 20000000}),
        'selected_quantitative_units_scenario': (173958, {5000000, 10000000, 20000000}),
    }
    for plan, (length, budgets) in specifications.items():
        scenarios = [s for s in data['scenarios'] if s['source_plan'] == plan]
        checks[plan + '_budgets_and_lengths'] = {s['budget_fecu'] for s in scenarios} == budgets and all(s['source_content_tokens'] == length for s in scenarios)
    table_lines = [line for line in section_path.read_text(encoding='utf-8').splitlines() if re.match(r'^\| (100k benchmark|Complete book|Six chapters) \|', line)]
    checks['ten_displayed_scenarios'] = len(table_lines) == len(data['scenarios']) == 10
    for number, (scenario, line) in enumerate(zip(data['scenarios'], table_lines), 1):
        selected = scenario['selected_editions']
        ids = [r['row_id'] for r in selected]
        cost = math.fsum(float(rows[i]['compute_scenario_point']) * scenario['source_content_tokens'] / 100000 for i in ids)
        audience = math.fsum(float(rows[i]['plausibly_helped_point']) for i in ids)
        cells = [c.strip() for c in line.strip('|').split('|')]
        checks[f'scenario_{number}_selected_ids_unique'] = len(set(ids)) == len(ids)
        checks[f'scenario_{number}_source_recomputed_cost'] = math.isclose(cost, scenario['spent_fecu'], abs_tol=1e-6)
        checks[f'scenario_{number}_source_recomputed_audience'] = math.isclose(audience, scenario['additive_opportunity_coefficient'], abs_tol=1e-6)
        checks[f'scenario_{number}_budget_respected'] = cost <= scenario['budget_fecu'] + 1e-6
        checks[f'scenario_{number}_table_exact_format'] = cells[1] == f"{scenario['budget_fecu']/1e6:.0f}" and cells[2] == f"{cost/1e6:.3f}" and cells[4] == f"{audience/1e6:,.1f}"
        checks[f'scenario_{number}_optimum_bound_matches'] = math.isclose(audience, scenario['optimizer_objective_bound'], rel_tol=1e-9, abs_tol=.001)
        checks[f'scenario_{number}_unknowns_not_observed_zero'] = len(scenario['symbolic_audience_challengers']) == 25 and all(r['audience_coefficient'] is None for r in scenario['symbolic_audience_challengers'])
    for comparison in data['complete_versus_selected']:
        budget = comparison['budget_fecu']
        full = next(s for s in data['scenarios'] if s['source_plan'] == 'complete_source_collection' and s['budget_fecu'] == budget)
        small = next(s for s in data['scenarios'] if s['source_plan'] == 'selected_quantitative_units_scenario' and s['budget_fecu'] == budget)
        ratio = full['additive_opportunity_coefficient'] / small['additive_opportunity_coefficient']
        checks[f'break_even_{int(budget)}'] = math.isclose(ratio, comparison['small_over_full_yield_required_under_additive_scenario'], rel_tol=1e-12)
    checks['input_hashes_match'] = all(digest(ROOT / b['path']) == b['sha256'] for b in data['source_bindings'])
    expected = section_path.read_text(encoding='utf-8').strip()
    before = digest(paper_path)
    paper = paper_path.read_text(encoding='utf-8')
    pattern = r'(?ms)^### 7\.9 .*?(?=^### 7\.10 |^## References used in this draft)'
    matches = list(re.finditer(pattern, paper))
    if len(matches) != 1:
        raise ValueError('Expected one bounded manuscript section 7.9')
    if args.integrate:
        if not all(checks.values()):
            raise ValueError('Arithmetic failed; manuscript not changed')
        paper = re.sub(pattern, lambda _: expected + '\n\n', paper, count=1)
        paper_path.write_text(paper, encoding='utf-8')
    actual = re.search(pattern, paper_path.read_text(encoding='utf-8')).group().strip()
    checks['manuscript_exactly_matches_generated_results'] = actual == expected
    receipt = {
        'status': 'PASS' if all(checks.values()) else 'FAIL',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'operation': 'integrate_generated_results_and_audit' if args.integrate else 'read_only_audit',
        'paper_sha256_before': before, 'paper_sha256_after': digest(paper_path),
        'checks': checks, 'check_count': len(checks),
        'failures': [key for key, value in checks.items() if not value],
        'source_bindings': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in (data_path, section_path, paper_path)],
        'scope': 'Arithmetic, source scales, selection identities, solver bounds, missing-audience representation and exact manuscript concordance. No empirical learning-effect or visual certification.',
    }
    output = ROOT / ('qa/BUDGET_MANUSCRIPT_INTEGRATION_v1.json' if args.integrate else 'qa/BUDGET_MANUSCRIPT_CONCORDANCE_v1.json')
    output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': receipt['status'], 'checks': len(checks), 'failures': receipt['failures'], 'receipt': str(output.relative_to(ROOT)), 'paper_sha256': receipt['paper_sha256_after']}))
    if receipt['failures']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
