"""Build the v0.8 working paper with generated allocation and effect results."""
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "scripts/build_living_notebook_v0_5.py").read_text(encoding="utf-8")
source = source.replace("v0_5", "v0_8").replace("v0.5", "v0.8").replace("0.5.0", "0.8.0")
source = source.replace("2026-09-06", "2026-09-07").replace("6 September 2026", "7 September 2026")
def replace_one(old, new):
    global source
    if source.count(old) != 1:
        raise AssertionError('Unexpected template occurrence count: ' + old[:90])
    source = source.replace(old, new, 1)

# The DOCX is still built for the full workflow, but is not distributed before
# its required renderer can run. This does not hold the independently checked
# PDF, HTML, editable Markdown, data and evidence archive.
replace_one('public_names = [PDF, HTML, DOCX, MARKDOWN,',
            'public_names = [PDF, HTML, MARKDOWN,')
replace_one('required = [PDF, DOCX, MARKDOWN,',
            'required = [PDF, MARKDOWN,')
replace_one('<a href="{DOCX}">Download the editable Word document</a>', '')
replace_one('The HTML contains the full paper, the DOCX is editable, and the source archive preserves the evidence and deterministic receipts.',
            'The HTML contains the full paper, the Markdown source is editable, and the source archive preserves the evidence and deterministic receipts.')
replace_one('"editable_document": {"name": DOCX, "bytes": (OUT / DOCX).stat().st_size, "sha256": digest((OUT / DOCX).read_bytes()), "source": MARKDOWN},',
            '"editable_document": {"name": MARKDOWN, "format": "Markdown", "bytes": (OUT / MARKDOWN).stat().st_size, "sha256": digest((OUT / MARKDOWN).read_bytes())},\n        "additional_format_status": {"DOCX": "Not included in this snapshot; separate visual rendering remains unfinished."},')
spec = importlib.util.spec_from_loader("living_v08_builder", loader=None)
module = importlib.util.module_from_spec(spec)
module.__file__ = str(ROOT / "scripts/build_living_notebook_v0_5.py")
exec(compile(source, str(ROOT / "scripts/build_living_notebook_v0_5.py"), "exec"), module.__dict__)
module.SOURCES = list(module.SOURCES) + [
    "GLOBAL_BUDGET_SCENARIOS_v1.md", "structured/GLOBAL_BUDGET_SCENARIOS_v1.json", "qa/GLOBAL_BUDGET_SCENARIOS_QA_v1.json",
    "CHN_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "IND_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md",
    "NGA_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "PAK_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "UKR_RUS_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md",
    "JPN_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "BRA_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "MEX_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md",
    "ETH_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.md", "PHL_SECONDARY_SUPPLY_AND_PACKAGE_v1.md", "CENTRAL_ASIA_PACKAGE_NEEDS_20260904.md",
    "WEST_AFRICA_PACKAGE_NEEDS_20260904.md", "AMERICAS_PACIFIC_PACKAGE_NEEDS_20260904.md", "GLOBAL_COUNTRY_TERRITORY_OMISSION_AUDIT_v1.md",
    "GLOBAL_SIGNED_LANGUAGE_OMISSION_AUDIT_v1.md", "DISPLACEMENT_PACKAGE_NEEDS_20260904.md", "GLOBAL_DISPLACEMENT_OMISSION_AUDIT_v1.md",
    "DISPLACEMENT_CORRIDOR_LANGUAGE_EDUCATION_EVIDENCE_v3.md", "SOM_ETH_FOUNDATIONAL_SECONDARY_SUPPLY_AND_TRAFFIC_v1.md", "DEU_F_S_SUPPLY_AND_TRAFFIC_v1.md",
    "HOU_F_S_SUPPLY_AND_TRAFFIC_v1.md", "OPENSTAX_SUBJECT_SOURCE_SCALE_v1.md", "ACCESSIBILITY_PACKAGE_NEEDS_20260904.md",
    "DISPLACEMENT_CORRIDOR_INTERVENTION_COMPARISONS_v2.md", "sources/language_instruction/WORLD_BANK_LOUD_AND_CLEAR_2021.pdf",
    "sources/language_instruction/WORLD_BANK_LOUD_AND_CLEAR_2021.txt",
    "GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md", "scripts/build_global_budget_scenarios_v1.py", "scripts/audit_budget_manuscript_v1.py",
    "qa/BUDGET_MANUSCRIPT_CONCORDANCE_v1.json", "DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.md", "DIRECT_TRANSLATION_EFFECT_SECTION_v1.md",
    "structured/DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.json", "scripts/build_direct_translation_effect_allocation_v1.py",
    "qa/DIRECT_TRANSLATION_EFFECT_ALLOCATION_QA_v1.json", "sources/language_instruction/BALTER_EMI_2024.pdf",
    "assets/fonts/NotoSans-Regular.ttf", "assets/fonts/NotoSans-Bold.ttf", "assets/fonts/NotoSans-Italic.ttf", "assets/fonts/NotoSans-BoldItalic.ttf",
    "assets/fonts/NotoSerif-Regular.ttf", "assets/fonts/NotoSerif-Bold.ttf", "assets/fonts/NotoSansMono-Regular.ttf", "assets/fonts/LICENSE_NOTO.txt"
]
_paper = (ROOT / 'PAPER_CURRENT_DRAFT.md').read_text(encoding='utf-8')
for _section_name in ('GLOBAL_ALLOCATION_RESULTS_SECTION_v1.md', 'DIRECT_TRANSLATION_EFFECT_SECTION_v1.md'):
    if (ROOT / _section_name).read_text(encoding='utf-8').strip() not in _paper:
        raise AssertionError('Manuscript differs from generated result section: ' + _section_name)
_original_build_html = module.build_html
def _build_html_with_archive_links(html_builder, paper, pdf_info):
    info = _original_build_html(html_builder, paper, pdf_info)
    target = module.OUT / module.HTML
    rendered = target.read_text(encoding="utf-8")
    public_names = {module.PDF, module.MANIFEST, module.ZIP, module.HTML, module.DOCX, module.MARKDOWN,
                    module.REACH_TOP100, module.COMPUTE_TOP100, module.PROFILE_INVENTORY, module.PUBLICATION_STATUS}
    for rel in module.SOURCES:
        if rel not in public_names:
            rendered = rendered.replace(f'href="{rel}"', f'href="{module.ZIP}" title="Source preserved in archive: {rel}"')
    target.write_text(rendered, encoding="utf-8")
    info["bytes"] = target.stat().st_size
    info["sha256"] = module.digest(target.read_bytes())
    return info
module.build_html = _build_html_with_archive_links
module.main()
