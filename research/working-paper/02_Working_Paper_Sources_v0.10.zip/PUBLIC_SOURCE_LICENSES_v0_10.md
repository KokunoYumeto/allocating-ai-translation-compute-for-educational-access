# Source licenses and reproduction

Original research analysis is available under CC BY 4.0. This does not relicense third-party source material.

The pinned OpenStax Prealgebra 2e CNXML source archive retains CC BY-NC-SA 4.0 and its original author and publisher credits. Its source identity is commit 38cae454e644abf9f0a623e876994553881597c9 of https://github.com/openstax/osbooks-prealgebra-bundle. The archive contains its source license and credits. Users reusing that source must follow its own terms, including the noncommercial and share-alike requirements.

Other cited or preserved documents and fonts retain their original licenses and credits. A citation or source hash does not transfer ownership or change a license. Internal instruction appendices are not public research payloads; excerpt transformations are identified in the snapshot manifest.

The practical-business and joint-audience extensions include original analysis, calculation code, evidence records and review records. Their cited articles, survey questionnaires and microdata are not redistributed here. For source-hash replay, download the exact publicly available PDF witnesses from the URLs named in the evidence records into the indicated relative paths and verify their listed hashes. The audience calculations are explicitly synthetic examples, not extracted survey estimates; they require no survey microdata. Reproduction of the audience and vocational calculation scripts is separate from reproducing the earlier source reading and independent reviews. The frozen v0.9 PDF remains publicly available as a predecessor artifact; it is not duplicated inside this new source archive.
