# Intervention-effect evidence for educational-access compute

**Working evidence register—not a universal multiplier or an eligibility test.**

## Governing thesis

Academic-register familiarity is an institutionally distributed access advantage. Source-faithful language and adult-register editions with any credible nonzero educational benefit remain eligible. Evidence estimates effects and improves audience, package, format, sequence, fidelity and scale; it never functions as a permission test, innate-capacity screen or language-level withholding rule.

A null or adverse result for one document, audience or delivery design redirects the intervention. It does not establish low reader capacity and does not remove a language, register or community from eligibility.

## What the evidence currently says

The closest same-content translation evidence is an eight-module Swedish/English programming-course RCT and a short professional-reading RCT among Scandinavian physicians. Adult register-translation experiments in health, legal and scientific material often improve immediate comprehension, but the size varies sharply by source and null or adverse controls exist. Large foundational effects mostly belong to language-of-instruction or structured-pedagogy bundles. Free/open access chiefly changes acquisition; offline delivery changes practical access; worked examples, retrieval practice, explanatory feedback and self-regulation change learning conditional on use.

No located controlled study measures a complete proposition-preserving mathematics curriculum translated into another language or adult register. The scenarios below are therefore disclosed planning intervals, not a new meta-analysis.

## Closest direct and short-text anchors

| ID | Study | Stages | Comparison | Exact result | Transfer boundary |
|---|---|---|---|---|---|
| `EFF-001` | [Leroy et al.](https://doi.org/10.2196/jmir.2569) | `A|U|R` | Translated general-register passages versus originals. | Correct comprehension 63% versus 52% (+11 percentage points, p<.001); learning gain +18% versus +9% (p=.003); free recall unchanged; perceived difficulty 2.3 versus 3.2/5. | Not a full-course, mathematics, long-run attainment or universal register effect. |
| `EFF-002` | [Martínez, Mollica, and Gibson](https://doi.org/10.1016/j.cognition.2022.105070) | `A|V|U` | Equivalent-meaning ordinary English versus legalese. | Comprehension 73.5% versus 67.7% (+5.8 percentage points); register coefficient remained significant after below-chance items were excluded. | Not a complete-statute, complete-contract, academic-course or global effect. |
| `EFF-003` | [Martínez, Mollica, and Gibson](https://doi.org/10.1073/pnas.2302672120) | `A|V|U` | Ordinary-language versus legalese contract registers. | Both groups comprehended plain versions better (beta=.354, SE=.088, p<.001) and recalled more (beta=.360, SE=.121, p=.003); register-by-legal-training interactions were nonsignificant. | Not evidence that operative legal text can be freely altered or a long-form education effect. |
| `EFF-004` | [Feinberg et al.](https://doi.org/10.1038/s41598-024-64139-9) | `A|V|U` | Original clinical-consent wording followed by a plain-language rewrite. | Mean comprehension 10.53/15 versus 9.15/15 (+1.38 items, +9.2 points of the test maximum), t(191)=9.36, p<.001, d=.68; 52.6% improved, 32.6% unchanged, 15.1% decreased. | Original-always-first order prevents treating the full gain as translation-only. |
| `EFF-005` | [Beskow et al.](https://doi.org/10.1038/gim.2016.157) | `A|V|U` | Concise form versus traditional form communicating the same required information. | Knowledge 17.6/21 versus 17.5/21 (noninferior); median reading time 5 versus 10 minutes, p<.0001; targeted review and retest improved all strata. | Not every source sentence was preserved; not evidence of superior long-run learning. |
| `EFF-006` | [Sayfi et al.](https://doi.org/10.1016/j.jclinepi.2023.11.009) | `A|V|U` | Plain-language recommendations versus originals. | WHO comprehension +19.8 percentage points (95% CI 14.7-24.9, p<.001); CDC +3.9 points (95% CI -0.7 to 8.3, p=.096); accessibility and satisfaction each +1.2/7. | The WHO effect cannot be applied to the CDC text, a textbook or another audience. |
| `EFF-009` | [August et al. (Paper Plain)](https://doi.org/10.1145/3589955) | `U|R` | Original PDF versus original-plus-definitions, question navigation, and localized gists. | Perceived difficulty 2.00 versus 4.00/5 and perceived understanding 3.50 versus 2.00; actual comprehension 3.67/7 versus 3.50/7, F(4,20)=1.38, p=.267, with reported noninferiority. | Small college-educated sample; curated summaries; no measured knowledge gain. |
| `EFF-030` | [Piesche et al.](https://doi.org/10.1016/j.learninstruc.2016.04.001) | `S` | English/German bilingual physics versus German-only physics. | Smaller science gains immediately, d=-.21, and after six weeks, d=-.23. | One topic and teacher; only partially transferable to self-study translation. |
| `EFF-031` | [Bälter et al.](https://doi.org/10.1515/applirev-2022-0093) | `V|U` | Otherwise identical translated self-study course. | Analyzed groups: 7.24 versus 4.18 correct of 42, Cliff's delta .15. Active subset: 16.9 versus 14.3, delta .085. At least one test attempted: 485/1,134 versus 330/1,129, a 13.540-percentage-point difference; not course completion. | Self-selected sample, registration selection and excluded post-assignment switchers limit causal inference and transport. Not a full intention-to-treat estimate. |
| `EFF-032` | [Gulbrandsen et al.](https://doi.org/10.1001/jama.287.21.2851) | `R|V` | Mother tongue versus English and paper versus screen. | Median recall 4/13 facts (IQR 3-6) in mother tongue versus 3/13 (2-4) in English, p=.01; paper versus screen was null. | Small convenience sample, short exposure, one medical article and closely related languages. |

## Planning intervals

| Scenario | Intervention | Endpoint | Range | Evidence status |
|---|---|---|---:|---|
| `SCN-REG-ADVERSE` | well-audited full-content adult register translation | immediate objective comprehension probability | -3.0 to 0.0 absolute_percentage_points | `scenario_not_meta_analysis` |
| `SCN-REG-NEAR-NULL` | well-audited full-content adult register translation | immediate objective comprehension probability | 0.0 to 3.0 absolute_percentage_points | `scenario_not_meta_analysis` |
| `SCN-REG-CENTRAL` | well-audited full-content adult register translation | immediate objective comprehension probability | 3.0 to 10.0 absolute_percentage_points | `scenario_not_meta_analysis` |
| `SCN-REG-HIGH-MISMATCH` | well-audited full-content adult register translation | immediate objective comprehension probability | 10.0 to 20.0 absolute_percentage_points | `scenario_not_meta_analysis` |
| `SCN-SELF-STUDY-TRANSLATED` | otherwise identical translated self-study course among starters | course-test performance | 0.0 to 0.085 Cliffs_delta | `direct_anchor_bounded_transport` |
| `SCN-SELF-STUDY-PERSISTENCE` | otherwise identical translated self-study course | increase in attempting at least one module test question; not course completion | 0.0 to 13.539552881153117 absolute_percentage_points | `direct_anchor_bounded_transport` |
| `SCN-FOUNDATIONAL-STRUCTURED-L1` | structured early-grade L1 literacy package | sentence reading or comprehension | 0.1 to 0.3 standard_deviation | `synthesis_based_package_scenario` |
| `SCN-OPEN-REPLACES-PAID` | free/open book replaces comparable paid book among enrolled learners | course learning | -0.05 to 0.1 standard_deviation | `meta_analysis_informed_scenario` |
| `SCN-PASSIVE-PUBLICATION` | file merely published without active dissemination or usage evidence | average learning effect per eligible person offered the file | 0.0 to 0.02 standard_deviation | `conservative_scenario` |
| `SCN-STATIC-ACTIVE-USE` | level-appropriate static package with worked examples, retrieval, answers and explanatory feedback among active users | learning change over roughly a term or year | 0.05 to 0.25 standard_deviation | `component_synthesis_informed_scenario` |
| `SCN-ADAPTIVE-ROLLOUT` | level-adaptive system with repeated explanatory feedback | rollout intent-to-treat learning change | 0.12 to 0.24 standard_deviation | `meta_analysis_informed_scenario` |
| `SCN-OFFLINE-SUBSTITUTION` | offline digitization substituting for conventional instruction without major pedagogical redesign | knowledge change | -0.1 to 0.2 standard_deviation | `systematic_review_informed_scenario` |
| `SCN-SMS-ONLY` | SMS or phone content without instruction | rollout intent-to-treat learning change | 0.0 to 0.05 standard_deviation | `direct_anchor_bounded_transport` |
| `SCN-SMS-GUIDED` | SMS plus brief structured tutoring or guided practice | rollout intent-to-treat learning change | 0.03 to 0.21 standard_deviation | `direct_anchor_bounded_transport` |
| `SCN-AUTONOMOUS-LIBRARY` | curated offline digital library with devices and observable voluntary use | secondary-school learning change | 0.05 to 0.15 standard_deviation | `direct_anchor_bounded_transport` |
| `SCN-SELF-REGULATION` | planning, goal setting, progress monitoring, retrieval schedules and study protocols | incremental performance among users | 0.1 to 0.3 standard_deviation | `meta_analysis_informed_scenario` |
| `SCN-PRESCHOOL-UNQUANTIFIED` | preschool language-accessible package | age-appropriate learning and dual-language development | unmeasured—not zero | `unmeasured_not_zero` |
| `SCN-RESEARCH-RECALL` | translated professional or research reading | immediate factual recall after ten minutes | 0.0 to 1.0 additional_facts_out_of_13 | `direct_anchor_bounded_transport` |

## Calculation rule

For passive or lightly supported releases, model E[learning change | eligible] = p(reached) × p(acquired | reached) × p(usable | acquired) × p(active | usable) × active-user effect. Do not apply those multipliers to an intent-to-treat estimate from a comparable rollout because uptake and nonuse are already included.

Report newly usable access, sustained active use or completed units, and standardized learning change separately. Do not add effects measured in incompatible units or from overlapping components. Do not multiply a language population directly by a comprehension uplift without an exposure/use model.

## Design implications

- Preserve every proposition, definition, condition, negation, quantifier, exception, equation, theorem status, example, exercise, answer, citation and cross-reference.
- Pair stable technical terms with inline accessible glosses; do not replace the advanced vocabulary needed for later transfer.
- Include correct worked examples, retrieval practice, immediate answers with explanations, prerequisite diagnostics, mastery checks, study plans, restart instructions and download-once navigation.
- Keep original and translated registers available as user-selectable parallel routes; develop more than one adult and World English target profile.
- Treat readability, fluency and downloads as diagnostics—not proof of semantic fidelity, active use or learning.
- Use proposition-level source-target reconciliation, protected-token and formula maps, and independent model/mechanical checks. No human-dependent release gate is introduced.
