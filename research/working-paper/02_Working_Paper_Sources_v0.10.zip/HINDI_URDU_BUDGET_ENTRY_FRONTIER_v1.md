# When does a Hindi-Urdu bridge improve a fixed-budget portfolio?

A conditional research calculation, not a recommendation to replace native-language editions. No comprehension or learning rate is invented.

The comparison uses the same 100,000-source-token package and a budget of five million declared workload units. Both bridge and native portfolios pay common source preparation once. The optimizer can select Hindi, Urdu, both or neither, alongside the other numeric edition profiles.

| Declared cost scenario | Bridge workload, millions | Retention with no overlap | Retention with fully nested audiences | Lowest retention across overlap |
|---|---:|---:|---:|---:|
| Low preparation cost | 1.938 | 78.29% | 120.54% | 78.29% |
| High shared preparation | 1.646 | 89.66% | 110.55% | 87.41% |
| Extensive profile checking | 2.458 | 107.35% | 165.27% | 107.35% |
| Expensive bridge design | 3.971 | 177.51% | 273.28% | 177.51% |

Retention here is normalized educational benefit relative to the assumed native-route opportunity, not a reading-comprehension percentage. Above 100% requires extra benefit relative to that normalization; it is not automatically impossible, but extra benefit has not been established. The endpoints are declared scenarios, not confidence intervals.

## The allocation result

For each cost anchor, all native states reduce to two competing lines: `T(O) = max(M, L - O) - W`. Here M is the best Hindi-only, Urdu-only or neither coefficient; L is the both-editions coefficient before subtracting overlap; W is the best affordable remainder alongside the bridge. The bridge is better only when its additional normalized benefit exceeds T. There is at most one interior breakpoint. The threshold cannot rise with overlap, but its ratio to the shrinking pair audience can fall and then rise.

At the low-setup anchor, the entry threshold is 626,560,499 normalized benefit units. The result compares against the best affordable native portfolio, not against an unnecessarily expensive promise to translate every native edition.

In that first scenario, the best native mix is Chinese, Hindi, Spanish, Portuguese and Indonesian. Buying the bridge instead leaves room for Chinese, Spanish and Arabic. The bridge must therefore earn back the difference between those two portfolios; saving on Hindi and Urdu in isolation is not enough.

The high-shared-preparation scenario has an interior minimum: the required retention falls from 89.66% to 87.41%, then rises to 110.55%. Its native comparator switches from including both Hindi and Urdu to including Hindi alone at overlap coefficient 142,848,211. This coefficient is a hypothetical shared opportunity, not a measured count of bilingual people.

A useful provisional decision rule follows. At low preparation cost and no pair overlap, benefit above 78.29% of the normalized native opportunity makes the bridge preferable in this declared budget scenario. At full nesting, 120.54% would be needed. Neither endpoint establishes where real readers lie. Under the more expensive checking or design assumptions, cost savings alone are insufficient at every modeled overlap; that is a finding about those cost assumptions, not a dismissal of bridges.

## Exact scope and interpretation

The inherited Hindi and Urdu audience coefficients are 519,812,678 and 280,449,183. They are screening inputs, not verified new learners or assignments of entire language groups to a standard register. Their sum is 800,261,861 before overlap. No country population is substituted for either audience.

The educational endpoint is learning a new mathematical definition and its boundaries. Familiar-result lookup, following a proof and applying a worked example remain separate endpoints. Formal mathematical structure may help some of these tasks more than others; this calculation does not presume that prose-comprehension scores determine mathematical learning.

The bridge contribution must be additive with the selected remainder, or its incremental benefit must not depend on which remaining editions are chosen. If it does depend on them, the bridge and its remainder must be optimized jointly. This sensitivity does not identify a global unique-person optimum.

## What remains unknown

Hindi-Urdu audience overlap, script literacy, bridge comprehension and educational yield remain unmeasured. The Urdu workload proxy is generic Arabic-script traffic, not a Nastaliq-specific measurement. Other multilingual overlaps remain outside this pairwise sensitivity. All 25 unmeasured-audience native rows and bridge-plus-native hybrids remain explicit alternatives, not zero-need cases. Earlier programme output does not reduce global need.

The next substantive test is to bind a specified educational package and exact reader/register profiles to these thresholds. The calculation does not require new participant data to remain usable as a transparent provisional comparison.

## Reproducibility

The accompanying JSON preserves the four native subset states, all selected row IDs, exact rational selected costs, integer coefficients, twenty bounded solver results, overlap segments and source hashes. A separate QA file records deterministic checks. Floating-point optimization is not a formal exact-arithmetic proof.
