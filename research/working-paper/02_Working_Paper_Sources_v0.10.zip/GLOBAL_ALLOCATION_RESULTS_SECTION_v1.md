### 7.9 How the available workload changes the translation portfolio

The decision is which educational editions to produce within a fixed budget. This calculation tests ten portfolios across all 775 retained language-and-script rows. It uses the same positive but unknown educational yield for every edition within each source plan. Under that explicit assumption, audience size and production workload determine which editions fit. This is a provisional allocation result, not a measurement of learning gains.

Three source plans are kept distinct: a standardized 100,000-source-token benchmark; the complete OpenStax *Prealgebra 2e* content, measured at 364,270 tokens; and six selected chapters, measured at 173,958 tokens. The benchmark is not the complete book. Workload is scaled linearly with source length; shared preparation and fixed package-specific costs are not yet estimated.

The budget unit below is one million standardized fresh-equivalent token events. It is a declared production-workload index, not a measurement of electricity, accelerator time, subscription usage or money. The final column is a sum of potential-audience estimates before adjusting for overlapping readers. It is not a count of unique people educated.

| Source plan | Budget, million workload units | Workload used, millions | Editions selected | Potential-audience sum, millions |
|---|---:|---:|---|---:|
| 100k benchmark | 5 | 4.211 | Simplified Standard Written Chinese, Hindi, Spanish | 2,126.4 |
| 100k benchmark | 10 | 9.860 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Portuguese, Indonesian | 3,210.0 |
| 100k benchmark | 25 | 24.944 | 17 editions; full selection in the calculation appendix | 4,745.6 |
| 100k benchmark | 50 | 49.893 | 33 editions; full selection in the calculation appendix | 5,811.6 |
| Complete book | 5 | 4.890 | Simplified Standard Written Chinese | 1,152.0 |
| Complete book | 10 | 9.898 | Simplified Standard Written Chinese, Spanish | 1,606.6 |
| Complete book | 20 | 19.845 | Simplified Standard Written Chinese, Spanish, French, Portuguese | 2,128.3 |
| Six chapters | 5 | 4.934 | Simplified Standard Written Chinese, Hindi | 1,671.8 |
| Six chapters | 10 | 9.760 | Simplified Standard Written Chinese, Hindi, Spanish, French | 2,424.7 |
| Six chapters | 20 | 19.816 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Urdu, Portuguese, Indonesian | 3,490.5 |

At a budget of 10 million workload units, the complete-book scenario selects Chinese and Spanish. The six-chapter scenario instead fits Chinese, Hindi, Spanish and French. The 100k benchmark is a third, shorter plan and must not be described as the complete book. Integer package costs matter: a list sorted by audience per workload does not necessarily produce the best combination that fits the budget.

For the same learning outcome, a smaller package is preferable only if the extra audiences it reaches compensate for any lower educational yield. Under the additive-audience assumption, the six-chapter package needs to retain the following shares of the complete-book yield:

| Budget, million workload units | Minimum six-chapter yield relative to the full book |
|---:|---:|
| 5 | 68.9% |
| 10 | 66.3% |
| 20 | 61.0% |

These are decision thresholds, not observed effectiveness estimates. They apply only to a shared outcome: six chapters cannot be credited with teaching topics they omit. Conversely, a complete book does not automatically provide greater benefit on a narrow outcome such as fractions. The empirical question is which resource produces enough additional understanding for its additional cost.

Multilingual overlap can change the portfolio. If every useful audience were nested within the largest one and each edition delivered the same benefit, additional editions would add no unique beneficiaries. If audiences were disjoint, the displayed sums would apply. Actual allocation must account for intersecting audiences, audience-specific educational yield, register and script access, and shared production costs. Counting two editions is not automatically counting two different people.

The 25 rows with unresolved audience counts remain symbolic alternatives, not zero-need languages. For each budget, the calculation reports how large their audience-benefit contribution would need to be to improve the portfolio after paying their opportunity cost. Additional varieties, signed languages, non-academic-register English and interlanguage designs remain eligible in the wider register. None is excluded by the limits of this inherited numeric table.

The calculation appendix `GLOBAL_BUDGET_SCENARIOS_v1.md` and its structured JSON preserve all 775 rows, ten solved scenarios, full edition selections, budget bounds and unknown-audience entry thresholds. The figures in this section are generated from those same results and checked for exact agreement.
