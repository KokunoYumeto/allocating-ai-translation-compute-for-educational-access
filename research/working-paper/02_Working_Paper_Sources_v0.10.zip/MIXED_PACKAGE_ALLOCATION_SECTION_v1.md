### 7.13 Choosing languages and package sizes together

A fixed budget can support a better combination when it is allowed to mix focused resources and complete books. Across the twelve scenarios here, the best mixed combination improves the modelled educational-opportunity score by between zero and 22.6% over the best policy that uses one package size for every selected language. This is a conditional calculation, not a measured improvement in learning. The useful finding is that package choice and language choice must be made together.

Each language can receive one of three alternatives: the eight fractions modules with eight directly linked support modules; six selected chapters; or the complete OpenStax Prealgebra 2e source. Their extracted content contains 87,655, 173,958 and 364,270 tokens respectively. The first is a priced support scenario, not a completed prerequisite audit. The calculation allows additional per-edition work of 5% of full-book variable workload for supported fractions and 2% for six chapters. These additional-work allowances are scenarios, not measured production costs.

All three alternatives are compared on the same proposed outcome: understanding fraction magnitude, arithmetic and novel applications, assessed on a common normalized scale six weeks after the resource is offered. The currently usable educational alternative and the learner population are held consistent within each comparison. The complete book has other educational benefits; a fractions-only calculation does not value or replace its wider curriculum. Those additional outcomes require their own comparison.

Two assumptions test how much benefit a shorter resource retains. Under the lower pattern, supported fractions and six chapters deliver 35% and 70% of the full book's incremental benefit on this outcome. Under the higher pattern they deliver 65% and 90%. These are illustrative final-benefit ratios after the extra work, not estimates extracted from the instructional studies in section 7.12. The four studies guide the choice of explanations, practice and feedback, but do not identify these ratios for all languages.

Reusable preparation is charged once for the actual union of source modules. The supported-fractions package is not wholly contained in the six-chapter selection: their joint source contains 40 modules and 198,477 tokens. At the higher preparation rate it costs 396,954 workload units to prepare this joint source, compared with 523,226 if its shared modules were charged twice. Translation and review still incur their own per-edition source-reading work. No completed local translation is credited against worldwide educational need.

The table compares budgets of 5, 10 and 20 million standardized workload units. Preparation rates of zero and two additional units per distinct source token test the effect of reusable work. In the package-count column, the three numbers mean supported-fractions editions, six-chapter editions and complete-book editions. Workload is a token-event index, not money, energy or accelerator time. The final percentage compares each mixed solution with the best separately optimized policy using just one package size.

| Benefit pattern | Preparation rate | Budget millions | Fractions / six / full | Work used millions | Gain over one size |
|---|---:|---:|---|---:|---:|
| Lower | 0 | 5 | 0 / 0 / 1 | 4.890 | 0.00% |
| Lower | 0 | 10 | 0 / 2 / 1 | 9.918 | 4.50% |
| Lower | 0 | 20 | 1 / 5 / 1 | 19.906 | 11.18% |
| Lower | 2 | 5 | 1 / 1 / 0 | 4.412 | 22.56% |
| Lower | 2 | 10 | 1 / 1 / 1 | 9.782 | 12.53% |
| Lower | 2 | 20 | 0 / 5 / 1 | 18.984 | 7.37% |
| Higher | 0 | 5 | 0 / 2 / 0 | 4.925 | 0.00% |
| Higher | 0 | 10 | 3 / 2 / 0 | 9.745 | 11.91% |
| Higher | 0 | 20 | 6 / 4 / 0 | 19.578 | 6.73% |
| Higher | 2 | 5 | 3 / 0 / 0 | 4.634 | 0.00% |
| Higher | 2 | 10 | 3 / 2 / 0 | 9.981 | 8.63% |
| Higher | 2 | 20 | 6 / 4 / 0 | 19.975 | 6.73% |

For example, with the lower benefit pattern, zero additional shared preparation and a ten-million-unit budget, the model selects the full book in Simplified Standard Written Chinese and six chapters in Spanish and French. At twenty million units it selects the full Chinese book, six chapters in Hindi, Spanish, Arabic, French and Urdu, and supported fractions in Bangla. These differences follow from the declared costs, audiences and benefit ratios; the calculation does not assume that different nationalities learn differently.

Under the higher benefit pattern at twenty million units, the selected mix is six chapters in Chinese, Hindi, Spanish and Arabic, plus supported fractions in French, Urdu, Bangla, Portuguese, Indonesian and Russian. Both preparation rates select this mix. It illustrates a conditional high-reach allocation, not a universal recommendation to give those communities only those resources. Every language had the same three choices. A different educational outcome or source-specific benefit can change the result.

The worldwide audience inputs remain unchanged for all 775 retained edition profiles. A separate set of nine secondary-school proficiency counts describes educational difficulty in particular survey populations; it is not substituted for the worldwide language audiences. In particular, the model does not shrink a researched language to a small student cohort while leaving unresearched languages with their entire population. The calculation contains 750 numerical audience estimates and 25 explicitly unknown audiences, with single-option entry thresholds for each unknown. All wider language, signed-language, register and interlanguage opportunities remain in the study; this bounded calculation is not the whole candidate universe.

Existing-supply research changes the practical alternatives worth comparing. Indonesian official student books and separate teacher guides motivate testing independent-learning companions alongside a full course. Philippine K-12 and Alternative Learning System provision motivate testing coherent exact-language, downloadable pathways and answer support. Japanese-language transition needs and Ukrainian educational disruption require their own population and resource comparisons. None of these observations measures the benefit ratio used above, proves that an entire country lacks books, or reduces eligibility. The source-bound package records and the accompanying population-and-supply crosswalk preserve those distinctions.

The objective weights each edition audience by its assumed relative benefit. To interpret it as expected score gain, multiply by an explicit common factor for the relevant fraction-learning audience and the full-book offer-level effect. Uptake is already part of an offer-level effect and must not be multiplied twice. Audience sums overlap and are not unique people. The output therefore also re-evaluates each selected mix under a nested-audience, maximum-available-benefit scenario; it does not pretend that the additive selection is optimal under that different geometry.

The calculation and its independent audit are preserved in MIXED_PACKAGE_ALLOCATION_v1.md and the accompanying structured JSON. They record every selected package, source union, budget remainder, same-size comparator and symbolic insertion. Numerical optimality bounds and exact rational recomputation check the saved results; they are not a formal proof of the floating-point optimizer. These results advance the allocation question while leaving the global educational-effect estimates and other subject portfolios open to further research.
