# Independent review: joint-audience allocation v1

8 September 2026. Scope: only `AUDIENCE_JOINT_ALLOCATION_v1.md`, `scripts/build_audience_joint_allocation_v1.py` and `structured/AUDIENCE_JOINT_ALLOCATION_v1.json`. No external searches, survey-record extraction, builder execution or changes to those artifacts. Findings are confined to this review file.

## Verdict

**The presented synthetic arithmetic is correct, and the unknown audience remains a possible winner. No actual population or causal-effect estimate is claimed.** Two wording clarifications and several helper-boundary limitations should be addressed or explicitly retained as preconditions; none changes the displayed synthetic results.

## Independent recomputation

I started with complete nonnegative four-cell tables, not the builder's `bounds()` implementation: independently enumerated 1,820 tables for N=0 through 12, yielding 819 distinct (N,A,B) triples. For every triple the attainable integer intersections were exactly `max(0,A+B-N)` through `min(A,B)`. For all 3,025 pairs of strata with each N=0 through 4, I formed the actual pairwise sums of attainable intersections; each summed interval lay inside the aggregate interval. This independently confirms the numerical claims, not merely that the builder reports success.

For the supplied example:

- Aggregate `(100,40,30)` gives `[0,30]`; `40*30/100=12`.
- Region 1 `(50,35,20)` gives `[5,20]`; Region 2 `(50,5,10)` gives `[0,5]`; sum `[5,25]`.
- Conditional independence gives `35*20/50 + 5*10/50 = 14+1 = 15`.
- Both low tables `(5,30,15,0)` and `(0,5,10,35)`, and both high tables `(20,15,0,15)` and `(5,0,5,40)`, have nonnegative integer cells, the stated marginal counts, and respective joint totals 5 and 25.

Independent subset enumeration gives exactly six affordable portfolios: empty; targeted; alternative; third; targeted+third; alternative+third. Their scores are `0, X, 20, 6, X+6, 26`. Thus:

| X | Complete optimal selection set | Cost | Score |
|---:|---|---:|---:|
| 5 | Alternative + third | 3 | 26 |
| 12 | Alternative + third | 3 | 26 |
| 15 | Alternative + third | 3 | 26 |
| 20 | Alternative + third; targeted + third | 3 each | 26 each |
| 25 | Targeted + third | 3 | 31 |

Every optimum, tie, cost and score matches the JSON. The strict choice threshold is X=20; preserving X=25 proves that the targeted option was not converted to zero eligibility. Common-reference choices at 12 or 15 do not establish dominance.

Weight arithmetic independently gives selected mass `2+3=5`, total `2+3+7=12`, and share `5/12`. Scaling by 100 gives masses 500 and 1,200 with the same exact share. JSON exact-fraction values match; its decimal share is appropriately an approximation. `absolute_population=null` and `real_population_estimates_calculated=false` are correct. Neither mass establishes an expansion count.

## Findings and limits

1. **Clarify the audience-to-benefit normalization.** Manuscript line 46 assumes equal additional benefit per reached person, but the displayed scores and `feasible_portfolios()` (script lines 87-102) directly use audience counts as benefit. To justify the numerical score units, explicitly assume that every listed audience member is reached and receives one additional unit, or state that all options share a common positive reach-times-benefit factor normalized to one. Equal benefit per reached person alone does not supply equal reach. This is a synthetic-model wording gap, not evidence of any real causal effect. The subsequent separation of counts, learning amounts, costs and overlapping gains is sound.

2. **Independence need not produce an integer population table.** Manuscript line 27's wording that `A*B/N` chooses a table should specify an expected/fractional reference table when necessary. For N=3 and A=B=1, independence gives 1/3, whereas an actual intersection is 0 or 1. The independent probe `cells(3,1,1,Fraction(1,3))` is accepted and returns `[1/3,2/3,2/3,4/3]`; therefore `cells()` itself does not certify integer-count realizability. All displayed examples use valid integer tables. If that helper is meant to certify finite-population witnesses, reject noninteger X; otherwise distinguish its fractional-table role.

3. **Unit checks do not establish survey semantics or weight provenance.** The direct `bounds()` helper rejects different unit, universe and period tags, and independently exercised probes confirmed those rejections. However, `stratified()` accepts bare numeric rows and recreates default Margin metadata; its partition flag is an explicit caller assertion, not a verification of coverage, dates or units. Similarly, the test labelled `No household weight as person record` (script line 188) rejects a row with `unit='household'`, not a household-derived weight attached to a person-labelled row. Rename that test to describe row-unit rejection, and preserve verified weight origin, matched denominator population and compatible-stratum metadata as real-data preconditions. The manuscript already correctly warns against treating a weight name as an expansion scale.

4. **Duplicate-key detection is not valid-key validation.** `weighted_share()` rejects repeated keys but accepts a single `person_key=None`. An independent probe with one such person-labelled record, selected true and an unverified weight, returned mass 100, total 100 and share 1. This does not contradict the helper's already-decoded-record precondition, but the test suite must not be described as establishing valid linkage. Reject blank/missing keys or explicitly perform that check upstream before real use. No real records enter the present calculation.

5. **Unknown membership and possible winners are handled correctly within the claimed scope.** Independent probes confirmed that `None`, integer 0/1 and text in `selected` are rejected rather than recoded false. Unknown-membership bounds are not implemented by this complete-case helper; rejection must therefore trigger a separate bounded/scenario path, not dropping people. The manuscript and JSON retain that path conceptually, and the X=25 scenario supplies a genuine numerical possible-winner witness. The JSON's `All communities retained` is a stated study policy, not a test of a global community inventory; this component contains no such inventory or global ranking integration. It does not claim to complete that integration.

## Claims versus evidence

The stated 23 builder checks are consistent with the code's check/rejection calls, including three compatibility checks and one pinned-questionnaire check. I did not invoke `run()` or reverify the questionnaire bytes, because this review was limited to the three named artifacts. Independent numerical enumeration confirms the 819 and 3,025 case counts. These finite tests and the general nonnegativity argument validate the synthetic method, not category coding, current denominators, representativeness, weight expansion, physical compute or educational effects. For estimated rather than exact margins, sampling and other uncertainty must be propagated before presenting true-population bounds.

Zero lower bound means zero overlap is compatible with the supplied margins; it does not mean actual zero overlap, zero need or zero benefit. Ranking only by lower bounds would require an extra pessimistic policy choice. Keeping a common-reference scenario together with feasible alternative and possible-winner scenarios is consistent with the stated method.

## Reviewed byte identities

| Artifact | SHA-256 |
|---|---|
| `AUDIENCE_JOINT_ALLOCATION_v1.md` | `458c511e87d5bc90223d856b7966790e1f757a4414dc9bf60b748975d87f55dc` |
| `scripts/build_audience_joint_allocation_v1.py` | `f57fbf45fe2244a191518f88bcdf3610d8ce2440a7fb21ec2f788ba605d2e4d4` |
| `structured/AUDIENCE_JOINT_ALLOCATION_v1.json` | `e5c2dafa6d3a8d16b7dfee488722179c955c1a4f1b1a8c190bb7e451c6f6bfdc` |

Review complete. No numerical correction to the displayed scenarios is required; findings above delimit wording and future real-data reuse.

## Delta review after corrections - 8 September 2026

**Outcome: all five original findings are addressed for the stated synthetic-method scope.** The original findings and their reviewed hashes above remain historical. The opening adjective was corrected from "published" to "presented" because this work was local and not yet published.

This was a delta check only: inspected the affected manuscript passages, helper changes, test labels and JSON additions; loaded helper definitions without invoking the builder's writing function; did not repeat the full 819/3,025-case audit, inspect new literature or extract survey records.

- Finding 1: manuscript line 46 and JSON `benefit_normalization` now state a common positive reach-times-additional-benefit factor normalized to one. This justifies the numerical units without claiming actual full reach or measured causal benefit.
- Finding 2: manuscript line 27 distinguishes expected, possibly fractional independence tables from actual integer intersections. Independent probes confirm `cells(3,1,1,Fraction(1,3))` now raises ValueError; integer X=0 and X=1 still return the correct feasible tables.
- Findings 3-4: the test is accurately renamed `No household-unit row in person-share helper`. The manuscript's helper-preconditions paragraph explicitly distinguishes declared stratum compatibility, key validation and row labels from proven source coverage, linkage and weight provenance. Independent probes confirm `weighted_share()` rejects keys `None`, empty string, whitespace-only string and integer 123; a valid canonical string-key control still works. Upstream canonicalization and semantic linkage remain disclosed caller responsibilities, not falsely claimed automated certification.
- Finding 5: the helper still rejects unknown membership, and the manuscript explicitly requires the next operation to retain affected people in separate bounded/scenario analysis. JSON `eligibility_policy` now identifies community retention as policy and says the component does not test a global inventory. The upper-endpoint possible-winner scenario remains intact.

Compared the updated JSON's displayed margins, both endpoint tables, all five scenario selections/costs/scores and exact weight results against the original review values: unchanged. The absolute population remains null and real-population-estimate flag remains false. Seven targeted rejection probes and the integer/key positive controls passed. The three new builder rejection cases (fractional witness, missing key, blank key) explain the documented increase from 23 to 26 checks; I did not rerun the full builder and do not represent the parent's full-suite receipt as my own execution.

### Delta-reviewed byte identities

| Artifact | SHA-256 |
|---|---|
| `AUDIENCE_JOINT_ALLOCATION_v1.md` | `653a694059fadf4bafa83250e81036013b82165fac822e98d92a90767f0c7174` |
| `scripts/build_audience_joint_allocation_v1.py` | `2b420e5083edaaf3ebaa9ff06bc42d0a8534a3e21f24cd0908faed317be8a421` |
| `structured/AUDIENCE_JOINT_ALLOCATION_v1.json` | `7bfe2cf463090631138e1fd6fbda62aa412e7a244513a4aa1096a391655a5fa9` |

Delta review complete. No remaining correction is identified within this bounded change set; the explicitly disclosed real-data preconditions remain future extraction requirements, not a hold on the synthetic method.
