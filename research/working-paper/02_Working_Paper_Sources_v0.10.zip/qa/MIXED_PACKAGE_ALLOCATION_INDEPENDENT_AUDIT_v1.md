# Independent audit of the mixed-package allocation

**PASS_WITH_NUMERICAL_CERTIFICATE_SCOPE**

All 12 scenarios and all 66 saved solve records were checked without running an optimizer. The 12,839 deterministic checks produced 0 failures. All 775 original row objects are unchanged: 750 numeric profiles and 25 named null-audience profiles.

## Result and certificate scope

All 62 feasible records have exact feasible selected costs, source-union setup, objectives, single-package comparisons, and overlap rescores. The four infeasible insertions are full-book symbolic editions under the five-million budget: their forced variable cost alone exceeds the budget. No optimizer was rerun.

All feasible saved solver records report optimal status and zero relative gap. Integer audiences and yields 7/20, 14/20, 20/20 or 13/20, 18/20, 20/20 place objectives on an enclosing 0.05 lattice. The largest absolute reported-bound discrepancy is 0.00005000; the smallest margin below the next lattice point is 0.04995000. This is numerical consistency evidence, not a formally checked exact global-optimality certificate.

## Scenario rescore

| Scenario | Fractions / six / full | Exact additive coefficient | Exact nested coefficient | Best uniform gain |
|---|---|---:|---:|---:|
| lower_focused_yield::setup0::B5000000 | 0 / 0 / 1 | 1151960048 | 1151960048 | 0.000000% |
| lower_focused_yield::setup0::B10000000 | 0 / 2 / 1 | 8395008984/5 | 1151960048 | 4.504211% |
| lower_focused_yield::setup0::B20000000 | 1 / 5 / 1 | 12822214501/5 | 1151960048 | 11.178301% |
| lower_focused_yield::setup2::B5000000 | 1 / 1 / 0 | 9883064709/10 | 4031860168/5 | 22.562097% |
| lower_focused_yield::setup2::B10000000 | 1 / 1 / 1 | 33499306917/20 | 1151960048 | 12.526024% |
| lower_focused_yield::setup2::B20000000 | 0 / 5 / 1 | 24766940089/10 | 1151960048 | 7.374055% |
| higher_focused_yield::setup0::B5000000 | 0 / 2 / 0 | 14459719887/10 | 5183820216/5 | 0.000000% |
| higher_focused_yield::setup0::B10000000 | 3 / 2 / 0 | 22145353503/10 | 5183820216/5 | 11.908288% |
| higher_focused_yield::setup0::B20000000 | 6 / 4 / 0 | 15826646583/5 | 5183820216/5 | 6.733667% |
| higher_focused_yield::setup2::B5000000 | 3 / 0 / 0 | 27643826873/20 | 3743870156/5 | 0.000000% |
| higher_focused_yield::setup2::B10000000 | 3 / 2 / 0 | 8598557363/4 | 5183820216/5 | 8.628863% |
| higher_focused_yield::setup2::B20000000 | 6 / 4 / 0 | 15826646583/5 | 5183820216/5 | 6.733667% |

All 36 scenario-level uniform comparator values were reconstructed from the 18 distinct saved uniform optimizations and the exact scenario yield. The JSON audit records their exact values, costs and selected IDs, along with every one of the 36 symbolic insertion cases.

## Dominance and simultaneous pruning

Every known choice has variable cost at least c_min>0. After paying a forced symbolic variable cost, at most K=floor((B-forced_cost)/c_min) known rows fit, because setup costs are nonnegative. For each pruned row j this audit supplies K distinct retained rows with audience at least P_j and base cost at most base_j. If j appears in a feasible selection of at most K rows, at most K-1 of those witnesses can already appear. An unused retained witness replaces j in the same package, preserving the package mask and setup and weakly improving cost and benefit. Each replacement removes one pruned selected row and adds a retained row, so simultaneous pruning terminates after at most the original number of pruned selections. For K=0 no known row can fit. Deterministic identity ordering makes equal-audience/equal-cost dominance acyclic. This is an optimization reduction, not an eligibility or needs judgment.

| K | Retained profiles | Pruned profiles | K retained witnesses for every pruned row |
|---:|---:|---:|---|
| 1 | 2 | 748 | PASS |
| 2 | 5 | 745 | PASS |
| 3 | 7 | 743 | PASS |
| 4 | 9 | 741 | PASS |
| 5 | 10 | 740 | PASS |
| 7 | 15 | 735 | PASS |
| 8 | 18 | 732 | PASS |
| 10 | 23 | 727 | PASS |
| 12 | 27 | 723 | PASS |
| 13 | 29 | 721 | PASS |
| 14 | 31 | 719 | PASS |

The machine-readable audit includes the actual retained witness IDs for each pruned row and maps each feasible solve to its K certificate. Saved production witness lists were also checked exactly.

## Source and interpretation checks

The package sets contain 16, 36 and 75 modules with 87,655, 173,958 and 364,270 hash-bound content tokens. All eight masks were rebuilt from sets. Supported fractions and six chapters are non-nested; their union has 40 modules and 198,477 tokens. The eight outside support links were reconstructed directly from pinned CNXML. Archive and normalized-text identities were checked independently.

Nested maximum-yield benefit was independently reconstructed by integrating over yield levels (rather than the production code's audience breakpoints). Every selected set satisfies largest-single ≤ nested max-yield ≤ additive coefficient.

For an inserted symbolic package, let V be the unforced optimum and R the reoptimized known coefficient with its variable cost and source setup forced. The benefit boundary is V−R; the audience boundary is (V−R)/yield. Equality ties, and strict improvement requires exceeding it. The production JSON's “minimum … for strict improvement” fields should be read as these boundaries, as its explicit unknown contract already states. The audit additionally supplies the least improving integer audience. None of the 25 unknowns is converted to zero, and joint unknown insertions are not claimed solved.

## Limitations

- No large or small optimization was rerun. Saved terminal solver outputs were independently rescored and compared with their reported numerical dual bounds.
- All exact incumbent arithmetic, feasibility, source unions, forced insertion floors, and dominance replacement proofs are deterministic. Reported HiGHS bounds are numerical, not formally checked exact dual certificates.
- Integer audiences and the declared rational yields imply an enclosing objective lattice of 1/20. Every reported numerical upper bound lies below the next lattice point; this supports the saved optimal statuses but does not convert numerical bounds into a formal global-optimality proof.
- The pinned archive, all 78 source-file hashes, and all 75 normalized content-text hashes were independently checked. Token totals were independently summed from hash-bound module counts; the tokenizer was unavailable in this numerical Python environment and tokenization itself was not rerun.
- A symbolic threshold is a boundary: equality ties, strictly greater benefit improves. With continuous audience coefficients there is no attained minimum strictly improving value. An additional least-integer-audience field makes the discrete interpretation explicit.
- Overlap layer cake only rescores each additive-optimal selected set. It is neither an empirical overlap estimate nor an optimum under a different overlap objective.
- The 775-row baseline is treated as the pinned input population basis; this audit establishes exact inheritance, not a fresh demographic evidence audit. No PISA cohort replacement is introduced.

## Exact input identities

| Relative path | Bytes | SHA-256 |
|---|---:|---|
| structured/MIXED_PACKAGE_ALLOCATION_v1.json | 14522201 | 736A5A69BABD64FBDB3C02A4F1A0515B7B12B99D7BCC395C43AC3A47FDEB17B3 |
| structured/GLOBAL_BUDGET_SCENARIOS_v1.json | 438221 | CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57 |
| structured/OPENSTAX_PACKAGE_SCALE_20260904.json | 83429 | F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16 |
| structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json | 34051 | 61088618CCF3C3C1A32E4D68EB4F9BAC115D354CB74DAE675E6816475A98CD86 |
| qa/MIXED_PACKAGE_SOLVE_CACHE_v1.json | 15214064 | 2A11235449F5092D233C2F7E2945F9A4EE5B3964AA27C5ADEE91C13896B26831 |
| qa/MIXED_PACKAGE_ALLOCATION_QA_v1.json | 754 | B4F0997E90B7DDD94981797D88F187D5B35F6CC51A3ED6213382090E06BC0FF0 |
| MIXED_PACKAGE_ALLOCATION_v1.md | 8379 | CDBA7737E9477276620585C941C9C2B46C36874FF45E22829036507CB5ADE6A7 |
| scripts/build_mixed_package_allocation_v1.py | 26317 | D3BBCED54ADE30DF2A6E2B42A8457C95EDACE7FB554F675AA2B8DB58BA7A190E |
| scripts/audit_mixed_package_allocation_v1.py | 33644 | 63BB1F13240F37357CEBB1EA3F6E43677B4C65582F4C22C3D452589237F2218F |
| sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip | 1191697 | E9020DA36693D94C0F16FA9CA0025531551E285B5C654BE02E42C85D0679D44A |

## Failures

None.
