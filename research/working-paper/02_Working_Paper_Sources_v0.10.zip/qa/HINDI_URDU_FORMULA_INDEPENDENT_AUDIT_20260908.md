# Independent Hindi-Urdu budget-entry formula audit

8 September 2026. Bounded mathematical audit of the proposed 5,000,000-FECU, 100,000-source-token calculation. No external evidence, numerical-library worker, global builder, source mutation, construction decision, or publication was used. The only write is this new audit. The research objective remains additional educational understanding under a finite compute-workload budget, not a schedule for local work.

## Finding

The proposed common-preparation calibration and native-versus-bridge entry inequality are algebraically sound under their explicitly conditional additive-opportunity assumptions. Three saved sensitivity results are independently certified below using elementary cardinality bounds and a small exhaustive enumeration. The large-setup frontier requires its own saved solver certificates; rounded endpoint percentages alone do not certify those optima.

Two implementation hazards need explicit tests: normalized retention need not be monotone in overlap, and the existing MILP helper's tolerances alone do not establish an exact integer-benefit optimum or exact budget feasibility.

## Independent derivation

Write `S = P_H + P_U = 800,261,861`, `U = P_U = 280,449,183`, and let `R(t)` optimize native rows other than the exact Hindi/Urdu rows at variable-cost budget `t`. Infeasible residual budgets must remain marked infeasible; an affordable empty residual has value zero.

Let `A_0`, `A_H`, `A_U`, and `A_HU` be the four feasible native-state intercepts before overlap is subtracted. Define `M = max(A_0,A_H,A_U)`, `L = A_HU`, and `W = R(B-C_bridge)`. Then the complete conditional entry frontier is

```text
N(O) = max(M, L-O)
T(O) = N(O)-W = max(M-W, L-W-O),  0 <= O <= U.
```

There is at most one active interior breakpoint, `O_star = L-M`. If `O_star <= 0`, the entire frontier is flat. If `0 < O_star < U`, its slope is -1 before the breakpoint and 0 afterward. If `O_star >= U`, its slope is -1 throughout the interior. Ties and boundary breakpoints must not be silently dropped. The four native states remain recorded even when their lines are never active.

Consequently `T` is continuous, convex, nonincreasing, nonnegative, and 1-Lipschitz. Nonnegativity follows because `A_0 >= W` for a positive bridge variable cost. Strict improvement requires `G_bridge > T(O)`; equality is a tie, not an improvement.

Under the additional normalization `G_bridge = rho*(S-O)`, the required retention is `r(O)=T(O)/(S-O)`. The denominator is positive throughout this saved interval. On an active HU segment,

```text
r'(O) = (L-W-S)/(S-O)^2.
```

On a flat-threshold segment, `r'(O)=(M-W)/(S-O)^2 >= 0`. Therefore retention can decrease and then increase even though the direct threshold never increases. The saved large-setup endpoints imply this decreasing-then-increasing case; their two values are not the full frontier's minimum and maximum.

At unit retention, strict bridge entry is equivalent to both `S > L-W` and `O < S-M+W`. For other benefit scales or nonpositive comparator gains, retain the direct inequality rather than a positive-retention interpretation.

## Calibration checks

The proposed calibration implies, identically,

```text
f + v_i = c_i
C(H,U) = c_H+c_U-f = lambda*(F+2+2Q)
C_bridge/C(H,U) = (F+1+D+A+2Q)/(F+2+2Q).
```

Thus the native pair receives the same one-time preparation benefit as the bridge and all other native portfolios. The original four dimensionless pair-cost ratios are preserved. A native portfolio's empty case costs zero, not `f`; every nonempty portfolio pays `f` exactly once. Adding a native edition to either kind of already prepared portfolio costs its same `v_i`.

Across all 775 preserved candidate rows, the smallest standalone cost is Portuguese at `1,331,472.665707` FECU. The minimum native variable costs at the four anchors are approximately `858,738.32517825`, `145,002.163987784`, `953,285.193284`, and `858,738.32517825`: all are positive. Validation must inspect all native rows, including unknown-audience rows, not just Hindi and Urdu.

The four anchors recalibrate `lambda` while preserving standalone costs. In particular the large-setup anchor lowers the bridge's FECU cost by lowering the implied variable-cost scale. This is a declared alternative decomposition of fixed proxies, not a causal claim that increasing measured setup work makes production cheaper. The common preparation and script-specific production costs remain unmeasured.

## Independent numeric checks without MILP

For low setup, six native editions cannot fit even at six times the cheapest variable cost: the resulting lower-bound cost is `5,625,164.29159825` FECU. At most five natives fit. Any selection of at most four has benefit at most `2,465,746,663`. A five-edition set containing a row outside the thirteen largest coefficients has benefit at most `2,571,093,164`, below the saved incumbent. Exhaustive inspection of all 8,191 nonempty subsets of those thirteen rows, with costs represented as exact integers in units of `10^-8` FECU, gives Chinese, Hindi, Spanish, Portuguese, and Indonesian: coefficient `2,572,494,484`, cost `4,994,642.985296`. This proves the global conditional numeric optimum without another solver.

The low-setup bridge residual accommodates at most three natives. Its three largest eligible non-Hindi/non-Urdu coefficients, Chinese/Spanish/Arabic, fit, proving `W=1,945,933,985`. Hence `T=626,560,499`. The native winner excludes Urdu and remains optimal for every permitted overlap. The exact endpoint retentions round to `78.2944%` and `120.5358%`; unit retention ties at `O=173,701,362` and strictly improves only below that value.

For checking intensive, at most four native editions fit. The globally largest four coefficients, Chinese/Hindi/Spanish/Arabic, do fit at cost `4,651,642.755445`, proving `N=2,465,746,663`. The bridge residual accommodates at most two natives, and its two largest eligible coefficients, Chinese/Spanish, fit. Thus `W=1,606,635,543` and `T=859,111,120`, constant over overlap. The endpoints round to `107.3538%` and `165.2732%`.

For design intensive, the native calibration equals low setup, hence its native optimum is the same. The bridge residual fits at most one native; Chinese fits and has the largest eligible coefficient. Thus `W=1,151,960,048` and `T=1,420,534,436`, constant over overlap. The endpoints round to `177.5087%` and `273.2781%`.

## Exact implementation tests and interpretation limits

- Recompute every portfolio's costs from the source-decimal/rational calibration and its benefits from the integer source coefficients. Confirm feasibility without the helper's `+0.01` FECU slack. `solve()` also permits an objective mismatch below 1,000 coefficient units; do not inherit that as an exact-arithmetic test.
- Inspect each maximization dual bound: a relative gap of `1e-9` can exceed one benefit unit at billion-scale objectives. An integer incumbent `V` is certified by a valid upper bound strictly below `V+1`, not by relative-gap tolerance alone. Preserve the raw solver bound and an explicit certification test.
- Reconstruct `max(M-W,L-W-O)` at both endpoints and every breakpoint, assert continuity and equal branch values at an interior switch, and sample each open segment. Test monotonicity on the direct threshold, not blindly on normalized retention.
- Check all four states, exact Hindi/Urdu identity exclusion in every residual, positive variable costs for all 775 rows, one common-preparation charge on both sides, and correct zero cost for the truly empty portfolio.
- Keep all 25 unknown native audiences and all bridge audience/comprehension/literacy fields null or symbolic. None is zero need or an eligibility exclusion. All broader registers, varieties, script formats, diaspora/displaced groups, and educational stages remain eligible beyond this one conditional numeric comparison.
- A shared positive native relevance/use/effect normalization is an assumption, not an educational-effect estimate. The overlap coefficient is a compatible shared-benefit correction, not a measured bilingual-person count. FECU is a stipulated workload index, not physical compute or money.
- `G_bridge+W` is valid only if bridge benefit is additive with the chosen residual portfolio, or is an incremental benefit independent of which remainder is chosen. If actual incremental bridge benefit varies with the remainder, optimize `G_bridge(T)+G_native(T)` jointly; maximizing the native remainder alone need not select the best bridge remainder.
- Native-Hindi/Urdu-plus-bridge hybrids, overlap with Arabic or other residual editions, unequal educational gains, uptake, and exact Nastaliq production/reading access are unresolved alternatives and parameters. This test cannot select a globally best edition or infer new-definition comprehension, proof checking, transfer, or reference-use outcomes from one another.

## Inspected source identities

Hashes were recomputed from the exact files on 8 September 2026. Paths are relative to the task root.

| Source | SHA256 |
|---|---|
| `agent_reports/INTERLANGUAGE_ALLOCATION_NEXT_TEST_20260907.md` | `1C08DA9611ED648D01556D51EC0B9559DBFADE57E59CA34BF3814C69BE9892B0` |
| `SHARED_REGISTER_PORTFOLIO_COMPARISONS_v1.md` | `799CCBBDDA93A963D49A3C7D74926B1B226CEE09B0E09B42B54C519C37187555` |
| `structured/GLOBAL_BUDGET_SCENARIOS_v1.json` | `CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57` |
| `structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json` | `0C55B90034DCF6034540815F2B4D399E1FD13B75A4C015B0748032228197BB2F` |
| `scripts/build_global_budget_scenarios_v1.py` | `407FB5DD00329E557DC0034C6F7D3164A0F15D99FB043D2BE15A82EA527415CF` |

Next exact action for the implementing task: produce and verify the four-state/one-bridge-residual certificates, particularly the large-setup intercepts and interior retention minimum, in its bounded frontier builder and QA outputs. No independent completion or release claim is made here.
