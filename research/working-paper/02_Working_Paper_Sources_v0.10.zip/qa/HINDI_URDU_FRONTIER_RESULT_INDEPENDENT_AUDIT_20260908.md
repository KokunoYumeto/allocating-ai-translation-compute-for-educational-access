# Independent Hindi-Urdu frontier result audit

8 September 2026. Status: **PASS for saved selection arithmetic and conditional frontier identities; not an empirical allocation ranking or formal exact-optimization certificate.**

## Scope and method

The assigned bounded check was to inspect `scripts/build_hindi_urdu_budget_entry_frontier_v1.py` and the existing formula audit, independently recompute the saved frontier results from `structured/GLOBAL_BUDGET_SCENARIOS_v1.json`, and write only this report. No network, publication, new optimization, numerical solver import, child agent, or source mutation was used. Computation used Python standard-library JSON, Decimal, Fraction and SHA256. Decimal source tokens were preserved before conversion to exact rational values; no rounded display costs were used for feasibility.

The final inspected result is the JSON generated at `2026-09-07T22:35:15.348886+00:00`. Its six source bindings and the generated QA file's three artifact bindings all match recomputed byte counts and SHA256 hashes. Artifact identities below fix the exact audited versions. Its recorded production runtime is Python 3.13.9, NumPy 2.4.4 and SciPy 1.17.1.

During this bounded audit, the implementing task regenerated its outputs once after adding the runtime versions, explicit zero costing for a genuinely empty native state, and clearer human-readable explanations including the interior retention minimum. The earlier result had SHA256 `32632F36C255562CF05A35BA166B6F833BB36C602C76B1AE9E069C85DCAE33E5`. The regenerated result was checked again without optimization: all 20 selected identity lists, source-recomputed exact portfolio costs, integer coefficients, M/L/W, thresholds, breakpoint coordinates, retention values, segment derivatives and unit-retention ties are unchanged against the earlier directly observed results. Only the current result hashes below bind this final audit.

## Verified arithmetic

All 775 source row identities are unique and retained. The numeric layer contains 750 positive integer-valued population coefficients. The other 25 source coefficients are null, and exactly those 25 identities remain null symbolic challengers in the frontier output. No missing coefficient was treated as an observed zero audience.

For every scenario, independently recomputed `lambda=(c_H+c_U)/(2*(F+1+Q))`, setup `f=lambda*F`, native variable costs `v_i=c_i-f`, and bridge cost `lambda*(F+1+D+A+2*Q)` match the saved exact rationals. All 775 variable costs are positive. Every native standalone proxy is preserved, not only the Hindi and Urdu anchors. The pair cost is `c_H+c_U-f`, so it receives the same one-time setup sharing as the bridge.

All 20 saved residual selections were checked: 16 native-state residuals and four bridge residuals. Checks included unique and valid selected IDs, matching edition labels, no Hindi/Urdu ID in any residual, no unknown-audience ID in a numerical solution, exact source-rational variable costs and residual capacities, source-integer coefficients, fixed-member additions, and final feasibility without the solver helper's allowance. All pass. The smallest final budget slack is exactly `112657527197/25500000` workload units (about 4,417.942243), in the large-setup H state.

Native coefficients below are intercepts before the HU overlap subtraction. Displayed costs are rounded to six decimals only; the checks used exact fractions.

| Cost scenario | Native state | Edition count | Coefficient intercept | Total workload |
|---|---|---:|---:|---:|
| low_shared_setup | neither | 5 | 2,350,923,095 | 4,899,719.322275 |
| low_shared_setup | H | 5 | 2,572,494,484 | 4,994,642.985296 |
| low_shared_setup | U | 4 | 2,226,383,168 | 4,405,466.980772 |
| low_shared_setup | HU | 4 | 2,406,897,404 | 4,324,638.307660 |
| large_shared_setup | neither | 15 | 3,886,755,404 | 4,956,725.130461 |
| large_shared_setup | H | 15 | 4,323,828,165 | 4,995,582.057757 |
| large_shared_setup | U | 15 | 4,059,032,959 | 4,986,307.206985 |
| large_shared_setup | HU | 14 | 4,466,676,376 | 4,869,860.447006 |
| community_check_intensive | neither | 4 | 2,244,175,274 | 4,556,719.092424 |
| community_check_intensive | H | 4 | 2,465,746,663 | 4,651,642.755445 |
| community_check_intensive | U | 4 | 2,226,383,168 | 4,689,107.585089 |
| community_check_intensive | HU | 4 | 2,406,897,404 | 4,608,278.911977 |
| design_intensive | neither | 5 | 2,350,923,095 | 4,899,719.322275 |
| design_intensive | H | 5 | 2,572,494,484 | 4,994,642.985296 |
| design_intensive | U | 4 | 2,226,383,168 | 4,405,466.980772 |
| design_intensive | HU | 4 | 2,406,897,404 | 4,324,638.307660 |

| Cost scenario | Bridge residual coefficient W | Residual edition count | Bridge plus residual workload |
|---|---:|---:|---:|
| low_shared_setup | 1,945,933,985 | 3 | 4,812,195.472426 |
| large_shared_setup | 3,749,154,432 | 13 | 4,945,749.036332 |
| community_check_intensive | 1,606,635,543 | 2 | 4,419,185.175766 |
| design_intensive | 1,151,960,048 | 1 | 4,840,721.758930 |

## Independently reconstructed frontier and extrema

The source pair coefficients are `P_H=519,812,678`, `P_U=280,449,183`, and `S=P_H+P_U=800,261,861`. On `0 <= O <= 280,449,183`, recomputing all four native lines gives `T(O)=max(M,L-O)-W`.

| Cost scenario | M | L | W | Candidate L-M |
|---|---:|---:|---:|---:|
| low_shared_setup | 2,572,494,484 | 2,406,897,404 | 1,945,933,985 | -165,597,080 |
| large_shared_setup | 4,323,828,165 | 4,466,676,376 | 3,749,154,432 | 142,848,211 |
| community_check_intensive | 2,465,746,663 | 2,406,897,404 | 1,606,635,543 | -58,849,259 |
| design_intensive | 2,572,494,484 | 2,406,897,404 | 1,151,960,048 | -165,597,080 |

Thus the low-setup, checking-intensive and design-intensive thresholds are constant at 626,560,499; 859,111,120; and 1,420,534,436, respectively. H is the winning native state over their entire interval. Large setup has the only active interior switch:

```text
T(O) = 717,521,944 - O,   0 <= O <= 142,848,211
T(O) = 574,673,733,       142,848,211 <= O <= 280,449,183.
```

HU wins below that switch, H and HU tie at it, and H wins above it. Both branches are equal at the switch. Every saved endpoint, breakpoint, winning-state tie and segment equation was reproduced. Each segment was also tested at its endpoints, midpoint and quarter points. Direct thresholds are continuous, nonnegative, nonincreasing and 1-Lipschitz.

For normalized retention `r(O)=T(O)/(S-O)`, the HU segment derivative has the sign of `L-W-S`; the flat-threshold segment derivative has the sign of `M-W`. These signs were independently reconstructed and agree with every saved segment. Since the denominator remains positive and each open segment is monotone, endpoints and the one interior switch exhaust the extrema:

| Cost scenario | Minimum required retention | Overlap at minimum | Maximum required retention | Overlap at maximum |
|---|---:|---:|---:|---:|
| low_shared_setup | 78.2944345513% | 0 | 120.5358248303% | 280,449,183 |
| large_shared_setup | 87.4143293191% | 142,848,211 | 110.5540048025% | 280,449,183 |
| community_check_intensive | 107.3537502995% | 0 | 165.2732140558% | 280,449,183 |
| design_intensive | 177.5087012425% | 0 | 273.2781434777% | 280,449,183 |

In particular, the large-setup minimum is exactly `574673733/657413650`, not its no-overlap value `717521944/800261861 = 89.6608946356%`. Its retention falls and then rises. Reporting the two endpoint percentages as the minimum/maximum range would be wrong. The final inspected human-readable report explicitly includes the 87.41% minimum in its table and explanation, avoiding that error.

The unit-retention tie overlaps are exactly 173,701,362 for low setup and 225,588,128 for large setup. Unit retention strictly improves the conditional native optimum below the respective tie, ties at it, and does not improve above it. Neither intensive-cost scenario admits entry at unit retention anywhere in this interval. These statements concern the declared normalized-benefit model, not measured performance.

## Limits and non-generalizable conclusions

1. **Numerical optimality is not independently proved here.** All 20 saved upper bounds satisfy the builder's numerical separation check against the next integer objective. Four serialized bounds are nevertheless 0.0000002 below their recomputed integer incumbent: low-setup HU, checking-intensive HU, checking-intensive bridge residual, and design-intensive HU. This is consistent with floating-point roundoff and within the declared 0.0001 tolerance, but those raw values are not rigorous rational upper-bound certificates. The reported solver qualification is necessary. This audit establishes exact incumbent arithmetic and saved-bound consistency; it does not rerun or formally certify the MILP. The earlier formula audit's independent small-case arguments are separate evidence and were not rerun here.

2. **Empty portfolios:** a genuinely empty native portfolio costs zero. The JSON declares that correctly, and the final inspected builder explicitly returns zero total cost when neither fixed members nor residual selections exist. Its `neither` label means neither Hindi nor Urdu, not an empty portfolio. Every saved `neither` residual is nonempty, so all present setup charges are correct. The repair does not change any saved number. General reuse for budgets below setup would still require revisiting the fixed-budget feasibility branches; this audit covers the declared five-million budget only.

3. **Retention is not comprehension.** The ratios are educational-benefit thresholds under an assumed common positive relevance/use/effect normalization. They do not estimate reading comprehension, literacy, educational yield, uptake, unique beneficiaries, or the probability of successfully learning a definition. Percentages above 100% are not inherently impossible in an uncapped relative-benefit normalization; extra benefit has not been established. No inference to proof checking, reference lookup, transfer, or other educational endpoints follows from this calculation.

4. **Audience additivity is conditional.** The remaining language coefficients are inherited additive opportunities, not disjoint measured people. The overlap O is a compatible pair-benefit correction, not an estimated bilingual-person count. The saved `bridge_residual_independence_assumption` correctly states the additional condition required for `W+G_bridge`: bridge benefit must be additive with the residual or have the same incremental value for every feasible residual. If its incremental value depends on the remainder, native-only remainder optimization does not establish the bridge-plus-remainder optimum. Pair overlap alone cannot repair this.

5. **Hybrid alternatives are unresolved, not inferior.** The residual deliberately excludes Hindi and Urdu when a bridge is inserted. This is appropriate for the stated bridge-replacement comparison, but does not compare bridge-plus-Hindi, bridge-plus-Urdu or bridge-plus-both against the frontier. The JSON explicitly retains these as unresolved alternatives. They require incremental benefits and overlaps; no redundancy, dominance, global optimality or recommendation to replace native editions is established. The 25 symbolic-audience rows and wider language/register/stage universe likewise remain eligible rather than zero need.

6. **Cost calibration is a stipulated sensitivity.** All anchors preserve the same standalone proxies while recalibrating their fixed/variable decomposition. Lower calibrated bridge workload in the large-setup anchor is not evidence that increasing measured setup effort causes cheaper production. Workload is not physical compute, money or energy, and the Urdu proxy does not measure Nastaliq-specific costs. These qualifications are preserved in the inspected output.

No incorrect numerical result was found in the inspected saved frontier. The finite result is usable with the stated conditional scope and numerical-certificate qualification. This audit makes no publication, full-research completion, or human-review gate claim.

## Audited artifact identities

Paths are relative to `01_methodology/research_department/ai_compute_educational_access_20260825/from_scratch_20260901`.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| `scripts/build_hindi_urdu_budget_entry_frontier_v1.py` | 21529 | `C51683ECCF74C7819C7676939590D3E5923C15C36F9352E157545829D5AAE718` |
| `qa/HINDI_URDU_FORMULA_INDEPENDENT_AUDIT_20260908.md` | 10012 | `A21AD4BDAB5BA39C5DDC6F82D97911389609FD6C5C5A31A32EC4423958C53244` |
| `structured/GLOBAL_BUDGET_SCENARIOS_v1.json` | 438221 | `CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57` |
| `structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json` | 86137 | `0C55B90034DCF6034540815F2B4D399E1FD13B75A4C015B0748032228197BB2F` |
| `scripts/build_global_budget_scenarios_v1.py` | 23633 | `407FB5DD00329E557DC0034C6F7D3164A0F15D99FB043D2BE15A82EA527415CF` |
| `structured/HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.json` | 59453 | `A6388C1002C95A289728D15B7CDB30C579850366C7F76050FF254E77236B494E` |
| `qa/HINDI_URDU_BUDGET_ENTRY_FRONTIER_QA_v1.json` | 3277 | `746596A659D80F193BEA14185502A51B1A42CE13A43D703FE0948378834F5E62` |
| `HINDI_URDU_BUDGET_ENTRY_FRONTIER_v1.md` | 5329 | `A74A2E82218399A79417B9C3D9B142241147C618C594F20A094DEF1883DCD2FC` |
