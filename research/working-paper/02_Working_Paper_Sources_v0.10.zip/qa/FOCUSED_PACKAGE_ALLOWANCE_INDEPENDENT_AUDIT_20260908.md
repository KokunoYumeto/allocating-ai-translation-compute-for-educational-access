# Independent focused-package workload allowance audit

8 September 2026. Status: **PASS for the proposed conditional average-efficiency inequality, with the domain and interpretation limits below.** This is a within-language, same-cohort, same-outcome comparison, not a language ranking, eligibility filter, empirical learning estimate or fixed-budget portfolio solution.

## Bounded assignment and evidence

The assignment is to audit `V>0`, shared setup `F=fV>=0`, focused base workload `rV`, additional focused-specific work `E>=0`, and `alpha=G_focused(E)/G_full` with `G_full>0`; derive the allowance; test signed, zero and equality cases; explain setup, endogenous benefit, source representation and indivisible-budget limitations; and calculate scenarios `alpha=1/4,1/2,3/4,1`, `f=0,1/10,1`. Its bounded extension checks the saved 30-cell calculator including `alpha=5/4`, ten workload conversions, 775 preserved source IDs, and eight pinned modules underlying the support inventory. The only write is this audit. No optimizer, network, publication, child agent, source tokenization rerun, production artifact or wider filesystem scan was used.

Source sizes were read only from `structured/OPENSTAX_PACKAGE_SCALE_20260904.json`. Its pinned source commit is `38cae454e644abf9f0a623e876994553881597c9`; measurement timestamp is `2026-09-04T16:43:02.563604+00:00`. The audited file has 83,429 bytes and SHA256 `F02E34E4A47B11A0069680BC6563361B0F8288BEBBA766D96AEA081B752FEF16`.

The declared ratios use that file's `cl100k_base/content_text` counts:

| Package | Source-content tokens | Ratio to complete collection |
|---|---:|---:|
| Complete collection | 364,270 | 1 |
| Fractions chapter only | 41,336 | `20668/182135` = 11.3476267604% |
| Selected six-chapter scenario | 173,958 | `86979/182135` = 47.7552365004% |

The six selected chapters are 1, 3, 4, 6, 8 and 11. These are package identities, not a finding that they contain all prerequisites or achieve a particular outcome. The source archive and eight fractions-module byte hashes were independently verified in the saved-output extension below. Tokenizer counts remain pinned source evidence, not independently recounted tokens in this audit.

## Independent derivation

Treat the two products as alternative fresh productions with the same genuinely required setup. Put `e=E/V`. Their positive costs are

```text
C_full = F+V = V(1+f),
C_focused = F+rV+E = V(f+r+e).
```

Both supplied ratios satisfy `0<r<1`, so `C_focused>0` even when setup and additional work are zero. The average-efficiency comparison is

```text
G_focused(E)/C_focused > G_full/C_full
iff G_focused(E)*C_full > G_full*C_focused
iff alpha(E)*(1+f) > f+r+e
iff E/V < alpha(E)*(1+f)-f-r.
```

Every multiplication and division preserves the inequality because `V`, both costs and `G_full` are positive. The proposed formula is therefore correct. Define its allowance at the declared benefit ratio as

```text
A(alpha,f,r) = alpha*(1+f)-f-r = alpha-r-f*(1-alpha).
```

For fixed alpha, focused production is strictly more efficient for `0<=e<A`, ties at `e=A` when that point is admissible, and is less efficient for `e>A`. A is normalized by the full variable workload V, not by total full workload `F+V`. The corresponding bound on `E/(F+V)` is `A/(1+f)`. A strict upper bound is a supremum, not an attained maximum that can safely be spent in full.

## Signed, zero and equality cases

- If `A>0` and alpha is fixed, the admissible strict-improvement interval is `[0,A)`. Equality at `E=AV` is a tie, never a strict improvement.
- If `A=0`, only `E=0` ties; no admissible E strictly improves efficiency. If `A<0`, even zero extra work fails, and no admissible E improves efficiency **at that same fixed alpha**. A negative value is not a negative budget allocation and must not be silently clamped to zero and called feasible.
- At `E=0`, strict improvement requires `alpha>(f+r)/(1+f)`. Equality at that positive ratio is a useful exact zero-allowance test. For fractions and `f=1/10`, it is exactly `77763/400697`; for six chapters it is `210385/400697`.
- With `G_full>0`, zero or negative focused net benefit gives `alpha<=0` and necessarily `A<0`, so it cannot beat the positive full-package efficiency. Negative effects remain signed effects, not missing data and not zero need.
- The positive-full-benefit assumption is essential for the alpha interpretation. If `G_full=0`, alpha is undefined: with positive costs, compare directly and the focused package is more efficient exactly when `G_focused(E)>0`, ties when it is zero, and loses when it is negative.
- If `G_full<0`, direct cross-multiplication remains valid, but division by that benefit reverses the normalized comparison: `e>alpha*(1+f)-f-r`. Do not reuse the positive-benefit allowance direction. For example, a cheaper package with a smaller negative absolute benefit can still have a more negative benefit-per-cost ratio. If doing nothing has zero incremental cost and benefit and is feasible, a negative-total-benefit package is inferior to doing nothing; cost-efficiency among harmful options does not justify choosing one.
- `V=0` is outside the normalization domain. The supplied positive r excludes zero-cost products here; an extension allowing a zero denominator requires direct cost/benefit reasoning, not this ratio test.
- `alpha=1` gives `A=1-r` for every f. The same positive benefit beats the comparator exactly when focused total cost is lower; at `E=(1-r)V` costs and efficiencies are equal. `alpha>1` is algebraically allowed if a focused intervention produces greater net benefit on the same outcome; it is not established by selecting less text.

All inequalities above remain pointwise valid if alpha depends on E. Statements about an entire admissible E interval require alpha to be held fixed or its response function to be specified.

## Setup effects

At fixed alpha and r, `dA/df=alpha-1`. Increasing the same setup burden on both alternatives reduces the allowance when `alpha<1`, leaves it unchanged when `alpha=1`, and increases it when `alpha>1`. Equal setup does not cancel out of benefit-per-total-cost ratios.

For zero extra work, the required benefit ratio is `(f+r)/(1+f)`, with derivative `(1-r)/(1+f)^2>0` and limit 1 as f increases without bound. Thus a small source package does not retain an arbitrarily large efficiency advantage when common setup dominates. For fixed `alpha<1`, positive allowance requires both `alpha>r` and

```text
f < (alpha-r)/(1-alpha).
```

For general fixed e, the corresponding condition is `f<(alpha-r-e)/(1-alpha)` with a positive numerator. If setup itself changes benefit, these partial-derivative comparisons are not total causal effects.

"Shared" means the same setup applies to each mutually exclusive fresh-production comparison. It does not mean charging setup twice when both products are produced in one portfolio. Conversely, if setup has already been paid and is irrelevant to the marginal choice, the relevant remaining-work comparison uses marginal costs without charging that sunk setup again. Existing source preparation, different setup requirements, later extension from focused to full, and reuse between products require their own incremental-cost specification; the present formula does not estimate those facts.

## Exact allowance scenarios

Each table entry is A, the strict ceiling for `E/V`, followed by its percentage of V. All fractions were calculated from the exact source-token ratios; percentages are rounded displays. No alpha or f in the table is an empirical estimate.

| f | alpha | Fractions-chapter allowance A | Six-chapter allowance A |
|---:|---:|---:|---:|
| 0 | 1/4 | `99463/728540` (13.652373240%) | `-165781/728540` (-22.755236500%) |
| 0 | 1/2 | `140799/364270` (38.652373240%) | `8177/364270` (2.244763500%) |
| 0 | 3/4 | `463733/728540` (63.652373240%) | `198489/728540` (27.244763500%) |
| 0 | 1 | `161467/182135` (88.652373240%) | `95156/182135` (52.244763500%) |
| 1/10 | 1/4 | `17929/291416` (6.152373240%) | `-440843/1457080` (-30.255236500%) |
| 1/10 | 1/2 | `245171/728540` (33.652373240%) | `-20073/728540` (-2.755236500%) |
| 1/10 | 3/4 | `891039/1457080` (61.152373240%) | `360551/1457080` (24.744763500%) |
| 1/10 | 1 | `161467/182135` (88.652373240%) | `95156/182135` (52.244763500%) |
| 1 | 1/4 | `-223471/364270` (-61.347626760%) | `-356093/364270` (-97.755236500%) |
| 1 | 1/2 | `-20668/182135` (-11.347626760%) | `-86979/182135` (-47.755236500%) |
| 1 | 3/4 | `140799/364270` (38.652373240%) | `8177/364270` (2.244763500%) |
| 1 | 1 | `161467/182135` (88.652373240%) | `95156/182135` (52.244763500%) |

Three useful interpretations:

- At `alpha=1/2, f=1/10`, fractions can use additional work strictly below `245171/728540` of V while retaining better average efficiency. The six-chapter allowance is negative, so no admissible E works at that fixed half-benefit assumption.
- At `alpha=3/4, f=1`, six chapters have an allowance of only `8177/364270`, about 2.24476% of V. Their shorter source alone does not allow unlimited redesign/checking overhead.
- At `alpha=1`, both allowances equal the saved variable-work fractions `1-r`, irrespective of setup. An allowance of about 88.65% of V for fractions is not an 88.65% comprehension requirement or an observed production saving.

## Benefit may depend on additional work

Targeted prerequisite explanations, examples, exercise selection, accessibility, terminology work and checking can change focused benefit; poor choices can also reduce it. Extra work is not automatically a pure cost with an unchanged alpha.

Put `a(e)=G_focused(Ve)/G_full` and define `h(e)=(1+f)*a(e)-f-r-e`. The exact decision condition is `h(e)>0`, not a fixed allowance known from `a(0)`. Where differentiable, `h'(e)=(1+f)*a'(e)-1`. Extra work improves this comparator margin only when its normalized marginal benefit exceeds `1/(1+f)`. Increasing focused average efficiency has a different derivative condition, `a'(e)*(f+r+e)>a(e)`. These are marginal tests, not measured benefit curves.

For an exact hypothetical counterexample to freezing baseline alpha, take fractions, `f=0`, and `a(e)=min(1/20+2e,9/20)`. At `e=0`, the allowance `1/20-r` is negative. At `e=1/10`, alpha becomes `1/4` and `1/10<1/4-r`, so the focused option is more efficient. At `e=2/5`, alpha has saturated at `9/20` and the option is no longer more efficient. A failed baseline comparison therefore does not rule out useful additional work. Without a specified response shape, there need not be a unique crossing or a single interval that can be described as "all spending below the cap."

The ratio should be described as a conditional relative net benefit on the chosen educational outcome, not automatically as reading-comprehension retention. Its denominator must remain the same full-package benchmark. No intervention benefit, rate, reader response or monotonicity was imputed in this audit.

## Same outcome, omitted outcomes and source representation

The numerator and denominator must describe the same cohort, outcome definition, baseline/comparator and time horizon. A full collection's total educational benefit across many topics cannot silently be compared with the focused package's benefit on fractions alone. Either evaluate both on the same target endpoint or retain an explicit vector of other outcomes and any declared aggregation weights. A same-endpoint advantage does not establish superiority for a complete course, omit prerequisite dependencies, or assign zero value to outcomes not studied here.

The source protocol counts normalized extracted CNXML content module by module, using `cl100k_base`. That ratio is a stipulated proxy for variable production workload, not a measurement of translation, source editing, mathematical QA, reader effort or educational benefit. Text extraction omits some structure, layout, media and attributes; whole CNXML includes nontranslatable markup and metadata. Target-language expansion, retries, additional examples and accessible formats need not scale linearly with source tokens.

Representation can materially change even the proxy ratio. The same recorded inventory gives six-chapter/full `cl100k_base` ratios of about 47.75524% for extracted content but 50.21516% for whole CNXML. Fractions similarly changes from 11.34763% to 13.44899%. This does not identify either representation as true workload; it demonstrates why the stated content-token basis must remain visible. The recorded `o200k_base` content ratios are about 47.84567% and 11.37067%, respectively, also not identical to the chosen ratios. No tokenizer or representation sensitivity is evidence of semantic equivalence.

## Average efficiency is not indivisible fixed-budget selection

A larger benefit-per-cost ratio does not establish the best package under a particular finite budget. For example, use abstract workload units `V=100`, `f=0`, `E=0`, fractions r as above, `G_full=1`, and `alpha=1/2`. The focused package costs about 11.3476 units and has benefit 0.5, so its average efficiency exceeds the full package's `1/100`. But if the same cohort can receive only one alternative, the budget is 100, and no useful additional intervention is available, the full package fits and yields benefit 1 instead of 0.5. Savings do not automatically create another cohort or permit repeated independent benefits for the same learners.

If a smaller budget makes only focused production feasible, that establishes affordability relative to the full product, not a worldwide optimum. If useful remainder choices exist, they can reverse the comparison. Under an explicitly additive model with correct shared-cost accounting, let R denote the best attainable other benefit at each remaining budget. Focused production beats full production when

```text
G_focused + R(B-C_focused) > G_full + R(B-C_full),
```

with infeasible options excluded rather than assigned a misleading zero cost. Overlapping outcomes/cohorts, mutually exclusive packages, reusable work and interactions can invalidate simple additivity and require joint optimization. Indivisibility makes R discontinuous in budget; a ratio alone cannot settle that choice. When both costs and benefits make one option no worse and at least one strictly better, ordinary dominance can be used, but most alpha-below-one examples trade lower cost against lower total benefit.

No community, language, register, script or educational stage is excluded by this local comparison. Unknown benefit parameters remain unknown; no measured zero need or broader eligibility conclusion follows from them. The calculation can be used provisionally with declared parameters without requiring a human-dependent hold or inventing empirical evidence.

## Saved calculator and support inventory: independent result check

The final bounded extension inspected `scripts/build_focused_package_allowance_v1.py`, `structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json`, `structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json`, and the named internal-QA receipt. The builder was not executed or imported. Independent standard-library Fraction calculations and XML traversal checked the saved outputs against the source JSON and the exact eight ZIP members.

All 30 Cartesian-product cells are present exactly once: two package ratios, five alpha scenarios, and three setup scenarios. Every saved ratio, allowance, sign classification and tie calculation agrees with the independently derived formula. There are 23 positive allowances and seven negative allowances; no cell has a zero allowance. Nonnegative extra-work probes below, at and above applicable boundaries agree with both the strict ratio inequality and equality. The six added `alpha=5/4` cells are:

| f | Fractions A at alpha=5/4 | Six chapters A at alpha=5/4 |
|---:|---:|---:|
| 0 | `828003/728540` (113.652373240%) | `562759/728540` (77.244763500%) |
| 1/10 | `1692433/1457080` (116.152373240%) | `232389/291416` (79.744763500%) |
| 1 | `505069/364270` (138.652373240%) | `372447/364270` (102.244763500%) |

These positive responses to setup at alpha above one match `dA/df=alpha-1`; neither the 125% benefit nor that response is an observed effect.

All ten saved workload conversions also agree exactly with source-decimal arithmetic. For source baseline workload b per 100,000 source tokens, the common conversion is `V=b*(36427/10000)` and `F=V/10`. Fractions uses `alpha=1/2`, giving `E_break_even=b*(245171/200000)`; six chapters uses `alpha=3/4`, giving `E_break_even=b*(360551/400000)`. The focused base costs are respectively `b*(5167/12500)` and `b*(86979/50000)`. These expressions independently reproduce all saved numerators and denominators, not merely their displayed decimals.

| Source row ID | Fractions break-even extra workload | Six-chapter break-even extra workload |
|---|---:|---:|
| COMMON100K:zh-Hans | 1,645,695.184727 | 1,210,088.151838 |
| COMMON100K:hi-Deva | 1,831,448.791657 | 1,346,673.736455 |
| COMMON100K:pt-Latn | 1,632,192.424620 | 1,200,159.502733 |
| COMMON100K:id-Latn | 1,646,015.154892 | 1,210,323.427550 |
| COMMON100K:fil-Latn | 1,930,533.024734 | 1,419,530.883753 |

The table is rounded to six decimals and is illustrative workload conversion, not a ranking. Every selected row's ID and edition label matches the source. The saved list of all candidate IDs is exactly equal to the 775 source IDs in source order, has no duplicates, and includes the same unknown-audience rows. The result explicitly does not use population for the within-cohort comparison and has zero case-study need adjustment. It preserves identities, not a new empirical audience estimate.

The pinned ZIP matches its saved 1,191,697-byte size and SHA256. All eight requested CNXML members match their recorded byte counts and SHA256 values. Independent traversal of their content elements reproduces every per-module count, each distinct-image-path list, each outside-module-link list, and the aggregate totals:

| Recorded structural quantity | Verified total |
|---|---:|
| Example containers | 108 |
| Exercise nodes | 1,047 |
| Exercises containing an embedded solution descendant | 696 |
| Exercises without an embedded solution descendant | 351 |
| Try It note containers | 216 |
| Readiness note containers | 19 |
| Image-reference instances | 367 |
| Pinned content-token sum, not retokenized | 41,336 |

The partition `696+351=1047` is exact. Other rows are not disjoint quantities to add. Ancestor traversal confirms that 108 of the counted exercise nodes are inside example containers, 216 are inside Try It notes, and 19 are inside readiness notes. Each corresponding class marker in these eight files is indeed on a note element. Adding these container counts to 1,047 would double-count exercises. The 367 image-reference instances point to 362 globally distinct src strings; neither count proves that 367 distinct pictures exist, that media bytes are present, or that they have been checked for accessibility.

The exact outside-module set is `m81245`, `m81268`, `m81270`, `m81271`, `m81273`, `m81275`, `m81276`, `m81281`. These are links to inspect, not a certified complete prerequisite graph or a finding that every linked module must be included in full. Counting embedded solutions does not certify answer correctness or explanation quality; absence of an embedded solution does not prove absence of an answer elsewhere. No semantic, image, rendering, accessibility or licence-compliance certification is inferred from structural counts.

All result source bindings and both internal-QA artifact bindings match recomputed sizes and SHA256 values. No numerical or source-structure discrepancy was found. The inspected result explicitly handles the alpha(E) caveat, omitted-outcome separation and non-ranking scope described in this audit.

The following table identifies the audited pre-padding snapshot. The one-hop extension and its current artifact identities are recorded at the end of this same report; unchanged source identities above remain valid.

| Additional audited artifact, pre-padding snapshot | Bytes | SHA256 |
|---|---:|---|
| `scripts/build_focused_package_allowance_v1.py` | 11660 | `44B7A6584C50E84E12741B6100D0A630ED7F54715C6110D4F474B091E90FB9B8` |
| `structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json` | 54745 | `6757F858A3405A0581D10F49DC7AFAACC2354A2D7F7C1BF60AD4FC232AB78698` |
| `structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json` | 30108 | `B8DFC5D86BC363968A8C1E5E1E6826C484287ADC624DC25D5F57B3A100C3D81D` |
| `qa/FOCUSED_PACKAGE_WORK_ALLOWANCE_QA_v1.json` | 743 | `AD4C4F858AD79D0474ABA6E4EE78C8E3130D096E35A4DA4ADEA8FB63A3800362` |
| `structured/GLOBAL_BUDGET_SCENARIOS_v1.json` | 438221 | `CBCB5D462EBBF2C857B918E7DB85C3C558B9D3A60B4DEF8922FD7CE817E18D57` |
| `sources/openstax_scale_20260904/prealgebra2e_cnxml_source_only.zip` | 1191697 | `E9020DA36693D94C0F16FA9CA0025531551E285B5C654BE02E42C85D0679D44A` |

## Deterministic verification and conclusion

Standard-library exact Fraction arithmetic reproduced all 24 originally requested allowance entries and all 30 final saved calculator cells. A 195-point rational check over both r values, `f=0,1/10,1`, positive/zero/negative alpha, and extra-work values below, at and above admissible boundaries verified the three-way efficiency/allowance equivalence. The same check verified the reversed direction for negative full benefit and the direct zero-full-benefit sign test. The final saved-output extension independently verified all ten workload conversions, 775 retained IDs, eight pinned module hashes and all structural totals. The analytic derivation, rather than finite sampling, establishes the general inequality.

The formula is ready to use as a transparent conditional average-efficiency test. Its primary implementation obligations are preserving strict ties and negative allowances, identifying the source-token representation, not freezing an E-dependent benefit response, accounting correctly for common or sunk setup, and separating this local efficiency result from full-course value and fixed-budget portfolio choice. This report creates no production, publication or full-research completion claim.

## Final bounded delta: one-hop source padding

The implementing task added `one_hop_padding_scenario` to the result and inventory. This addition was independently verified without rerunning the builder or tokenization. The eight padded module identities are exactly the already verified directly linked outside-module set, are unique, and are disjoint from the original eight fractions modules. Each additional CNXML member was read from the same hash-verified archive; its byte count, SHA256, pinned path, title and URL match the source-scale record and saved padding inventory.

The inherited content-token counts are:

| One-hop module | Pinned content tokens |
|---|---:|
| m81245 | 4,681 |
| m81268 | 7,104 |
| m81270 | 5,874 |
| m81271 | 4,640 |
| m81273 | 6,901 |
| m81275 | 6,188 |
| m81276 | 4,784 |
| m81281 | 6,147 |
| Total additional source | 46,319 |

The exact sum is `4681+7104+5874+4640+6901+6188+4784+6147=46319`. Adding the original `41336` gives `87655` content tokens, and

```text
r_padded = 87655/364270 = 17531/72854
         = approximately 24.0631948829% of full source content.

A_remaining = (1/2)*(11/10) - 1/10 - 87655/364270
            = 152533/728540
            = approximately 20.9368051171% of full variable workload V.
```

This is also exactly the original fractions allowance minus the priced padding: `245171/728540 - 46319/364270 = 152533/728540`. Thus padding is counted once, not made free or double-charged. The remaining amount is a strict bound on further extra work after those eight modules are priced under the same linear proxy; equality ties efficiencies. Exact probes at zero, half the bound, the bound and above it reproduce the original benefit-per-workload comparison.

The alpha=1/2 scenario must describe final benefit after padding and any further work. Neither 24.06% source size nor the approximately 20.94% remaining allowance measures learning or guarantees retained benefit. This is **one-hop padding, not full dependency closure, and not a claim that every included module is compulsory**. Links from the added modules were not recursively expanded. Additional prerequisites, media, missing explanations, checking, accessibility and delivery work remain separately priced, and there is no offline-completeness assertion. The original structural counts still describe the original eight fractions content elements, not a combined sixteen-module exercise inventory.

The current 30 cell identities, ten workload-conversion arithmetic results and all 775 ordered candidate IDs were rechecked and remain consistent with the earlier audit. Current result, source-inventory and internal-QA bindings match recomputed hashes. No discrepancy was found in this delta.

| Current artifact after one-hop addition | Bytes | SHA256 |
|---|---:|---|
| `scripts/build_focused_package_allowance_v1.py` | 13278 | `CB8B8888B8B786DB69B66409BF4F22BEA1524077C745B057F22A9E7BD107DF53` |
| `structured/FOCUSED_PACKAGE_WORK_ALLOWANCE_v1.json` | 55539 | `99E4017FC91BD433E24EEA6AD9A051D81296392CD15D51A4757F52BD4A122BC0` |
| `structured/OPENSTAX_FRACTIONS_SUPPORT_INVENTORY_v1.json` | 34051 | `61088618CCF3C3C1A32E4D68EB4F9BAC115D354CB74DAE675E6816475A98CD86` |
| `qa/FOCUSED_PACKAGE_WORK_ALLOWANCE_QA_v1.json` | 743 | `FCD7DFD1BFB0BF926BB717AB38B232A17F050ABFBCAD272FC09D1162C56D67FE` |

Final audit status remains PASS for exact conditional arithmetic and the specified structural/hash checks, with all educational-effect, source-representation and portfolio limitations retained. No additional report or production artifact was created.
