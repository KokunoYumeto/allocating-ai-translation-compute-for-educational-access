# Vocational package allocation: independent review closeout

Date: 2026-09-08. Result: **PASS. Finding F1 is closed for the exact revised artifacts below. No remaining defect was found in this delta-only scope.**

## Scope and artifact identities

This closeout checks only the clarification of incremental benefit/workload versus constrained total benefit, the new finite two-resource example, and the corresponding builder/JSON changes. The original review is preserved unchanged. No study was re-audited, no global model or production builder was run, no new source was read or downloaded, and no agent was spawned. Only this closeout file was authored.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `VOCATIONAL_PACKAGE_ALLOCATION_v1.md` | 15,475 | `4EE72DC7A7E2D0247D3621F0EE0E2448FF01BF6212D33E2078744259E8D3D00E` |
| `structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json` | 15,203 | `9D86A95A6D3DAC6AD117D0A52B05F5B9B3CA11AB3894EC463F85D5D5520B451B` |
| `scripts/build_vocational_package_allocation_v1.py` | 11,259 | `B47818F9F06E97A586FA83F91D1A48887E1B4D103C27C014B67ACFFDE99063C3` |
| Original `qa/VOCATIONAL_PACKAGE_ALLOCATION_INDEPENDENT_REVIEW_v1.md` | 10,369 | `97EB8556A9A749C7A4043BD0C9A072CF3D7655DE8EFF6DAF8E9F2816167660AB` |

The revised JSON hash matches the exact identity supplied in the closeout request. The original review hash matches its previously recorded identity.

## F1 correction: PASS

Markdown line 64 now explicitly distinguishes unequal-cost **incremental benefit per production-workload unit** from the best total-benefit portfolio under hard budgets. It identifies indivisibility, unused budget, and the separate delivery constraint as reasons to compare feasible portfolios. The JSON `comparison_kind` fields carry the same limitation for every threshold.

Independent exact-rational checks confirm that the audience thresholds remain 5/8, 5/4 and 5/2 for production-workload ratios 1/2, 1 and 2, since each equals `(3/4) * workload_ratio / (3/5)`. These are appropriately labeled efficiency comparisons, not a general optimizer. The equal-workload threshold also compares total benefit under the stated common-endpoint scenario.

## Finite two-resource example: PASS

The two actions are:

| Action | Production | Delivery | Additional benefit |
|---|---:|---:|---:|
| Add support | 1/2 | 1 | 9/20 = .45 |
| New edition | 1 | 1/4 | 3/4 = .75 |
| Both | 3/2 | 5/4 | 6/5 = 1.20 |
| Neither | 0 | 0 | 0 |

The support benefit is `.75 * .60 = .45`; its production-efficiency ratio is `.45/.50 = .90`, versus `.75/1 = .75` for the new edition. The two cohorts are expressly disjoint and benefits are incremental, so adding the two action benefits is consistent with the disclosed example rather than double-counting readers.

A separate read-only calculation using exact rational arithmetic enumerated all four action subsets under every budget pair, checking all 16 portfolio records, all resource sums, feasibility flags and selected maximizers. Results match both Markdown and JSON:

| Production budget | Delivery budget | Unique best feasible subset | Additional benefit |
|---|---|---|---|
| 1/2 | 1 | Add support | 9/20 |
| 1 | 1 | New edition | 3/4 |
| 3/2 | 1 | New edition | 3/4 |
| 3/2 | 5/4 | Both | 6/5 |

At the third budget pair, both actions fit production but exceed delivery; at the fourth, both constraints permit them. At the second pair, the more production-efficient support action yields less total benefit than the feasible new edition. This correctly demonstrates the distinction raised in F1. The inspected builder performs finite enumeration with `Fraction` values and applies both resource constraints before selecting the largest benefit; it does not substitute a ratio sort for this maximum.

## Interpretation and boundaries: PASS

Markdown lines 66-75 explicitly label the cohorts and costs hypothetical and normalized, not actual population, money, compute, empirical effects or a global portfolio. JSON marks every scenario `empirical: false` and declares that units are not money or measured compute. The new example introduces no language exclusion, review/measurement prerequisite or human-dependent gate. Exact finite arithmetic is not promoted to empirical educational-effect evidence.

This closes F1 without altering the earlier study-fact findings. The original review's limits still apply: OpenStax source-scale observations and global artifact identities were outside that review's permitted verification scope and were not newly certified here. No claim is made that the worldwide allocation objective is complete.
