# Independent content check: consolidated working paper v0.10, sections 7.14–7.15

8 September 2026. Status: PASS within the bounded content-integration scope. No substantive numerical or source-qualification discrepancy was found. This is not a full-paper, worldwide-ranking, rendered-format or publication audit.

## Scope and method

Read the complete new sections in `PAPER_CURRENT_DRAFT.md`, their cited reference entries, both component reports and their structured calculation outputs. Read the two trial-extraction records, the Philippine field specification, the joint-calculation QA receipt and the earlier independent method review including its delta. Independently recomputed the values actually displayed in these two sections without invoking either author's builder. Source-extraction receipts were compared as records of previous primary-source consultation; this check did not reopen the original articles, survey questionnaire or live websites, rerun regressions, obtain microdata or repeat the earlier exhaustive 819/3,025-case audit.

All file identities below were freshly hashed. Only this review file was created. No source, manuscript, calculation, ranking or public file was changed.

## Section 7.14: practical business education

The 1,193-person assignment sample agrees with the Dominican extraction record: 387 control + 402 conventional accounting + 404 practical rules. The 15- and 18-hour schedules agree with five and six three-hour sessions; three common introductory sessions and instructor, handout and homework support are retained. The p = .195 pooled business-practice-index contrast and p = .014 cash-separation contrast match the named primary table extraction. The manuscript distinguishes these results from mastery, demonstrated profit gains and unattended-translation effects, and retains the observed-business-owner and attrition qualifications.

The Hiligaynon eligibility language and explicitly costed Hindi and Kannada recordings match the mobile-study record. Urdu is retained as eligible without fabricating a separately established recording or language-specific effect. The manuscript does not convert the Dominican location into verified Spanish delivery. It does not turn the mobile study's practice-index result into a proportion of learners understanding, and it correctly avoids claiming higher regular-week profits.

Every displayed audio and conditional-allocation number agrees with the reports and JSON. Independent recomputation gives:

| Quantity | Independent result | Manuscript result |
|---|---:|---:|
| 73 minutes at 24,000 bits/second, decimal MB | 13.14 MB | 13.14 MB |
| 85 minutes at the same bitrate | 15.30 MB | 15.30 MB |
| 81 minutes at the same bitrate | 14.58 MB | 14.58 MB |
| Equal-benefit retention at fivefold distinct reach | 1/5 = 20% | 20%; strictly more to improve benefit |
| Download 0.40; support reaches half with total benefit 1.00 | 0.40 + 0.50 × (1.00 − 0.40) = 0.70 | 0.70, not 0.90 |

The USD 2.04, 2.38 and 14.99 figures preserve the respective Hindi, Kannada and Philippine route ordering, historical full-listening airtime scope and distinction from full delivery or compute cost. File sizes are explicitly engineering scenarios, not trial downloads or intelligibility observations. Production and delivery budgets remain separate. Conditional effects are not represented as actual new-language estimates. Neither trial samples nor whole-language populations are treated as the vocational beneficiary count.

The practical package is a proposed distinct educational product, not an abridged translation of a full accounting source. Deeper accounting remains available for its own objective. Exact-language leads do not become a new worldwide language ranking, and missing evidence does not remove other communities.

## Section 7.15: joint audiences and allocation

The intersection expression is correct for compatible exact person totals: nonnegative cells require `max(0,A+B−N) ≤ X ≤ min(A,B)`. An independence value is identified as a scenario, not a measured intersection. Disjoint, exhaustive strata can tighten the interval; no actual survey audience is asserted.

Independent numerical checks reproduce the manuscript:

- Aggregate N = 100, A = 40, B = 30: bounds [0,30] and independence 12.
- First region (50,35,20): [5,20]; second (50,5,10): [0,5]; summed bounds [5,25].
- Within-region independence: 35 × 20 / 50 + 5 × 10 / 50 = 14 + 1 = 15.
- Both endpoint tables printed in the component report are nonnegative and preserve the stated margins.
- With costs 2, 2 and 1 and budget 3, all affordable selections are empty, target, alternative, third, target plus third, and alternative plus third. Their benefits are 0, X, 20, 6, X+6 and 26. X = 5, 12 or 15 selects alternative plus third at 26; X = 20 retains both tied combinations at 26; X = 25 selects target plus third at 31.

The common positive reach-times-additional-benefit factor normalized to one makes the synthetic benefit units explicit. These are not physical compute or observed learning. A zero lower bound is expressly distinguished from zero need, and the upper-endpoint possible winner remains eligible.

The manuscript's survey descriptions stay within the component reports: IHDS respondent-associated mother tongue is not per-person academic proficiency; the Philippine language concept is household home language. Neither data-access check produced analysis-ready joint records. Historical period, updating requirements and missing national entrepreneur/learner counts are disclosed. The summary does not invent retail category codes, personal proficiency or completed record linkage.

Weight rescaling leaves `sum(w×I)/sum(w)` invariant but changes its numerator; absolute totals therefore need an established expansion scale or compatible calibration. WT versus household-size-multiplied INDWT and unique-person handling match the cited IHDS documentation as recorded in the component report. Missing membership is not recoded false. The stated 26 checks, 819 marginal combinations and 3,025 stratum pairs match the named QA receipt. The earlier independent review documents independent enumeration and the subsequent three added rejection checks. This integration check does not claim to have reexecuted that exhaustive suite or validated survey keys, weight provenance, population representation or real effects.

## References and small editorial observations

Every author-year citation in these sections has the corresponding manuscript reference: Drexler, Fischer, and Schoar (2014); Cole, Joshi, and Schoar (2024); Desai and Vanneman (2018); the NCAER/University of Maryland questionnaire; Lazaroff's guide; the IHDS FAQ; and Philippine Statistics Authority 2024a/2024b. Titles, DOI strings and field-specific URLs agree with the reports. The PSA POPWGT reference 2024c appears in the component report, but is neither cited nor needed for a PSA-weight assertion in the main section; no orphan 2024c citation was found in these sections. Both headings are at the same `###` hierarchy level as sections 7.1–7.13.

Two optional precision edits would reduce possible ambiguity without changing any finding:

1. In 7.14, “full-sample index contrast” could be “pooled index contrast among observed business owners.” The next sentence already limits the analysis to observed business owners, so the current paragraph does not claim outcomes for all randomized participants; the alternative makes that limit immediate.
2. In 7.15, the census dictionary “similarly links household home-language and work-industry concepts” could say “lists household home-language and work-industry fields in the same survey file.” This would distinguish co-presence of field definitions from the uncompleted empirical record linkage. The current next sentence already states that joint records were not obtained.

Neither observation is a new evidence gap or a reason to delay publication of the correctly qualified findings. Any subsequent manuscript edit changes its hash and needs only a bounded delta check of that edit.

## Reviewed file identities

Relative paths are rooted at this research directory. The full manuscript was hashed; its reviewed content was limited to sections 7.14–7.15, their heading context and cited references. The other listed text/JSON files were read completely.

| File | Bytes | SHA-256 |
|---|---:|---|
| `PAPER_CURRENT_DRAFT.md` | 293807 | `7ABCB2A3711E2235401F5CA4D111F3E15EC167A7102BD08551145444FC4F27AA` |
| `VOCATIONAL_PACKAGE_ALLOCATION_v1.md` | 15654 | `2E27A014E15FFDDC98002681D7E3C30BFCC28D65E70DBAB8A6F915E5FD4D1EB6` |
| `AUDIENCE_JOINT_ALLOCATION_v1.md` | 15514 | `653A694059FADF4BAFA83250E81036013B82165FAC822E98D92A90767F0C7174` |
| `structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json` | 15203 | `9D86A95A6D3DAC6AD117D0A52B05F5B9B3CA11AB3894EC463F85D5D5520B451B` |
| `structured/AUDIENCE_JOINT_ALLOCATION_v1.json` | 4075 | `7BFE2CF463090631138E1FD6FBDA62AA412E7A244513A4AA1096A391655A5FA9` |
| `structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json` | 9175 | `E25B4A5F493FA40332388018E21CD221083587437F7A5CB9D9BDA2C0F8826395` |
| `structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json` | 16194 | `9D729FA2789AB48959336CA61B23CD86EAA9A84AAF59ACBC51B938698C754107` |
| `qa/AUDIENCE_JOINT_ALLOCATION_QA_v1.json` | 1420 | `AEBCEBFE1F4CD96578B1B08C6AF1A3D708A369F24036227FFF472218427FB254` |
| `PSA_BUSINESS_JOINT_FIELD_SPEC_v1.md` | 12470 | `D2B84CB68283DE7423BB001640048859ED95C4E2B5F80FE9320FCF865A528AD5` |
| `qa/AUDIENCE_JOINT_ALLOCATION_INDEPENDENT_REVIEW_v1.md` | 11385 | `46DE466B0BB635635AD8233FBAF0E721021E9ACEDC48DCA9D7DABDE44ADA6410` |

Conclusion: the new sections faithfully integrate the checked component results and retain their inferential limits. Their correctly scoped contribution is a vocational resource choice and an audience-evidence allocation method, not completion of the global allocation study.
