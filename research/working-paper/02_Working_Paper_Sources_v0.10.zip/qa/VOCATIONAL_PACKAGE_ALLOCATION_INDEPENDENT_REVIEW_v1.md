# Independent review: vocational package allocation v1

Date: 2026-09-08. Result: **PASS for checked primary-study facts and exact arithmetic; one allocation-interpretation finding (F1) requiring a local clarification.** This is a completed bounded review, not a human-dependent gate or a certification that the global allocation problem is solved.

## Exact scope and method

Read only the six assigned analysis/evidence files listed below, plus the exact mobile-study PDF, printed pp. 583-590 (PDF pages 4-11). No global model was run, no global baseline or publication artifact was opened, no new agent was spawned, and no file other than this review was changed. The main builder was read but not executed because it writes outputs and reads artifacts outside this audit's scope. Instead, a read-only independent check used exact rational arithmetic for the allocation formulae and payload sizes.

| Inspected file | Bytes | SHA-256 |
|---|---:|---|
| `VOCATIONAL_PACKAGE_ALLOCATION_v1.md` | 13,887 | `55C816352658056048C010BA88A71AE600BA69AF9FD3A7BB02B7C0F41618817F` |
| `structured/VOCATIONAL_PACKAGE_ALLOCATION_v1.json` | 9,253 | `BB63D8F590C5BF0708B08A70CDBF7F8F89433A3B683A70B3D278A79119B8D9B6` |
| `scripts/build_vocational_package_allocation_v1.py` | 8,715 | `68F48ABD8737B109F3E97A520030F71C28F1E3142042EE08B488D2731A3E7E52` |
| `VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.md` | 10,893 | `3405DCD996FAFF72EDAE33843549F45E6F86C6EAC7DB7AC30A5065464D853D72` |
| `structured/VOCATIONAL_FINANCIAL_PACKAGE_EVIDENCE_v1.json` | 16,194 | `9D729FA2789AB48959336CA61B23CD86EAA9A84AAF59ACBC51B938698C754107` |
| `structured/MOBILE_BUSINESS_EDUCATION_EVIDENCE_v1.json` | 9,175 | `E25B4A5F493FA40332388018E21CD221083587437F7A5CB9D9BDA2C0F8826395` |
| `sources/mobile_business_20260908/Cole_Joshi_Schoar_2024_Heuristics_on_Call.pdf` | 995,986 | `7C7732F7D44B21F4652A3A4FEB0F50C4595CB9F0050FDBBFCD76142082576E31` |

The two evidence-input identities embedded in the allocation JSON match the inspected files. The mobile PDF identity matches its evidence record. The Dominican extraction remains byte-identical to the prior completed primary-PDF/table audit; its numerical provenance was not re-created from memory.

## F1: distinguish efficiency thresholds from the constrained total-benefit optimum

Location: allocation Markdown line 64; JSON `support_vs_new_edition_thresholds`; builder's `n_support*(1-r)/C_support > n_new*other_yield/C_new` comparison.

The three thresholds are arithmetically correct for **incremental benefit per unit of production workload**:

`n_support/n_new > (0.75/0.60) * (C_support/C_new)`.

Consequently the ratios 0.625, 1.25 and 2.5 are correct for workload ratios 0.5, 1 and 2. But the prose says what it takes for support to beat a new edition immediately after defining the objective as total benefit subject to separate production and dissemination budgets. At unequal costs, these are not generally the same choice criterion.

Concrete counterexample, using only the disclosed scenario:

- New edition: audience 1, effect 0.75, production cost 1; total benefit 0.75.
- Extra support: audience 0.75, incremental effect 0.60, production cost 0.5; total benefit 0.45.
- Support's audience ratio 0.75 exceeds the displayed 0.625 threshold and its benefit/workload ratio is 0.90 versus 0.75.
- Nevertheless, with production budget 1, nonbinding dissemination cost, and these two indivisible mutually exclusive options, the new edition yields more total benefit. Selecting support leaves unused budget; the efficiency ranking alone does not solve that problem.

Recommended local correction: explicitly label these as **marginal benefit-per-production-workload thresholds**, not a complete optimizer. State the conditions needed to use that ranking for an allocation decision (for example, scalable/divisible opportunities with the relevant production resource binding and dissemination already accommodated), or compare feasible total-benefit portfolios directly. With two binding resources, a single unweighted workload ratio is insufficient. The equal-workload threshold of 1.25 is already a valid total-benefit comparison under the stated common-endpoint assumptions.

This is a model-interpretation finding, not a numerical-error finding. It does not require new empirical observations or human review; it can be repaired directly in prose and structured labels. No fixes were made outside this review.

## Primary-study attribution: PASS within scope

- Dominican allocation statements match the evidence: 1,193 assigned clients; 15 versus 18 scheduled hours; common introductory sessions and material/instructor support; practice-index estimates 0.14 versus 0.07 with equality p=.195; cash-separation estimates 0.08 versus 0.00 with equality p=.014. The text correctly limits the estimand to observed endline business owners and does not claim a universal practical-course advantage. It does not relabel index units as percentages, comprehension, profits, or translation effects.
- Mobile delivery is genuinely bundled with an initial 30-minute orientation, local-language handouts and weekly voice messages (printed p. 583). The four proposed business topics correspond to the source curriculum. The extra Indian supplier-related message is supported by p. 583, note 6; it is not generalized into a universally valid business rule.
- Recruitment totals 2,096 and 3,849 are supported by pp. 584-585. They are not used as occupational population estimates or global language denominators.
- Table 3, p. 590, confirms three-point practice-index effects 0.037 (p=.006) and 0.021 (p=.027), and binary-index effects 0.019 (p=.010) and 0.010 (p=.058). The allocation text preserves the Indian binary result's p=.058 and does not call it significant at .05.
- The no-established-increase wording for regular-week profits is accurate: Table 3 prints Philippine level effect -91.640 (p=.392), Indian level effect -11.976 (p=.943); log-profit results also fail to establish increases. This wording is not a claim of exactly zero economic effect.
- Independence, translation-only effects, direct comprehension and full accounting mastery are not identified by these interventions. The proposed downloadable edition and the 40%/75% effect assumptions are clearly identified as design/scenario choices, not observed treatment effects.

Primary mobile source: [Cole, Joshi, and Schoar, World Bank PDF](https://documents1.worldbank.org/curated/en/099149308012421075/pdf/IDU198cbc1df1421614add1b901130eab4fc86f8.pdf), DOI [10.1093/wber/lhad038](https://doi.org/10.1093/wber/lhad038). Direct inspection in this pass used PDF text extraction, not a new rendered-table QA claim. The source evidence record separately records its earlier visual checks.

## Exact languages and eligibility: PASS

The source explicitly names Hiligaynon eligibility in the Philippines and Kannada/Hindi/Urdu eligibility in India (p. 584). Combined with p. 583's local-language delivery statement, Hiligaynon is a supported Philippine audio-route attribution. The cost paragraph explicitly distinguishes Hindi and Kannada recordings but does not separately establish an Urdu recording or Urdu-specific effect. The allocation prose preserves that difference. The pooled Indian outcome coefficients are not presented as separately estimated effects for each Indian language.

The Dominican delivery language remains unverified rather than being inferred as Spanish. Urdu and all other languages remain eligible; no observed-study, occupational, literacy, age, comprehension, expert-response or local-project-completion condition is used to delete a language or reduce global need. Support is optional and not a prerequisite for producing the independent edition. The script's `independent_review_pending` metadata is not used as an execution or human-approval gate in the inspected code.

## Independent arithmetic: PASS, 29 checks, zero failures

The read-only check covered four evidence-file hash/size checks, nine audio calculations, five frontier calculations, three nested-benefit calculations, three overcount calculations, three workload-efficiency thresholds and two contact-hour calculations.

| Calculation family | Independently confirmed values |
|---|---|
| Hiligaynon payload, 16/24/32 kbps | 9.72 / 14.58 / 19.44 decimal MB |
| Hindi payload, 16/24/32 kbps | 8.76 / 13.14 / 17.52 decimal MB |
| Kannada payload, 16/24/32 kbps | 10.20 / 15.30 / 20.40 decimal MB |
| Break-even retained benefit, reach multipliers 1/2/3/5/10 | 1 / 1/2 / 1/3 / 1/5 / 1/10; 33.33% is the displayed rounding of 1/3 |
| Nested audiences, supported shares .1/.5/1 and initial effect .4 | .46 / .70 / 1.00 total; naive overcounts .04 / .20 / .40 |
| Benefit/workload audience thresholds at cost ratios .5/1/2 | .625 / 1.25 / 2.5, subject to F1's interpretation |
| Contact time | 6 x 3 = 18; 5 x 3 = 15; proportional reduction (18-15)/18 = 1/6 |

The payload formula correctly converts kbps to bits per second and uses decimal MB. It does not establish codec quality, accessibility or intelligibility. Historical airtime facts are directly supported by p. 584 and note 8: Hindi 73 minutes/USD 2.04, Kannada 85/USD 2.38, Philippines 81/USD 14.99. The totals assume complete listening; they are not current tariffs or complete delivery-program costs.

## Explicit audit limits

The OpenStax counts (282,065 tokens, 194,805 core tokens and 131 modules), source commit, book scope and title-specific licensing cannot be independently certified from the six assigned records. Their named supporting files and source were outside the permitted read scope, so they were not opened. They are correctly described as workload observations rather than learning effects in the inspected prose. This is a scope limitation, not an invented discrepancy or a human-dependent hold.

Likewise, the global-file identities embedded by the builder were read as metadata only, not independently verified against those global files. No global model, world-audience estimate, publication state or unchanged-file assurance beyond the inspected files is certified by this review. All conclusions apply to the hashes above. The next executable action is the small F1 labeling/assumption correction and regeneration of the affected bounded allocation outputs, not a global recomputation or another empirical gate.
