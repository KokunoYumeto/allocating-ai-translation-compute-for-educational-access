# From language populations to audiences for particular educational resources

Research calculation, 8 September 2026. This is a component of the worldwide compute-allocation study, not a replacement for its ranked comparisons. The numerical examples below are synthetic. No new Indian or Philippine learner-population estimate has been calculated.

## What changes the allocation decision

The number of people who use a language is a useful starting point for an access comparison. It is not automatically the audience for every resource in that language. A practical retail-accounting course, a secondary algebra course and a research monograph have different immediate audiences. Their broader and future audiences can also matter, but must be named rather than silently included in a worker or enrolment count.

The initial language-community population times its academic-English-nonaccess share remains a screening scenario. This study preserves it wherever equivalent evidence is missing. The following analysis adds information about particular packages; it does not remove a language from the worldwide comparison or infer that people outside a selected occupation cannot benefit from education.

The concrete methodological result is that separately published population totals do not determine a joint audience. Multiplying a language share by a national business count introduces an independence assumption. It can produce a different compute allocation from another equally feasible arrangement of the same people. Better evidence can narrow the uncertainty, while a disclosed reference scenario still permits provisional allocation now.

## 1. Compatible units before multiplication

A usable count identifies its unit, reference period, geographic and population coverage, language measurement, stage or practical role, and missing-value treatment. Household language, individual language proficiency and academic-register access are distinct observations. Likewise, people, households, establishments, enrolments, devices and downloads cannot be exchanged just because each is a count.

For a retail-resource audience, distinguish owners, decision-makers, employees, unpaid family workers, people preparing to start a business, and other interested learners. A narrow decision-maker cohort is a testable intervention route, not the only legitimate audience. Reporting both narrow and broader routes is preferable to silently changing the definition to obtain a larger number.

The same principle applies to interlanguages: membership in a language family is not an observed reader pool. A shared edition can nevertheless remain a positive scenario with explicit comprehension, script, subject-background and overlap assumptions. Those assumptions belong in the calculation, not in an eligibility veto.

## 2. What separate totals identify

Suppose N people form one defined population. A of them satisfy a language condition and B satisfy a package-audience condition. If X satisfy both, the four table cells are X, A-X, B-X and N-A-B+X. Nonnegativity gives the sharp bounds:

`max(0, A+B-N) <= X <= min(A,B)`.

Every integer between these limits has a feasible table. The familiar expression `A*B/N` instead supplies an expected, possibly fractional reference table under independence. It is not a measured intersection: for N=3 and A=B=1 it gives 1/3, although an actual intersection contains zero or one person. With N=0, the intersection is zero and the independence fraction is undefined.

If the population is divided into disjoint, exhaustive strata, apply the bounds within each stratum and add the results. The summed lower bounds cannot be below the aggregate lower bound, and the summed upper bounds cannot exceed the aggregate upper bound. This can tighten uncertainty without assuming independence. Overlapping administrative groups, differently dated totals, or incompletely represented strata do not satisfy this result as stated.

### Exact example: the allocation can reverse

All counts in this example are invented for demonstration; none represents a named country or language.

| Population segment | Total N | Language condition A | Occupational condition B | Possible joint audience |
|---|---:|---:|---:|---:|
| Region 1 | 50 | 35 | 20 | 5 to 20 |
| Region 2 | 50 | 5 | 10 | 0 to 5 |
| Combined | 100 | 40 | 30 | 5 to 25 using regional information |

Without the regional information, the bounds are 0 to 30. National independence gives 12; independence within the two regions gives 15. Neither assumption establishes the actual value. Regional endpoint tables `(both, language only, occupation only, neither)` are:

- Lower endpoint: `(5,30,15,0)` and `(0,5,10,35)`, total joint audience 5.
- Upper endpoint: `(20,15,0,15)` and `(5,0,5,40)`, total joint audience 25.

Now give the targeted resource a cost of 2, an alternative resource cost 2 and audience 20, and a third resource cost 1 and audience 6. The budget is 3. Assume distinct beneficiaries across these resources and a common positive reach-times-additional-benefit factor, normalized to one. Audience values then equal normalized benefit values in this example. These are arbitrary cost units, not tokens, money or physical compute.

| Joint audience of targeted resource | Best affordable selection | Total additional-benefit units |
|---:|---|---:|
| 5, feasible lower endpoint | Alternative plus third resource | 26 |
| 12, national independence | Alternative plus third resource | 26 |
| 15, within-region independence | Alternative plus third resource | 26 |
| 20 | Both combinations tie | 26 |
| 25, feasible upper endpoint | Targeted plus third resource | 31 |

Thus the targeted resource is a possible winner even when a common reference scenario selects another resource. The missing joint measurement has a decision consequence; it is not a reason to erase the option. Nor is a zero lower bound evidence of zero educational need. Selecting only by lower bounds would impose an additional pessimistic policy, not follow from these data.

This example isolates audience uncertainty. In the real allocation, replace audience by additional educational benefit on an explicit outcome, allow delivery and production costs to differ, and account for intersecting beneficiaries. A person can benefit from more than one resource; deduplicate the same access gain, not all learning by that person. Counts of newly helped people and amounts of learning are different objectives and should be reported separately rather than mixed.

## 3. Joint Indian survey route

IHDS-II supplies a relevant historical route, not a current audience estimate. The pinned questionnaire identifies `SN1` as respondent-associated mother tongue; Hindi is 01 and Kannada 07. It is not a per-person language-proficiency item. Business industry fields are `NF1a/NF21a/NF41a`; decision-maker IDs are `NF15/NF35/NF55`. The roster uses `RO5` for age, `RO6` for marital status and `RO7` for primary activity. The business decision-maker need not be a working household member, and `OH1b` identifies the main interview respondent without proving who answered SN1 (NCAER & University of Maryland, n.d., printed pp. 4, 14-16, 28, 32).

Consequently, the proposed route is unique adult retail decision-makers associated with a specified household/respondent language. Decode business categories from the actual released codebook; no retail code has been verified here. Count a person once across business slots. Do not require a primary-activity business code, employment in the business, or matching the main interview respondent. Such restrictions would change the audience; respondent matching can be a separately labelled sensitivity analysis. Keep other languages, unspecified language text and missingness in the output, rather than folding them into Hindi or Kannada.

The official guide describes 42,152 households in the 2011-12 wave and excludes Andaman and Nicobar and Lakshadweep from survey coverage. Its within-wave household key uses `STATEID, DISTID, PSUID, HHID, HHSPLITID`, or the equivalent `IDHH`; individual linkage also needs the documented person identifier. For individual cross-sectional analysis it recommends `WT`. Household-file `INDWT` already multiplies weight by household size (Lazaroff, n.d., sections II, V-VI). Using INDWT on every individual would multiply household size again. Linkage cardinality and missing IDs require checks before producing the affected estimate. Survey exclusions do not exclude those communities from global educational need.

The public catalogue identifies version 6, released 8 August 2018, DOI `10.3886/ICPSR36151.v6`. These are historical data; applying historical joint shares to current populations requires an explicit stability or updating model, not a silent date change (Desai & Vanneman, 2018).

## 4. Relative weights are not automatically population counts

For decoded unique-person records with known cohort indicator I and positive weight w, the weighted cohort share is `sum(w*I)/sum(w)`. Multiplying every weight by the same constant leaves this share unchanged. It does not leave the numerator unchanged.

In the synthetic test, selected people have weights 2 and 3 and a nonselected person has weight 7. The selected mass is 5 of 12, a share of 5/12. Scaling all weights by 100 gives 500 of 1,200 and exactly the same share. Neither 5 nor 500 can be called a national learner count merely because a field is named weight.

Use absolute weighted totals only when the release establishes an expansion scale and coverage. Otherwise an absolute count additionally needs a matched population calibration. The calibration must have the same period, coverage and eligible population as the estimated share. A separate-language population should not multiply a share whose denominator is all adults unless the conditioning is explicitly transformed. Sampling uncertainty, missing cohort membership and transfer across years remain separate from the arithmetic.

The inspected IHDS documentation establishes which weight to use, but this check has not established its numerical expansion scale from released records. Its FAQ also warns that missing-value treatment is module-specific and that wave variable names can change. A recoding recommendation for illness or behaviour modules is not a warrant to turn missing mother tongue or decision-maker identity into zero (India Human Development Survey, n.d.).

## 5. Philippine route and unfinished inputs

PSA's 2020 CPH Form 3 dictionary independently provides a household home-language field `H13`, work-industry field `P22` for the previous twelve months, and a `POPWGT` field. These establish a joint-variable lead, not individual language proficiency or a successfully extracted entrepreneur count. The detailed field report records unresolved category codes, person/household keys, age detail and weight properties; no numeric code is borrowed from another census (Philippine Statistics Authority, 2024a, 2024b, 2024c).

The ordinary-access checks did not obtain analysis-ready joint records: the IHDS download and online-analysis routes required sign-in, and the PSA microdata route required registration. No account was created or access control bypassed. These are limits of the present extraction, not evidence against the educational proposals. The study continues using explicitly conditional audience scenarios and already accessible evidence; no participant or reviewer response is required.

## 6. Reproduction and consequences for the worldwide study

`scripts/build_audience_joint_allocation_v1.py` produces `structured/AUDIENCE_JOINT_ALLOCATION_v1.json` and `qa/AUDIENCE_JOINT_ALLOCATION_QA_v1.json`. It runs 26 checks, including exhaustive sharp-bound verification for 819 small count triples, stratification containment for 3,025 pairs of small strata, exact budget selections and ties, incompatible-unit rejection, nonblank/unique-person-key checks and weight-scale invariance. Fractional reference scenarios cannot pass the integer-witness helper. These tests validate this synthetic arithmetic, not the survey coding, population representativeness or real educational effects.

The helpers are not a raw-survey importer. Stratum compatibility and exhaustive coverage are caller-validated preconditions; a boolean declaration does not prove them. A person-labelled row does not establish the origin of its weight. Rejecting missing or duplicate keys is not proof that the remaining keys identify the intended people. The known-membership share helper rejects unknown membership; the next operation must carry it into a separate bounded/scenario analysis, never discard the affected people.

The next substantive allocation input should be a named language/register-and-package cohort, with an explicit conditional reference value and feasible alternatives. Preserve the worldwide baseline while supplementing it with these package-specific quantities. Source-backed language access, currently usable educational supply, uptake, incremental understanding and cost must then be applied with their actual conditioning. The same logic applies to academic-English access, phone use, school stage, occupation and interlanguage comprehension: separate marginal percentages cannot silently be multiplied into a measured beneficiary population.

This result neither changes the current global Top 100 nor completes the worldwide allocation study. It defines and tests how new audience evidence may legitimately change future package and portfolio comparisons.

## References

Desai, S., & Vanneman, R. (2018). *India Human Development Survey-II (IHDS-II), 2011-12* (Version 6) [Data set]. Inter-university Consortium for Political and Social Research. https://doi.org/10.3886/ICPSR36151.v6

India Human Development Survey. (n.d.). *Frequently asked questions*. Retrieved September 8, 2026, from https://ihds.umd.edu/faq

Lazaroff, S. C. (n.d.). *India Human Development Survey-II (IHDS-II), 2011-12 (ICPSR 36151) data guide*. Data Sharing for Demographic Research. Retrieved September 8, 2026, from https://www.icpsr.umich.edu/sites/dsdr/posts/shared/ihds-ii-data-guide

National Council of Applied Economic Research, & University of Maryland. (n.d.). *IHDS-2: Income and social capital questionnaire*. https://ihds.umd.edu/sites/default/files/2022-08/ihds2isq.pdf

Philippine Statistics Authority. (2024a). *Census of Population and Housing 2020: Language/dialect generally spoken at home (H13)* [Data dictionary]. https://psada.psa.gov.ph/catalog/231/variable/F8/V1050?name=H13

Philippine Statistics Authority. (2024b). *Census of Population and Housing 2020: Kind of business or industry (P22)* [Data dictionary]. https://psada.psa.gov.ph/catalog/231/variable/F8/V728?name=P22

Philippine Statistics Authority. (2024c). *Census of Population and Housing 2020: Population weight (POPWGT)* [Data dictionary]. https://psada.psa.gov.ph/catalog/231/variable/F8/V1009?name=POPWGT

## Source identity

The original questionnaire was inspected at printed pages 4, 14-16, 28 and 32, with page images inspected for the first business and language tables. Exact local source: `sources/ihds_audience_20260908/IHDS2_Income_Social_Capital_Questionnaire.pdf`, 749,070 bytes, SHA-256 `0caf5e6609048a5774a29911433068089f12194b2f5876c736036a7f5df24354`. Official web documentation was read on 8 September 2026. The related `PSA_BUSINESS_JOINT_FIELD_SPEC_v1.md` is an inspection report, not a downloaded census data file.
