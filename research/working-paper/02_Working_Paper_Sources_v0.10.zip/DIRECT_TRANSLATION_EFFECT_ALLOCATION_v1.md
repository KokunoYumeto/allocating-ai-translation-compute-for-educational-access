# Direct translation evidence and compute allocation

### 7.10 What direct translation evidence contributes to allocation

A translated self-study course can change participation as well as test performance. Bälter et al. (2024) compared otherwise identical Swedish and English programming courses. Among the 2,263 analyzed learners, the Swedish group had an average score 3.06 answers higher out of 42 and a test-initiation rate 13.54 percentage points higher. Here initiation means attempting at least one module-test question, not completing the course (Tables 2-3 and section 4.2).

The analysis excluded 212 language switchers. Assigning their missing outcomes every allowable value gives a registered-cohort initiation difference of 4.37 to 21.42 percentage points, still positive, but a score difference of -0.23 to 6.95 answers. These are missing-outcome bounds, not confidence intervals or a full randomized-cohort estimate; 547 assigned applicants never completed registration.

This supports familiar-language self-study as a concrete intervention to compare, without assuming a universal learning effect. For 1,000 comparable future enrollees, preserving one-quarter, one-half or all of the analyzed score difference would yield 765, 1,530 or 3,060 additional correct-answer units. These are declared transport scenarios. The denominator for efficiency is the production and delivery workload of the actual course. Correct-answer units measure aggregate performance, not distinct people helped.

Allocation should therefore compare relevant learner cohorts and particular resources, preserving participation and learning as separate outcomes. The result strengthens the case for worked exercises, feedback and accessible language in self-study packages. It does not establish a population-wide benefit multiplier for any language. The calculation appendix preserves sampling intervals, missing-outcome bounds and exact assumptions.

## Recomputed effects

| Outcome | Analyzed-group difference | Approximate 95% sampling interval | Registered-cohort missing-outcome bounds |
|---|---:|---:|---:|
| Correct answers out of 42 | 3.06 | 2.09 to 4.03 | -0.23 to 6.95 |
| Test initiation percentage points | 13.540 | 9.624 to 17.455 | 4.373 to 21.423 |

Normal intervals use reported rounded means and standard deviations or exact binary counts. They do not include selection or transport uncertainty. Missing-score bounds use integer totals compatible with rounding of the published means. The initiation bound is based on assigning missing outcomes zero or one by original assignment. The positive bound does not remove possible selection during registration.

## Explicit deployment sensitivities

| Comparable enrollees | Fraction of analyzed effect retained | Additional correct-answer units | Additional test initiators |
|---:|---:|---:|---:|
| 1000 | 0% | 0 | 0.0 |
| 1000 | 25% | 765 | 33.8 |
| 1000 | 50% | 1,530 | 67.7 |
| 1000 | 100% | 3,060 | 135.4 |

Zero retention is a sensitivity case, not a default for an unmeasured language. No scenario is assigned to a target community by evidence availability. Benefits on the two endpoints overlap and must not be added. A normalized score difference of 3.06/42 is not the probability that a person benefits.

## Source and reproducibility

Bälter, O., Kann, V., Mutimukwe, C., & Malmström, H. (2024). English-medium instruction and impact on academic performance: A randomized control study. *Applied Linguistics Review, 15*(6), 2373-2396. https://doi.org/10.1515/applirev-2022-0093

Full primary text: https://research.chalmers.se/publication/537583/file/537583_Fulltext.pdf. Printed pp.7-11,13,15; repository cover adds one PDF page. Calculations: `scripts/build_direct_translation_effect_allocation_v1.py`; inputs and results: `structured/DIRECT_TRANSLATION_EFFECT_ALLOCATION_v1.json`.
