# Which business-learning resources should translation compute produce?

Research extension, 8 September 2026. Ongoing global study; the recommendations below concern particular vocational opportunities, not a new ranking of whole languages.

## Recommendation

For adult micro-retailers seeking day-to-day business skills, commission a practical business-records and decisions package as a distinct alternative to translating an entire corporate-finance textbook. Include concrete cash-record examples, customer-credit records, stock decisions and supplier comparisons, with explanations of why the procedures work, their limits, worked exercises and reusable blank records. Offer locally voiced audio together with a transcript and visual material; an independently usable, downloadable edition is a worthwhile proposed route, not an intervention whose effect has already been measured by the studies below.

Hiligaynon, Hindi and Kannada have unusually specific evidence here: a phone-based training study names the first as its Philippine eligibility language and explicitly reports Hindi and Kannada audio durations and delivery costs in India. These are actionable exact-language leads. Urdu remains a separate eligible proposal: the Indian recruitment criteria include it, but the reported cost paragraph does not establish a separately tested Urdu recording. Dominican microbusiness evidence informs course design; the article's delivery language is not explicitly named, so it is not counted as a verified Spanish-language experiment. These evidence distinctions do not change any language's global eligibility or underlying population need.

## What the experiments actually add

Drexler, Fischer, and Schoar (2014) randomized 1,193 existing loan clients in Santo Domingo. Both course arms included instructors, homework, handouts and three common introductory sessions. The practical-rules arm scheduled 15 hours, compared with 18 for conventional accounting. Its business-practice index effect was 0.14, compared with 0.07 for accounting; the direct equality test had p = .195. Cash separation specifically improved by 0.08 against 0.00, with a between-arm p = .014. Thus the result supports a practical-course candidate, not a claim that it outperformed accounting on every outcome. The primary results concern observed endline business owners; missing outcomes and business closure matter. Revenue findings were weaker and sensitive to attrition assumptions. No direct accounting-mastery or AI-translation effect was measured (pp. 8-9, 15, 23, 26).

Cole, Joshi, and Schoar (2024) evaluated brief local-language voice messages plus an initial orientation among 2,096 Philippine and 3,849 Indian microfinance clients with retail businesses and phone access. The three-point practice index rose by 0.037 in the Philippines (p = .006) and 0.021 in India (p = .027). The respective binary-index effects were 0.019 (p = .010) and 0.010 (p = .058). These are composite-index changes, not percentages of people newly understanding a course. The study did not establish higher regular-week profits in either site. Its content and language details support specific delivery proposals without identifying an independent-download, translation-only or general financial-literacy effect (pp. 583-590).

The experiments are not a head-to-head comparison. Recruitment, context, instruction, outcome scales and follow-up differ. Their point estimates must not be combined into a global language ranking, and an instructor-supported effect must not be silently reassigned to a download. Conversely, the absence of a tested download does not justify withholding an independently usable edition. It identifies an assumption to expose in allocation scenarios while construction and source-grounded validation proceed.

## Match the educational resource to the job

| Proposed resource | Intended educational use | What to retain or add | Allocation interpretation |
|---|---|---|---|
| Practical micro-retail package | Keep intelligible records and reason through everyday cash, credit, inventory and supplier decisions | Worked cases, explanation of assumptions, blank records, answers, audio and text | Specific vocational candidate for the named communities and analogous audiences; no whole-population benefit count inferred |
| Deeper accounting pathway | Explain transactions, reconcile records and distinguish cash movement from accounting profit | Full conceptual treatment, exercises and relevant local examples | An additional learning objective, not an inferior alternative because it is longer |
| Corporate-finance course | University or professional study of finance | Preserve the complete source's theory and exercises | Appropriate for its own audience; the word finance does not make it the default microbusiness curriculum |
| Independent offline edition | Learn and revisit material without an ongoing teacher, account or connection | Navigation, worked answers, transcripts, accessible visuals and downloadable files | Proposed design with a disclosed effect range; supported-course attendance is not its estimated uptake |

OpenStax remains a useful source baseline. The pinned Principles of Finance source measured in this programme contains 282,065 content-text tokens across 131 modules; its publisher-core selection contains 194,805. These are text-workload measurements, not estimates of learning or a microbusiness course's required size. The publisher describes an undergraduate finance course and explicitly includes small-business and personal-finance examples. Relevant sections may therefore contribute to a practical package; neither adopting the whole book by default nor dismissing it wholesale follows from its university scope. The 15-versus-18-hour experiment measures scheduled contact time, not AI effort. Practical-package source length and audio-production work must be counted from the chosen material rather than inferred from classroom hours.

The proposed independent edition is not an abridged translation of a complete finance textbook. It is a separately specified educational product. Where a complete work is translated into another language or adult register, its intellectual content remains intact. The existence of a short vocational product neither changes that translation standard nor limits anyone's access to advanced study.

## Voice delivery has a cost structure that translation tokens miss

The 2024 paper prices complete listening at the 2016-2017 study tariffs. It reports 73 minutes and USD 2.04 for Hindi, 85 minutes and USD 2.38 for Kannada, and 81 minutes and USD 14.99 for the Philippine route. These amounts cover airtime only, not development, orientation, platform operations, devices or learner time; actual billed listening could be lower. They are historical observations, not current quotations. They show why creating an edition and delivering it to each additional learner require separate budgets.

| Audio route | Reported duration | Historical full-listening airtime | Illustrative audio payload at 24 kbps |
|---|---|---|---|
| Hiligaynon | 81 minutes | USD 14.99 | 14.58 MB |
| Hindi | 73 minutes | USD 2.04 | 13.14 MB |
| Kannada | 85 minutes | USD 2.38 | 15.30 MB |

The file sizes are engineering scenarios, calculated as minutes x 60 x bitrate / 8, with decimal units. A 16-32 kbps envelope gives 9.72-19.44 MB for Hiligaynon, 8.76-17.52 MB for Hindi and 10.20-20.40 MB for Kannada. Headers and accompanying files add bytes; this calculation makes no claim about codec quality, spoken intelligibility or what device a learner owns. A low-bandwidth audio/text edition could be shared and replayed offline. The voice-call trial did not test that alternative, and audio alone does not serve every reader or signed-language user.

Local adaptation includes commercial context, not only vocabulary. The phone curriculum contained one more message in India because the supplier-credit situation differed. A source-faithful translation should retain the source's account of that difference; an independently commissioned local course should identify where its examples and rules apply. Neither approach warrants copying a context-dependent business rule universally.

## A usable allocation rule

Choose a common educational endpoint before comparing resources: for example, understanding how to reconcile a simple retail cash record, rather than a mixture of course completion, income and broad finance mastery. For each distinct learner group, estimate the additional offer-level benefit over its currently usable alternative. The objective is the sum of those benefits across people, subject to both a production-workload budget and a separate dissemination budget. An offer-level effect already includes participation in the offered intervention; multiplying by attendance again would discount it twice.

Unknown direct comprehension effects and occupational audience counts remain parameters, not zeroes. Use transparent scenarios for equivalent missing cells. Neither the trial sample nor the language's whole population is the number of micro-retailers helped. This bounded vocational comparison leaves the current worldwide audience baselines and Top 100 tables unchanged; it adds candidate educational resources underneath them.

For two delivery routes to the same outcome, let the downloadable route reach k times as many distinct relevant learners as a supported route, and let it retain a fraction r of the supported offer-level benefit. Once their different production and delivery costs fit the chosen budgets, the downloadable route yields more total benefit when k x r > 1. If k = 5, its break-even retention is 20%. This is a decision threshold, not a measured fivefold reach advantage or an estimate that independent study retains 20% of any trial effect.

| Distinct audience reached by download, relative to supported route | Required retained benefit for equal total benefit |
|---|---|
| 1 times | 100% |
| 2 times | 50% |
| 3 times | 33.33% |
| 5 times | 20% |
| 10 times | 10% |

The comparison must also recognize shared readers. If a downloadable course is already available to a cohort and a supported option is added for some of those same people, count only the support's additional benefit for them. In an illustrative case where download delivers 40% of the supported benefit and support reaches half the cohort, the combined benefit is 0.40 + 0.50 x (1 - 0.40) = 0.70 per cohort member, not 0.90. This is a same-outcome, nested-audience scenario with no extra complementarities, not an empirical effect estimate.

That marginal rule changes the next compute decision. With the same illustrative 40% initial benefit, an added supported route can deliver only the remaining 60% for an already-served learner. If a new disjoint-language edition would deliver 75% per learner at the same additional workload, support needs to reach more than 1.25 times as many people to beat it. For benefit per production-workload unit, the audience threshold is 0.625 if support costs half as much, and 2.5 at twice the cost. The unequal-cost ratios compare efficiency, not the best total-benefit combination under hard budgets. They can guide scalable opportunities when the relevant resource is binding, but indivisible packages, unused budget and a separate delivery constraint require comparing feasible portfolios. None of these effect values is an estimate for an actual community.

An exact four-scenario example demonstrates that distinction. Suppose adding support costs 0.5 production units and 1 delivery unit, while a new edition costs 1 production unit and 0.25 delivery units. Added support serves a cohort of size 0.75 at incremental effect 0.60, giving benefit 0.45; the disjoint new-edition cohort has size 1 and effect 0.75, giving benefit 0.75. Thus support has the higher production-efficiency ratio (0.90 versus 0.75), but not the greater total benefit. These are anonymous hypothetical cohorts and normalized costs, not actual population or compute estimates. Exhausting all four possible action subsets gives:

| Production budget | Delivery budget | Best feasible addition | Incremental benefit |
|---|---|---|---|
| 0.5 | 1 | Support | 0.45 |
| 1 | 1 | New edition | 0.75 |
| 1.5 | 1 | New edition | 0.75 |
| 1.5 | 1.25 | Both | 1.20 |

The second row shows why sorting benefit/workload is insufficient: support leaves production budget unused and delivers less total benefit. The third and fourth show that a delivery budget can limit what additional AI production achieves. These finite choices are solved exactly within the stated example; they are not a new empirical global portfolio. The globally useful implication is to price and optimize production and delivery together, while retaining them as distinct resources.

## What to commission, and what can change the choice

The initial vocational recommendation is an independently usable practical package, with locally appropriate audio, text, worked reasoning and reusable records, for exact-language micro-retail audiences. Hiligaynon, Hindi and Kannada are source-supported entry points; Urdu and other languages remain eligible with their evidence status stated. The recommendation concerns the kind of resource worth producing, not a new claim that these languages globally outrank others. Treat supported distribution as an optional additional intervention with its own incremental cost and benefit, not a prerequisite for the free edition.

For a given language, prefer deeper accounting when the educational objective requires it; prefer the practical package for the specified recordkeeping and daily-decision objective when its audience-benefit/workload scenario is stronger. Across languages, compare the additional distinct learners reached, not the number of editions. Changing the occupational audience, independently usable existing resources, source length, language/register fit, delivery cost or effect assumptions can change which option comes first. Local project accomplishments subtract nothing from worldwide educational needs.

This is a concrete extension to allocation research beyond mathematics: specified resources, exact language leads, separate delivery costs and explicit choice boundaries. It does not claim the global maximization problem is finished.

## References and reproducibility

Drexler, A., Fischer, G., & Schoar, A. (2014). Keeping it simple: Financial literacy and rules of thumb. American Economic Journal: Applied Economics, 6(2), 1-31. https://doi.org/10.1257/app.6.2.1

Cole, S., Joshi, M., & Schoar, A. (2024). Heuristics on call: The impact of mobile-phone-based business-management advice. The World Bank Economic Review, 38(3), 580-597. https://doi.org/10.1093/wber/lhad038

OpenStax. Principles of Finance 2e, source commit e3e5135ae36e21282d7afb4cccd5ce09f421d830. Scope: https://openstax.org/books/principles-finance-2e/pages/preface. Source-scale observations and licensing remain title-specific in OPENSTAX_SUBJECT_SOURCE_SCALE_v1.md and structured/OPENSTAX_SUBJECT_SOURCE_SCALE_v1.json.

The two primary-extraction records preserve exact source hashes, locators, observed samples, table-specific estimates and uncertainties. The standard-library script scripts/build_vocational_package_allocation_v1.py checks those source identities and reproduces audio sizes, contact-hour arithmetic and all displayed conditional thresholds. No participant data, third-party article, copied teaching script or raw user transcript is redistributed. Original analysis: CC BY 4.0. Cited works retain their original rights and credits.
