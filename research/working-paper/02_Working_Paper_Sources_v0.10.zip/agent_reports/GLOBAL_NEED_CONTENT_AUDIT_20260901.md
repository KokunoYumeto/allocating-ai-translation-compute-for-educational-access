# Global educational-needs content audit (read-only)

**Audit date:** 2026-09-01  
**Purpose:** bounded content audit for the from-scratch global educational-access paper. This report does not alter scores, rankings, candidate files, source registries, or publication artifacts. It does not use local translation output as a need input.

## Executive finding

The current evidence base is strong enough to support a descriptive, literature-backed needs chapter and a transparent “what is known/unknown” register. It is not yet strong enough to support an observed global Top 10/Top 100 or a claim that a language has a measured number of *comfortable advanced-education readers*. The best-supported content is stage/subject need, denominator discipline, and exact large-cohort inclusion. The largest remaining content gaps are exact language × stage × subject learning/functional-access cross-tabs, territory-specific instructional-language routes, and direct evidence for major Sinitic, South Asian, African, sign-language, refugee, and interlanguage profiles.

The central substantive result that survives all audits is **not** “translate the largest population.” It is: use exact profile/construct/stage units; keep foundational, practical, tertiary, postgraduate, and research needs separate; retain large official languages and small/minoritized languages in the same census; and treat missingness as uncertainty rather than a low-need value.

## Exact artifacts inspected

All paths below are relative to the source archive root.

| Artifact | Bytes | SHA-256 | Content status |
|---|---:|---|---|
| `PAPER.md` | 52,300 | `DA6449DBECC207442C0F628E197671A08F48DCF63B4851974C62B22C9D9155F1` | Methods/prospectus; no completed global ranking section |
| `agent_reports/LITERATURE_NEEDS_AUDIT_20260901.md` | 48,677 | `00242A65BCDF3CACC6E29601D46A1EDD81FAE128E35C4E06541DF90AA8FEDEA2` | Stage/subject/resource synthesis; bounded and caveated |
| `agent_reports/STAGE_SUBJECT_NEEDS_EVIDENCE.md` | 40,137 | `FD30D7271C394691F79D92F8711B0538C57FEF561D7B70D9F6D0413ADDB8C56C` | Stage and subject evidence map |
| `agent_reports/ASIA_EMPIRICAL_NEED_INPUTS.md` | 17,877 | `88D117E6628FFBE8B890A48E6DAB3E98537D3A73BE01464A22F5E2E72E4BC4B1` | 44-row Asia evidence bundle; 27 original + 17 controls |
| `agent_reports/LARGE_POPULATION_OMISSION_AUDIT_FINAL.md` | 18,956 | `035CB4A9BA480E3583941B7FA0E1506588962745277EAFE6AF085D870DB4B17B` | 51-row large-cohort disposition/omission audit |
| `agent_reports/global_omission_audit.md` | 53,225 | `B5915EAF030F3AF3F3FB0595AE334D213667B36166FE98BBD1CF309775A5B48B` | Independent global profile screen and mandatory split register |
| `agent_reports/EQUAL_TREATMENT_CONTRACT_AUDIT_20260901.md` | 27,625 | `70B140AD67B4041473A10877166510AC4859CB7074CB3F54843D1F8D29F46A9C` | Read-only scoring/provenance contract audit |
| `structured/canonical_universe_successor_v2.json` | 20,724,344 | `E078F8E72701D87B23A0F4B25184F89293A1E2931776B61F8E77F599D801A97C` | 969 language targets, 541 population-evidence rows, 1,039 source records; validated successor universe, not a ranking |
| `structured/EVIDENCE_AUTHORIZATION_v1.csv` | 1,195,520 | `96D49D19788C4D5F857661F2167B92CA5922F4B4EA569131633DC4D34AD6D7F0` | 843 authorization rows: 169 ADMIT, 671 EXCLUDE, 3 STAGE_OPPORTUNITY |
| `structured/GLOBAL_TARGET_SCORE_TABLE_v3.csv` | 1,605,319 | `D5BC13AEA1D95124605E6DFA3A6F046EE4977DB6E96A29E012866EADB56686DB` | Current model output; not treated as an observed finding |
| `structured/SUCCESSOR_EDITION_EVIDENCE_MAPPING_v3.csv` | 884,958 | `C5E44FB71F895AB9D1E4DD5A8292942DC8D7FF80442F75DEB4AF583A03288508` | 937 rows; legacy `rank_eligible` remains all false and must not be silently overridden |
| `qa/GLOBAL_ACCESS_RANKINGS_V3_QA.json` | 3,599 | `83FD136C7C49B36CB0DB55C0FEB934BE5CC43B1D4C82323164B5111DF0876282` | Structural/model QA only: 1,065 rows, 136 person-need, 2 stage, 927 unranked, 256 draws |
| `structured/open_resource_canon_map.json` | 291,120 | `B374C2BAF7613EADA2905A497707B8B3DE6464FC14D0C3DDF96CFED992E21442` | 118-resource canon map (73 OpenStax + 45 complementary) |
| `qa/oer_target_canon_evidence_matrix.csv` | 6,216,778 | `7B1402942F0AF690E2EB89CE2BB255FAFAED906A4D13FA0CDF83F043C450370A` | Rectangular target×canon evidence expansion; unresolved cells remain missing |
| `structured/SIGNED_ACCESSIBILITY_EMPIRICAL_INPUTS.csv` | 38,194 | `32655527D53E223D5689DA3A841B2DF635931214DB97CA167C473861A6CF8D89` | 35 non-additive signed/accessibility rows |
| `agent_reports/INTERLANGUAGE_STRUCTURED_EVIDENCE_MATRIX.md` | 19,619 | `9C60778DDBF2AE8C2CA09D166F24BE6E7E1EF1536A8E25AFCD08D073CE943F65` | 20-profile interlanguage matrix; no measured global mathematical gain |

## Sections ready for a paper (with scope labels)

### 1. Functional-access definition and equal-treatment method — ready as methods

`PAPER.md` §§2–5 and `EQUAL_TREATMENT_CONTRACT_AUDIT_20260901.md` provide a coherent unit: exact variety/register × script/orthography × territory/community × mode × stage × subject/canon × endpoint. They explicitly separate intrinsic person need, package access gain, and compute efficiency; ban local holdings/prior translation from the need estimand; preserve L-C, L-ID, and L-M lanes; and require non-additivity/overlap controls. This can be published as a method, provided the manuscript says that the empirical global order is still being built.

### 2. Stage and subject material needs — ready as evidence synthesis

`STAGE_SUBJECT_NEEDS_EVIDENCE.md` and `LITERATURE_NEEDS_AUDIT_20260901.md` support a stage ladder from emergent literacy through research/professional learning. High-confidence cross-cutting material classes are:

- foundational oral language, literacy, numeracy, level-based catch-up, and structured practice;
- secondary mathematics/science, health, digital safety, and transition/bridge language;
- vocational/adult safety, finance, bookkeeping, agriculture/climate, and job-specific competency;
- undergraduate gateway texts, computing/data, and research literacy;
- postgraduate/research methods, statistics, reproducibility, scholarly writing, open science, and specialist reference; and
- offline/low-bandwidth, print, audio, semantic HTML/MathML, captions/transcripts, and sign/video variants as distinct delivery interventions.

These are material classes, not language ranks. Country learning-poverty and connectivity values are contextual unless a language × stage cross-tab exists.

### 3. Equal-basis large cohorts — ready as a bounded inclusion/measurement section

The Asia bundle and large-population audit provide a defensible table of constructs, not a speaker ranking:

- Bahasa Indonesia: BPS reported communicative ability **248,501,794** age 5+; a direct oral/receptive measure, not advanced literacy.
- Hindi proper: India 2011 raw mother-tongue return **322,230,097**; the broader 528.35m Hindi census umbrella is not assigned to Standard Hindi.
- Bengali India **96,177,835**, Marathi **82,801,140**, Telugu **81,127,740**, Tamil **68,888,839**, Gujarati **55,036,204**, and other exact Indian language returns remain separate.
- Punjabi Pakistan **88,915,544** and Punjabi India **31,144,095** are a two-script package context (**120,059,639**), not one readership count.
- Mainland written Chinese has a high-only territorial ceiling **1,411,778,724**; the 80.72% Putonghua rate is retained without multiplying it into a compatible written-reader denominator. Formal enrolment **280,404,300** is a stage opportunity, not whole-language need.
- Japan’s resident exposure ceiling **123,802,000** and exact support/tertiary cohorts (including **84,759** pupils reported as needing Japanese instruction) are separate; strong national schooling does not establish zero advanced/open/accessibility need.
- Vietnamese **101,112,656**, Filipino **112,729,484**, Bangla Bangladesh **168,419,331** (mixed-year arithmetic context), and Russian ability/daily-use endpoints are retained with their construct labels.

This section is ready if every number is captioned as direct count, sample point, exposure ceiling, stage opportunity, package context, or proxy. None should be called “comfortable readers” without a matching assessment.

### 4. Global omission and split register — ready as a transparent data-gap section

`global_omission_audit.md` and `LARGE_POPULATION_OMISSION_AUDIT_FINAL.md` establish that a language-name list is not enough. They identify required script/territory splits, displacement overlays, signed-language profiles, and large education-language routes. The 10-row supplement is validated, but remains outside the frozen successor and must be labelled append-required rather than silently folded into current ranks.

### 5. OpenStax/Open Logic/resource baseline — ready as a canon map, not scarcity estimates

The canon map contains **118 records** (73 OpenStax titles and 45 complementary/open resources). OpenStax is strongest as an exercise-rich upper-secondary/introductory-tertiary spine; Open Logic is a modular logic/computability/metatheory corpus; neither is a complete E0–E8 curriculum. The OER expansion covers **148 targets × 35 canon cells = 5,180 cells / 25,900 query records**, with **5,148 unresolved** cells and **zero numeric resource-gap values**. This supports a resource inventory and evidence-acquisition plan, not a claim that unresolved cells are scarce or empty.

### 6. Interlanguage and mathematics — ready as a conditional research agenda

The interlanguage matrix supports preserving exact community/script profiles, testing bridge comprehension by stage and genre, and separating shared-source production from beneficiary credit. It does **not** support a blanket multiplier, automatic regional coverage, or a zero-value conclusion. The current audited evidence has no representative mathematics-specific learning-gain estimate for an interlanguage; the correct label is “unidentified in the reviewed evidence,” with notation/formula and technical-lexicon hypotheses tested separately.

## Missing high-population and Asia candidates

“Missing” below means absent as an exact target or absent from the current direct-evidence/authorization lane; it does not mean that the population is small or that no need exists. The check is against the 969-target successor and the 843-row authorization file, not against a universal language census.

| Candidate/profile requiring append or explicit disposition | Current evidence status | Why it matters / next bounded evidence action |
|---|---|---|
| **Mainland Sinitic beyond Standard Mandarin:** `wuu-Hans-CN` (Wu), `nan-Hant-TW` (Min Nan/Taiwanese), `hak-Hant-TW` and `hak-Hans-CN` (Hakka) | No exact target under these IDs in the successor; Cantonese Yue exists, but mainland direct count is unresolved. | Prevents “Chinese” from meaning only Putonghua/Simplified Written Chinese. Obtain current direct language-use/education-medium evidence, with territory/script split and no ethnicity substitution. |
| **Mainland minority-script routes:** Uyghur `ug-Arab-CN`, Tibetan `bo-Tibt-CN`, Zhuang `za-Latn-CN`, Nuosu/Yi `ii-Yiii-CN`, Mongolian `mn-Mong-CN`, Hmong/Miao varieties | Not present as exact successor IDs (ethnicity proxies must not be promoted to speaker counts). | China’s 125.47m minority-ethnicity total is an audit trigger only. Attach language-specific census/education/reader evidence and preserve Arabic, Tibetan, Latin, Yi, and traditional Mongolian scripts separately. |
| **India script/minority routes:** Kashmiri `ks-Arab-IN`/`ks-Deva-IN`, Meitei `mni-Mtei-IN`/`mni-Beng-IN`, Bodo `brx-Deva-IN`, Konkani `kok-Deva-IN`/`kok-Latn-IN` | No exact targets under the tested IDs; current India rows cover many, but not all, C-16 returns. | These communities can be hidden inside Hindi/other umbrella returns. Append direct mother-tongue counts and script/education crosswalks; do not collapse scripts. |
| **Pakistan Hindko and other exact routes:** `hno-Arab-PK` plus Balochi/Saraiki/Pashto provincial overlays | Hindko exact target absent; Balochi, Saraiki, Pashto, Sindhi are present with direct counts for some endpoints. | Pakistan’s Urdu national exposure ceiling cannot replace home-language routes. Add exact census rows and stage/medium evidence for Hindko and provincial languages. |
| **English territorial education routes:** `en-Latn-US`, `en-Latn-IN`, `en-Latn-PH`, `en-Latn-PK`, `en-Latn-NG`, `en-Latn-ET`, and **French DRC** `fr-Latn-CD` | Not in the 969 exact target set; appear in the 10-row post-freeze supplement as append-required (US English home-language **245,472,067**; India English L1/L2/L3 **128,539,090**; Philippines/Pakistan/Nigeria/Ethiopia/French-DRC exposure ceilings). | Large official/academic-language populations are easy to lose behind global English/French labels. Add exact territory rows, retaining exposure ceilings as ceilings and C-17/ACS direct measures as separate endpoints. |
| **Kurdish exact standards:** Kurmanji `kmr-Latn-TR` and Sorani `ckb-Arab-IQ` (plus diaspora overlays) | Only macro `ku-001` is present; exact standards tested are absent. | A macro Kurdish row cannot establish script or curriculum reach. Append direct community/education evidence by standard and territory. |
| **Ukrainian origin/displacement:** `uk-Cyrl-UA` and host overlays | No exact Ukrainian target in the successor despite displacement relevance. | Pair origin-country language access with host-country schooling; do not add refugee status to speaker counts. |
| **West African Pidgin six-variety cluster:** Ghanaian Pidgin, Pichi, Aku, plus a shared package | Nigerian Pidgin/Cameroon Pidgin/Krio are present; Ghanaian Pidgin, Pichi, Aku and the six-variety package are absent. Peer-reviewed context estimates **106–143m** but no comprehensive census or panregional standard. | Large lingua-franca reach and formal-education exclusion warrant a visible package/context row, not a single standardized language score. |
| **Kiswahili exact country rows** | Macro and several exact Tanzania/Kenya/Uganda/Rwanda/Burundi/DRC routes exist; most have no compatible direct person measure. | Keep one shared >200m context record, not repeated child denominators. Add country-specific school-medium and direct-user evidence before comparing children. |
| **Malay/Indonesian distinction** | Indonesian exact target and Malaysia/Brunei/Singapore Malay profiles exist, but no pooled bridge count is admitted. | Preserve Indonesian’s **248,501,794** communicative-ability measure and Malay children separately; test comprehension before awarding interlanguage reach. |
| **Large sign-language profiles** (especially Korean Sign Language `kvk-KR`; Chinese `csl-CN`, Indian `ins-IN`, Indonesian `inl-ID`, Brazilian `bzs-BR`, Japanese `jsl-JP`) | Most named profiles are present as nonnumeric rows, but `kvk-KR` is absent and direct signer counts are generally unavailable. | Hearing-loss/disability totals are proxies, not signer counts. Add video-native stage/subject evidence and preserve each national sign language as a separate modality. |
| **Global-language territorial children** (German, French, Portuguese, Russian, Dutch, Spanish beyond US/Mexico) | Global macro targets exist; most territorial academic/education rows do not. | A global speaker estimate is context, not a country-disjoint learner denominator. Add children where curriculum, script, migration, or research-language conditions differ. |

## Content claims that remain unjustified or need narrower wording

1. **No current “global Top 10/Top 100” claim is evidence-backed.** `GLOBAL_TARGET_SCORE_TABLE_v3.csv` and `GLOBAL_ACCESS_RANKINGS_V3_QA.json` are model/adapter outputs. The QA’s structural `PASS` does not establish a source-bound joint need event, complete OER evidence, or observed comfortable-reader gain. The current compute class is `SCRIPT_ENVELOPE_FALLBACK`, not direct end-to-end package cost.
2. **Do not call direct population measures access counts.** Indonesian 248.5m is reported communicative ability; Hindi/Bengali/etc. are mother-tongue returns; Chinese 1.411b is a territorial written-standard ceiling; Japan 123.8m is a resident exposure ceiling. None is a count of people lacking or comfortably using advanced open material.
3. **Do not transport country learning-poverty/PISA/connectivity values to a language without a cross-tab.** They support contextual material hypotheses (for example, foundation, TVET, health, or offline delivery), not language-specific deficit percentages.
4. **Do not describe China as having “no content” or Japan as “served.”** The bounded OER audit reports Chinese F3/O0 and Japanese F2/O0 routes with unresolved completeness, adaptation, accessibility, and offline properties. Japan’s strong PISA/school outcomes are a negative-control *context*, not an exclusion from advanced, research, or accessible work.
5. **Do not treat unresolved OER queries as scarcity.** The 5,148 unresolved cells and zero numeric gap values are missing evidence. Use “unresolved route” or “evidence acquisition needed,” not a high scarcity score.
6. **Do not treat interlanguage reach as zero or universal.** Existing evidence supports production-sharing hypotheses and experiments; it does not quantify mathematical learning gain or permit family-wide beneficiary credit.
7. **Do not add package totals or overlapping endpoints.** Bangla Bangladesh/India (**~264.6m**), Punjabi Gurmukhi/Shahmukhi (**120.06m**), Arabic MSA/vernacular ceilings, Kiswahili cross-border users, and Indonesian ability/home/stage cohorts are context or alternative measures with explicit non-additivity.
8. **Avoid future-tense claims phrased as completed results.** `PAPER.md` currently promises target-level ranks, posterior probabilities, VOI, compute grids, and public artifacts that are not all present. Label them planned until their synchronized, hash-bound outputs exist.
9. **Qualify the interlanguage literature claim.** “No representative mathematics-specific gain was found in the reviewed evidence set” is defensible; “no such evidence exists” is not.
10. **Keep the 40% UNESCO/Walter–Benson context aggregate.** It is not a modern named-language census or a target denominator; the published record does not expose a verified named list of all 97 languages.

## Recommended content handoff to the parent task

1. Retain the methods, stage/subject synthesis, equal-basis cohort table, omission register, canon map, and interlanguage conditionality as paper-ready *descriptive* sections with their local hashes.
2. Add a “large-profile gaps and append-required rows” table using the exact candidates above; do not silently convert missing rows to zero or remove them from the universe.
3. Make the first results table a lane/status table (`L-C`, `L-ID`, `L-M`, stage opportunity, context, unranked) rather than a global importance list until provenance, exactness, and missingness gates pass.
4. Ensure Indonesia, Mainland Simplified Chinese, Japan, and all other large profiles use the same template: exact target, construct, denominator, stage, subject, functional endpoint, resource/open status, delivery/accessibility, overlap, and confidence.
5. Keep compute efficiency downstream from need and clearly label fallback/model-conditional costs. Do not let local work, prior translation, or source availability lower intrinsic need.
6. Append direct territory/script evidence for the missing high-population profiles before any claim of global coverage; preserve macro/package contexts as non-ranked evidence.

**Bottom line:** the current dossier can support a credible, globally inclusive needs-and-evidence paper foundation. It cannot yet support a factual global rank. The most important content repair is not another heuristic weight; it is closing exact profile/construct gaps while keeping large official languages, regional/minoritized languages, signed modalities, displaced communities, and advanced/research education on the same non-discriminatory evidence contract.
