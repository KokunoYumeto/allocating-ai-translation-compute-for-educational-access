# Independently usable mathematics packages: bounded direct-evidence report

Date: 2026-09-08. Scope: global allocation of AI compute to educational understanding, not optimization of a local production programme. Four primary papers examined; this is not a systematic review or a pooled estimate.

## Finding

A provisional fractions-to-algebra catch-up package is defensible as a **design scenario**: source-faithful explanations, stepwise worked examples, paired exercises, explanatory answer routes, prerequisite navigation, and genuinely independent checking. It is not defensible to describe its full causal effect as already measured. None of the four papers below simultaneously tests a complete static package, unsupported voluntary study, translation, and sustained mathematical understanding.

The evidence is useful without a language-matched trial: it identifies plausible instructional mechanisms, demonstrates that some self-paced delivery can work, and reveals material nulls and implementation risks. Indonesian, Brazilian Portuguese, and Filipino remain candidate translation communities; absence of a matched trial is neither observed zero benefit nor a reason to exclude them.

## Existing evidence reused, not duplicated

Inspected the requested `INTERVENTION_EFFECT_EVIDENCE_v1.md` and relevant structured study/scenario entries. The register already includes worked examples (`EFF-041`), retrieval (`EFF-042`), feedback (`EFF-043`), supported adaptive instruction (`EFF-045`), autonomous library use (`EFF-048`), and self-regulation (`EFF-051`). Those sources need not be rediscovered here. `SCN-STATIC-ACTIVE-USE` is explicitly a component-synthesis-informed scenario, 0.05-0.25 SD with 0-0.40 sensitivity, **not an observed standalone-package effect**. Its term/year horizon cannot be validated from the short-horizon studies added below.

Read-time SHA-256 identities:

| Existing artifact | SHA-256 |
|---|---|
| `INTERVENTION_EFFECT_EVIDENCE_v1.md` | `41FDFE5DA38DD1E1E46D04B801441978809639311AAC8A01BC6B4E7300C4C510` |
| `structured/INTERVENTION_EFFECT_EVIDENCE_v1.json` | `B4EE3CD3D39E5E3593F9A69E3C9AB0A9D342B3BD0F365061123CD18F21B6C734` |

## Direct-study benefit and design table

Effects below retain their original metrics. A source-page locator is a printed page unless explicitly called a PDF page. Chronological age is not inferred from grade. Multiple experiments within one paper are not independent publications.

| Primary paper; exact population/stage | Package and comparator | Exposure and support | Outcome/horizon and estimate | Locator; transport boundary |
|---|---|---|---|---|
| **Sweller & Cooper (1985), Experiment 3.** 22 Year-9 pupils, two Sydney high schools; sufficient algebra background but limited proficiency; age not reported. | Four worked-example/problem pairs versus eight problems; both groups initially received examples. | Single individually administered acquisition/test session; five-minute problem limits; experimenter explained initial material, required corrections, and supplied timed-out solutions. | Immediate four-problem test: mean 43.6 versus 78.1 seconds/problem; 0.18 versus 1.64 errors/problem. Both differences significant under the paper's .05 criterion; test-time U(11,11)=27.5. Experiment 2 had no significant test-time advantage, cautioning against universal benefit. | [Original paper](https://onderwijs.felienne.nl/vakdidactiek/materiaal/sweller_worked_examples.pdf), pp. 72-76, especially Table 6 p.76; [DOI](https://doi.org/10.1207/s1532690xci0201_3). Controlled mechanism evidence; allocation method not sufficiently specified to label this row an RCT. Not unaided learning, retention, or a standardized attainment effect. |
| **Booth et al. (2015), Experiments 1 and 2.** US Algebra-I students: E1 N=56, analyzed 51, mean age 14.3, three classes/two districts; E2 N=425, analyzed 395, 28 classes/five districts, non-honors; age not reported. | Individually randomized worksheets: correct/incorrect examples with self-explanation plus problems versus corresponding problem-only worksheets. | Four assignments within one unit; E1 3-4 weeks. Independent worksheet work within ordinary classes; teachers retained instruction and could discuss practice problems, but not experimental examples. | Unit-end content tests. E1 partial eta-squared=.10, F(1,47)=5.34, p=.03. E2 treatment coefficient=.10 (SE .08), nonsignificant; adjusted main-effect=.08 (.09); pretest-by-treatment=-.16 (.07), p<.05. | [Grantee manuscript](https://files.eric.ed.gov/fulltext/ED574649.pdf), manuscript pp.11-14,17-20, Table 4 p.38 (PDF pp.13-16,19-22,40); [DOI](https://doi.org/10.1080/19345747.2015.1055636). Independent activity, not independent education. Larger experiment supports differentiated response, not a universal positive mean. Posttest-missing cases were excluded despite the table's ITT label. |
| **McGuire et al. (2017).** 196 sixth-graders from existing ASSISTments classrooms in one US state; chronological age/state not identified in paper. | Fraction-division word problems; student-randomized text hints (71), pictorial hints (58), or correct answer only (67). | Three learning items then five test items online; no delayed test or session-time dose reported. Existing classroom platform; not a trial removing teachers. | Analyzed 112 completers who made learning-phase errors. Test means/5: 2.56 text, 2.51 pictures, 2.10 answer-only; adjusted F(2,108)=1.394, p=.253. Completion: 77.5%, 62.1%, 86.6%, respectively; chi-squared(2)=10.36, p=.006. | [Published paper](https://par.nsf.gov/servlets/purl/10060122), pp.235,238-241, Table 1 and Results p.240; [DOI](https://doi.org/10.1080/09523987.2017.1384161). Scores are selected post-assignment contrasts, not clean full-sample ITT gains. A direct warning against assuming richer feedback or pictures necessarily increase either learning or persistence. |
| **Pitchford (2015).** One urban Lilongwe, Malawi primary school; 318 randomized, 283 analyzed, Standards 1-3. Mean ages across arms: S1 81-84 months; S2 91-92; S3 105-109. | Self-paced Chichewa maths apps with repeated activities, feedback, mastery quizzes versus normal instruction; non-maths tablet placebo in S2-S3. | Eight weeks, equivalent 30 min/day; supplied tablets/headsets, scheduled learning centre, teacher technical assistance/progress monitoring and VSO technical support. Normal instruction also Chichewa. | Immediate posttest versus normal practice, Table-4 Cohen d: S2 concepts .626, curriculum 1.119, paper generalization .354; S3 .161, 1.698, .818 respectively. S2 concepts and S3 paper-generalization advantages significant versus normal practice; S2 paper generalization nonsignificant. | [Full primary paper](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2015.00485/full), Methods and Tables 1-4; [DOI](https://doi.org/10.3389/fpsyg.2015.00485). Package/context effect, not translation or unsupervised home-study effect. Curriculum tests reused app items; novel paper items give a more relevant transfer check. No standalone causal offline-versus-online contrast. |

## Actionable provisional package design

The choices below are **design inferences**, not claims that these exact combined specifications were tested. They are suitable for compute-allocation scenarios covering any candidate language community.

| Package decision | Provisional implementation | Benefit to track | What must remain varied |
|---|---|---|---|
| Level-matched entry | Short prerequisite checks linked directly to arithmetic, fraction meaning, equivalence, operations, ratio, and elementary equation routes; allow learners to skip or return. | Newly usable units; objective progress at the selected starting level. | Starting knowledge, curricular alignment, age/stage; never treat placement as a capacity label. |
| Example/practice pairing | Give an explicitly reasoned correct example, an analogous unsolved item, then a less familiar item. Make every algebraic transformation and fraction unit explicit. | Correct solutions, explanations of why steps are valid, and transfer beyond cloned items. | Example density and difficulty; mastery learners may need fewer examples. |
| Answers that permit independent repair | Separate quick correctness/answer access from optional full reasoning, diagnostic explanations of common wrong turns, and a fresh retry problem. Use clear navigation rather than compulsory long feedback. | Successful self-correction and subsequent unaided performance, separately from opening an answer. | Feedback length, representation fit, use/dropout; do not assign a fixed positive increment for elaboration. |
| Incorrect examples | Start with correct examples; add clearly marked, bounded misconception contrasts with corrected solutions available. | Ability to reject and repair an invalid step. | Need for error-location cues and prerequisite knowledge; more errors displayed is not inherently better. |
| Offline independence | Put instructions, figures, exercises, explanations, answer routes, glossary, and progress/restart guidance in the downloaded package; no essential cloud call. | Actual usability with networking disabled, completed units, return use. | Print versus small-screen presentation, storage/download cost, device sharing, and access conditions. This format specification is not itself an estimated learning gain. |
| Translation as its own intervention | Preserve source propositions, notation, conditions, definitions and problem identity; retain technical terms with useful glosses. If pedagogy is added, identify that layer separately. | Same-item comprehension/learning contrast and newly usable access, with identical pedagogical structure. | Language variety, academic-register mismatch, source fidelity, conventions and typography. No country/language-specific causal number supplied here. |
| Sustained understanding | Include cumulative retrieval and novel-problem checks with delayed rechecks; assess reasoning as well as answers. | Unit retention and transfer at a stated horizon. | Persistence, spacing, opportunity cost and retention. Short immediate tests do not establish a term/year effect. |

## Benefit scenarios and compute allocation

For planning, keep three estimands separate:

1. **Package effect:** translated/self-study package versus the actual alternative available to that audience. The alternative might be another usable book, unaided problem practice, unsupported internet fragments, or no usable material; these are different comparisons.
2. **Translation effect:** the same pedagogical package in one language/register versus another, with exposure and delivery held as similar as possible. None of the four new papers estimates this. Even the Chichewa study changes delivery/content, while its normal-instruction comparison also uses Chichewa.
3. **Availability/use effect:** reaching, acquiring, opening, using, and returning to the package. Publishing or downloading is not a measured understanding gain.

An operational sensitivity grid may retain the existing 0.05-0.25 SD static-active-use scenario **only under its disclosed non-empirical status**, alongside 0 and a modest negative mismatch case (for example -0.05 SD). These are analyst-chosen stress tests, not confidence limits, a fitted prior, or a numeric conclusion from the four papers. The upper 0.40 case already in the register remains exploratory. Do not present the interval as evidence of a strictly positive lower bound. Keep the outcome horizon explicit; do not silently transfer immediate effects to a year later.

For a passive or lightly supported release, calculate scenarios as:

`eligible people × reach × acquisition-given-reach × usability-given-acquisition × active-use-given-usability × active-user learning effect`.

Report the counts at every stage and learning separately. Use comparable rollout ITT estimates directly when available; do not discount them again by the same uptake probabilities. Do not add worked-example, feedback, retrieval, self-regulation and translation estimates as independent gains. Do not convert partial eta-squared, seconds/errors, test points, standardized regression coefficients and Cohen d into a common outcome without a justified conversion.

The actionable global allocation inference is to compare **complete, correct, independently checkable packages** against their real alternatives, while varying reach/use and pedagogical fit. Translation communities lacking matched RCTs can share the same disclosed transport scenarios initially; evidence absence does not justify a hidden negative adjustment. Potential educational gain and uncertainty remain visible, and source-faithful access work remains eligible.

## Verification and finite completion

- Four substantive primary papers checked, with exact methods/results and page/table anchors; no additional study was adopted from search snippets.
- No full independently used static fractions/algebra package trial was established in this bounded search. That is a search finding, not proof that none exists.
- PDF skill used for source reading and table-check planning. Web PDF screenshots returned reference-only output, and one screenshot timed out; no visual-QA success is claimed. Numeric entries above were checked in full-text table extraction and accompanying results, with the original locators retained for readback.
- Existing register and structured data were read only. No teaching artifact, production change, publication, or local-programme optimization was performed.
- This report is the sole written artifact. Its next executable use is synthesis by the parent task, preserving the estimand and transport distinctions above. No outstanding worker operation remains.
