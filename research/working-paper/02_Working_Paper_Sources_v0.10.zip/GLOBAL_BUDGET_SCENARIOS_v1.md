# What a fixed translation workload budget buys

This calculation makes the budget decision explicit across all 775 retained edition rows. Four budgets are tested for the common 100,000-token benchmark; three budgets each are tested for the complete book and six-chapter source plans. The inherited table contains 750 positive audience coefficients and 25 zero coefficients that do not establish zero readership. Those 25 are represented as unknown audiences with portfolio-entry thresholds. The numeric solutions are conditional on the stated audience scenarios; none is a global optimum over unresolved populations.

The result is a conditional planning exercise. A language population is much larger than the audience for one book. A common fraction for subject relevance, active use and educational gain remains symbolic. Those common factors do not change the conditional selection, but their values are needed before a coefficient can be called people helped.

The complete-source and six-chapter plans use the measured OpenStax Prealgebra 2e content-text sizes of 364,270 and 173,958 tokens. These sizes determine source workload only. They do not prove that the shorter plan produces the same educational outcome.

## Exact solutions under the additive opportunity scenario

| Source plan | Workload budget in millions | Workload used in millions | Editions selected | Sum of reach coefficients in millions |
|---|---:|---:|---|---:|
| 100k benchmark | 5 | 4.211 | Simplified Standard Written Chinese, Hindi, Spanish | 2,126.4 |
| 100k benchmark | 10 | 9.860 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Portuguese, Indonesian | 3,210.0 |
| 100k benchmark | 25 | 24.944 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Urdu, Bangla, Bangla-script, Portuguese, Indonesian, Russian, Cyrillic-script, Swahili, Punjabi, Shahmukhi/Perso-Arabic-script, German, Japanese, Japanese-script, Telugu, Telugu-script, Javanese, Vietnamese | 4,745.6 |
| 100k benchmark | 50 | 49.893 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Urdu, Bangla, Bangla-script, Portuguese, Indonesian, Russian, Cyrillic-script, Swahili, Punjabi, Shahmukhi/Perso-Arabic-script, German, Japanese, Japanese-script, Telugu, Telugu-script, Western Panjabi, Marathi, Javanese, Vietnamese, Tamil, Tamil-script, Persian, Wu Chinese, Simplified-script, Turkish, Korean, Korean-script, Cantonese, Simplified-script, Filipino, Egyptian Arabic, Italian, Gujarati, Gujarati-script, Pashto, Thai, Thai-script, Kannada, Kannada-script, Levantine Arabic | 5,811.6 |
| Complete book | 5 | 4.890 | Simplified Standard Written Chinese | 1,152.0 |
| Complete book | 10 | 9.898 | Simplified Standard Written Chinese, Spanish | 1,606.6 |
| Complete book | 20 | 19.845 | Simplified Standard Written Chinese, Spanish, French, Portuguese | 2,128.3 |
| Six chapters | 5 | 4.934 | Simplified Standard Written Chinese, Hindi | 1,671.8 |
| Six chapters | 10 | 9.760 | Simplified Standard Written Chinese, Hindi, Spanish, French | 2,424.7 |
| Six chapters | 20 | 19.816 | Simplified Standard Written Chinese, Hindi, Spanish, Arabic, French, Urdu, Portuguese, Indonesian | 3,490.5 |

These sums count edition opportunities. Multilingual users can appear in more than one row. Only under the explicit disjoint-audience scenario can the sum, multiplied by the common relevance, active-use and gain factors, represent unique additional benefit.

## Unknown audiences remain potential alternatives

For each of the 25 inherited zero rows, the model records an unknown audience and calculates an entry threshold. If a candidate costs c and the numeric optimum at budget B has coefficient V(B), the candidate improves that solution when its coefficient exceeds V(B) minus V(B-c). This tests the full opportunity cost of inserting a package. It does not assign an unknown community zero benefit.

The unresolved editions are: Ancient Greek, Greek-script profile; Balinese, Balinese-script profile; Caddo, Latin-script profile; Chickasaw, Latin-script profile; Church Slavic, Cyrillic-script profile; Fula, Adlam-script profile; Geez, Ethiopic-script profile; Ido, Latin-script profile; Jutish, Latin-script profile; Kawi, Balinese-script profile; Literary Chinese, Traditional-script profile; Lojban, Latin-script profile; Mycenaean Greek, Linear B-script profile; Obolo, Latin-script profile; Osage, Osage-script profile; Palatine German, Latin-script profile; Pali, Devanagari-script profile; Pali, Myanmar-script profile; Pali, Sinhala-script profile; Pali, Thai-script profile; Romagnol, Latin-script profile; Samogitian, Latin-script profile; Samtao, Tai Le-script profile; Vai, Latin-script profile; Votic, Latin-script profile.

## When broader coverage beats a complete course

With the same budget, a shorter source may permit more editions. Its required effect retention therefore depends on which editions fit, as well as the length ratio.

| Budget in millions of workload events | Minimum selected-package yield as a share of complete-package yield |
|---:|---:|
| 5 | 68.9% |
| 10 | 66.3% |
| 20 | 61.0% |

Each threshold applies only to a shared, stated learning outcome and the additive scenario above. A complete course also provides outcomes absent from six selected chapters. Those outcomes need their own comparison; they cannot be assumed away when making a final recommendation.

## What overlap changes

If the useful audiences for every edition were fully nested, the unique-benefit objective would favor the largest affordable individual opportunity and additional editions would add no unique reach. If audiences were disjoint, the additive budget solution above would apply. Actual multilingual overlap lies between these limiting cases and can change which additional edition is most useful. The numerical model reports both extremes rather than inventing intersections.

This result supports a practical distinction: a sorted ratio is useful for screening, while indivisible book packages require a budget calculation. The optimizer checks all 775 rows, reports the unspent budget and compares its result with a simple benefit-per-workload greedy selection. No national wealth, local completed translation or research-availability factor changes any language denominator.

The current budget unit is a declared token-event workload index. Physical hardware measurements may refine future estimates. Their absence does not prevent publication of this clearly stated workload-budget analysis.

## Evidence and reproducibility

- The existing 775-row worldwide reach and workload table supplies every edition input.
- The pinned OpenStax source-scale record supplies package lengths.
- Subject relevance, uptake, effect retention, overlap and budgets are declared scenario parameters.
- Every optimizer run must return an optimal solution within a 15-second bound and a relative gap of at most 1e-9.
- `structured/GLOBAL_BUDGET_SCENARIOS_v1.json` contains all candidates, exact selections, cost sums, solver bounds and package reversal thresholds.
