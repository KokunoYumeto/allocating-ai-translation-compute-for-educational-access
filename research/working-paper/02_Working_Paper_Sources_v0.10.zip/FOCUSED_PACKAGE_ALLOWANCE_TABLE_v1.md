| Focused material | Final benefit relative to full book | No common setup | Setup = 10% of full variable work | Setup = full variable work |
|---|---|---|---|---|
| Fractions chapter | 50% | 38.65% | 33.65% | -11.35% |
| Six chapters | 50% | 2.24% | -2.76% | -47.76% |
| Six chapters | 75% | 27.24% | 24.74% | 2.24% |
| Fractions chapter | 100% | 88.65% | 88.65% | 88.65% |
| Six chapters | 125% | 77.24% | 79.74% | 102.24% |
