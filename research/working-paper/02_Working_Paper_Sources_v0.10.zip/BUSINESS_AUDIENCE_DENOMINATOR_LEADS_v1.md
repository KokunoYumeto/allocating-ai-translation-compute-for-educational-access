# Business-education audience denominator leads

Bounded primary-source check, 8 September 2026. Scope: Hindi, Kannada and Hiligaynon business-learning audiences; not a ranking of whole languages. Starting document: `VOCATIONAL_PACKAGE_ALLOCATION_v1.md`, SHA-256 `2e27a014e15ffddc98002681d7e3c30bfcc28d65e70dbab8a6f915e5fd4d1eb6`.

## Finding that changes the next step

Do a joint-record tabulation before attempting ecological allocation from national business totals. Original Indian survey and Philippine census documentation contain both language and business variables. Neither consulted source publishes the requested exact-language adult micro-retailer count. Both primarily measure language at household/respondent level, not every entrepreneur's own language ability. Thus they support a **language-associated occupational denominator**, with an explicit measurement qualification; they do not establish individual-language eligibility, unmet educational need, reach or comprehension effects.

Three primary-source leads follow. Supporting pages within a lead document the same original survey/census source, not independent corroboration. URLs and relevant passages were opened on the date above; no microdata estimates were calculated.

## 1. India: IHDS-II, 2011-12, original survey documentation

Source: NCAER and University of Maryland, [Income and Social Capital Questionnaire](https://ihds.umd.edu/sites/default/files/2022-08/ihds2isq.pdf). Printed pages 4, 14-16, 28 and 32 are PDF pages 5, 15-17, 29 and 33. [Publisher overview](https://ihds.umd.edu/data/ihds-2) identifies a nationally representative survey of 42,152 households and links ICPSR study 36151; this sample size is not an entrepreneur denominator.

Relevant fields: p. 28, Q17.1/SN1 asks "What is your mother tongue?" Hindi=01, Kannada=07, Urdu=13. It is not a per-person roster language question. Pages 14-16 record up to three nonfarm businesses, industry/occupation, working family members and primary decision-maker IDs (NF15/NF35/NF55). Page 4 has roster age RO5 and primary activity RO7; RO6 is marital status. Primary-activity code 06 covers petty shops/small business, but that filter is not required for the decision-maker audience. Children are included in business-work lists. Page 32 identifies the primary interview respondent (OH1b), but does not establish who answered SN1 specifically. The field alignment was checked against the original questionnaire on 8 September 2026; the earlier RO6 activity label is not an extraction authority.

Proposed denominator: unique resident decision-makers aged 18+ for retail-coded businesses in SN1=01 or 07 households. Deduplicate decision-makers across business slots; do not count all household members or every business as another learner. Report a broader all-nonfarm-business comparison separately. The language belongs to the respondent-associated household classification; even matching OH1b to the decision-maker is a sensitivity restriction, not proof of SN1's respondent. Business-work reference is the preceding year; 2011-12 estimates are historical, not 2026 counts. Verify released weights, industry-code labels, missingness and sparse-cell precision before estimating.

## 2. Philippines: PSA 2020 CPH sample-household joint-record route

Stable source identity: `PHL-PSA-CPH-2020-v1.0`, [Form 3 data dictionary, file F8](https://psada.psa.gov.ph/catalog/231/data-dictionary/F8?file_name=CPH+Form+3+-+Sample+Household+Questionnaire), metadata modified 15 May 2024. It lists H13 (home language), P21 (usual activity/occupation), P22 (industry), P23 (class of worker), P5 (five-year age group), POPWGT and household/person identifiers. H13's [literal question](https://psada.psa.gov.ph/catalog/231/variable/F8/V1050?name=H13) concerns the language generally spoken at home. [P21](https://psada.psa.gov.ph/catalog/231/variable/F8/V727?name=P21) and [P22](https://psada.psa.gov.ph/catalog/231/variable/F8/V728?name=P22) use the preceding 12 months; P21 skips nongainful usual activities past the business questions.

Proposed denominator: unique adults in Hiligaynon/Ilonggo-home-language households whose usual industry is retail and worker class identifies own-account work or an employer. This excludes employee status from an entrepreneur count; family workers can form a separately specified learning audience. No enterprise-size variable is listed, so employer status alone cannot identify microenterprises. Secondary retail businesses may be missed by usual-activity classification.

The successfully retrieved official metadata does not establish the collection's minimum age or P23 category codes. Verify these in the original Form 3/manual before execution; do not borrow codes from another census. If only five-year age bands are released, preserve 15-19 separately and bound an 18+ audience between the corresponding 20+ and 15+ counts, conditional on coverage. Dictionary "Cases 0" is metadata, not a zero audience. No sample records or ready-made cross-tab were retrieved.

## 3. Philippines: an exact published household-language ceiling

Source: PSA, release 2023-42, 7 March 2023, [Tagalog is the Most Widely Spoken Language at Home](https://psa.gov.ph/system/files/phcd/02%20-Press%20Release%20on%20Language_Dialect%20Generally%20Spoken%20at%20Home_030323_PMMJ_CRD.pdf), Table 1, printed/PDF p. 2; qualifications p. 3.

The 2020 count is **1,933,512 Hiligaynon/Ilonggo households**, within **26,388,654 households**; **117,335** households have language not reported. The total excludes households enumerated as homeless. Unit is households, with no age or occupation restriction; it is not a count of individual Hiligaynon speakers, entrepreneurs, phones or learners. This table and lead 2 derive from the same census and must not be treated as independent audience pools.

## Transparent bounds and executable continuation

For a deliberately household-based route serving at most one selected adult micro-retailer per household, the recorded Hiligaynon/Ilonggo-language cohort satisfies `0 <= X <= 1,933,512`. This is an upper bound on eligible **households under that definition**, not on all Hiligaynon-speaking entrepreneurs. It gives no positive lower bound. Speakers in differently classified or missing-language households are outside that recorded cohort; multiple entrepreneurs within a household require person-level counting.

If a same-year, same-universe count `B` of households containing the specified adult retail entrepreneurs becomes available, with `H=1,933,512` and `T=26,388,654`, then the elementary intersection bounds are `max(0,H+B-T) <= X <= min(H,B)`. These do not assume independence. A national establishment count or individual-worker count cannot substitute for `B`; a generic language share times businesses would impose an unmeasured independence assumption.

Next bounded action: inspect the released IHDS household/individual codebooks and access route, then produce one weighted Hindi/Kannada table with unique adult retail decision-makers, unweighted cell sizes, missing cases, design-based uncertainty and an explicit respondent-language label. In parallel only if useful, check the PSA Form 3 release and code availability, retaining the exact household ceiling above while that extraction remains unavailable. Do not create accounts, request custom tabulations, contact people, or wait for human review as part of this lead-finding step. Keep unknown cohort parameters in allocation scenarios; neither this uncertainty nor unavailable human evidence suspends independently useful educational production. Never multiply national population by a trial effect.

Operational observation: the PSA Form 3 download failed through the retrieved catalogue link; the legacy FOI attachment resolved to a missing-document page. The accessible official dictionary established the joint-variable lead, not successful acquisition of usable microdata. No source-byte hash or completed cross-tab is claimed.
