# Financial-training package evidence: Drexler, Fischer, and Schoar (2014)

Evidence checked: 2026-09-08. Scope: one randomized study and its own online appendix, not financial advice, a translation, or a new review of the financial-education literature. The numerical entries below are factual extraction; recommendations are explicitly marked as inference.

## Finding for educational-access package selection

This study supports testing a focused, locally adapted practical curriculum for comparable micro-entrepreneurs. It does **not** compare a complete course with a standalone practical resource: both active arms were courses, shared three initial classes, and included instructors, record books, handouts, and homework. It supplies no treatment effect for unattended AI-translated books, no language-access contrast, no compute-to-learning conversion, and no evidence that comprehensive study should generally be replaced by heuristics. [Primary paper, pp. 8-9, 25-26](https://www.povertyactionlab.org/sites/default/files/research-paper/124_303%20Rules%20of%20Thumb%20AEJ%20Apr2014.pdf)

## Population and treatment facts

| Field | Extracted fact | Locator |
|---|---|---|
| Audience | Existing ADOPEM personal/business loan clients in Santo Domingo, Dominican Republic; generic training interest in the sampling frame, not a population sample | pp. 3-4, 8-11 |
| Sample | 1,193; original 1,200 minus seven baseline-survey errors; group borrowers with loans below RD$15,000 excluded | p. 8, note 12 |
| Baseline | Mean age 40.2; 90% female; 35% high-school education or more; 50% sales/trading businesses; 47% specifically interested in accounting/financial training | Table 1, p. 10 |
| Business context | 60% sole proprietorships without additional employees; typical shops, groceries, salons, food service; local markets | p. 11 |
| Language | Named delivery language **not established**. Adaptation of the conventional curriculum to Dominican language, idiom, and examples is reported; this is not an explicit statement of Spanish delivery | p. 2, note 1; whole-paper language search |
| Allocation | Individual randomization, stratified using loan size, borrowing history, and formal savings-account status | p. 8 |
| Arms | Accounting 402; rules-of-thumb 404; control 387, with no additional training | p. 8; Table A3, p. 27 |
| Dose | Accounting: 6 weekly sessions x 3 hours = 18 scheduled hours. Rules: 5 x 3 = 15 scheduled hours. Hours are arithmetic from the stated schedule | p. 8 |
| Common foundation | First three sessions: savings, consumption, debt management; later sessions differed in accounting depth and practical estimation/account separation | Table A1, p. 26 |
| Delivery | Qualified local instructors, seven schools, preference-informed scheduling, subsidized fees randomized to RD$0/RD$200; stated program cost about RD$700 | p. 9 |
| Timeline | Training March-May and July-August 2007; endline summer/mid-2008, described by the paper as at least 12 months after completion | pp. 9, 11 |
| Participation | Any class: accounting 184/402 (45.8%); rules 174/404 (43.1%). Not completion rates | Table A3, p. 27 |
| Added assistance | In-person business follow-up randomized conditional on first-class attendance; 83 accounting and 74 rules participants assigned | p. 22, note 26; Table A3 |

The active comparison is therefore a **supported practical-course package versus a supported conventional-accounting-course package**, with content and scheduled duration changing together. The follow-up results are inconclusive, not evidence that instructor support can be removed. [Primary paper, pp. 22-23, Table A4 p. 28](https://www.povertyactionlab.org/sites/default/files/research-paper/124_303%20Rules%20of%20Thumb%20AEJ%20Apr2014.pdf)

## Outcomes and uncertainty

Table 2 estimates are assignment effects among observed respondents operating a business at endline, not effects on all randomized participants or effects of completing training. Standard errors are barrio-clustered. No direct mastery/knowledge-test outcome is reported in the consulted results. Index coefficients are **index units**, not automatically standard deviations of the composite. [Primary paper, pp. 12-16](https://www.povertyactionlab.org/sites/default/files/research-paper/124_303%20Rules%20of%20Thumb%20AEJ%20Apr2014.pdf)

| Table 2 outcome | N | Accounting estimate (SE) | Rules estimate (SE) | Between-arm equality p |
|---|---:|---:|---:|---:|
| Business-practices index | 795 | 0.07 (0.06) | 0.14 (0.04), p<.01 | .195 |
| Separate business/personal cash | 793 | 0.00 (0.03) | 0.08 (0.03), p<.01 | .014 |
| Keep accounting records | 794 | 0.04 (0.05) | 0.11 (0.03), p<.01 | .095 |
| Any reporting error | 757 | -0.04 (0.04) | -0.09 (0.03), p<.01 | .161 |
| Revenue index | 774 | -0.02 (0.05) | 0.09 (0.05), p=.054 in text | .031 |
| Average-week sales, RD$ | 570 | -682 (809) | 424 (867), not significant at .10 | .290 |
| Bad-week sales, RD$ | 551 | -660 (514) | 979 (524), .05<=p<.10 | .002 |
| Employees | 794 | 0.07 (0.09) | -0.03 (0.09), not significant at .10 | .399 |

Locations: Table 2 p. 15 and interpretation pp. 16-17. The paper translates the rules business-practices and revenue estimates to approximately 0.25 and 0.11 composite SD respectively. A significant rules-versus-control result does not itself establish rules-versus-accounting superiority: the full-sample practice-index and error-rate contrasts above do not reject equality.

Follow-up reached 1,032/1,193: control 335, accounting 349, rules 348. Endline business owners numbered 266, 264, and 276 respectively (806 total); item-level Ns are smaller. Among reached respondents, business ownership fell from roughly 97% at baseline to 78% at endline. Differential ownership estimates were accounting -0.037 (p=.235), rules 0.001 (p=.977). Nonsignificance does not prove absence of selection. [Table A3 p. 27; pp. 21-22](https://www.povertyactionlab.org/sites/default/files/research-paper/124_303%20Rules%20of%20Thumb%20AEJ%20Apr2014.pdf)

The worst-case missing-outcome bounds include zero for all three headline outcomes. Revenue is especially sensitive: its lower-bound estimate becomes 0.013 (SE 0.038) under the paper's +/-0.10-SD imputation scenario. Revenue measures are self-reports; training can change reporting and respondents' classification of bad weeks. The bad-week effect loses significance without baseline-sales controls. Profits/welfare are not established, and nearby same-industry firms show suggestive crowd-out. [Table 5 p. 23; pp. 12, 17, 22-25](https://www.povertyactionlab.org/sites/default/files/research-paper/124_303%20Rules%20of%20Thumb%20AEJ%20Apr2014.pdf)

## Subgroups: selected direct contrasts, not universal effects

Subgroup categories were in the analysis plan before endline (p. 13, note 20). High skill means high-school completion **or** prior formal financial training; low skill means neither. Reported subgroup p-values are not a demonstrated multiplicity-adjusted confirmation.

| Subgroup | Rules minus accounting | Equality p | Qualification |
|---|---|---:|---|
| Low skill | Reporting errors -0.12; revenue index +0.17 | .016; .044 | Practice-index contrast +0.06 has p=.328 |
| Lowest baseline-practice quartile | Practice index +0.21; revenue index +0.28 | .010; .014 | Rules-only revenue effect +0.12 is not significant; accounting effect is negative |
| No prior specific training interest | Practice index +0.12; revenue index +0.17 | .052; .055 | Marginal, not below .05 |
| High skill | Practice index +0.05; revenue index +0.02 | .449; .832 | No detected advantage is not equivalence |
| Second baseline-practice quartile | Practice index -0.04; revenue index +0.04 | .589; .790 | Expanded appendix restores the omitted quartile |

Source: Table 4, p. 19, and [online appendix, p. 1, expanded Table 4](https://www.aeaweb.org/aej/app/app/0602/2013-0101_app.pdf). Do not mix tables silently: Table 4/appendix report rules errors -0.08 and bad-week sales +967; Table 2 reports -0.09 and +979. Accounting also improves selected outcomes/subgroups, so “accounting never works” is false.

## Package-design inference and non-transfer

For comparable adult microbusiness learners, a practical-first curriculum with concrete account-separation routines is a defensible candidate alongside a deeper optional accounting pathway. This is a design inference, **not** a tested adaptive pathway or a demand estimate for a new book. Preserve the tested shared foundation and distinguish a resource's availability from engagement, comprehension, practice adoption, and business outcomes.

Unattended AI-translated books remove or change instructor mediation, homework feedback, institutional recruitment, local adaptation, pricing, dose, and selection into attendance. The experiment did not randomize translation, book length, language, AI, or compute allocation. It therefore cannot justify assigning the trial's effect size to translated books, calculating universal learners-benefited per GPU-hour, or discarding full-course provision for advanced learners. It also cannot establish that all practical heuristics preserve correctness in unfamiliar business settings.

## Source custody and completed checks

- Primary: Drexler, Alejandro, Greg Fischer, and Antoinette Schoar. 2014. *Keeping It Simple: Financial Literacy and Rules of Thumb*. AEJ: Applied Economics 6(2): 1-31. DOI: [10.1257/app.6.2.1](https://doi.org/10.1257/app.6.2.1). Downloaded from the J-PAL URL linked above: `sources/financial_package_20260908/Drexler_Fischer_Schoar_2014_published_JPAL.pdf`; 1,741,786 bytes; SHA-256 `d9ef107b5a9a84336df9ead7b6a7ef48b265abe3d705398aa3eb4288e531fa50`.
- Directly related primary supplement: same authors' online appendix, expanded Table 4, one page, publisher URL linked above. `sources/financial_package_20260908/Drexler_Fischer_Schoar_2014_online_appendix_AEA.pdf`; 29,136 bytes; SHA-256 `b192dbf880be2f625fe005421bf96618e3c182861b2028536ca6c580d480935d`. Publication association: 2014 article; PDF creation metadata 2013-11-13, not treated as a separate study date.
- Access date for both: 2026-09-08. Primary PDF has no cover offset: PDF page number = printed page number. Relevant consulted text: pp. 2-4, 7-29 (including Tables 1-6, A1-A5); supplement p. 1. Numerics visually checked against rendered Tables 2, 4, 5, A3, and expanded Table 4. Appendix rendering issued substitute-font warnings, but the table remained legible and agreed with extracted text.
- LSE mirror fetch failed on a challenge page; no source PDF was saved from that route. Two source PDFs only were downloaded. No replication or additional studies were downloaded; no primary research state or publication was changed. This extraction is complete; integration is the parent task's next action. Remaining uncertainties are evidentiary limitations, not review holds.
