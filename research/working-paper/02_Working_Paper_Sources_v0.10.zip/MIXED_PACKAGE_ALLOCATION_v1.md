# Choosing focused resources and complete books within the same budget

This calculation chooses both the language edition and the size of its educational package. It retains the same worldwide audience basis for every profile. Its new result is a set of mixed-package allocations, not a claim that a fraction of the world has been educated.

## What is compared

All options target the same six-week fraction-understanding outcome. Full prealgebra has other valuable outcomes, but these are not silently counted against a fractions-only package. The wider paper retains other subjects, stages, research mathematics, registers and accessibility routes.

| Package | Source modules | Content tokens | Extra edition work as share of full variable work |
|---|---:|---:|---:|
| Fractions with linked support | 16 | 87,655 | 5% |
| Six chapters | 36 | 173,958 | 2% |
| Complete prealgebra | 75 | 364,270 | 0% |

The source is OpenStax Prealgebra 2e at commit 38cae454e644abf9f0a623e876994553881597c9. Source-length counts are reproduced from its pinned CNXML. The support package follows eight direct outside links, not a claim of complete prerequisite closure. Six chapters and supported fractions are not nested: their union is 40 modules and 198,477 tokens. Common preparation is charged for that union once, not once per edition.

The extra-work rates, budgets, source-preparation rates and learning ratios below are declared scenarios, not measurements. In the lower-focused-yield scenario, supported fractions and six chapters retain 35% and 70% of the full book's incremental offer-level benefit on the same outcome. In the higher-focused-yield scenario they retain 65% and 90%. Full-book benefit is positive but unmeasured; the common multiplier is not assigned a fabricated empirical value.

## Budget results

The score column is the audience-weighted relative-benefit coefficient, expressed in millions for legibility. It is not unique people, learners reached or observed score gains. A common unknown relevant-audience and offer-level-benefit factor converts it to a conditional gain. Shared preparation rates are additional workload units per distinct source-content token.

| Focused benefit scenario | Setup rate | Budget millions | Fractions / six / full editions | Work used millions | Relative opportunity score millions | Improvement over best one-package-size policy |
|---|---:|---:|---|---:|---:|---:|
| Lower | 0 | 5 | 0 / 0 / 1 | 4.890 | 1,152.0 | 0.00% |
| Lower | 0 | 10 | 0 / 2 / 1 | 9.918 | 1,679.0 | 4.50% |
| Lower | 0 | 20 | 1 / 5 / 1 | 19.906 | 2,564.4 | 11.18% |
| Lower | 2 | 5 | 1 / 1 / 0 | 4.412 | 988.3 | 22.56% |
| Lower | 2 | 10 | 1 / 1 / 1 | 9.782 | 1,675.0 | 12.53% |
| Lower | 2 | 20 | 0 / 5 / 1 | 18.984 | 2,476.7 | 7.37% |
| Higher | 0 | 5 | 0 / 2 / 0 | 4.925 | 1,446.0 | 0.00% |
| Higher | 0 | 10 | 3 / 2 / 0 | 9.745 | 2,214.5 | 11.91% |
| Higher | 0 | 20 | 6 / 4 / 0 | 19.578 | 3,165.3 | 6.73% |
| Higher | 2 | 5 | 3 / 0 / 0 | 4.634 | 1,382.2 | 0.00% |
| Higher | 2 | 10 | 3 / 2 / 0 | 9.981 | 2,149.6 | 8.63% |
| Higher | 2 | 20 | 6 / 4 / 0 | 19.975 | 3,165.3 | 6.73% |

A single package-size policy means every selected language receives the same size, with its own optimal language selection. The mixed policy may give different sizes to different languages; every language had the same three choices and yield assumptions. The result does not impose country-specific learning assumptions or deduct local translations from need.

## Exact portfolio selections

### lower_focused_yield::setup0::B5000000

- Complete prealgebra: Simplified Standard Written Chinese profile.

### lower_focused_yield::setup0::B10000000

- Six chapters: Spanish, Latin-script profile; French, Latin-script profile.
- Complete prealgebra: Simplified Standard Written Chinese profile.

### lower_focused_yield::setup0::B20000000

- Fractions with linked support: Bangla, Bangla-script profile.
- Six chapters: Hindi, Devanagari-script profile; Spanish, Latin-script profile; Arabic, Arabic-script profile; French, Latin-script profile; Urdu, Arabic-script profile.
- Complete prealgebra: Simplified Standard Written Chinese profile.

### lower_focused_yield::setup2::B5000000

- Fractions with linked support: Hindi, Devanagari-script profile.
- Six chapters: Simplified Standard Written Chinese profile.

### lower_focused_yield::setup2::B10000000

- Fractions with linked support: Spanish, Latin-script profile.
- Six chapters: Hindi, Devanagari-script profile.
- Complete prealgebra: Simplified Standard Written Chinese profile.

### lower_focused_yield::setup2::B20000000

- Six chapters: Hindi, Devanagari-script profile; Spanish, Latin-script profile; Arabic, Arabic-script profile; French, Latin-script profile; Urdu, Arabic-script profile.
- Complete prealgebra: Simplified Standard Written Chinese profile.

### higher_focused_yield::setup0::B5000000

- Six chapters: Simplified Standard Written Chinese profile; Spanish, Latin-script profile.

### higher_focused_yield::setup0::B10000000

- Fractions with linked support: Spanish, Latin-script profile; Arabic, Arabic-script profile; French, Latin-script profile.
- Six chapters: Simplified Standard Written Chinese profile; Hindi, Devanagari-script profile.

### higher_focused_yield::setup0::B20000000

- Fractions with linked support: French, Latin-script profile; Urdu, Arabic-script profile; Bangla, Bangla-script profile; Portuguese, Latin-script profile; Indonesian, Latin-script profile; Russian, Cyrillic-script profile.
- Six chapters: Simplified Standard Written Chinese profile; Hindi, Devanagari-script profile; Spanish, Latin-script profile; Arabic, Arabic-script profile.

### higher_focused_yield::setup2::B5000000

- Fractions with linked support: Simplified Standard Written Chinese profile; Hindi, Devanagari-script profile; Spanish, Latin-script profile.

### higher_focused_yield::setup2::B10000000

- Fractions with linked support: Hindi, Devanagari-script profile; Arabic, Arabic-script profile; Portuguese, Latin-script profile.
- Six chapters: Simplified Standard Written Chinese profile; Spanish, Latin-script profile.

### higher_focused_yield::setup2::B20000000

- Fractions with linked support: French, Latin-script profile; Urdu, Arabic-script profile; Bangla, Bangla-script profile; Portuguese, Latin-script profile; Indonesian, Latin-script profile; Russian, Cyrillic-script profile.
- Six chapters: Simplified Standard Written Chinese profile; Hindi, Devanagari-script profile; Spanish, Latin-script profile; Arabic, Arabic-script profile.

## Unknown audiences and overlap

All 25 unknown-audience profiles remain named with null audiences. For each of their three packages, every budget scenario reoptimizes the known portfolio with that option forced into the source union. The saved threshold states the contribution needed to improve the allocation, not a zero-need assignment. One-at-a-time thresholds do not solve combinations of multiple unknowns.

The solver maximizes additive edition opportunities. The same person may benefit from more than one edition, so the sum is not unique people. The output additionally evaluates each selected set with nested audiences and maximum available package benefit per person. With unequal package benefits, nested audiences do not reduce to the largest single audience-weighted score. None of these geometries is assumed to describe real multilingual populations.

## Scope and reproducibility

The 750 numeric profiles and 25 symbolic alternatives come unchanged from the worldwide baseline. The much larger inclusion register remains in the paper; this bounded solve does not claim to estimate every language, signed language or register. Nine PISA-related need-context counts remain separate and are not substituted for the corresponding worldwide language audiences.

The JSON records all profile identities, all selected options, exact rational selected costs and coefficients, actual source unions, all single-size comparators and symbolic insertion portfolios. Every finite solve has a 20-second cap and one worker. Successful numerical solver bounds are not formal mathematical certificates. Empty choices are allowed; no community is presumed to have negative benefit because evidence is missing.
