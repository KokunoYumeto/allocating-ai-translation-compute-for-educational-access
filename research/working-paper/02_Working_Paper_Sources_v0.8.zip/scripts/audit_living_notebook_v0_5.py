"""Audit the v0.5 paper, allocation tables, formats, privacy, and archive."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET
import csv
import hashlib
import json
import os
import re
import zipfile

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "publication/living_notebook_v0_5"
REPORT = ROOT / "qa/LIVING_WORKING_PAPER_COMPREHENSIVE_AUDIT_v0_5.json"
PDF = OUT / "00_START_HERE__Current_Working_Paper_v0.5.pdf"
MANIFEST = OUT / "01_SNAPSHOT_MANIFEST_v0.5.json"
ARCHIVE = OUT / "02_Working_Paper_Sources_v0.5.zip"
HTML = OUT / "03_READABLE_WORKING_PAPER_v0.5.html"
DOCX = OUT / "04_EDITABLE_WORKING_PAPER_v0.5.docx"
MARKDOWN = OUT / "05_CURRENT_WORKING_PAPER_v0.5.md"
REACH_TOP100 = OUT / "06_WORLDWIDE_REACH_TOP100_v0.5.csv"
COMPUTE_TOP100 = OUT / "07_COMMON_PACKAGE_COMPUTE_PROXY_TOP100_v0.5.csv"
PROFILE_INVENTORY = OUT / "08_NONORDINAL_PROFILE_INVENTORY_v0.5.csv"
STATUS = OUT / "PUBLICATION_STATUS.md"

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
DC = "http://purl.org/dc/elements/1.1/"
CP = "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def json_file(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def audit_citations(paper: str) -> dict[str, object]:
    marker = "## References used in this draft"
    if marker not in paper:
        raise AssertionError("Reference section missing")
    body, references = paper.split(marker, 1)
    patterns = [
        r"\b([A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ’'\-]+)(?:\s+et al\.)?\s*\((\d{4}[a-z]?)\)",
        r"(?:\(|;\s*)([A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ’'\-]+)(?:\s+et al\.)?,\s*(\d{4}[a-z]?)",
    ]
    ignore = {"Figure", "Table", "Section", "Appendix", "Equation", "Version"}
    citations = sorted({(lead, year) for pattern in patterns for lead, year in re.findall(pattern, body) if lead not in ignore})
    matched = []
    unresolved = []
    aliases = {"nisr": "National Institute of Statistics of Rwanda"}
    for lead, year in citations:
        normalized_lead = re.sub(r"(?:'s|’s)$", "", lead, flags=re.IGNORECASE)
        reference_lead = aliases.get(normalized_lead.casefold(), normalized_lead)
        if reference_lead.casefold() in references.casefold() and year in references:
            matched.append(f"{lead}, {year}")
        else:
            unresolved.append(f"{lead}, {year}")
    return {
        "method": "Lead-author and year string reconciliation against the manuscript reference section; this is a completeness triage, not claim-level entailment review.",
        "citation_pairs": len(citations),
        "matched": len(matched),
        "unresolved": unresolved,
        "pass": not unresolved,
    }


def audit_pdf(manifest: dict[str, object]) -> dict[str, object]:
    reader = PdfReader(PDF)
    text = "\n\f\n".join(page.extract_text() or "" for page in reader.pages)
    metadata = "\n".join(str(value) for value in (reader.metadata or {}).values() if value is not None)
    root = reader.trailer.get("/Root", {})
    names = root.get("/Names", {}) if hasattr(root, "get") else {}
    sizes = Counter((round(float(page.mediabox.width), 3), round(float(page.mediabox.height), 3)) for page in reader.pages)
    checks = {
        "hash_matches_manifest": sha(PDF) == manifest["paper"]["sha256"],
        "bytes_match_manifest": PDF.stat().st_size == manifest["paper"]["bytes"],
        "page_count_matches_manifest": len(reader.pages) == manifest["paper"]["pages"] and len(reader.pages) > 0,
        "unencrypted": not reader.is_encrypted,
        "no_javascript": not bool(names.get("/JavaScript")) if hasattr(names, "get") else True,
        "no_embedded_files": not bool(names.get("/EmbeddedFiles")) if hasattr(names, "get") else True,
        "no_acroform": not bool(root.get("/AcroForm")) if hasattr(root, "get") else True,
        "no_replacement_character": "\ufffd" not in text,
        "no_private_profile_path": not re.search(r"(?i)[A-Za-z]:\\Users\\", text + metadata),
        "no_private_name": Path.home().name not in text + metadata,
        "ascii_prose_dashes": not any(ch in text for ch in ("\u2011", "\u2013", "\u2014")),
        "governing_thesis_present": "governing thesis" in text.casefold(),
        "indonesia_present": "Indonesian" in text,
        "ukraine_present": "Ukrainian" in text,
        "simplified_chinese_present": "Simplified Standard Written Chinese" in text,
        "correct_model_count_present": "1,069" in text,
        "worldwide_reach_rows_present": "775 non-English" in text,
        "common_package_proxy_present": "Common-package proxy position" in text,
        "ordinal_distinction_present": "Profile IDs are never ranks" in text,
    }
    return {
        "checks": checks,
        "pass": all(checks.values()),
        "pages": len(reader.pages),
        "page_sizes_points": [{"width": w, "height": h, "pages": n} for (w, h), n in sorted(sizes.items())],
        "tagged_pdf": bool(root.get("/MarkInfo", {}).get("/Marked")) if hasattr(root, "get") else False,
        "accessibility_note": "The PDF is the visual entry point. The complete offline HTML reader supplies semantic headings, tables, links, reflow, and a skip link; PDF tagging is reported rather than inferred.",
    }


def audit_docx() -> dict[str, object]:
    with zipfile.ZipFile(DOCX) as package:
        corrupt = package.testzip()
        names = set(package.namelist())
        parts = {name: package.read(name) for name in names if name.endswith((".xml", ".rels"))}
    decoded = "\n".join(value.decode("utf-8", errors="replace") for value in parts.values())
    document = ET.fromstring(parts["word/document.xml"])
    styles = ET.fromstring(parts["word/styles.xml"])
    core = ET.fromstring(parts["docProps/core.xml"])
    creator = core.findtext(f"{{{DC}}}creator") or ""
    last_modified = core.findtext(f"{{{CP}}}lastModifiedBy") or ""
    tables = document.findall(f".//{{{W}}}tbl")
    header_rows = document.findall(f".//{{{W}}}tblHeader")
    paragraphs = document.findall(f".//{{{W}}}p")
    title_texts = []
    for paragraph in paragraphs:
        style = paragraph.find(f"./{{{W}}}pPr/{{{W}}}pStyle")
        if style is not None and style.get(f"{{{W}}}val") == "Title":
            title_texts.append("".join(node.text or "" for node in paragraph.findall(f".//{{{W}}}t")))
    heading_colors = {}
    for style in styles.findall(f".//{{{W}}}style"):
        style_id = style.get(f"{{{W}}}styleId")
        if style_id in {"Title", "Subtitle", "Heading1", "Heading2", "Heading3"}:
            color = style.find(f"./{{{W}}}rPr/{{{W}}}color")
            heading_colors[style_id] = color.get(f"{{{W}}}val") if color is not None else None
    punctuation = re.compile(r"[^\w\s]", re.UNICODE)
    checks = {
        "valid_zip": corrupt is None,
        "document_xml_present": "word/document.xml" in names,
        "no_comments": not any(name.startswith("word/comments") for name in names),
        "no_tracked_changes": not document.findall(f".//{{{W}}}ins") and not document.findall(f".//{{{W}}}del"),
        "no_replacement_character": "\ufffd" not in decoded,
        "no_private_profile_path": not re.search(r"(?i)[A-Za-z]:\\Users\\", decoded),
        "no_private_name": Path.home().name not in decoded,
        "ascii_prose_dashes": not any(ch in decoded for ch in ("\u2011", "\u2013", "\u2014")),
        "model_provenance_creator": creator == "OpenAI Codex gpt-5.6-sol, Ultra",
        "model_provenance_last_modified": last_modified == "OpenAI Codex gpt-5.6-sol, Ultra",
        "ten_tables": len(tables) == 10,
        "all_tables_have_header_row": len(header_rows) >= len(tables),
        "title_present": title_texts == ["Allocating AI assisted educational publishing for greater access"],
        "title_has_no_punctuation": bool(title_texts) and not punctuation.search(title_texts[0]),
        "titles_and_headings_black": bool(heading_colors) and all(value in {"000000", "auto"} for value in heading_colors.values()),
    }
    return {
        "checks": checks,
        "pass": all(checks.values()),
        "paragraphs": len(paragraphs),
        "tables": len(tables),
        "table_header_flags": len(header_rows),
        "title_texts": title_texts,
        "heading_colors": heading_colors,
        "creator": creator,
        "last_modified_by": last_modified,
    }


def audit_html() -> dict[str, object]:
    text = HTML.read_text(encoding="utf-8")
    first_content_link = re.search(r'<section class="downloads".*?<a href="([^"]+)"', text, flags=re.S)
    checks = {
        "full_manuscript_size": HTML.stat().st_size > 200_000,
        "doctype": text.lower().startswith("<!doctype html>"),
        "language_declared": '<html lang="en">' in text,
        "skip_link": 'href="#paper"' in text,
        "semantic_article": '<article id="paper">' in text,
        "responsive_viewport": 'name="viewport"' in text,
        "no_script": "<script" not in text.casefold(),
        "no_external_http_dependency": "http://" not in text,
        "no_private_profile_path": not re.search(r"(?i)[A-Za-z]:[\\/]Users[\\/]", text),
        "no_private_name": Path.home().name not in text,
        "pdf_is_first_content_download": bool(first_content_link) and first_content_link.group(1) == PDF.name,
        "complete_paper_abstract": "AI-assisted translation can expand educational access" in text,
        "governing_thesis_present": "governing access thesis" in text.casefold(),
        "correct_model_count_present": "1,069" in text,
        "reach_download_present": REACH_TOP100.name in text,
        "compute_download_present": COMPUTE_TOP100.name in text,
        "profile_inventory_download_present": PROFILE_INVENTORY.name in text,
        "ordinal_distinction_present": "Do not confuse IDs with ranks" in text,
    }
    return {"checks": checks, "pass": all(checks.values()), "bytes": HTML.stat().st_size, "sha256": sha(HTML)}


def audit_archive(manifest: dict[str, object]) -> dict[str, object]:
    bindings = {row["path"]: row for row in manifest["source_bindings"]}
    with zipfile.ZipFile(ARCHIVE) as archive:
        corrupt = archive.testzip()
        entries = archive.namelist()
        mismatches = []
        for rel, binding in bindings.items():
            data = archive.read(rel)
            if len(data) != binding["bytes"] or hashlib.sha256(data).hexdigest().upper() != binding["sha256"]:
                mismatches.append(rel)
    checks = {
        "zip_integrity": corrupt is None,
        "entry_count_66": len(entries) == 66,
        "all_source_bindings_present": set(bindings).issubset(entries),
        "all_source_binding_bytes_match": not mismatches,
    }
    return {"checks": checks, "pass": all(checks.values()), "entries": len(entries), "mismatches": mismatches, "bytes": ARCHIVE.stat().st_size, "sha256": sha(ARCHIVE)}


def main() -> None:
    paths = [PDF, MANIFEST, ARCHIVE, HTML, DOCX, MARKDOWN, REACH_TOP100, COMPUTE_TOP100, PROFILE_INVENTORY, STATUS]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)
    manifest = json_file(MANIFEST)
    effect = json_file(ROOT / "structured/INTERVENTION_EFFECT_EVIDENCE_v1.json")
    portfolios = json_file(ROOT / "structured/CONDITIONAL_GLOBAL_PORTFOLIOS_v1.json")
    model = json_file(ROOT / "structured/CONDITIONAL_PORTFOLIO_MODEL_v1.json")
    paper = MARKDOWN.read_text(encoding="utf-8")
    reach_rows = read_csv(REACH_TOP100)
    compute_rows = read_csv(COMPUTE_TOP100)
    profile_rows = read_csv(PROFILE_INVENTORY)
    reach_source_rows = read_csv(ROOT / "structured/GLOBAL_EDITION_REACH_BASELINE_v3.csv")
    compute_source_rows = read_csv(ROOT / "structured/GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv")

    model_checks = {
        "effect_studies_53": effect["counts"]["studies"] == 53,
        "effect_scenarios_18": effect["counts"]["planning_scenarios"] == 18,
        "effect_validation_pass": effect["validation"]["status"] == "PASS",
        "portfolio_programs_10": portfolios["counts"]["top10_programs"] == 10,
        "profile_inventory_100": portfolios["counts"]["top100_candidates"] == len(profile_rows) == 100,
        "portfolio_possible_outrankers_10625": portfolios["counts"]["global_universe_entities"] == 10625,
        "portfolio_validation_pass": portfolios["validation"]["status"] == "PASS",
        "model_interventions_1069": model["counts"]["interventions"] == 1069,
        "model_source_routes_1022": model["counts"]["source_route_interventions"] == 1022,
        "model_program_stage_records_47": model["counts"]["program_stage_interventions"] == 47,
        "model_possible_outrankers_10625": model["counts"]["possible_outrankers"] == 10625,
        "model_zero_robust_dominance_edges": model["counts"]["robust_dominance_edges"] == 0,
        "model_validation_pass": model["validation"]["status"] == "PASS" and model["validation"]["failure_count"] == 0,
        "reach_top100_exact_first_100": reach_rows == reach_source_rows[:100],
        "compute_top100_exact_first_100": compute_rows == compute_source_rows[:100],
        "profile_inventory_copy_exact": PROFILE_INVENTORY.read_bytes() == (ROOT / "structured/CONDITIONAL_TOP100_CANDIDATE_PORTFOLIO_v1.csv").read_bytes(),
        "reach_positions_1_to_100": [int(row["reach_position"]) for row in reach_rows] == list(range(1, 101)),
        "compute_positions_1_to_100": [int(row["proxy_position"]) for row in compute_rows] == list(range(1, 101)),
        "simplified_chinese_first_in_both": reach_rows[0]["language_code"] == "zh" and reach_rows[0]["script_code"] == "Hans" and compute_rows[0]["language_code"] == "zh" and compute_rows[0]["script_code"] == "Hans",
        "profile_ids_not_numeric_positions": all(not row.get("ordinal_rank") for row in profile_rows),
        "combined_markdown_contains_current_paper": (ROOT / "PAPER_CURRENT_DRAFT.md").read_text(encoding="utf-8").strip() in paper,
        "combined_markdown_contains_allocation_checkpoint": "Worldwide reach and common-package allocation checkpoint" in paper,
        "thesis_outside_empirical_scoring": "Governing access thesis" in (ROOT / "HYPOTHESIS_OUTCOMES_v2.md").read_text(encoding="utf-8"),
        "thesis_nonzero_benefit_rule_in_paper": "any credible nonzero educational benefit" in paper,
    }
    citation = audit_citations(paper)
    pdf = audit_pdf(manifest)
    docx = audit_docx()
    html_audit = audit_html()
    archive = audit_archive(manifest)

    manifest_artifacts = {row["name"]: row for row in manifest["public_artifacts_excluding_manifest"]}
    artifact_mismatches = []
    for path in [PDF, ARCHIVE, HTML, DOCX, MARKDOWN, REACH_TOP100, COMPUTE_TOP100, PROFILE_INVENTORY, STATUS]:
        row = manifest_artifacts.get(path.name)
        if row is None or row["bytes"] != path.stat().st_size or row["sha256"] != sha(path):
            artifact_mismatches.append(path.name)
    manifest_checks = {
        "schema_v0_5": manifest["schema"] == "living-educational-access-working-paper/0.5.0",
        "explicitly_nonfinal": manifest["final_product"] is False and manifest["exhaustive"] is False,
        "no_missing_evidence_exclusion": manifest["missing_evidence_means_exclusion"] is False,
        "thesis_not_scored": manifest["governing_access_thesis_is_scored"] is False,
        "all_nonmanifest_artifacts_match": not artifact_mismatches,
    }
    sections = {
        "model_and_data": {"checks": model_checks, "pass": all(model_checks.values())},
        "citations": citation,
        "pdf": pdf,
        "docx": docx,
        "html": html_audit,
        "archive": archive,
        "manifest": {"checks": manifest_checks, "pass": all(manifest_checks.values()), "mismatches": artifact_mismatches},
    }
    failures = []
    for section, result in sections.items():
        if not result["pass"]:
            failures.append(section)
    report = {
        "schema": "living-working-paper-comprehensive-audit/0.5.0",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS_DETERMINISTIC_AND_STRUCTURAL_CHECKS_VISUAL_REVIEW_PENDING" if not failures else "FAIL",
        "sections": sections,
        "failures": failures,
        "visual_review": "PENDING",
        "public_mutation": False,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "failures": failures, "citation_unresolved": citation["unresolved"], "path": str(REPORT), "bytes": REPORT.stat().st_size, "sha256": sha(REPORT)}, ensure_ascii=False, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
