"""Run the comprehensive v0.8 audit using the bounded v0.5 audit logic."""
from pathlib import Path
import importlib.util
ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "scripts/audit_living_notebook_v0_5.py").read_text(encoding="utf-8")
source = source.replace("v0_5", "v0_8").replace("v0.5", "v0.8").replace("0.5.0", "0.8.0")
source = source.replace('"ten_tables": len(tables) == 10', '"thirteen_tables": len(tables) == 13')
source = source.replace('"entry_count_66": len(entries) == 66', '"source_and_output_entry_inventory": len(entries) == len(bindings) + 5 and len(entries) == len(set(entries))')
source = source.replace('for path in [PDF, ARCHIVE, HTML, DOCX, MARKDOWN,', 'for path in [PDF, ARCHIVE, HTML, MARKDOWN,')
# DOCX structural checks remain, but no unrendered DOCX is a public artifact.
source = source.replace('"no_replacement_character": "\\ufffd" not in text,', '"no_replacement_character": "\\ufffd" not in text,\n        "no_null_glyph": "\\x00" not in text,')
spec = importlib.util.spec_from_loader("living_v08_audit", loader=None)
module = importlib.util.module_from_spec(spec); module.__file__ = str(ROOT / "scripts/audit_living_notebook_v0_5.py")
exec(compile(source, str(ROOT / "scripts/audit_living_notebook_v0_5.py"), "exec"), module.__dict__)
module.main()
