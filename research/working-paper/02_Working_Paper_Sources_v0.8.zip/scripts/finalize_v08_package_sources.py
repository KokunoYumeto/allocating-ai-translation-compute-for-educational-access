"""Preserve the exact v0.8 rebuild entrypoints with the public evidence sources."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'publication/living_notebook_v0_8'
MANIFEST = OUT / '01_SNAPSHOT_MANIFEST_v0.8.json'
ZIP = OUT / '02_Working_Paper_Sources_v0.8.zip'

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest().upper()}

manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
bindings = {row['path']: row for row in manifest['source_bindings']}
previous_packager_identity = bindings.pop('scripts/finalize_v08_package_sources.py', None)
for rel, row in bindings.items():
    if identity(ROOT / rel) != {key: row[key] for key in ('bytes', 'sha256')}:
        raise RuntimeError('Source changed after build: ' + rel)
for rel in ('scripts/build_living_notebook_v0_8.py', 'scripts/audit_living_notebook_v0_8.py',
            'scripts/finalize_v08_package_sources.py', 'scripts/build_living_notebook_v0_3.py',
            'scripts/build_living_notebook_v0_5.py', 'scripts/build_html_v1.py',
            'scripts/build_research_artifacts_v1.py', 'scripts/audit_living_notebook_v0_5.py'):
    bindings[rel] = {'path': rel, **identity(ROOT / rel)}
outputs = ['05_CURRENT_WORKING_PAPER_v0.8.md', '06_WORLDWIDE_REACH_TOP100_v0.8.csv',
           '07_COMMON_PACKAGE_COMPUTE_PROXY_TOP100_v0.8.csv', '08_NONORDINAL_PROFILE_INVENTORY_v0.8.csv',
           'PUBLICATION_STATUS.md']
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for rel in sorted(bindings):
        info = zipfile.ZipInfo(rel, date_time=(2026, 9, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, (ROOT / rel).read_bytes())
    for name in outputs:
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, (OUT / name).read_bytes())
with zipfile.ZipFile(ZIP) as archive:
    if archive.testzip() is not None or len(archive.namelist()) != len(bindings) + 5:
        raise RuntimeError('Source archive verification failed')
    if any(name.lower().endswith('.docx') for name in archive.namelist()):
        raise RuntimeError('Unrendered DOCX unexpectedly included')
manifest['source_bindings'] = list(bindings.values())
manifest['source_archive'] = {'name': ZIP.name, **identity(ZIP), 'entries': len(bindings) + 5, 'integrity': 'PASS'}
manifest['rebuild_sequence'] = ['scripts/build_living_notebook_v0_8.py', 'scripts/finalize_v08_package_sources.py', 'scripts/audit_living_notebook_v0_8.py']
manifest['rebuild_python_packages'] = ['reportlab', 'pypdf', 'python-docx', 'lxml']
manifest['rebuild_dependencies'] = 'The versioned entrypoints, imported local helper scripts, source bindings and bundled fonts are preserved in the source archive.'
for item in manifest['public_artifacts_excluding_manifest']:
    item.update(identity(OUT / item['name']))
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'PASS', 'sources': len(bindings), 'archive': manifest['source_archive'], 'manifest': identity(MANIFEST)}))
