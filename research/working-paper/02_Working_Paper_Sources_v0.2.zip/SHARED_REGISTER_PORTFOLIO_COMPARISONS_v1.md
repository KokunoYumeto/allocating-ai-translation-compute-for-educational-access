# When a shared educational register can justify its cost

Research calculation, 4 September 2026. Ten concrete design alternatives and forty task comparisons. These are conditional production-and-benefit comparisons, not measured comprehension rates or a worldwide ranking.

## The useful question

A shared edition need not reproduce every benefit of separate editions to be worthwhile. It needs enough additional usable access for its cost. The comparison must also give separate editions their genuine economies: common source preparation is done once, not once per language.

Let `G_b` and `G_s` be net additional access from a bridge and a specified separate-edition portfolio. For compatible positive costs, the bridge is more efficient when:

`G_b * C_s > G_s * C_b`.

When `G_s > 0`, this is equivalent to requiring benefit retention `G_b/G_s > C_b/C_s`. Retention need not be at most one: a bridge could create access for people not helped by the comparator. If comparator benefit is zero or negative, use the cross-product expression rather than the ratio.

## What is being compared

Each design has exact proposed reader/script profiles in the accompanying JSON. These are not population assignments. The Interslavic comparison includes ten natural-language content editions and both Serbian scripts; the Hindi–Urdu design has two script outputs; the Persian–Dari–Tajik design also has two. A proposed pan-Germanic profile is compared with narrower West- and North-Germanic alternatives. Their audiences differ, so their cost ratios alone cannot rank them.

| Design | Separate content editions in this scenario | Shared output scripts | Benefit retention needed across the four declared cost scenarios |
|---|---:|---|---:|
| Interslavic | 10 | Latin and Cyrillic | 24.6%–46.0% |
| Hindi–Urdu | 2 | Devanagari and Nastaliq | 75.9%–155.6% |
| Malay–Indonesian | 2 | Latin | 72.2%–137.0% |
| Persian–Dari–Tajik | 3 | Perso-Arabic and Cyrillic | 56.6%–113.2% |
| Oghuz-focused | 3 | Latin profile | 53.9%–100.0% |
| N'Ko versus three named Manding editions | 3 | N'Ko | 53.9%–100.0% |
| Romance mathematical intercomprehension | 5 | Latin profile | 37.5%–66.7% |
| Targeted pan-Germanic hypothesis | 9 | Latin and Hebrew | 26.4%–48.2% |
| West-Germanic alternative | 8 | Latin and Hebrew | 28.5%–51.6% |
| North-Germanic alternative | 3 | Latin profile | 53.9%–100.0% |

These ranges are sensitivity results over stipulated production scenarios, **not confidence intervals, predicted retention, token-cost estimates or a recommendation to replace native editions**. A threshold above 100% means cost savings alone no longer suffice; greater benefit or a different design would be needed. Equal-looking numerical rows arise from equal assumed production structure, not equal languages or needs.

The model is deliberately inspectable:

`C_s = F + n*(1 + Q) + e_s*A`

`C_b = F + 1 + D + (m - 1)*A + n*Q`.

One unit is a stipulated variable-content cost for a native edition. `F` is common source preparation, `D` additional bridge design, `A` an extra presentation-format cost, and `Q` checking for each of the `n` community profiles. The native bundle has `e_s` extra formats beyond its first format per content edition; the bridge has `m` formats. Both alternatives pay community-specific checking. These are not claims about actual model speed or quality.

| Scenario | F | D | A | Q |
|---|---:|---:|---:|---:|
| Low common setup | 0.5 | 0.25 | 0.10 | 0.10 |
| Large common setup | 4.0 | 0.25 | 0.10 | 0.10 |
| Community-check intensive | 0.5 | 0.50 | 0.25 | 0.50 |
| Design intensive | 0.5 | 2.00 | 0.50 | 0.10 |

These values explore mechanisms, not empirical bounds on production. Larger common preparation and community-check costs reduce the relative saving from avoiding separate prose editions. Extra design can erase that saving. Transliteration is not automatically free, and a different script is not a new person.

## Compare the strongest alternatives, not only a full bundle

Beating all ten native editions at once would not establish that a bridge beats the best one, two or three editions under a limited budget. The calculation therefore retains every native-subset size, with benefit left specific to the selected communities. It also specifies the hybrid comparison: the benefit of adding a bridge after native editions is the extra access beyond those editions, not its standalone audience again.

This distinction prevents an apparent interlanguage advantage from being manufactured by comparing it only with an unnecessarily expensive alternative. It equally prevents a useful bridge from being discarded because it does not match native comprehension perfectly.

## Mathematics must be separated into tasks

Every design has four separate benefit questions:

1. Finding and applying a familiar result.
2. Learning a new definition and its boundaries.
3. Following a proof and recognizing an invalid inference.
4. Using a worked example on a new task.

Prepared reference use may benefit differently from notation than new-definition learning. No single comprehension percentage is copied across these tasks. The earlier five-study evidence file retains this distinction. A direct Interslavic cloze study supplies additional evidence about bridge prose, not mathematical-edition effectiveness. [Merunka et al., 2019](https://interslavic-language.org/doc/ijeg-2019-interslavic.pdf).

N'Ko is an existing literary-register case, not merely a new constructed proposal. Its script-specific numeral direction creates a concrete mathematical-layout consideration. [Unicode 17, §19.4](https://www.unicode.org/versions/Unicode17.0.0/core-spec/chapter-19/). Published N'Ko computational resources also make feasibility investigation concrete; benchmark scores do not identify educational benefit. [Doumbouya et al., 2023](https://arxiv.org/abs/2310.15612v3).

## Population and inclusion

The relevant population is prepared readers whose usable access changes, including people served in diaspora or displacement—not every speaker in a language family. Script literacy, existing native/academic-language access and duplicate membership remain explicit unknowns where unmeasured. No such unknown removes a candidate.

The targeted Germanic hypotheses retain Low Saxon, Plautdietsch, Pennsylvania German, Hutterisch, West Frisian, Afrikaans, Eastern Yiddish, Scots and Faroese profiles rather than using German/Dutch/Nordic English proficiency as their proxy. The narrower northern alternative additionally investigates Icelandic and Nynorsk. These are research profiles, not assertions that each is underserved or that a single standard already works.

The next empirical task is to bind stage-specific audiences and exact independent educational alternatives to these profiles, then estimate or transparently vary task benefit and actual standardized production cost. Construction or publication does not depend on new participant recruitment. No interlanguage was built or authorized by this calculation.

## Reproducibility

`scripts/build_bridge_portfolio_comparisons_v1.py` generates `structured/BRIDGE_PORTFOLIO_COMPARISONS_v1.json`; thirteen arithmetic and scope checks pass. All five educational stages remain eligible for each design, including the three new challengers; the forty mathematical tasks do not delimit other needs. The direct-source record is `structured/BRIDGE_DIRECT_SOURCE_EVIDENCE_v1.json`. The original 100-candidate forecast is unchanged. This result extends the paper's comparison framework; it does not complete the global recommendations.
