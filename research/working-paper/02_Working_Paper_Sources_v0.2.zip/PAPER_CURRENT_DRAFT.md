# Allocating AI-assisted educational publishing for greater access

Working manuscript. Empirical synthesis in progress; not a completed publication or funding ranking.

## Abstract

AI-assisted translation can expand educational access, but its value depends on who can use the resulting material and what educational need it addresses. We compare language, subject, educational stage and delivery format, from early learning to research. We distinguish the number of people with an educational need from the benefit a particular publication might create. Language communities remain in the analysis when measurements are missing, and shared-register designs are evaluated alongside native-language editions. Initial source comparisons identify substantial foundational-learning opportunities in Indonesia, Bangladesh and Pakistan; distinct language-transition opportunities in India and East Africa; and learning-continuity needs among displaced populations. A complete extraction of PISA 2022 population and mathematics tables supplies one comparable stage-specific starting point across 81 jurisdictions. It also shows why survey coverage, existing provision and language attribution cannot be omitted. We use conditional benefit-per-cost thresholds where intervention effects are unmeasured, rather than presenting uncertain assumptions as an observed worldwide ordering. The global recommendation portfolio and remaining empirical synthesis are still being completed.

## 1. Research question

Which educational publications could create the greatest additional usable access per standardized unit of AI production effort? The relevant decision is not simply which language has the most speakers. It is which material, in which language or shared register, would help which learners do something educationally valuable that their existing options do not adequately support.

Education includes preschool and school learning, vocational development, university study and research. A mathematical research text can be an important educational resource even when few school learners need it. Equally, a technically advanced translation does not address missing early arithmetic. The analysis therefore keeps stages and learning tasks explicit instead of assigning each language one universal need score.

Autonomous learners are a central audience. The availability of teachers, uninterrupted internet, expensive software or institutional subscriptions is not assumed. Downloadable, phone-readable material with prerequisites, exercises, answers and usable navigation can offer a different route from classroom instruction. Classroom use, independent study and research/reference use are analyzed as distinct, potentially overlapping endpoints.

The unit is an intervention: a specified population and language/variety/script profile, a defined educational package, a format and a time horizon. A multilingual learner may have several viable routes. Those alternatives are compared without counting the learner repeatedly in a combined portfolio.

## 2. What counts as additional access?

For a specified educational task, additional access is the difference between what learners can use with the intervention and what they could use otherwise. A file's existence is not proof that everyone has access to it. Conversely, failure to find a title on one website is not proof that an entire language lacks educational resources.

Open licensing is important because it enables lawful translation, adaptation and redistribution without charging each learner or institution. Price, independent-download access, device compatibility and permission to adapt are separate attributes. A free-to-view video, a reusable textbook and a complete offline course are different resources. Existing paid or institutionally restricted material may serve some people while leaving substantial unmet need among others.

The programme used as a case study does not change the estimated educational needs of a language community. Its local files, completed translations, recent publication counts or sunk production effort are not inputs to global need, eligibility or priority. The research concerns the world's educational opportunities, not a schedule of what one project should do next.

## 3. Evidence and comparison method

### 3.1 Population and inclusion

The candidate universe starts with the frozen Glottolog language-level register and overlays exact varieties, scripts, signing communities, displaced populations, accessibility modes and possible interlanguages. Historical and unresolved entries remain traceable with their appropriate interpretation. Registry membership is not itself proof of a current speaker population, and a macro-language is not automatically an intelligible edition for each constituent community.

Population evidence preserves the construct a source actually measures: mother tongue, home language, additional-language use, literacy or technical reading. These cannot be substituted without explanation. Historical counts retain their dates; cross-year projections or cross-source combinations are explicit inferences. National totals may constrain a resident subset when the relationship is defensible, but do not bound an entire worldwide diaspora.

Missing evidence does not remove a community or assign it zero need. A related educational system can motivate a hypothesis and, where its mechanism is supported, a bounded inference. It does not automatically supply the same population, need rate or rank. The analysis records both expected candidates and unexpected possible contenders.

### 3.2 Need, benefit and cost

Let B describe a specified population with a stated educational need. Let q describe its average net change in usable access, relative to independent existing options, for a specified task and time horizon. With access normalized between zero and one, q lies between −1 and 1. The simplest common-endpoint net benefit is Bq. Both components may vary across subgroups; the general analysis sums over mutually exclusive learner strata.

Net change is not the same as the gross number newly gaining access. For binary access, q equals the share gaining access minus the share losing it. A nonnegative scenario explicitly assumes no access losses; their absence is not established by missing evidence. An optional additional resource can motivate that assumption for availability when existing routes remain intact, but it does not establish a nonnegative effect on learning. Being below a proficiency benchmark also does not mean a learner had no usable resources beforehand.

Benefit per standardized production cost is Bq/C. A large B can coexist with modest benefit per person. A smaller population can justify a high-value intervention because its unmet need, language fit or practical delivery is different. The analysis reports these components separately.

When q is not measured, useful conditional comparisons remain possible. For positive population and cost terms and q_B>0, intervention A exceeds B on a matched endpoint when q_A/q_B exceeds (B_B/B_A)(C_A/C_B). Otherwise the analysis compares B_A q_A C_B with B_B q_B C_A directly, preserving signed and zero effects. This identifies what would have to be true for one option to be more efficient. It does not disguise an assumed common yield as an empirical estimate.

Observed data, evidence-based transport and illustrative scenarios are labelled separately. Common priors cannot produce a high-confidence rank. Uncertain comparisons remain visible alongside the information that could change them. The final Top 10 and Top 100 are intended as transparent portfolios with possible alternatives, not an eligibility boundary for everyone outside them.

### 3.3 Hypotheses and anomaly investigation

Before the next ordering, we record twelve hypotheses and one hundred expected candidate profiles. They predict large additional-language opportunities, school-to-academic-language transitions, stage-specific shortages, useful interlanguage designs, independent-learning routes and displacement-related needs. Initial stage annotations never exclude other stages.

The initial high-reach expectation includes Indonesian, Hindi, Bangla, Simplified Written Chinese and Urdu, with Telugu, Tamil, Marathi, Hausa and Kiswahili as further strong investigations. This is not a predicted exact order or a guaranteed final ten. The complete [100-profile forecast](HYPOTHESES_AND_EXPECTED_CANDIDATES_v1.md) includes regional, research, signed-language and shared-register candidates; its sections are not priority bands. Profiles outside that forecast remain eligible. The forecast was recorded after earlier analyses, so it is prospective only for the next analysis, not an original preregistration.

| Expected pattern | A result that would require investigation | What could legitimately change the expectation? |
|---|---|---|
| Large additional-language audiences make Indonesian and other common educational languages important contenders. | The model counts only mother-tongue speakers, or removes a language because a local project translated material. | Source-specific literacy, educational-stage need and independently usable provision can change a package's expected benefit. |
| A need found in one Slavic community suggests checking comparable needs elsewhere, including Ukrainian. | Russian is compared while Ukrainian or other relevant communities disappear. | Different population sizes, interruption of schooling, publication markets or usable alternatives can produce different results. They must be investigated, not assumed. |
| School-to-academic-language transitions create opportunities beyond early schooling. | Regional-language learners vanish because their country has an official academic lingua franca. | Evidence of comfortable subject access or an equally usable existing package can weaken the proposed intervention. |
| Established scientific languages can still have specific educational gaps. | School provision removes Japanese, Chinese, English or another language from every stage. | An accessible equivalent can weaken a specific proposed package; it does not answer every other subject and stage. |
| Formula-rich interlanguages may retain enough benefit to justify their lower shared-production cost. | Every design is assigned either zero comprehension or the entire language-family population. | Findings on exact mathematical tasks, scripts, reader preparation and design cost can support or weaken the advantage. |
| Written-language comparisons miss some signing, displacement and access-format needs. | An entire modality or displaced community is absent without an investigated reason. | Actual language routes and task-specific provision can distinguish useful from ineffective packages. |

An unexpected absence prompts a trace through identity, population, educational need, provision, overlap, cost and implementation. If a rule caused the absence, it is checked across the entire retained candidate-stage universe. For example, a population-data join that excludes one language must be tested against every initially unmeasured language, not patched only for the noticed case. Evidence can justify unequal outcomes; it cannot justify equating missing measurement with no need.

The [expectation-versus-investigation table](EXPECTED_CANDIDATE_COVERAGE_v1.md) exposes the work still missing. In this bounded calculation, 44 of the 100 expected profiles have a proposed route and 56 do not; separate shared-register analyses are not counted in those figures. These are investigation counts, not rankings or proportions of educational need covered. All 100 retain preschool, foundation, secondary, vocational, university and research stages. Preschool is an explicit column, not an invisible part of foundation. Source references, proposed designs, identity qualifications and unresolved population estimates are represented separately; none supplies an implicit low rank.

### 3.4 Standardized production scenarios

The currently reusable production model measures token traffic, not physical computing operations, electricity, subscription consumption or money. It combines a declared workflow with recorded tokenization measurements from 1,012 aligned general-domain sentences. Target counts use `o200k_base`; the fixed source reference uses `cl100k_base`. That mixed reference is explicit and is not a measurement of a contemporary model's actual mathematical-translation workflow.

For the base text scenario, traffic is approximately `T = S(7.585897 + 4.73R)`, where S is the source-reference token count and R is the target working-token count divided by the source-reference count. The coefficients describe stipulated production and checking work, not observed learning benefit. Extra model work remains an explicit additional term; rendering, speech and signed-video production require separate resources.

| Edition benchmark | Base-scenario token traffic for 100,000 source-reference tokens |
|---|---:|
| Indonesian | 1.343 million |
| Bangla | 1.559 million |
| Urdu | 1.531 million |
| Hindi | 1.494 million |
| Simplified Chinese | 1.342 million |
| Japanese | 1.534 million |
| Ukrainian | 1.577 million |
| Russian | 1.423 million |
| Hausa | 1.484 million |
| Kiswahili | 1.453 million |

These scenario costs can inform conditional benefit thresholds; they cannot determine a language's need. An unmeasured language retains a symbolic cost or an explicitly labelled predictive scenario, not a penalty or exclusion. General-domain tokenization is also an imperfect transport to mathematics, where shared formulas may change relative expansion. The exact source bindings, coefficients and reconstruction checks are retained in `structured/STANDARDIZED_COMPUTE_REUSE_20260904.json`; no local programme completion or sunk-compute adjustment enters this model.

### 3.5 Complete courses and smaller additions must be compared on the same outcome

A short companion is not automatically more efficient than a complete course. For the same community and educational outcome, let a smaller package have net additional access `G_s` and positive cost `C_s`, and a fuller sequence have `G_f` and positive cost `C_f`. The smaller package has more access per cost only when `G_s × C_f > G_f × C_s`. If both packages address the same potential population and have positive yields, this becomes `q_s/q_f > C_s/C_f`. Negative or zero effects require the cross-product form rather than that ratio.

The source scale is no longer represented solely by an arbitrary 100,000-token canon. A bounded measurement of the exact OpenStax *Prealgebra 2e* source at commit `38cae454e644abf9f0a623e876994553881597c9` finds 75 unique CNXML modules across 11 chapters. NFC-normalized text extracted from the learning-content elements contains **364,270 `cl100k_base` tokens**. A declared six-chapter quantitative sequence—whole numbers, integers, fractions, percents, linear equations and graphs—contains 173,958 tokens, or **47.8%** of that measured full source. The fractions chapter contains 41,336 tokens, or **11.3%**. These are source representations, not teaching-time, difficulty or learning-effect measurements. The archive excludes media, and text extraction omits mathematical and document structure; tokenizing the complete XML instead gives 2,811,119 tokens because markup and metadata are included (OpenStax, 2026).

Under the declared text-workflow coefficient and the general-domain Indonesian expansion measurement, the corresponding traffic scenarios before unmeasured extra work are approximately **4.89 million**, **2.34 million** and **0.56 million** token events. They are neither actual model usage nor money or physical compute. The same measured English source scale is carried through all ten currently measured language profiles rather than charging each a different source canon.

At zero common setup cost and equal per-source-token workflow, the six-chapter package needs more than 47.8% of the full course's net benefit on their common endpoint to be more efficient. If shared setup costs both alternatives an additional 10% of the full course's variable cost, the threshold is 52.5%; if setup equals the full variable cost, it is 73.9%. The corresponding fractions-only thresholds are 11.3%, 19.4% and 55.7%. These figures demonstrate why a small-content shortcut can lose its apparent advantage once terminology, formats and validation infrastructure are substantial. They do not estimate either package's educational effect.

The comparison must also preserve outcomes that exist only in the full course. A fractions unit and a complete prealgebra sequence can be compared on fractions access, while the latter's additional algebra, decimal, geometry and graph outcomes are reported separately or assigned explicit weights. Counting every stage as a new person would double-count overlapping learners. Conversely, once common infrastructure has been produced, the next decision compares the *marginal* benefit and cost of the next unit; sunk production never reduces a community's educational need.

## 4. Initial findings

### 4.1 Indonesian access includes a large additional-language audience

BPS's 2022 tables report 248,501,794 Indonesian-capable residents aged five or above, compared with 71,971,184 whose first-acquired language was Indonesian. These are different constructs. With the reported national marginals treated as fixed, approximately 176.53–181.71 million residents can use Indonesian without having acquired it first. This is a conditional joint-event bound, not a measure of advanced reading. It nevertheless demonstrates why an L1-only audience would omit a substantial potential route (BPS, 2022a, 2022b).

Regional-language needs do not disappear because Indonesian is widely used. Javanese, Sundanese and other routes may offer distinct benefits for particular ages, tasks or readers. They must be compared as overlapping interventions rather than assigned either complete national-language coverage or complete separation.

### 4.2 Secondary mathematics gives a comparable need measure

The complete PISA 2022 table comparison covers 81 jurisdictions. Combining represented cohort size with the source's unrounded below-Level-2 mathematics categories yields approximately 3.10 million represented students below the threshold in Indonesia, 1.66 million in Brazil, 1.50 million in the Philippines and 122,000 in Japan. These are educational-system observations, not language-specific translation-benefit counts (OECD, 2023a, 2023b).

This supports a substantial Indonesian foundational-mathematics opportunity. It does not show that Japanese education has no gaps, that every low-performing learner needs a translation, or that research-level access is unimportant. Independent provision and the package's actual contribution remain consequential.

Coverage can change the comparison materially. Under an explicit subset assumption and treating source population estimates as fixed, allowing all unrepresented learners' proficiency to remain unknown gives a Cambodia age-15 need range of approximately 111,000–333,000, compared with 122,000–210,000 in Japan. The represented point estimates alone therefore cannot settle that comparison. The complete calculation retains sampling cautions and source inconsistencies rather than repairing them silently.

The Ukrainian data require particular care. The same sample represents 165,591.78 students in both an 18-region and a national population frame. Its estimated below-threshold represented population is approximately 70,228. A national coverage sensitivity range is approximately 70,000–303,000; it does not extend the participating regions' observed percentage to all Ukraine. These are 2022 observations, not a current wartime educational census.

### 4.3 Different regional needs suggest different packages

Bangladesh's MICS 2025 indicators report foundational reading for 50.2% and numeracy for 39.2% of children aged 7–14. Pakistan's HIES 2024–25 reports 28% of children aged 5–16 out of school. These findings support investigating foundational catch-up, school re-entry and secondary progression, while preserving the different survey populations and constructs (UNICEF Bangladesh, 2026; Pakistan Bureau of Statistics, 2026).

For Bangladesh, combining the age-specific numeracy rate with projected age groups and explicit within-group age assumptions gives approximately 15.3–15.7 million children aged 7–14 not meeting the numeracy criterion. This is a range across three cross-source scenarios, not a confidence interval or direct census count. Without a within-age-bin composition assumption, the fixed-source sensitivity range is much wider, about 10.0–19.5 million. The calculation does not multiply a child learning rate by an all-age language population. It motivates a concrete package of number concepts, comparison, addition, patterns and worked practice, while existing national textbooks remain part of the provision baseline (UNICEF Data, n.d.; BBS & UNICEF Bangladesh, 2026).

Actual content inspection narrows that proposal. The sampled2026 NCTB grade2 book already covers all four numerical domains with visual explanations, worked answers and practice; selected Bangla Khan Academy lessons also provide explanations and exercises. For this task set, a portable diagnostic/feedback companion is a stronger provisional addition than an undifferentiated replacement book. It would link to existing examples and supply entry checks, prerequisite routing, self-check keys and short explanations of wrong answers. The sample does not establish complete national supply or universal autonomous usability, and it does not lower the population need estimate. Other stages and subject packages remain separate questions (National Curriculum and Textbook Board, 2026; Khan Academy, n.d.).

The language choices differ. Bangladesh has a large broad Bangla-language route, with exact-variety questions still important. Pakistan's census records several substantial mother-tongue communities: Urdu cannot stand for all Pakistanis. Urdu editions and Punjabi, Sindhi, Pashto, Saraiki and other editions require explicit capability and overlap comparisons.

Pakistan's 2023 census provides a matched historical count: 25,373,350 out-of-school children among 71,270,068 children aged 5–16 in its detailed-characteristics population. These are published school-status counts and summed single-year age counts, respectively. The newer HIES rate of 28% would imply 19.96 million only if that older cohort size and relevant frames were held constant; this is a scenario, not a measured decline between the two sources. Headcount-only populations missing detailed characteristics, AJK, Gilgit-Baltistan and diaspora communities remain outside this particular estimate, not outside the research (Pakistan Bureau of Statistics, 2023a, 2023c, 2026).

The same census makes a stronger language-specific inference possible. Rural Sindh has 25,623,864 residents, 23,605,495 with Sindhi as mother tongue, and 5,117,164 out-of-school children aged 5–16. Even if every non-Sindhi resident were in that last group, at least 3,098,795 out-of-school children must be Sindhi-mother-tongue children. Combining ten disjoint geographic cells gives a national detailed-frame interval of 3,098,795–8,757,513 for that intersection. This is a logical bound on the recorded margins, not an estimate of comfortable readers or beneficiaries. It supports investigating a distinct Sindhi foundational-learning route without assuming that a province is a language or that Urdu serves everyone (Pakistan Bureau of Statistics, 2023b, 2023c).

Considering several editions requires joint population accounting. Urdu, Punjabi, Sindhi, Pashto and Saraiki mother-tongue categories together contain between 9,929,282 and 25,373,350 of the recorded out-of-school children, conditional on the ten geographic cells' margins. Adding their separately maximized upper bounds would instead yield an impossible 54,141,695. The integrated calculation retains the shared constraints and feasible endpoint allocations. It also adds a Western/Pakistani Punjabi written-profile challenger outside the original forecast, while preserving uncertainty about how the census category maps to an exact edition. None of these membership bounds is a measured package-benefit count.

Existing distance education is a material countercheck. Bangladesh Open University already lists Bangla financial-management and business-statistics content; Pakistan's Virtual University lists extensive mathematics and related subjects. The useful additional package may therefore be a prerequisite companion, complete worked practice, accessible offline material or a specific missing topic—not another generic introductory volume. Catalogue presence alone does not establish which learners can use the material or what adaptation rights apply.

Regional investigations also identify distinct transition mechanisms: regional-language schooling to English technical education in India; Kiswahili-supported entry to English-medium secondary subjects in Tanzania; and Hausa–French learning routes in Niger. Their population magnitudes, independent provision and package effects must be estimated separately. A familiar mechanism is a research lead, not permission to copy one country's rate into another.

India illustrates how a hypothesis should change when confronted with evidence. Among higher-secondary students in the 2017–18 NSS survey's home-language categories, the English-medium shares were 19.5% for Hindi, 37.4% for Tamil, 74.5% for Telugu and 28.2% for Marathi. Thus a universal story of switching to English only upon entering university is particularly weak for the Telugu group. These historical cross-sections are neither English-proficiency measurements nor the same learners followed into university (Ministry of Statistics and Programme Implementation, 2020, Statement 4.17).

A more precise candidate is an optional bilingual prerequisite companion. Inspection of actual Hindi and Telugu NPTEL pages finds substantial existing explanations, worked examples, answers and glossaries. Both inspected mathematics books open with Rolle's theorem. A provisional eight-page entry insert can supply prerequisite orientation, six transfer tasks with explanatory answers, two compact foundation bridges and precise navigation to the existing lectures. This is a design scenario, not a demonstrated optimum or proof that similar support is unavailable elsewhere. Tamil and Marathi content remains uninspected in this comparison. English-medium learners remain eligible for local-language support; regional-language learners are not presumed incapable of English (NPTEL, n.d.).

Tanzania offers a different, source-bound transition example. Uwezo's 2017 Standard 7 reading margins imply that 39%–53% of the assessed cohort could pass the basic Kiswahili task but not the English task. Adding its subtraction-test margin gives a 19%–53% interval for pupils passing both Kiswahili and subtraction while not passing English, without assuming independence. This supports investigating paired subject explanations and English task practice, with separate foundational support. The tests concern basic competencies among assessed ages 6–16, not current technical-reading ability or a guaranteed translation effect (Uwezo Tanzania, 2019). A separately labeled transport scenario scales these bounds to historical administrative grade enrollment; it does not turn them into a current population estimate.

### 4.4 Existing Chinese and Japanese provision tests the package hypotheses

Existing materials can weaken a proposed intervention without resolving a community's broader needs. A Chinese probability/statistics textbook already supplies Python explanations and advertises maintained source code. A teacher-qualified support offer does not establish that all supplementary material is restricted (Xu, 2023). The University of Tokyo provides public Japanese programming lessons, scientific-computing topics and exercise-answer routes (University of Tokyo, n.d.).

These are concrete alternatives, not evidence that all learners are served. They require a new package to identify its additional contribution: a different task, prerequisite sequence, price, format or otherwise unavailable explanation. They also weaken any automatic inference that Chinese or Japanese opportunity must move wholesale from school to research. The remaining comparison is package-specific at every stage.

### 4.5 Practical skills and continuity beyond a uniform mathematics package

Seven further profiles generate eleven concrete package hypotheses. These are different educational tasks, not a new language league table. The complete source cards retain national versus language populations, observation dates, existing alternatives and uncertainty: [mainland Southeast Asia](agent_reports/MAINLAND_SOUTHEAST_ASIA_PACKAGE_NEEDS_20260904.md) and [Brazilian Portuguese and Latin-American Spanish](agent_reports/PORTUGUESE_SPANISH_PACKAGE_NEEDS_20260904.md).

Thailand provides particularly direct motivation for a practical-skills route. Its assessment of people aged 15–64 reports 64.7% below the foundational-reading threshold and 74.1% below the foundational-digital threshold. Basic digital tasks include using a pointer or keyboard and identifying a displayed price. These are different skill measures, not percentages to add or multiply. They motivate a Thai reading-and-digital-operations package, with device-based practice distinguished from paper exercises; they do not identify the number of Thai-language beneficiaries (World Bank, n.d.).

Myanmar illustrates a different mechanism. UNICEF's 2026-framed programme page describes around 3.5 million children outside schooling or learning, without providing an observation year or language breakdown. That is contextual evidence for interrupted-learning routes, not a Burmese-language count. A print-first sequence of independent science-reading units could serve Burmese-using adolescents with interrupted study. Existing ministry textbooks and curriculum videos are alternatives; other Myanmar languages remain separate candidates (UNICEF Myanmar, n.d.).

| Language profile | Concrete hypothesis to compare | Evidence that narrows, but does not settle, the additional benefit |
|---|---|---|
| Vietnamese | A six-unit science-reading and diagram companion for entry to Grade 6 | The publisher's existing science book already supports reading, practice and self-assessment. The specific technical-reading bottleneck is not measured. |
| Thai | Twelve short reading/digital-operation tasks, with optional offline practice | Thai MOOC already supplies digital-literacy courses and tests. Entry difficulty and device requirements need a task-level comparison. |
| Burmese | Twelve stand-alone science-reading restart units | Existing books/videos do not remove disruption; neither their presence nor disruption alone measures this package's effect. |
| Central Khmer | Eight technical-reading tasks connecting Grade 9 study and vocational entry | BEEP already combines equivalency, science, workplace and review material. A new bridge cannot claim those features are absent. |
| Lao | Twelve age-respectful comprehension stories with explained answers | Khang Panya Lao already offers readers and advertises offline delivery. Exact feedback overlap remains uninspected. |
| Brazilian Portuguese | Adult science-reading, enterprise-records and reproducible-data alternatives | Encceja and IFRS provide substantial existing study and self-paced routes; each proposed delivery or prerequisite advantage is provisional. |
| Latin-American Spanish, territory-specific | Country-aligned science-reading, business-case and data-laboratory alternatives | INEA, SENA and UNAM already supply relevant content. Mexican, Chilean and Colombian evidence is not a representative regional denominator. |

The package sizes are bounded design scenarios, not established minimum doses or optima. The eleven designs yield fifteen stage-specific routes because some span more than one stage; those variants are not disjoint populations. UNAM's public catalogue, for example, already includes R-based data science, finance and scientific thinking. Catalogue inspection establishes alternatives, not their full contents, offline usability or universal access (UNAM, n.d.).

A further methodological prediction follows: a search concentrated on existing textbook catalogues may favor supplement proposals simply because supplements are easier to distinguish from a listed title. The comparison must therefore retain full open editions, integrated learning packages and smaller additions under the same audience, quality and cost assumptions. The current evidence does not establish that small companions are globally optimal. Existing provision can change a particular intervention's expected additional benefit; it cannot erase the population's measured educational need.

### 4.6 More specific needs in Africa, Arabic/Iranic communities and signed languages

Nineteen additional profiles now have source-linked package comparisons. Their contribution is not nineteen new positions on a league table. They show why a useful publication can be a full course for one learner and a smaller addition for another. Complete courses and smaller alternatives remain distinct in the calculation, rather than allowing catalogue inspection to decide the size of every intervention.

| Learner situation | Concrete educational material worth comparing | Important existing alternative or boundary |
|---|---|---|
| Amharic- or Oromo-using early learners | A coherent low-equipment literacy/numeracy sequence with diagnostic questions and explanatory feedback | Regional guides and diagnostic tools already exist; a smaller reteaching layer is an alternative, not an automatic ceiling. |
| Kinyarwanda-using learners not adequately served by English text | Scientific reading, measurement, fractions, graphs and practical data, with separate school and adult entry points | English-medium textbooks and distribution programmes exist, but do not establish comfortable English study for every learner. |
| Somali- or Tigrinya-using learners returning after interruption | A complete prerequisite-to-school-continuity course | Existing accelerated or resumed instruction may make a practice companion more useful for some learners. |
| Kirundi-using school and practical learners | Applied science, observation, measurement, tables and records | Local STEM projects supply a concrete use case; their anecdotes are not a measured population effect. |
| isiZulu- or Sepedi-using Grade-4 learners | Independently usable bilingual mathematical instruction | DBE supplies substantial language-specific plans, guides and worksheets; do not claim an empty textbook market. |
| MSA, Dari and Kurdish learners with interrupted or changed-medium schooling | Sequential science/reading courses, with exact national curriculum and written-variety routes | Madrasa, Begum, Darakht-e Danesh and eWane supply substantial independent provision. Offline continuity and prerequisite fit are specific comparisons. |
| Persian- or Tajik-using learners | Early-learning, scientific-reading and practical computing/data courses matched to entry level | Existing school books and free course providers require a subject-level comparison, not a nationality-based scarcity assumption. |
| ASL, Libras, ISL, Kenyan Sign Language and SASL users | Distinct algebra, computing, practical numeracy, scientific-data and qualification-continuity courses | Signed dictionaries, course videos, workbooks and institutional training are different types of provision; none automatically establishes a full autonomous route. |

Rwanda supplies a particularly concrete language-access anchor. Table C.25 of its 2022 census education report covers 8,289,582 residents aged 15+ and reports 54.0% literate in Kinyarwanda alone: approximately 4.48 million under that reported category. Because the percentage is rounded, this is not an exact published person count; the nearest-tenth rounding interpretation gives 4,472,230-4,480,519 people. Nor is it the number who need a science course. Alongside the education board's account of English-medium instruction from lower primary since 2021, it supports investigating Kinyarwanda scientific and practical learning rather than assuming English provision serves everyone. Exact tables, language overlap and narrative discrepancies are retained in the [African evidence comparison](AFRICAN_PACKAGE_NEEDS_20260904.md) (NISR, 2023; Rwanda Basic Education Board, n.d.).

Displacement and exclusion also require full educational pathways, not only basic arithmetic. The Arabic/Iranic comparison separates national out-of-school observations from actual language readership, preserves MSA's spoken-to-written learning distinction, and distinguishes Iranian Persian, Dari, Tajik, Sorani and Kurmanji writing routes. It compares full science and practical-data courses with smaller additions to actual independent providers. Existing courses are evidence about the intervention's alternatives; their mere existence does not reduce a population's educational need. See the [six-profile report](agent_reports/ARABIC_IRANIC_PACKAGE_NEEDS_20260904.md) and its source-specific dates and population frames.

Signed-language access is not written-language translation plus a generic avatar. The five-profile comparison points to ASL algebra/computing, Libras fraction/ratio and research-data learning, ISL secondary/programming transitions, Kenyan Sign Language literacy/practical numeracy, and SASL matric mathematical literacy/digital-work preparation. Exact provision, replayable explanation, notation, exercises and explained answers matter. Deafness totals are not counts of sign-language users. The inspected sources do not provide matched beneficiaries or measured signed-course production costs; those remain unknown rather than zero. See the [signed-language comparison](agent_reports/SIGNED_LANGUAGE_PACKAGE_NEEDS_20260904.md).

These designs preserve independent-study and classroom routes. Preschool material normally needs a caregiver or educator, while older learners can use a complete self-contained course without assuming a teacher is available. Text, audio, signing, MathML, printable versions and offline delivery are distinct resources and costs. Keeping all six stages visible prevents the strongest evidence at one stage from silently excluding the others.

## 5. Shared registers and mathematics

An interlanguage can be useful without reproducing native-language comprehension perfectly. Suppose separate native-language editions yield positive combined net benefit B at positive cost C_s, and a shared-register edition yields r times that benefit at positive cost C_b. The shared edition has greater benefit per cost when r > C_b/C_s. A zero or negative comparator benefit requires a direct net-benefit comparison instead of this ratio. This compares complete alternatives; a fixed-budget portfolio choosing only some native editions is a separate optimization.

Formula-rich mathematics offers a specific hypothesis: prepared readers may recover more of an argument through notation, diagrams, familiar definitions and proof structure than through prose alone. But negation, quantifier scope, definitions and inferential dependencies remain consequential. The analysis should compare exact readers, scripts and tasks rather than awarding full language-family coverage or zero benefit by default.

Native-language and shared-register editions can complement each other. A shared introductory reference, an advanced mathematical register and a native-language foundational course may address different tasks. Their overlapping audiences must be accounted for in a portfolio.

### 5.1 What the intelligibility literature does and does not establish

Related-language comprehension varies by direction, task, preparation and script. Golubović and Gooskens (2015) studied six West/South Slavic language communities, using several spoken and written tasks. They found substantial asymmetries, and written Bulgarian tasks depended on reported Cyrillic literacy. Those results motivate exact community/script comparisons. They do not supply an Interslavic mathematics comprehension rate or an East Slavic population estimate.

Mathematical notation is also not automatically an advantage. In Österholm's (2006) group-theory reading experiment, a prose version produced higher median comprehension than the symbolic version. The unfamiliar subject matter and closed-text assessment differ from a prepared researcher's use of familiar mathematics. The finding therefore weakens a blanket claim that more notation always makes reading easier; it does not settle the proposed advantage of a carefully designed interlanguage for knowledgeable readers.

The useful hypothesis distinguishes advanced reference use, learning a new definition, following a proof and completing a worked example. These tasks may have different benefit retention. The expanded comparison retains ten design alternatives and forty task rows, including seven forecast bridges and three targeted Germanic alternatives. A direct Interslavic survey adds evidence about cloze comprehension, not mathematical-edition effectiveness (Merunka et al., 2019).

The production comparison charges common source preparation once in both alternatives and retains community checking, extra script outputs and bridge-design effort. Under four declared scenarios, the ten-edition Interslavic comparison requires 24.6%–46.0% benefit retention; the two-edition Malay–Indonesian comparison requires 72.2%–137.0%. These are cost-derived thresholds, not predicted comprehension or measured compute. A threshold above 100% means that cost saving alone does not justify that design. The full assumptions and exact communities appear in `SHARED_REGISTER_PORTFOLIO_COMPARISONS_v1.md`.

Every native-subset size remains a comparator: a bridge that beats a full ten-edition bundle might still lose to a well-targeted one- or two-edition portfolio. Hybrid portfolios use the bridge's additional benefit after the native editions, rather than counting its standalone audience again. This supports a meaningful interlanguage hypothesis without making family size or an assumed common effect decide the result.

If a bridge reaches people who receive no benefit from the separate-edition comparator, its total benefit ratio can exceed one. Such people are counted directly, not removed because a within-stratum retention ratio is undefined. Benefit weights also need not equal population weights. The comparison uses additional usable access for the specified task and horizon.

## 6. Initial intervention comparisons

The integrated calculation now contains 214 stage-and-mode routes: the earlier 46 plus 168 Arabic/Iranic, signed-language and African routes. These are alternative designs and stage applications, not 214 disjoint populations or equally strong findings. All 100 forecast profiles and one additional challenger retain all six stages. There are current package designs in 112 of the 600 forecast stage cells; empty cells are unfinished investigations, never lower ranks. Fifty-eight constructor checks preserve the earlier 46 route results and all 36 pairwise secondary-mathematics comparisons. A known source cohort and a measured tokenization profile permit a numerical threshold; otherwise the missing quantity remains symbolic. The Bangla route retains all three age-matched scenarios. Five Pakistan routes retain intervals and joint constraints rather than invented midpoints. New regional context counts are not converted into language-specific need. Normalized text-traffic values remain fixed-size scenarios, not the actual relative costs of a full course, short companion or signed-video edition.

| Intervention | Initial evidence-motivated routes | Intended educational contribution |
|---|---|---|
| Secondary quantitative catch-up | Indonesian, Japanese, Ukrainian, Brazilian Portuguese, Filipino, Thai, Vietnamese, Central Khmer and Malaysian Malay | Diagnostic, answer-supported work on numerical and algebraic prerequisites; language fit remains a route-specific condition. |
| Foundational learning and school re-entry | Bangla, Urdu alongside Pakistan's regional languages, and Hausa | Age-appropriate reading/numeracy support, oral explanation and short practice, rather than repurposing a college text as early learning. |
| Subject-language transitions | Kiswahili/English, Hausa/French, Hausa/English, Russian/Estonian and displaced Ukrainian/host-language routes | Paired explanations plus practice in the teaching or assessment language. |
| Tertiary-entry companions | Hindi, Tamil, Telugu, Marathi and separately evaluated extensions | Prerequisites and subject-language support that complement existing courses. |
| Statistics and practical skills | Prepared Chinese readers; Bangla, Hausa and Kiswahili practical-learning routes; Ukrainian/Russian alternatives | Reproducible analyses or specific financial, recordkeeping and planning tasks, with existing provision compared explicitly. |
| Technical preparation and research access | Ukrainian recovery training; exact Ukrainian, Russian, Chinese, Japanese and interlanguage research profiles | Preparatory calculations or source-specific arguments, at stated prerequisites. |

These are intervention recommendations for further comparative development, not a declaration that every listed package outranks every unlisted one. Source selection is concrete: relevant OpenStax topics, Open Logic/forall x and exact advanced open sources are starting points. The source package's learner assumptions, examples, complete-solution coverage and distribution terms are part of the comparison.

The secondary calculation illustrates the scale of the decision. Under its fixed-size text-traffic scenario, an Indonesian edition has higher additional access per traffic than a Japanese edition if its unknown incremental yield per learner exceeds approximately 3.45% of the Japanese route's yield. The conditional full-age-15 coverage envelopes widen this threshold to approximately 2.84–5.95%. These values concern one stage and endpoint, not total language priority.

Coverage can be decisive in a closer comparison. For Japanese and Ukrainian routes, the represented-cohort point threshold is approximately 0.559. Using Ukraine's national coverage envelope and Japan's full-age-15 envelope yields a range of approximately 0.325–2.414. Equal-yield scenarios can therefore imply different directions within those bounds. The national envelope does not copy the participating regions' observed rate to unassessed people.

The comparison fixes source population estimates and uses explicit subset assumptions. It does not identify actual package yields, complete physical production cost or future uptake. Its immediate contribution is a transparent threshold calculation with no silent population removal. The full route definitions, source identities, coverage conditions and sensitivity checks accompany the manuscript.

The first actual-source-scale comparison changes the earlier bookkeeping materially. A complete OpenStax prealgebra source is about 3.64 times the normalized 100,000-token canon used in the earlier table. For Indonesian, the scenario therefore rises from 1.34 million to 4.89 million token events before extra work. This is a correction to the *package-size input*, not a change in Indonesian need or eligibility. A selected six-chapter route is less than half the measured text, but it is preferable only if it retains enough benefit on the same outcome. A complete course remains a serious candidate when it substantially improves independent progression, supplies otherwise missing outcomes, or amortizes shared infrastructure across later units.

For the Bangladesh four-domain comparison, two deliberately broad design budgets make the unknowns visible. A twelve-item entry-and-feedback companion is represented by 2,720–7,840 English/source-reference tokens; a 24-unit explanatory and practice sequence by 12,800–30,400. Assuming the same per-token workflow and no unequal extra work, the small package's positive-yield threshold spans approximately **8.9%–61.3%** of the fuller sequence's yield across the crossed budget extremes. These are planning bounds, not confidence intervals, observed Bangla lengths or instructional specifications. They cannot establish that the companion wins. Authoring, answer verification, formula checking, accessibility and audio/video work remain separate terms. The underlying 15.3–15.7 million national numeracy scenario is unchanged because prior production and package size do not alter population need.

## 7. Remaining empirical synthesis

### 7.1 What existing evaluations suggest about package design

One actionable hypothesis is that matching prerequisites and supplying useful feedback will often matter more than adding another undifferentiated textbook. In a Delhi lottery evaluation, an adaptive after-school programme increased independently assessed mathematics scores by 0.37 standard deviations and Hindi scores by 0.23 over 4.5 months. The programme combined computer activities with small-group instruction; it did not isolate a translation or a teacher-free resource (Muralidharan et al., 2019). The design implication to test is a diagnostic entry point, appropriately sequenced practice and explanations—not assigning every proposed publication those effects.

Two other evaluations help distinguish access to an object from access to learning. Conventional textbook provision in Kenyan primary schools did not establish an average test-score improvement, though initially stronger pupils benefited more; language and prerequisite mismatch were possible explanations, not separately randomized treatments (Glewwe et al., 2009). Peru's One Laptop per Child evaluation found increased computer use but no established mathematics or language test-score effect after 15 months (Cristia et al., 2017). Neither finding establishes that open material, offline delivery or translation is unhelpful. They make the package's usability a substantive research question.

These findings generate three explicit predictions for the proposed packages. First, catch-up resources should be more useful when their entry level matches the learner's prerequisites. Second, a subject-language bridge should supply practice and explanations, not just substitute terminology. Third, the benefit of an offline edition should depend on whether a learner can navigate, study and check work with the available device. The comparisons will preserve evidence that supports or weakens each prediction. Classroom findings can inform these mechanisms without making teachers a requirement for the autonomous-learning pathway.

The study keeps functional access and subsequent learning outcomes separate. A test-score standard deviation is not a percentage of people newly able to study. None of these evaluations supplies a universal translation-effect multiplier or a measure of AI production cost. The detailed evidence register also distinguishes the 2012 working-paper and 2017 published versions of the Peru evaluation. Their sample sizes and coefficients are not mixed.

### 7.2 Work still needed for the global portfolio

The global recommendation portfolio is not yet complete. Required remaining work includes language-route estimates around the stage-specific populations; item-level comparisons of independent subject provision; explicit standardized production scenarios; global omission and sensitivity tests; and the final Top 10/Top 100 comparison with alternatives. Signed-language and accessibility interventions, smaller communities, and vocational/research opportunities remain part of that work rather than residual categories.

The present findings already distinguish useful package hypotheses from raw speaker-count priorities. The final synthesis must carry that distinction through every recommendation and remain understandable without knowledge of any particular translation project.

## References used in this draft

OpenStax. (2026). *Prealgebra 2e source collection* (Git commit `38cae454e644abf9f0a623e876994553881597c9`) [CNXML source]. GitHub. https://github.com/openstax/osbooks-prealgebra-bundle/tree/38cae454e644abf9f0a623e876994553881597c9

World Bank. (n.d.). *Fostering foundational skills in Thailand: From a skills crisis to a learning society*. https://www.worldbank.org/en/country/thailand/publication/fostering-foundational-skills-in-thailand

UNICEF Myanmar. (n.d.). *Learning*. Retrieved September 4, 2026, from https://www.unicef.org/myanmar/learning

Universidad Nacional Autónoma de México. (n.d.). *MOOC UNAM: Catálogo de cursos*. Retrieved September 4, 2026, from https://mooc.unam.mx/

Badan Pusat Statistik. (2022a). *Kemampuan berbahasa Indonesia: Long Form SP2020 tables*. https://sensus.bps.go.id/topik/tabular/sp2022/196/1/0

Badan Pusat Statistik. (2022b). *Bahasa pertama: Long Form SP2020 tables*. https://sensus.bps.go.id/topik/tabular/sp2022/197/0/0

Bangladesh Open University. (n.d.). *BBA course materials, third-level course contents*. https://www.ebookbou.edu.bd/wp/OS/osbba3_1.php

OECD. (2023a). *PISA 2022 results (Volume I): The state of learning and equity in education*. https://doi.org/10.1787/53f23881-en

OECD. (2023b). *PISA 2022 statistical tables: Annex A2 and Chapter 3*. https://stat.link/hpg9nd ; https://stat.link/znxau8

Pakistan Bureau of Statistics. (2026). *Household Integrated Economic Survey 2024–25: Social report*. https://www.pbs.gov.pk/wp-content/uploads/2020/07/PSLM_Report_2024-25-janurary-26-Social-Reportupdated.pdf

UNICEF Bangladesh. (2026). *Data on the situation of children in Bangladesh: MICS 2025 indicators*. https://www.unicef.org/bangladesh/en/data-situation-children-bangladesh

Virtual University of Pakistan. (n.d.). *Open courseware: Mathematics*. https://ocw.vu.edu.pk/Courses.aspx?cat=Mathematics

University of Tokyo. (n.d.). *Pythonプログラミング入門 [Introduction to Python programming]*. https://utokyo-ipp.github.io/

Xu, Z. (2023). *概率统计与Python解法 [Probability and statistics with Python solutions]*. Tsinghua University Press. https://www.tup.tsinghua.edu.cn/booksCenter/book_09529801.html

Golubović, J., & Gooskens, C. (2015). Mutual intelligibility between West and South Slavic languages. *Russian Linguistics*. https://doi.org/10.1007/s11185-015-9150-9

Österholm, M. (2006). Characterizing reading comprehension of mathematical texts. *Educational Studies in Mathematics, 63*, 325–346. https://www.diva-portal.org/smash/get/diva2:22664/FULLTEXT01.pdf

Cristia, J., Ibarrarán, P., Cueto, S., Santiago, A., & Severín, E. (2017). Technology and child development: Evidence from the One Laptop per Child program. *American Economic Journal: Applied Economics, 9*(3), 295–320. https://doi.org/10.1257/app.20150385

Glewwe, P., Kremer, M., & Moulin, S. (2009). Many children left behind? Textbooks and test scores in Kenya. *American Economic Journal: Applied Economics, 1*(1), 112–135. https://doi.org/10.1257/app.1.1.112

Muralidharan, K., Singh, A., & Ganimian, A. J. (2019). Disrupting education? Experimental evidence on technology-aided instruction in India. *American Economic Review, 109*(4), 1426–1460. https://doi.org/10.1257/aer.20171112

Bangladesh Bureau of Statistics, & UNICEF Bangladesh. (2026). *Bangladesh Multiple Indicator Cluster Survey 2025: Final report*. https://www.unicef.org/bangladesh/en/reports/bangladesh-multiple-indicator-cluster-survey-2025-0

UNICEF Data. (n.d.). *Child-related SDG progress assessment for Bangladesh: Population overview*. Retrieved September 4, 2026, from https://data.unicef.org/sdgs/country/bgd/

Ministry of Statistics and Programme Implementation. (2020). *Household social consumption on education in India: NSS 75th Round, July 2017–June 2018* (Report No. 585). https://mospi.gov.in/sites/default/files/publication_reports/Report_585_75th_round_Education_final_1507_0.pdf

NPTEL. (n.d.). *Translation programme and translated books*. https://nptel.ac.in/translation

Pakistan Bureau of Statistics. (2023a). *Population by single year age, sex and rural/urban: Census 2023* (Table 4). https://www.pbs.gov.pk/wp-content/uploads/census_tables/tables/Table_4_national.pdf

Pakistan Bureau of Statistics. (2023b). *Population by mother tongue, sex and rural/urban: Census 2023* (Table 11). https://www.pbs.gov.pk/wp-content/uploads/census_tables/tables/table_11_national.pdf

Pakistan Bureau of Statistics. (2023c). *Literacy rate, enrolment and out-of-school population by sex and rural/urban: Census 2023* (Table 12). https://www.pbs.gov.pk/wp-content/uploads/census_tables/tables/table_12_national.pdf

Uwezo Tanzania. (2019). *Are our children learning? Tanzania learning assessment report*. Twaweza East Africa. https://twaweza.org/wp-content/uploads/2021/01/Tanzania-Report-FINAL3-2019-13-12-2019-Print-Readyzm.pdf

National Curriculum and Textbook Board. (2026). *প্রাথমিক গণিত, দ্বিতীয় শ্রেণি [Primary mathematics, grade 2]* (2026 academic-year reprint). https://drive.egovcloud.gov.bd/index.php/s/VeBQB1ZuzSZPRBJ

Merunka, V., van Steenbergen, J., Yordanova, L., & Kocór, M. (2019). The Interslavic language as a tool for supporting e-democracy in Central and Eastern Europe. *International Journal of Electronic Governance, 11*(3/4), 260–288. https://interslavic-language.org/doc/ijeg-2019-interslavic.pdf

Khan Academy. (n.d.). *Early mathematics: Counting* [Bangla learning materials]. https://bn.khanacademy.org/math/early-math/cc-early-math-counting-topic

National Institute of Statistics of Rwanda. (2023). *Fifth Rwanda Population and Housing Census: Education characteristics of population*. Tables 7.7, C.25 and C.31. https://statistics.gov.rw/sites/default/files/documents/2025-02/Education.pdf

Rwanda Basic Education Board. (n.d.). *Translated books are now available for students and teachers*. https://www.reb.gov.rw/news-detail/translated-books-are-now-available-for-students-and-teachers
