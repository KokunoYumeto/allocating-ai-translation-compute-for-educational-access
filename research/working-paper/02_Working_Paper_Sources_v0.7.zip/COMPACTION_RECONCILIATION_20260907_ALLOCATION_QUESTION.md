# Compaction reconciliation — allocation question, 7 September 2026

The primary transcript through message 205 was read from
`RAW_USER_INPUT_TRANSCRIPT_APPEND_20260903.txt`. The controlling user point is
that profile IDs are catalogue keys, not a substitute for the research question:
allocate a fixed amount of AI production compute to create the greatest
additional functional educational understanding. The research question remains
active.

## Evidence check

- The live rankings page has two complete 100-row tables over the 775 retained
  language-and-script profiles: potential reach and reach per standardized
  fresh-equivalent workload. Simplified Standard Written Chinese is first in
  both conditional tables; Indonesian is 9/8, Russian 10/10 and Ukrainian 62/62.
- The C001–C100 inventory is explicitly nonordinal. It is a communication and
  investigation catalogue, not the replacement for the two ranking tables.
- The new local budget scenario solves the finite-budget question across all 775
  rows at 5m, 10m, 25m and 50m FECU, retaining 25 unresolved audience rows as
  unknown challengers rather than zero benefit. Its six runs pass deterministic
  budget, bound, optimality and retention checks.
- The nine-route PISA table is now labelled a context/workload sensitivity. Its
  prevalence counts are not intervention effects and its reversal ratios are not
  value-of-information estimates.

## Repair recorded

`PAPER_CURRENT_DRAFT.md` now states plainly that final package-specific funding
rank remains unbound while conditional Top 100 screens and finite-budget
scenario portfolios remain active allocation research. The nine-route heading and
text distinguish PISA context from people helped and remove the unsupported
value-of-information tier claim. A new section 7.9 reports the actual global
fixed-budget calculation and its limitations.

## Next executable action

Build the next human-readable checkpoint from this manuscript, add the budget
scenario artifacts to its evidence manifest, and run citation, arithmetic,
omission, accessibility, structural and complete render QA before any public
replacement. Keep the goal active; no completion claim is made here.

Artifact hashes at reconciliation:

- `PAPER_CURRENT_DRAFT.md`: 262,017 bytes,
  SHA-256 `9F9E5C9C7F7E2903384723FC3861ACE5EB6BA5013A535D961FE1CBE1DE770F93`.
- `GLOBAL_BUDGET_SCENARIOS_v1.md`: 5,897 bytes,
  SHA-256 `A561E9A07158FCE6DCA96371328173C2726F2174B122A13B469B8938DAC5814C`.
- `structured/GLOBAL_BUDGET_SCENARIOS_v1.json`: 363,154 bytes,
  SHA-256 `F32CD067A68C990C02779D18CCCAF0E0C270958BCFA6FD22A6777599DE757FEC`.
- `qa/GLOBAL_BUDGET_SCENARIOS_QA_v1.json`: 794 bytes,
  SHA-256 `8926B083C7FC8548F4E9E65EB985CCBED04DC5B6CD32FBE11D0235671438A3E7`.
