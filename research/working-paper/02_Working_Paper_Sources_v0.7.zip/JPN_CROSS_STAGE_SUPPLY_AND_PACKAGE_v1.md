# Japan cross-stage supply and package comparison

This checkpoint asks what a specific open educational package could add in Japan. It does not ask whether Japan has education, and it does not assign a global rank.

## Main finding

Japan has strong mainstream education and research supply, but the evidence also identifies concrete academic-language, transition, reskilling, endangered-language, signed-language, accessibility, open-reuse and advanced-work opportunities. A blanket inclusion or exclusion is unsupported. Compare exact packages on marginal access and standardized full cost.

The strongest immediately testable route in the current evidence is the measured academic-Japanese support population at the foundational/secondary transition. The source reports 69,123 enrolled learners under a functional definition that includes learners who can converse in Japanese but lack grade-level academic language. Their lower-secondary progression rate was 90.3%, compared with 99.0% for all students in the source comparison. That is a real access signal, but it is not yet a translation-effect estimate and the broad language labels are not exact varieties.

Japan is not a negative control. High national PISA means and strong domestic supply raise the need for exact additionality tests; they do not justify a country penalty, a zero-need conclusion, or exclusion from advanced/open/accessibility work.

## Exact-language boundary

All 25 Japan-linked Glottolog language-level nodes remain visible and unranked. The register includes three separately retained signed-language nodes. The official endangered-language page names eight categories, but broad labels such as Ainu and Amami are not forced into a single exact Glottolog node.

The MEXT survey partitions the 69,123 measured learners into broad home/daily-life language labels. These rows reconcile arithmetically, but they remain survey categories rather than exact production tags:

| Survey label | Foreign nationality | Japanese nationality | Combined partitions |
|---|---:|---:|---:|
| Japanese | 2,671 | 3,478 | 6,149 |
| English | 3,221 | 1,697 | 4,918 |
| Korean | 482 | 187 | 669 |
| Spanish | 3,668 | 378 | 4,046 |
| Chinese | 11,862 | 1,892 | 13,754 |
| Filipino | 8,913 | 2,208 | 11,121 |
| Vietnamese | 3,756 | 222 | 3,978 |
| Portuguese | 12,026 | 553 | 12,579 |
| Other | 11,119 | 790 | 11,909 |

## Stage comparisons

### P - preschool / early childhood

Observed supply: A large mainstream early-childhood system and free provision for ages 3-5 exist. This does not inventory openly reusable, exact-home-language, signed, accessible, offline or self-study early numeracy/oral-language material.

Complete alternative: Open early-language, early-numeracy, play and learning-to-learn sequences in the exact child/caregiver language, with educator/caregiver guidance, images, audio or signed video, print and offline delivery.

Bounded alternative: A phone/print/signed activity pack focused on number sense, patterns, spatial language and caregiver prompts, with an explicit remainder manifest.

Next comparison: Bind one exact child/caregiver route, current supply, delivery mode and common early numeracy/oral-language endpoint.

### F - foundational / primary

Observed supply: Paper and phased digital textbooks exist nationally, and national outcomes are strong. Exact home-language academic bridges, open reuse, autonomous-study feedback, signed routes and accessibility interoperability remain package-specific questions.

Complete alternative: A coherent open foundational sequence in literacy, mathematics, science and learning strategies, plus exact-language academic-Japanese bridges, full worked feedback, MathML, print and resumable offline delivery.

Bounded alternative: A diagnostic prerequisite-and-language bridge at one grade transition, including worked examples, wrong-answer feedback and an exact home-language, signed or accessibility route.

Next comparison: Compare the two alternatives for one exact learner-language group on the same mathematics/science/literacy endpoint and full production cost.

### S - secondary

Observed supply: High aggregate PISA means coexist with a measured academic-language transition gap. National means cannot settle the additionality of exact-language, transition, autonomous-study or accessible packages.

Complete alternative: Open secondary mathematics, statistics, computing, biology, chemistry and physics pathways with prerequisites, exercises, feedback, accessibility and exact-language academic bridges.

Bounded alternative: A transition package targeting one bottleneck such as algebra, quantitative science, statistics/data literacy or academic Japanese, with the remainder explicitly uncovered.

Next comparison: Use one exact cohort, current course/resource, common assessment or progression endpoint and standardized full cost.

### V - vocational / practical

Observed supply: A substantial specialized-training system exists; the national plan still identifies slow adult re-learning/reskilling and specialist shortages.

Complete alternative: Open modular reskilling in quantitative reasoning, computing/data, finance, management, science/health foundations and workplace communication with exercises, projects, answer feedback and offline delivery.

Bounded alternative: One credential- or task-aligned toolkit such as Python/data, practical statistics, finance, management decisions or quantitative health, adapted to exact terminology and device conditions.

Next comparison: Bind one occupational pathway, entry prerequisites, exact language route, current open supply, completion or task endpoint and standardized cost.

### U - university / taught tertiary

Observed supply: Domestic textbooks, universities and a large free-to-read journal platform exist. Open reuse, accessibility, autonomous-study completeness and exact Japanese availability for a chosen advanced source still require item-level comparison.

Complete alternative: Open degree-core/prerequisite sequences across mathematics, statistics, computing, life/physical sciences, finance, management and allied health, with full exercises, solutions, accessible notation and offline use.

Bounded alternative: A prerequisite repair or terminology bridge for one high-friction course, or a high-quality Japanese edition of one source absent from current open supply.

Next comparison: Inventory the exact Japanese course/source and license; compare matched completion, comprehension or task performance with full production cost.

### R - postgraduate / research

Observed supply: A large research system and mixed Japanese/English publication ecology exist. Journal abundance does not supply every research monograph, historical school, proof corpus or advanced open text in Japanese.

Complete alternative: Open advanced textbook, monograph and research-corpus editions with source-language terminology, formula/proof preservation, linked references, machine-readable mathematics and offline archival forms.

Bounded alternative: A source-faithful edition of one high-value absent work, or a bilingual terminology/reading scaffold around a formal mathematical corpus.

Next comparison: Bind a named field/work, current Japanese/open alternatives, prepared-reader population, comprehension/use endpoint and full production cost. Formal mathematical structure may reduce prose burden but cannot be assumed to create full intelligibility.

## Source-scale baselines

The nine OpenStax sources are retained as comparable workload baselines across mathematics, statistics, biology, chemistry, physics, management, finance, anatomy/physiology and Python. Their measured source sizes do not establish Japanese need, benefit, physical compute or priority. Open Logic, the Stacks Project and advanced mathematical corpora remain separate taught-tertiary/research hypotheses.

## Decision boundary

No exact addressable audience, incremental effect, physical compute, currency cost, dominance relation or funding rank is assigned. Existing supply changes the design of a matched package; it never lowers the underlying educational need of a person or language community.
