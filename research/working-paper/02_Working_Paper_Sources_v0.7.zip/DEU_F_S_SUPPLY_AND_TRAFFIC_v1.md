# Germany F/S supply and token-event traffic checkpoint

Bounded checkpoint. F means foundational/primary and S means secondary. This is not a global rank, a production authorization, or a claim that country of origin identifies a learner's language.

## Result

Germany is not a blank-supply case. German mathematics provision is substantial, an open language-sensitive mathematics collection exists, Hamburg publishes detailed multilingual/subject-language teaching materials, and one commercial platform advertises multilingual grade 5–10 content. That does not make newcomer access solved. The directly evidenced gap is the connection between a learner's strongest exact language, German mathematical register, prerequisites, word problems, and progression into the regular curriculum.

For this Germany-specific comparison, the first experiment should therefore be an open exact-language/script academic-mathematics bridge around regular-class progression. A complete parallel edition remains a live alternative for languages without current usable coverage, autonomous or offline learners, and cases where its additional outcomes justify its larger source scale.

## What current evidence says

- Hamburg's 133-page IVK mathematics handbook sequences data, fractions, percentages, and linear functions across grades 5–10. It explicitly pairs mathematical learning with German subject and academic language, invites learners to translate terminology into their own language, and provides worksheets plus some solutions.
- Hamburg's 2024 transition framework ordinarily moves learners to regular classes within twelve months, then provides another year of additive language support. It makes academic language a responsibility across school subjects, not a prerequisite to be completed before subject learning begins.
- The saved 2025/26 Hamburg chart shows 591 primary, 947 comprehensive-secondary, 846 Gymnasium, and 28 special-school pupils in state-school base/IVK classes: 2,412 in all. This excludes many directly integrated six- and seven-year-olds and generally excludes 16+ vocational entrants. It is not a language denominator, a national count, or a benefit estimate.
- A historical Hamburg administrative study found lower short-term standardized performance after separate preparatory classes than after direct integration with additional language support, especially in mathematics and German. It does not show that language support is harmful or establish a current Germany-wide effect.

## Existing material supply

- Serlo reports 930 articles, 20 courses, 105 videos, and 5,000 tasks with model solutions across school and higher mathematics, free and CC BY-SA 4.0. These are provider counts, not an audited completeness or impact result.
- Serlo's CC BY-SA 4.0 SchlaU-Werkstatt targets newly arrived adolescents and young adults with slow, language-sensitive mathematics. The saved root has four top-level collections and the saved first layer has 13 immediate branches; that is useful targeted supply, not a complete F/S curriculum.
- Binogi advertises more than 1,000 videos and three quizzes in 11 subjects for grades 5–10, in up to 15 languages. Arabic, Somali, Dari, Tigrinya, and Ukrainian are named; Pashto and Kurdish are not named on the captured list. The free tier is limited and full individual access is listed at €199/year, so this is not an open corpus.
- Hamburg says its materials may be adapted for one's own teaching and used on classroom devices, but this checkpoint did not verify a general open derivative licence. It is pedagogical/design evidence, not automatically a translation source.

## Package-scale comparison

The source scale is OpenStax Prealgebra 2e. The bridge uses chapters 2, 4, 6, 8, and 11 because they correspond to algebra language, fractions, percentages, linear equations, and graphs—the Hamburg handbook's core sequences. This is transparent scale arithmetic, not a claim of curricular equivalence.

| Package | Source tokens | Modules | Source-size share |
|---|---:|---:|---:|
| Complete parallel sequence | 364,270 | 75 | 100.00% |
| Five-chapter academic-math bridge | 143,859 | 30 | 39.49% |
| Language-of-algebra lower comparator | 30,563 | 6 | 8.39% |

At zero common setup, the bridge is **39.49%** of the full measured source scale. At the same endpoint it is more efficient if it retains more than 39.49% of the full package's positive yield; the full sequence must deliver more than **2.532×** as much positive yield to be more efficient. Neither yield has been measured.

The following base-FECU rows are language/script tokenization scenarios, not assignments of an origin community to one language:

| FLORES profile | Complete sequence | Five-chapter bridge | Algebra-language lower comparator |
|---|---:|---:|---:|
| apc_Arab | 5,055,467 | 1,996,526 | 424,164 |
| prs_Arab | 5,277,767 | 2,084,317 | 442,815 |
| pbt_Arab | 5,683,193 | 2,244,430 | 476,832 |
| ckb_Arab | 7,482,065 | 2,954,848 | 627,761 |
| deu_Latn | 4,996,073 | 1,973,070 | 419,181 |

FECU is a standardized token-event traffic index. It is not physical compute, money, quality, or educational impact. Mathematical and linguistic checking, bilingual alignment, formatting, accessibility, deployment, and maintenance remain explicit unmeasured work.

## First experimental package

The bridge should combine:

- exact origin-language explanations with German classroom and mathematical language;
- operators, structure words, word problems, and a bilingual mathematical glossary;
- prerequisite diagnostics, curriculum mapping, and catch-up routes;
- worked examples, exercises, answers, and feedback usable without a teacher;
- lawful links or reuse from current open German resources;
- phone-readable, low-bandwidth, offline, printable, and screen-reader-native forms;
- signed-language companion access where needed; and
- transition, examination, credential, and pathway navigation.

The audience, exact language/variety/script distribution, package effect, physical compute, currency cost, and global rank remain unresolved. Existing educational or translation work changes the package comparison only; it does not reduce any population's underlying educational need.

## Sources

- [Fachunterricht in Internationalen Vorbereitungsklassen der Sekundarstufe I: Mathematik](https://li.hamburg.de/resource/blob/650538/f9df57d2b8aa59a9a6c76927ec2b67d9/pdf-ivk-materialien-fachkapitel-mathematik-data.pdf) — Landesinstitut für Lehrerbildung und Schulentwicklung Hamburg; undated; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Hamburg_IVK_Mathematik_official.pdf; 10,215,181 bytes; SHA-256 F9D4000AF2D2397B62131A48CD9160BED4E8F0CB3F0528BA57A316F03B571FF4.
- [Aus der IVK in die Regelklasse](https://zsj.hamburg.de/wp-content/uploads/sites/876/2024/08/broschuere-uebergang-data.pdf) — Freie und Hansestadt Hamburg, Behörde für Schule und Berufsbildung; 2024. Snapshot: sources/deu_f_s_supply_20260905/Hamburg_IVK_to_Regelklasse_2024_official.pdf; 1,598,374 bytes; SHA-256 937B7FADFB2E107376A20B574A73405BD8C79A061941369B30B58CEAF599564C.
- [Fachunterricht in Internationalen Vorbereitungsklassen](https://li.hamburg.de/qualitaetsentwicklung-von-unterricht-und-schule/aufgabengebiete-und-querschnittsthemen/interkulturelle-erziehung/fachunterricht-ivk-651108) — Landesinstitut für Lehrerbildung und Schulentwicklung Hamburg; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Hamburg_IVK_materials_landing_official.html; 97,263 bytes; SHA-256 32689DD35D691A93E5193889613EBE965AEA3D7F375C5C0D98B2BA707678A42F.
- [Schüler*innen in Basisklassen und Internationalen Vorbereitungsklassen 2025/26](https://ifbq.hamburg.de/2026/02/10/schuelerinnen-in-basisklassen-und-internationalen-vorbereitungsklassen/) — Hamburg Institute for Educational Monitoring and Quality Development; 2026-02-10. Snapshot: sources/deu_f_s_supply_20260905/Hamburg_IVK_2025_26_IfBQ_official.html; 216,166 bytes; SHA-256 AD8283467CDDBDC7D12E6BDA1D29C37D1E2855B17C4007CDB60CE6BE0EE27720.
- [Development of pupil counts in Hamburg base and international preparatory classes](https://ifbq.hamburg.de/wp-content/uploads/sites/803/2025/02/6a.jpg) — Hamburg Institute for Educational Monitoring and Quality Development; school-year statistics 2025/26. Snapshot: sources/deu_f_s_supply_20260905/Hamburg_IVK_2025_26_chart_official.jpg; 119,584 bytes; SHA-256 CFE3A1110B5765759791EC63F72BB0598997138357FAD89776AD112A42A0E101.
- [Mathematik Startseite](https://de.serlo.org/serlo/19767/mathematik-startseite) — Serlo Education e.V.; page metadata modified 2022-06-15; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Mathematik_overview.html; 146,838 bytes; SHA-256 096051E56468868542388D5C8EA2BEEBBC423F411F245A3A2C96EF68C69A04A1.
- [Schlau-Werkstatt: Mathematik in DaZ](https://de.serlo.org/schlau-werkstatt/146870/schlau-werkstatt) — Serlo Education e.V. and SchlaU-Werkstatt; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Schlau_Werkstatt.html; 92,493 bytes; SHA-256 E58BA46AB14E546854828BECB5BF543311F50DF6DA424C4F8F4DA13D7B2EE56C.
- [Über Serlo](https://de.serlo.org/serlo/21556/ueber-serlo) — Serlo Education e.V.; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_about_and_license.html; 118,530 bytes; SHA-256 B6CD0CF2EC9A242EC55D3B6FB5E9472B2E9F74F027FAF0BA2C230BAD4ECC375B.
- [Rechenregeln und Rechenbegriffe](https://de.serlo.org/schlau-werkstatt/146948/rechenregeln-und-rechenbegriffe) — Serlo Education e.V. and SchlaU-Werkstatt; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Schlau_146948_Rechenregeln.html; 84,649 bytes; SHA-256 479840328BCBA23AA9D18A12D2EAF161AC6BC78005E08D548E59A0574F1E3B78.
- [Ganze Zahlen: Rechnen mit negativen Zahlen](https://de.serlo.org/schlau-werkstatt/183602/ganze-zahlen-rechnen-mit-negativen-zahlen) — Serlo Education e.V. and SchlaU-Werkstatt; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Schlau_183602_Ganze_Zahlen.html; 85,003 bytes; SHA-256 D33C533FF66AF874134ACF01B9EA95D1F8870828B508D524BB8D78EB48551185.
- [Grundlagen der Geometrie](https://de.serlo.org/schlau-werkstatt/183603/grundlagen-der-geometrie) — Serlo Education e.V. and SchlaU-Werkstatt; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Schlau_183603_Geometrie.html; 84,833 bytes; SHA-256 57EB738683FFB011F806FFB6C60A18EB7BA11E1ADAA69D0DB30F028362755758.
- [Rechnen mit Größen](https://de.serlo.org/schlau-werkstatt/183604/rechnen-mit-groessen) — Serlo Education e.V. and SchlaU-Werkstatt; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Serlo_Schlau_183604_Groessen.html; 86,671 bytes; SHA-256 9748373A6A4C69F76856933F7E6CECF2E48B2AF149CA794593063A27BE26B46D.
- [Binogi multilingual learning portal](https://www.binogi.de/) — Binogi; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Binogi_home_multilingual.html; 57,029 bytes; SHA-256 D08851B48EBEAB182071574362C8DDF3A4831694C823DE70C726811E9274CBAC.
- [Binogi individual pricing](https://www.binogi.de/preise-einzellizenzen) — Binogi; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Binogi_individual_pricing.html; 23,035 bytes; SHA-256 6121B49FC86AF21FE02149556CA650FA02E9C8B13253BECD2996C72E6966CE3E.
- [Binogi lessons](https://www.binogi.de/our-lessons) — Binogi; retrieved 2026-09-05. Snapshot: sources/deu_f_s_supply_20260905/Binogi_lessons.html; 34,084 bytes; SHA-256 63D8D70A3ECAC88DD2298AF3A465BB244E0FA2EAEEB3124B7AFF6116B0DE41C1.
- [Starting off on the Right Foot: The Effects of Language Learning Classes on the Educational Success of Immigrant Children](https://doi.org/10.1093/ej/ueaf087) — Schilling and Höckel, published 2025. Snapshot: sources/displacement_corridor_v3_20260904/Schilling_Hoeckel_Starting_off_on_the_Right_Foot_2025.html; 573,317 bytes; SHA-256 068EDA5538B6A51DE0449A39CC86C50CEA20B0F48C9E521BB704A2445F472E4F.
- [OpenStax Prealgebra 2e source repository](https://github.com/openstax/osbooks-prealgebra-bundle/tree/38cae454e644abf9f0a623e876994553881597c9) — measured at commit 38cae454e644abf9f0a623e876994553881597c9; CC BY-NC-SA 4.0.

This checkpoint narrows one intervention comparison. It does not establish a final funding order.
