# Houston foundational/secondary supply and standardized-traffic checkpoint

**Status:** bounded research checkpoint; not a global ranking, causal evaluation, or claim that any language need is satisfied.

## Plain-language result

Houston is not a simple case of either ‘Spanish materials exist’ or ‘Spanish materials do not exist.’ Texas currently provides a free, state-aligned Spanish mathematics sequence from kindergarten through grade 6. On the same official portal, grade 7, grade 8, Algebra I, Geometry and Algebra II are listed only in English. Houston ISD currently describes Spanish dual-language, English-as-a-second-language and elementary transitional-bilingual models, while one named campus demonstrates that Spanish dual-language schooling can continue through grade 8. The actual reach of those programs by campus, language, grade and learner is not published in the sources captured here.

The strongest bounded experiment is therefore a secondary-transition package, not a declaration that a complete edition is unnecessary. For Spanish-literate learners, it would connect Spanish mathematical knowledge to English academic register, prerequisites, Algebra I and geometry, state testing, course placement and credit. For other learners it must branch by exact language, variety, script and literacy. A complete exact-language sequence remains a live alternative for autonomous or offline learners and for any stratum where its measured extra benefit justifies its larger production scale.

## What current provision visibly covers

- The Texas portal lists Spanish mathematics for K–5 and grade 6. It lists English grade 7, grade 8, Algebra I, Geometry and Algebra II, but no Spanish counterparts for those stages on the captured page.
- Texas describes the materials as open educational resources, available digitally to any individual for free, with PDF components. This establishes access claims, not actual uptake or learning effect; component-level reuse and embedded-object rights still require checking before republishing derivatives.
- HISD describes dual-language, ESL and elementary-only transitional-bilingual models. The one-way partner language it names is Spanish.
- HISD's current intake uses a home-language survey and English-proficiency tests. The public page does not show measurement of academic-mathematics literacy, interrupted schooling, prior course credit, or device/offline access.
- Wharton K-8 is a bounded counterexample: its page reports Spanish dual-language instruction through grade 8 and an Algebra I high-school-credit opportunity. One campus cannot establish districtwide coverage.

## What the historical district cohort does—and does not—show

The 2021–2022 HISD evaluation reports 12,655 cumulatively enrolled immigrant pupils, including 405 from Venezuela; 11,241 (89%) were classified as emergent bilingual and 10,756 (85%) as economically disadvantaged. Its country table and home-language table are separate marginal distributions. They cannot be cross-tabulated from the publication. In particular, the 405 Venezuela-origin pupils cannot be assigned Spanish from this source.

| Published home-language label | Historical count |
|---|---:|
| Spanish | 9,615 |
| Pashto | 692 |
| English | 503 |
| Arabic | 262 |
| Farsi | 234 |
| Swahili | 76 |
| Dard | 71 |
| Vietnamese | 66 |
| French | 63 |
| Telugu | 57 |
| Japanese | 55 |
| Hindi | 46 |
| Mandarin | 41 |
| Other | 874 |

These labels are not always exact languages or varieties: Pashto, Farsi, Dard, Arabic, Mandarin and Swahili can conceal distinctions relevant to script, literacy and educational materials. The current language-by-grade audience is unknown.

The report's 2022 outcomes are signals for package design, not causal translation effects. Immigrant pupils met the English mathematics STAAR grade-level threshold at 34% versus 59% for all emergent bilingual pupils and 64% districtwide; on the Spanish mathematics STAAR the corresponding immigrant and emergent-bilingual values were 51% and 59%. Algebra I end-of-course values were 38%, 49% and 61%. AP course enrollment among grades 8–12 was 7.1%, 14.6% and 24.0%. The report itself highlights persistent secondary and postsecondary-readiness gaps, but none of these contrasts identifies which translation package caused or would close them.

## Proposed bounded experiment

1. Extend intake beyond a language name: record exact language/variety, script, literacy, prior mathematics, interrupted schooling, completed courses and credits, plus phone, data and offline access.
2. For Spanish-literate learners, test a bilingual grades 7–12 bridge at the visible grade-6-to-grade-7 breakpoint. Include academic-mathematics register, prerequisite diagnosis, Algebra I, geometry and graphs, worked examples, answers, state-test orientation, course placement and credit navigation.
3. Keep separate exact-language arms open for every non-Spanish learner. Do not collapse the broad home-language labels into one variety or script.
4. Retain a complete exact-language course as a comparison and production option. Existing K–6 Spanish supply changes package design; it does not reduce underlying educational need.

## Source scale and decision threshold

OpenStax Prealgebra 2e is used only as a lawful, reproducible source-scale comparator. The four selected chapters cover the language of algebra, linear equations, mathematical models/geometry and graphs. They do not equal the Texas curriculum.

| Comparator | Source content tokens | Modules | Share of complete source |
|---|---:|---:|---:|
| Complete sequence | 364,270 | 75 | 100.00% |
| Four-chapter transition bridge | 119,602 | 24 | 32.83% |
| Language-of-algebra lower comparator | 30,563 | 6 | 8.39% |

With zero common setup, equal variable cost per source token and the same learner endpoint, the complete sequence must produce more than **3.046 times** the bridge's positive yield to be more efficient. The threshold moves when common setup or unmeasured checking, alignment, rendering, accessibility and deployment work changes. It is not an assumed learning effect.

## Standardized text-traffic scenarios

FECU is declared token-event traffic, not physical compute, money, quality or benefit. These language/script profiles are scenarios only; they are not assignments to HISD's broad labels or country rows.

| FLORES profile | Complete sequence | Four-chapter bridge | Algebra-language lower comparator |
|---|---:|---:|---:|
| spa_Latn | 5,008,180 | 1,644,353 | 420,197 |
| eng_Latn | 4,466,725 | 1,466,575 | 374,767 |
| pbt_Arab | 5,683,193 | 1,865,982 | 476,832 |
| prs_Arab | 5,277,767 | 1,732,867 | 442,815 |
| arb_Arab | 5,117,080 | 1,680,108 | 429,334 |
| swh_Latn | 5,293,994 | 1,738,195 | 444,177 |
| tel_Telu | 6,050,270 | 1,986,505 | 507,630 |
| vie_Latn | 5,300,713 | 1,740,401 | 444,741 |
| fra_Latn | 5,096,479 | 1,673,344 | 427,605 |
| jpn_Jpan | 5,587,795 | 1,834,660 | 468,827 |
| hin_Deva | 5,442,257 | 1,786,875 | 456,617 |
| zho_Hans | 4,890,280 | 1,605,642 | 410,304 |

## High-consequence unknowns

- Current exact language/variety/script by grade and proficiency.
- Prior schooling, mathematics level, course credit and interrupted-schooling distribution.
- Current campus-level program and material access by language and grade.
- Current grade 7-12 Spanish and other-language open-material supply outside the captured official portal.
- Phone, data, offline, print and assistive-technology access.
- Matched learning, placement, credit, persistence and postsecondary outcomes.
- Physical compute, full workflow traffic, currency and maintenance cost.

Unknown values remain research obligations. They do not become zero need, a low priority, or permission to remove a language.

## Sources and frozen local identities

- SRC_HOU_HISD_CURRENT_MULTILINGUAL_MODELS: [Multilingual Program Models](https://www.houstonisd.org/schools-academics/academics/multilingual/multilingual-program-models) — `2DFE510A449A2BDD80959166772BD887DDCA7C2A8BF26DF3D5431D29C1706D54`
- SRC_HOU_HISD_MULTILINGUAL_REPORTS_INDEX: [Multilingual program evaluation reports](https://www.houstonisd.org/public-postings/research-accountability/reports/multilingual) — `7322819FD87E7E51EF7799F50C88B39411DFD023859BDE9028AC2ACB8E5FE2C8`
- SRC_HOU_HISD_CURRENT_LANGUAGE_IDENTIFICATION: [Testing & Identification](https://www.houstonisd.org/schools-academics/academics/multilingual/testing-identification) — `980BEBBADCD8C83121D801D2AEA08D179BDF6EA8DB714D35864100590C7633D3`
- SRC_HOU_WHARTON_K8_DUAL_LANGUAGE: [Academic Offerings](https://wharton.houstonisd.org/academics-programs/academic-offerings) — `3BC6E078F0D9782916785606524A8F260A1EC924A4AC7BCA8615C8E43E273703`
- SRC_TEXAS_BLUEBONNET_MATH_CURRENT: [Bluebonnet Learning: K-5 Math and Secondary Mathematics](https://tea.texas.gov/curriculum-and-instruction/instructional-materials/bluebonnet-learning/bluebonnet-learning-k-5-math-and-secondary-mathematics) — `DCC94C31A801E258F8CCE3490F89CD3383F62E4B8EA15579DA95A946A45DE306`
- SRC_TEXAS_BLUEBONNET_PORTAL_CURRENT: [Bluebonnet Learning Portal](https://bluebonnet.tea.texas.gov/) — `2B6906424AA3B6256C1EE3D809C562A96CD7ACF899DD9F41C33831D43495D470`
- SRC_TEXAS_SPANISH_TEKS_CURRENT: [Texas Essential Knowledge and Skills in Spanish](https://tea.texas.gov/laws-and-rules/state-board-education/teks/texas-essential-knowledge-and-skills-spanish) — `AE5DDC8DC91052E5D2A64518E76E6747BD8FDA9F0F6CFF331C82618F05CC0BDE`
- SRC_HOU_HISD_IMMIGRANT_EVALUATION_2022: [Immigrant Student Program Evaluation Report 2021-2022](https://www.houstonisd.org/fs/resource-manager/view/a76fe050-7086-4b96-9bdc-540738502595) — `8C1A98A6938DAA929105D58DD52191ADCB8C673ABA1DC68619C2B9DDB2A47CB6`

The report PDF was visually checked on PDF pages 10–12 for the demographic and outcome charts. All source snapshots and generated outputs are hash-bound in the machine-readable JSON and QA receipt.
