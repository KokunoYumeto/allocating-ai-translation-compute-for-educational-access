# Mexico cross-stage supply and package comparison

This checkpoint asks what specific open educational packages could add in Mexico. It does not treat Mexico as one language, does not assume Spanish covers every learner, and does not assign a global rank.

## Stage legend

| Code | Meaning |
|---|---|
| P | preschool / early childhood |
| F | foundational / primary |
| S | secondary |
| V | vocational / practical |
| U | university |
| R | postgraduate / research |

## Main finding

Mexico combines very large mainstream enrollments, substantial secondary subject bottlenecks, a large Indigenous-education service, 364 exact INALI variants, five signed-language nodes, online and print supply, and consequential tertiary/research systems. These are different audiences and intervention routes. Compare matched complete and bounded packages on newly usable access and standardized full cost; do not let Spanish supply or a broad language label erase exact communities.

The source freeze retains 339 Mexico-linked Glottolog language-level nodes, 364 INALI catalogue variants, 476 INALI self-denominations, five signed-language nodes and ten broad census labels on the selected national chart. Those are not interchangeable inventories. No name match is treated as proof of language boundary or educational coverage.

## Scale and non-additivity

| Context | Source-bound value |
|---|---:|
| National population, 2025 | 131,946,900 |
| National primary enrollments, 2024-2025 | 12,838,201 |
| Indigenous-education enrollments, initial through primary, 2023-2024 | 1,245,738 |
| People age 3+ speaking an Indigenous language, 2020 | 7,364,645 |
| Higher-education enrollments, 2024-2025 | 5,519,791 |
| Postgraduate enrollments, 2024-2025 | 478,382 |

These are different source frames, not one additive population. The professional-technical count is nested in upper secondary; the mathematics, reading and science PISA burdens overlap in the same represented cohort; and broad census labels cannot be split across exact INALI variants without a source-audited crosswalk.

## Exact-language boundary

All 339 country-linked Glottolog nodes, 364 INALI variants and 476 self-denominations remain visible in the JSON and CSV. Five signed-language nodes are retained separately:

- Albarradas Sign Language (alba1273; ISO 639-3 lsc)
- San Juan Quiahije Chatino Sign Language (chat1269)
- Mexican Sign Language (mexi1237; ISO 639-3 mfs)
- Tijuana Sign Language (tiju1234)
- Yucatec Maya Sign Language (yuca1236; ISO 639-3 msd)

INALI explicitly says that a linguistic grouping can contain forms that are not mutually intelligible. Accordingly, neither an INALI grouping nor a census label such as Nahuatl, Maya, Mixtec or Zapotec is treated as one automatic production audience.

## Stage comparisons

### P - preschool / early childhood

Observed supply and context: A national preschool system and a large Indigenous initial/preschool service are observed; exact child/caregiver language, variant-level materials, signed routes, licensing, offline access and effect remain unmeasured.

Complete alternative: An open early-language, pre-literacy, early-numeracy, play and learning-to-learn sequence in one exact child/caregiver language, with educator/caregiver guidance, illustrations, audio or signed video, print and offline delivery.

Bounded alternative: A phone/print/audio/signed activity pack for number sense, patterns, spatial language and caregiver prompts in one exact route, with the uncovered remainder stated.

Next comparison: Bind one exact child/caregiver language or sign-language route, current materials, delivery conditions and a common early-language/numeracy endpoint.

### F - foundational / primary

Observed supply and context: National textbooks and broad-label Indigenous material distribution are observed, but copy count is not title count, variant coverage, learner receipt, usability, open licensing or a coherent self-study pathway.

Complete alternative: Open literacy, numeracy, science and learning-strategy pathways with exercises, answers, worked feedback, exact-language/Spanish bridges, semantic mathematics, audio/signed alternatives, print and resumable offline use.

Bounded alternative: A diagnostic prerequisite-and-language bridge at one grade transition, with worked examples, wrong-answer feedback and one exact language, signed or accessibility route.

Next comparison: Resolve one INALI variant and its present school/material route; compare complete and bounded packages on the same literacy/numeracy endpoint.

### S - secondary

Observed supply and context: Large secondary enrollment coexists with strong mathematics, reading and science bottlenecks among the represented PISA cohort. The source does not identify which constraint is language, prerequisites, pedagogy, access or another mechanism.

Complete alternative: Open secondary mathematics, statistics, computing, biology, chemistry and physics pathways with prerequisites, exercises, answers, feedback, accessibility, exact-language or academic-Spanish bridges, print and offline delivery.

Bounded alternative: One transition package targeting algebra, quantitative science, reading, statistics/data literacy or academic language, with the remainder explicitly uncovered.

Next comparison: Use one exact cohort, current course/resource, common assessment or progression endpoint and standardized full production cost; preserve the 64-percent PISA coverage limit.

### V - vocational / practical

Observed supply and context: Technical and online-learning routes exist, but the freeze does not establish which occupations lack openly reusable, language-matched, accessible materials or which prerequisites dominate.

Complete alternative: Open modular pathways in quantitative reasoning, personal and business finance, management, computing/data, science/health foundations and workplace safety, with projects, answers, feedback, exact terminology and offline use.

Bounded alternative: A credential- or task-aligned toolkit such as practical statistics, finance, management decisions, Python/data or quantitative health/safety, paired with prerequisite repair.

Next comparison: Bind one occupation or qualification, existing materials, actual task/credential endpoint and exact-language/accessibility route before comparing complete and bounded production.

### U - university / taught tertiary

Observed supply and context: A large university system and domestic scholarly supply are visible, while language, prerequisite, licensing, accessibility and subject-complete gaps remain target-specific.

Complete alternative: Open prerequisite-through-degree pathways in mathematics, statistics, computing, physical/life science, health, finance and management with exercises, worked solutions, accessible diagrams, terminology bridges and offline use.

Bounded alternative: A gateway-course bridge in prealgebra/calculus prerequisites, statistics, Python, physics, chemistry, biology, anatomy, finance or management, tied to one programme and common endpoint.

Next comparison: Bind one institution/programme, instructional/reading language, current open supply, prerequisites and progression endpoint; separate enrollment from addressable audience.

### R - postgraduate / research

Observed supply and context: Mexico has consequential postgraduate, research and domestic-journal systems, but corpus-level language accessibility, field scarcity and research-reader comprehension are unmeasured.

Complete alternative: A coherent advanced corpus or field pathway with source-faithful translation, bilingual terminology/search navigation, formulas/code/data preserved, accessible HTML/PDF/source and offline use.

Bounded alternative: One foundational monograph, paper cluster, terminology/search sidecar or source-facing parallel edition for a named field and prepared reader group.

Next comparison: Bind a field, prepared-reader population, current-language supply, corpus dependency graph and research/teaching endpoint; compare full corpus, selected works and terminology/navigation sidecars.

## Cross-subject source-scale baselines

The nine measured OpenStax sources provide workload baselines across mathematics, statistics, biology, chemistry, physics, management, finance, anatomy/physiology and Python. Their source size does not establish Mexican need, benefit, language fit, production compute or priority.

| Source | Subject | Stages to test | Complete text tokens | Mexico-specific hypothesis |
|---|---|---|---:|---|
| Prealgebra 2e | mathematics | F/S/V/U | 364,270 | Test F/S/V/U prerequisite repair in Spanish and one exact Indigenous/signed/accessibility route; compare a complete autonomous course with a bounded transition module. |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | 396,969 | Test S/V/U data literacy against a concrete secondary, technical, health, public-administration, business or degree endpoint. |
| Biology 2e | life science | S/U | 763,621 | Test S/U biology where current Spanish or exact-language open supply, laboratory/field context and prerequisites are measured; do not infer local fit from source breadth. |
| Chemistry 2e | physical science | S/U | 625,793 | Test a secondary/university chemistry bridge with formula integrity, accessible diagrams and signed/exact-language terminology; bind laboratory constraints separately. |
| College Physics 2e | physical science | S/V/U | 950,860 | Test algebra-based physics at S/V/U against mathematics prerequisites, laboratory access, existing Spanish supply and low-bandwidth media constraints. |
| Principles of Management | business and management | V/U | 341,159 | Test one V/U management pathway with locally meaningful cases, projects and an occupational or programme endpoint rather than assuming generic business-text usefulness. |
| Principles of Finance 2e | finance | V/U | 282,065 | Test practical and degree-level finance with Mexican legal/institutional adaptation, prerequisite numeracy and task-based outcomes; source translation alone is not sufficient. |
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | 667,392 | Test allied-health V/U pathways with local professional terminology, accessible diagrams and a matched qualification or programme. |
| Introduction to Python Programming | computing and data skills | S/V/U | 70,994 | Test S/V/U computing and data skills with runnable low-bandwidth exercises, offline tooling and a project, study or employment-linked endpoint. |

## Near-term matched tests - workflow order, not rank

- One exact INALI-variant P/F package with a verified census/school boundary, present material supply and literacy/numeracy endpoint.
- One Mexican Sign Language/written-Spanish or other exact signed-language mathematics/science package with signed video, semantic text and a common endpoint.
- One Spanish or bilingual S prerequisite package targeting a measured mathematics, reading or science bottleneck, preserving PISA's cohort limitation.
- One V practical package in finance, management, statistics, computing or health/safety, bound to a real task or qualification.
- One low-bandwidth/offline U gateway package and one named R bilingual/full advanced-source comparison.

## Decision boundary

No exact addressable audience, incremental effect, physical compute, currency cost, dominance relation or funding rank is assigned. Existing supply changes the additionality of a matched package; it never lowers a person's educational need. Missing evidence remains a research obligation, never a reason to exclude a language.
