# Nigeria cross-stage educational-access gate

**Evidence freeze:** 2026-09-05  
**Status:** high-consequence multilingual country context retained; no exact audience, effect, compute cost, dominance relation or funding rank has been assigned.

## What this gate establishes

Nigeria is not a language. The universal register retains 589 Nigeria-linked Glottolog language-level nodes: 571 non-bookkeeping nodes, 18 bookkeeping nodes and seven signed-language nodes. English-medium policy does not prove comfortable English access. Hausa, Hausa Sign Language, Yoruba, Yoruba Sign Language, Igbo, Nigerian Pidgin/Naijá, each Fulfulde or Kanuri variety and every other node remain separate investigation obligations.

The World Bank's latest total-population series reports 237,527,782 people in 2025. That is country context, never the audience for one language or package. Existing local project work has zero effect on this need assessment.

## Directly observed educational bottlenecks

- MICS reports foundational reading skills for 26.8% and foundational numeracy skills for 25.3% of children ages 7–14. The reading instrument was offered in English, Hausa, Igbo and Yoruba; 8% could not be evaluated in a home or school language. National and zonal results are not language-specific.
- NALABE reports minimum proficiency of 50% in P3 mathematics, 34% in P5 mathematics and 14% in JS2 mathematics. At JS2, mathematics reasoning averaged 35% correct and science/technology application 36%. These sampled-school results identify tasks to investigate, not translation effects.
- UNICEF reports 62% of children ages 3–4 not attending early childhood education and 55% not developmentally on track; 68% junior-secondary and 54% senior-secondary completion. These are national survey contexts, not exact-language audiences.
- Ethnicity-of-household-head tables are not language measurements. No Hausa, Igbo, Yoruba, Fulani, Kanuri, Ijaw, Tiv, Ibibio or Edo ethnicity row is converted into a beneficiary count.

## What is measured by stage, and what to compare

P = preschool/early childhood; F = foundational/primary; S = secondary; V = vocational/practical; U = university/tertiary; R = postgraduate/research.

| Stage | Non-additive context | Existing supply signal | Complete comparison | Bounded comparison |
|---|---|---|---|---|
| P — preschool / early childhood | children ages 3-4 not attending early childhood education: 62 percent; children ages 3-4 not developmentally on track: 55 percent | NERDC reports basic and special-needs curriculum development, but the gate has not established exact child/caregiver-language early-learning inventories, audio/picture routes, open rights, offline completeness or effect. | An exact child-and-caregiver-language oral-language, picture-story, early numeracy, pattern, play and learning-to-learn sequence with audio, print, appropriate signed forms and one-download phone delivery. | A named-language oral-language, number-concept and caregiver sidecar linked to an existing local programme, with an explicit uncovered-scope manifest. |
| F — foundational / primary | ages 7-14 with foundational reading skills: 26.8 percent; ages 7-14 with foundational numeracy skills: 25.3 percent; children not evaluated in home or school language: 8 percent; P3 minimum proficiency in mathematics: 50 percent; P3 minimum proficiency in English: 32 percent; P5 minimum proficiency in mathematics: 34 percent; primary completion rate, latest World Bank value: 70.164909362793 percent | NERDC names curricula in Hausa, Igbo, Yoruba, Efik, Fulfude, Izon, Edo and Tiv plus dictionaries and metalanguages. MICS and NALABE identify severe task bottlenecks, but neither produces exact-language effects or a complete current open-material inventory. | Exact-language reading, arithmetic, introductory science and study-skills sequences with explanations, exercises, worked answers, semantic mathematics, audio/print/signed alternatives and offline phone use. | Diagnostic and worked-feedback modules for decoding/reading, place value, operations, fractions, word problems and home-to-school-language transition, tied to an existing curriculum. |
| S — secondary | junior-secondary completion: 68 percent; senior-secondary completion: 54 percent; JS2 minimum proficiency in mathematics: 14 percent; JS2 mathematics reasoning mean percent-correct: 35 percent; JS2 science/technology application mean percent-correct: 36 percent | NERDC reports 42 mainstream and 34 trade/entrepreneurship senior-secondary subjects plus special-needs routes. NALABE identifies especially low JS2 mathematics proficiency and weak application/reasoning, but current exact-language, answer-complete and accessible supply is unmeasured. | A coherent exact-language algebra, geometry, statistics, physics, chemistry, biology and study/exam sequence with full exercises, worked solutions, experiments or simulations, and offline/accessibility formats. | Fractions-to-algebra, mathematical reasoning, graphs/data, scientific reading, laboratory reasoning and terminology bridges matched to a named curriculum/exam route. |
| V — vocational / practical | visible historical TVET statistical digests: 8 documents; visible current NBTE download rows: 7 items; senior-secondary trade/entrepreneurship curriculum subjects: 34 subjects | NERDC and NBTE expose trades, entrepreneurship, out-of-school-youth, curriculum and ODFeL routes. The gate has no exact-language inventory, current enrolment denominator, open-rights audit, completion evidence or job-task effect. | An exact-language applied-numeracy, bookkeeping, household and enterprise finance, agriculture, health, data/digital skills, measurement, technical safety and business-operations pathway tied to local qualifications and law. | A task-specific record, measurement, safety, finance, health, agriculture or digital-skills module with worked answers and a named job/qualification endpoint. |
| U — university / tertiary | annual-school-census reported learners: 39881798 learners; annual-school-census reporting rate: 55.7 percent; TERAS sponsored mobile data: up to 2 GB per month | TIS exposes admissions reporting by year, state, institution and course. TERAS reports online/blended learning, data, digital skills, repositories and subscriptions. Exact open textbooks, course sequences, language routes, answer completeness, accessibility and effect remain unmeasured. | A complete exact-language first-year-to-degree open sequence in mathematics, computing, physical/life science, health, accounting/finance, management and academic writing, with prerequisites, exercises/answers and offline/accessibility routes. | A prerequisite, terminology, scientific-writing, formula-reading, runnable-computing or course-navigation bridge into a named existing programme. |
| R — postgraduate / research | TERAS communication-skill levels: 3 levels; preserved Nigerian higher-education repository claim: largest collection provider claim | TERAS reports a federated thesis repository and EBSCO subscriptions, but the gate does not establish open access, off-network persistence, exact-language research material, advanced proof/reference coverage, accessible structure or source-search usability. | An exact-language graduate/research source chain in a named field, including prerequisites, proofs, terminology, source links, exercises or worked arguments, reproducible methods and semantic/offline/accessibility forms. | A proof, theorem-navigation, terminology, abstract/example, methods and citation bridge around an open source such as Open Logic or the Stacks Project. |

## Exact target and script obligations

| Target profile | Glottocode(s) | Script or mode | Why it remains separate |
|---|---|---|---|
| English-medium policy route | policy route; no identity asserted | Latn | Policy-level route; no country-linked Glottolog identity is asserted in this register. |
| Hausa — Boko/Latin route | haus1257 | Latn | Exact language node; Nigerian Boko conventions must be audited independently. |
| Hausa — Ajami/Arabic-script route | haus1257 | Arab, naskh, Kano/Maghribi | Exact language node; script and style route separate from Boko and from Niger forms. |
| Yoruba | yoru1245 | Latn | Exact Glottolog language node; source labels do not define every dialect or orthographic practice. |
| Igbo | nucl1417 | Latn | Exact Glottolog language node; no automatic flattening of lectal variation. |
| Nigerian Pidgin / possible Naijá route | nige1257 | Latn | Nigerian Pidgin is the linked node; the relationship between the generic register and the NLA Naijá standard remains a measured hypothesis. |
| Adamawa Fulfulde | adam1253 | Latn?, Arab/Ajami?, Adlm? | Exact NG-linked language node; each script marker is an investigation route, not inferred current use or mutual intelligibility. |
| Borgu Fulfulde | borg1235 | Latn?, Arab/Ajami?, Adlm? | Exact NG-linked language node; each script marker is an investigation route, not inferred current use or mutual intelligibility. |
| Central-Eastern Niger Fulfulde | cent2018 | Latn?, Arab/Ajami?, Adlm? | Exact NG-linked language node; each script marker is an investigation route, not inferred current use or mutual intelligibility. |
| Hausa States Fulfulde | nige1253 | Latn?, Arab/Ajami?, Adlm? | Exact NG-linked language node; each script marker is an investigation route, not inferred current use or mutual intelligibility. |
| Western Niger Fulfulde | west2454 | Latn?, Arab/Ajami?, Adlm? | Exact NG-linked language node; each script marker is an investigation route, not inferred current use or mutual intelligibility. |
| Central Kanuri | cent2050 | Latn?, Arab/Ajami? | Exact NG-linked language node; the unqualified policy/report label 'Kanuri' is not automatically coextensive. |
| Manga-Dagera Kanuri | mang1399 | Latn?, Arab/Ajami? | Exact NG-linked language node; the unqualified policy/report label 'Kanuri' is not automatically coextensive. |
| Tiv | tivv1240 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| Efik | efik1245 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| Izon | izon1238 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| Bini — possible candidate for source label Edo | bini1246 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| Ibibio | ibib1240 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| Nupe-Nupe-Tako | nupe1254 | Latn? | Exact NG-linked language node; script, community and source-label correspondence require target-specific confirmation. |
| American Sign Language | amer1248 | signed video?, visual diagrams?, caption/transcript parallel route? | Multinational registry linkage only; Nigerian community, variety and equivalence to any local signing system are not inferred. |
| Bura Sign Language | bura1295 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |
| Hausa Sign Language | haus1246 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |
| Ibokun Sign Language | ibok1234 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |
| Magajingari Sign Language | maga1273 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |
| Nigerian Sign Language | nige1240 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |
| Yoruba Sign Language | yoru1246 | signed video?, visual diagrams?, caption/transcript parallel route? | Distinct NG-linked signed-language node; no mutual intelligibility or equivalence to Nigerian Sign Language is inferred. |

Unqualified source labels remain unresolved. In particular, `Fulfude` is not assigned to one of five linked Fulfulde nodes or to Latin, Ajami or Adlam; `Kanuri` is not assigned to both Central and Manga-Dagera Kanuri; `Edo` is not automatically equated with Bini; and the relationship between generic Nigerian Pidgin and the NLA Naijá common-core standard remains a testable hypothesis.

## What appears most useful to test

- **P/F:** exact child/caregiver-language oral and print literacy, foundational numeracy and worked-feedback pathways, including audio, signed and one-download phone routes.
- **S:** fractions-to-algebra, mathematical reasoning, graphs/data, scientific reading and science-application bridges matched to a named curriculum, exam and language endpoint.
- **V:** applied numeracy, bookkeeping, household/small-enterprise finance, agriculture, public health, management/operations, digital skills and technical safety tied to a job or qualification task.
- **U:** complete first-year/degree routes or smaller prerequisite, terminology, scientific-writing, formula-reading and computing bridges, selected only after auditing actual course bytes and current supply.
- **R:** complete graduate source chains and bounded proof/search/terminology/methods layers around open sources. Mathematically structured text may reduce some prose burden, but the effect remains an empirical comparison, not a blanket multiplier.

## Delivery and accessibility

The latest World Bank series reports 41.21139908% internet use and 62.5% electricity access in 2024. UNICEF reports that students ages 5–24 lived in households with 91% phone, 39% internet and 10% computer access, while 41% lacked TV, internet or computer. These measures are not interchangeable: household access is not personal ownership, permission, smartphone capability, reliable power/data, storage, accessibility or educational use. Phone-readable, small-download, resumable offline, print, audio and exact signed-language routes must therefore be costed separately.

Seven signed-language nodes remain separate. NERDC's ISLTENS and special-needs curriculum activity does not prove that Nigerian Sign Language, Hausa Sign Language, Yoruba Sign Language, Bura, Ibokun, Magajingari or American Sign Language covers any other signing community. Captions, transcripts, semantic HTML/MathML, screen-reader navigation, audio, tactile/large print and signed video are complementary rather than interchangeable modes.

## Open-source comparison portfolio

| Source | Subject | Possible stages | Nigeria comparison hypothesis |
|---|---|---|---|
| Prealgebra 2e | mathematics | F/S/V/U | Compare a complete independent-study arithmetic/prealgebra route with narrow P5-to-JS2 diagnostic and worked-feedback units at F/S/V/U transitions. |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | Test secondary, vocational, university and public data-literacy routes with local datasets and offline calculation. |
| Biology 2e | life science | S/U | Test complete life-science study at S/U and bounded health/agriculture/environment modules at S/V. |
| Chemistry 2e | physical science | S/U | Compare S/U chemistry with low-equipment measurement, safety and applied V bridges. |
| College Physics 2e | physical science | S/V/U | Test algebra-based physics at S/V/U with simulations and low-equipment activities, especially reasoning/application bottlenecks. |
| Principles of Management | business and management | V/U | Compare a full V/U management course with bounded planning, operations, communication and team-decision units. |
| Principles of Finance 2e | finance | V/U | Compare a complete V/U finance course with household and small-enterprise records, budgeting, risk and decision units. |
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | Test allied-health foundations at V/U and clearly separated bounded health-literacy derivatives. |
| Introduction to Python Programming | computing and data skills | S/V/U | Test runnable offline computing/data routes at S/V/U and phone-compatible lower-hardware alternatives. |

The nine OpenStax entries are measured source-scale comparisons, not automatic recommendations and not evidence that equivalent Nigerian material is absent. For advanced education, forallx: Calgary, the Open Logic modular corpus and the Stacks Project are retained as open comparison baselines, not predetermined production choices.

## Current allocation result

Nigeria combines severe measured foundational and secondary task bottlenecks, a very large country context, English-medium policy, named Nigerian-language curriculum activity, substantial practical/tertiary platforms, major delivery constraints and 589 noncoextensive linked language nodes. The actionable unit is exact language/variety × script/mode × stage × subject × package × delivery route. No national statistic establishes which exact package dominates.

No package is ranked here. Exact addressable audiences, marginal educational effects, physical compute and delivery costs have not been measured on common endpoints. Every missing exact-language measurement remains a possible outranker; missing evidence cannot lower need.

## Source and audit basis

- Nineteen fixed transport requests: 15 successful and 4 HTTP-403 failures. The failed UNICEF routes retain exact public locators and do not claim local source bytes.
- Two preserved PDFs, 117 pages total; six page-level claim groups; six visually inspected renders; 95 source/render/structure checks, all passing.
- Ten official/local HTML surfaces cover NERDC, federal education dashboards, NBTE, TERAS, policy and Naijá orthography within their stated scopes.
- Four World Bank API indicators provide country context. The latest primary-completion value is from 2010 and is explicitly stale.
- All national, zonal, ethnic, administrative, platform, catalogue, programme and provider figures are non-additive and are not beneficiary or causal-effect estimates.
