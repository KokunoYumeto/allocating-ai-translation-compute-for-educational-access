# Worldwide reach and common-package allocation checkpoint

**Status:** ongoing research checkpoint. This restores the quantitative allocation chain; it is not the final package-specific allocation result.

## What is being answered

The research question remains: how should AI compute be distributed so that educational-material availability produces the greatest additional functional understanding for as many people as possible?

The answer needs more than one list. The first table estimates potential reach. The second asks how that reach changes when every target receives exactly the same one 100,000-source-token, text-only educational package translated and checked to the independent-context-plus-deterministic-qa-v2 target. Later target-specific tables must replace the held-equal assumptions with evidence about the actual stage, subject, baseline supply, learning effect, delivery conditions, accessibility work, reusable setup, and overlapping beneficiaries.

Profile IDs are never ranks. Ordinal positions appear only in columns explicitly named **Reach position** or **Common-package proxy position**.

## Result 1: potential reach under one common missing-data scenario

The point multiplier is 89.57%; the displayed sensitivity range is 70%–99%. Missing comparable academic-register evidence keeps the common scenario instead of deleting or lowering a target. Chinese in the Simplified-script profile is position 1. Indonesian is position 9 after retaining the direct 2022 BPS communicative-ability population as its point population. Russian is position 10; Ukrainian is position 62 in the pinned CLDR reach layer. Those are potential-reach positions, not judgments about people or final funding positions.

| Reach position | Exact edition profile | Population point | Plausibly helped point | Sensitivity range | Population basis |
|---:|---|---:|---:|---:|---|
| 1 | Simplified Standard Written Chinese profile | 1.286 billion | 1.152 billion | 900.2 million–1.273 billion | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 2 | Hindi, Devanagari-script profile | 580.3 million | 519.8 million | 406.2 million–574.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 3 | Spanish, Latin-script profile | 507.6 million | 454.7 million | 355.3 million–502.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 4 | Arabic, Arabic-script profile | 378.8 million | 339.3 million | 265.2 million–375.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 5 | French, Latin-script profile | 333.0 million | 298.2 million | 233.1 million–329.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 6 | Urdu, Arabic-script profile | 313.1 million | 280.4 million | 219.2 million–310.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 7 | Bangla, Bangla-script profile | 279.9 million | 250.7 million | 195.9 million–277.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 8 | Portuguese, Latin-script profile | 249.5 million | 223.5 million | 174.6 million–247.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 9 | Indonesian, Latin-script profile | 248.5 million | 222.6 million | 126.4 million–246.0 million | DIRECT_BPS_2022_INDONESIAN_COMMUNICATIVE_ABILITY_POINT_WITH_CLDR_CONTEXT |
| 10 | Russian, Cyrillic-script profile | 201.2 million | 180.2 million | 140.8 million–199.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 11 | Swahili, Latin-script profile | 194.1 million | 173.9 million | 135.9 million–192.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 12 | Punjabi, Shahmukhi/Perso-Arabic-script profile | 176.7 million | 158.2 million | 123.7 million–174.9 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 13 | German, Latin-script profile | 141.9 million | 127.1 million | 99.3 million–140.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 14 | Japanese, Japanese-script profile | 117.6 million | 105.3 million | 82.3 million–116.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 15 | Telugu, Telugu-script profile | 101.5 million | 90.9 million | 71.0 million–100.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 16 | Western Panjabi, Arabic-script profile | 101.0 million | 90.5 million | 70.7 million–100.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 17 | Marathi, Devanagari-script profile | 98.6 million | 88.4 million | 69.0 million–97.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 18 | Javanese, Latin-script profile | 96.1 million | 86.1 million | 67.3 million–95.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 19 | Vietnamese, Latin-script profile | 92.4 million | 82.7 million | 64.7 million–91.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 20 | Tamil, Tamil-script profile | 90.6 million | 81.2 million | 63.4 million–89.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 21 | Persian, Arabic-script profile | 89.2 million | 79.9 million | 62.4 million–88.3 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 22 | Wu Chinese, Simplified-script profile | 85.0 million | 76.1 million | 59.5 million–84.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 23 | Turkish, Latin-script profile | 82.4 million | 73.8 million | 57.7 million–81.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 24 | Korean, Korean-script profile | 79.3 million | 71.0 million | 55.5 million–78.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 25 | Cantonese, Simplified-script profile | 73.6 million | 66.0 million | 51.5 million–72.9 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 26 | Filipino, Latin-script profile | 73.2 million | 65.6 million | 51.2 million–72.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 27 | Egyptian Arabic, Arabic-script profile | 71.2 million | 63.8 million | 49.8 million–70.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 28 | Italian, Latin-script profile | 70.5 million | 63.1 million | 49.3 million–69.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 29 | Gujarati, Gujarati-script profile | 65.6 million | 58.8 million | 45.9 million–65.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 30 | Pashto, Arabic-script profile | 58.1 million | 52.0 million | 40.6 million–57.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 31 | Thai, Thai-script profile | 55.9 million | 50.1 million | 39.2 million–55.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 32 | Kannada, Kannada-script profile | 52.1 million | 46.7 million | 36.5 million–51.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 33 | Nigerian Pidgin, Latin-script profile | 49.7 million | 44.5 million | 34.8 million–49.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 34 | Malayalam, Malayalam-script profile | 45.9 million | 41.1 million | 32.1 million–45.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 35 | Odia, Odia-script profile | 45.1 million | 40.4 million | 31.6 million–44.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 36 | Levantine Arabic, Arabic-script profile | 43.7 million | 39.1 million | 30.6 million–43.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 37 | Punjabi, Gurmukhi-script profile | 42.9 million | 38.5 million | 30.1 million–42.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 38 | Hausa, Latin-script profile | 41.9 million | 37.5 million | 29.3 million–41.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 39 | Polish, Latin-script profile | 41.5 million | 37.2 million | 29.1 million–41.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 40 | Xiang Chinese, Simplified-script profile | 41.1 million | 36.8 million | 28.7 million–40.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 41 | Amharic, Ethiopic-script profile | 39.2 million | 35.1 million | 27.4 million–38.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 42 | Traditional Written Chinese profile | 39.1 million | 35.0 million | 27.4 million–38.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 43 | Algerian Arabic, Arabic-script profile | 39.0 million | 35.0 million | 27.3 million–38.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 44 | Oromo, Latin-script profile | 38.3 million | 34.3 million | 26.8 million–37.9 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 45 | Sindhi, Arabic-script profile | 37.9 million | 33.9 million | 26.5 million–37.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 46 | Burmese, Myanmar-script profile | 37.2 million | 33.3 million | 26.0 million–36.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 47 | Malay, Latin-script profile | 36.8 million | 33.0 million | 25.8 million–36.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 48 | Bhojpuri, Devanagari-script profile | 34.6 million | 31.0 million | 24.2 million–34.3 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 49 | Sundanese, Latin-script profile | 33.8 million | 30.3 million | 23.7 million–33.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 50 | Dutch, Latin-script profile | 32.9 million | 29.4 million | 23.0 million–32.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 51 | Hakka Chinese, Simplified-script profile | 32.6 million | 29.2 million | 22.8 million–32.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 52 | Moroccan Arabic, Arabic-script profile | 32.5 million | 29.1 million | 22.8 million–32.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 53 | Yoruba, Latin-script profile | 31.8 million | 28.5 million | 22.2 million–31.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 54 | Uzbek, Latin-script profile | 31.6 million | 28.3 million | 22.1 million–31.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 55 | Sudanese Arabic, Arabic-script profile | 30.8 million | 27.6 million | 21.5 million–30.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 56 | Igbo, Latin-script profile | 30.8 million | 27.6 million | 21.5 million–30.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 57 | Saraiki, Arabic-script profile | 30.3 million | 27.1 million | 21.2 million–30.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 58 | Cebuano, Latin-script profile | 28.4 million | 25.4 million | 19.9 million–28.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 59 | Awadhi, Devanagari-script profile | 27.5 million | 24.6 million | 19.2 million–27.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 60 | Min Nan Chinese, Simplified-script profile | 26.9 million | 24.1 million | 18.8 million–26.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 61 | Malagasy, Latin-script profile | 26.5 million | 23.7 million | 18.6 million–26.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 62 | Ukrainian, Cyrillic-script profile | 24.1 million | 21.6 million | 16.9 million–23.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 63 | Gan Chinese, Simplified-script profile | 24.1 million | 21.6 million | 16.9 million–23.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 64 | Bavarian, Latin-script profile | 22.8 million | 20.4 million | 16.0 million–22.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 65 | Azerbaijani, Arabic-script profile | 22.5 million | 20.2 million | 15.8 million–22.3 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 66 | Nepali, Devanagari-script profile | 21.7 million | 19.5 million | 15.2 million–21.5 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 67 | Maithili, Devanagari-script profile | 20.3 million | 18.2 million | 14.2 million–20.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 68 | Romanian, Latin-script profile | 20.0 million | 18.0 million | 14.0 million–19.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 69 | Nyanja, Latin-script profile | 18.9 million | 16.9 million | 13.2 million–18.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 70 | Somali, Latin-script profile | 18.6 million | 16.7 million | 13.0 million–18.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 71 | Assamese, Bangla-script profile | 18.3 million | 16.4 million | 12.8 million–18.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 72 | Madurese, Latin-script profile | 17.7 million | 15.9 million | 12.4 million–17.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 73 | Rangpuri, Bangla-script profile | 17.0 million | 15.2 million | 11.9 million–16.9 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 74 | Haryanvi, Devanagari-script profile | 16.9 million | 15.1 million | 11.8 million–16.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 75 | Magahi, Devanagari-script profile | 16.9 million | 15.1 million | 11.8 million–16.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 76 | Marwari, Devanagari-script profile | 16.9 million | 15.1 million | 11.8 million–16.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 77 | Northeastern Thai, Thai-script profile | 16.8 million | 15.0 million | 11.7 million–16.6 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 78 | Nigerian Fulfulde, Latin-script profile | 15.9 million | 14.2 million | 11.1 million–15.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 79 | Chhattisgarhi, Devanagari-script profile | 15.5 million | 13.9 million | 10.9 million–15.3 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 80 | Khmer, Khmer-script profile | 15.2 million | 13.6 million | 10.6 million–15.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 81 | Zulu, Latin-script profile | 15.0 million | 13.4 million | 10.5 million–14.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 82 | Sinhala, Sinhala-script profile | 14.9 million | 13.4 million | 10.5 million–14.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 83 | Deccan, Arabic-script profile | 14.0 million | 12.5 million | 9.8 million–13.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 84 | Shona, Latin-script profile | 13.9 million | 12.4 million | 9.7 million–13.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 85 | Akan, Latin-script profile | 13.5 million | 12.1 million | 9.4 million–13.4 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 86 | Min Nan Chinese, Traditional-script profile | 13.5 million | 12.1 million | 9.4 million–13.3 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 87 | Swedish, Latin-script profile | 13.3 million | 11.9 million | 9.3 million–13.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 88 | Czech, Latin-script profile | 13.2 million | 11.9 million | 9.3 million–13.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 89 | Wolof, Latin-script profile | 13.2 million | 11.8 million | 9.2 million–13.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 90 | Kazakh, Cyrillic-script profile | 13.0 million | 11.6 million | 9.1 million–12.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 91 | Hungarian, Latin-script profile | 12.3 million | 11.0 million | 8.6 million–12.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 92 | Greek, Greek-script profile | 12.2 million | 11.0 million | 8.6 million–12.1 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 93 | Low German, Latin-script profile | 12.0 million | 10.8 million | 8.4 million–11.9 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 94 | Kinyarwanda, Latin-script profile | 12.0 million | 10.7 million | 8.4 million–11.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 95 | Quechua, Latin-script profile | 11.9 million | 10.7 million | 8.4 million–11.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 96 | Iloko, Latin-script profile | 11.4 million | 10.2 million | 7.9 million–11.2 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 97 | Luba-Lulua, Latin-script profile | 11.1 million | 9.9 million | 7.8 million–11.0 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 98 | Tigrinya, Ethiopic-script profile | 10.9 million | 9.8 million | 7.7 million–10.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 99 | Xhosa, Latin-script profile | 10.9 million | 9.8 million | 7.6 million–10.8 million | CLDR48_RESOLVED_SCRIPT_PROFILE |
| 100 | Tunisian Arabic, Arabic-script profile | 10.8 million | 9.7 million | 7.6 million–10.7 million | CLDR48_RESOLVED_SCRIPT_PROFILE |

## Result 2: the same package divided by standardized token-event workload

This is the first quantitative compute-allocation bridge. It holds the package and nominal QA target fixed, uses a measured language/script workload where a defensible binding exists, and otherwise uses the identical language-blind envelope. Missing tokenization evidence therefore cannot remove a row. The displayed unit is potential readers per one million fresh-equivalent token events.

It is a conditional proxy, not the final efficiency result: it assumes equal incremental educational effect and equal delivery. Fresh-equivalent token events are not physical compute, time, energy, money, or quality.

| Common-package proxy position | Exact edition profile | Reach position | Point readers per 1m FECU | Sensitivity range | Workload profile |
|---:|---|---:|---:|---:|---|
| 1 | Simplified Standard Written Chinese profile | 1 | 858,078,700 | 285,579,704–1,815,176,552 | zho_Hans |
| 2 | Hindi, Devanagari-script profile | 2 | 347,929,450 | 121,588,218–714,941,435 | hin_Deva |
| 3 | Spanish, Latin-script profile | 3 | 330,708,224 | 112,523,621–685,505,384 | spa_Latn |
| 4 | Arabic, Arabic-script profile | 4 | 215,448,628 | 65,561,796–486,510,536 | common envelope |
| 5 | French, Latin-script profile | 5 | 213,167,471 | 72,947,385–445,370,541 | fra_Latn |
| 6 | Urdu, Arabic-script profile | 6 | 183,122,705 | 64,241,656–377,096,747 | urd_Arab |
| 7 | Portuguese, Latin-script profile | 8 | 167,824,727 | 56,781,781–352,028,512 | por_Latn |
| 8 | Indonesian, Latin-script profile | 9 | 165,773,561 | 40,669,148–346,830,957 | ind_Latn |
| 9 | Bangla, Bangla-script profile | 7 | 160,790,872 | 56,660,233–327,339,326 | ben_Beng |
| 10 | Russian, Cyrillic-script profile | 10 | 126,609,405 | 43,088,824–262,644,274 | rus_Cyrl |
| 11 | Swahili, Latin-script profile | 11 | 110,400,876 | 33,595,385–249,299,286 | common envelope |
| 12 | Punjabi, Shahmukhi/Perso-Arabic-script profile | 12 | 100,477,258 | 30,575,593–226,890,489 | common envelope |
| 13 | German, Latin-script profile | 13 | 92,656,399 | 31,610,086–191,930,951 | deu_Latn |
| 14 | Japanese, Japanese-script profile | 14 | 68,675,694 | 23,998,228–140,625,240 | jpn_Jpan |
| 15 | Javanese, Latin-script profile | 18 | 61,541,346 | 21,007,940–128,074,730 | jav_Latn |
| 16 | Western Panjabi, Arabic-script profile | 16 | 57,435,613 | 17,477,865–129,696,954 | common envelope |
| 17 | Vietnamese, Latin-script profile | 19 | 56,859,648 | 19,670,421–116,635,627 | vie_Latn |
| 18 | Marathi, Devanagari-script profile | 17 | 54,856,862 | 19,524,561–110,944,071 | mar_Deva |
| 19 | Telugu, Telugu-script profile | 15 | 54,715,793 | 19,426,504–110,731,661 | tel_Telu |
| 20 | Turkish, Latin-script profile | 23 | 51,706,068 | 17,708,902–107,688,320 | tur_Latn |
| 21 | Persian, Arabic-script profile | 21 | 50,739,748 | 15,440,289–114,576,836 | common envelope |
| 22 | Wu Chinese, Simplified-script profile | 22 | 48,324,693 | 14,705,379–109,123,332 | common envelope |
| 23 | Tamil, Tamil-script profile | 20 | 48,188,313 | 17,300,503–97,178,539 | tam_Taml |
| 24 | Korean, Korean-script profile | 24 | 45,091,943 | 13,721,641–101,823,369 | common envelope |
| 25 | Egyptian Arabic, Arabic-script profile | 27 | 45,042,843 | 15,378,427–93,722,097 | arz_Arab |
| 26 | Italian, Latin-script profile | 28 | 43,669,442 | 15,129,536–89,714,453 | ita_Latn |
| 27 | Cantonese, Simplified-script profile | 25 | 41,881,400 | 12,744,662–94,573,554 | common envelope |
| 28 | Filipino, Latin-script profile | 26 | 41,633,549 | 12,669,239–94,013,874 | common envelope |
| 29 | Gujarati, Gujarati-script profile | 29 | 36,827,395 | 13,036,851–75,249,249 | guj_Gujr |
| 30 | Pashto, Arabic-script profile | 30 | 33,024,855 | 10,049,583–74,574,342 | common envelope |
| 31 | Thai, Thai-script profile | 31 | 29,876,777 | 10,801,084–61,115,876 | tha_Thai |
| 32 | Nigerian Pidgin, Latin-script profile | 33 | 28,277,832 | 8,605,046–63,854,958 | common envelope |
| 33 | Levantine Arabic, Arabic-script profile | 36 | 28,193,586 | 9,626,392–58,924,982 | apc_Arab |
| 34 | Kannada, Kannada-script profile | 32 | 27,796,911 | 9,998,822–55,339,835 | kan_Knda |
| 35 | Odia, Odia-script profile | 35 | 25,647,402 | 7,804,597–57,915,110 | common envelope |
| 36 | Hausa, Latin-script profile | 38 | 25,283,771 | 8,743,942–52,009,619 | hau_Latn |
| 37 | Traditional Written Chinese profile | 42 | 24,624,002 | 8,388,300–51,327,781 | zho_Hant |
| 38 | Malayalam, Malayalam-script profile | 34 | 24,579,283 | 8,785,283–49,969,023 | mal_Mlym |
| 39 | Polish, Latin-script profile | 39 | 24,379,279 | 8,531,559–49,624,459 | pol_Latn |
| 40 | Xiang Chinese, Simplified-script profile | 40 | 23,356,935 | 7,107,600–52,742,943 | common envelope |
| 41 | Algerian Arabic, Arabic-script profile | 43 | 22,198,628 | 6,755,123–50,127,339 | common envelope |
| 42 | Dutch, Latin-script profile | 50 | 21,933,157 | 7,398,669–46,278,700 | nld_Latn |
| 43 | Oromo, Latin-script profile | 44 | 21,763,944 | 6,622,847–49,145,766 | common envelope |
| 44 | Sindhi, Arabic-script profile | 45 | 21,759,491 | 7,691,771–44,210,075 | snd_Arab |
| 45 | Sundanese, Latin-script profile | 49 | 21,521,599 | 7,400,475–44,167,883 | sun_Latn |
| 46 | Malay, Latin-script profile | 47 | 20,929,961 | 6,369,063–47,262,527 | common envelope |
| 47 | Moroccan Arabic, Arabic-script profile | 52 | 20,063,920 | 6,931,069–41,979,056 | ary_Arab |
| 48 | Bhojpuri, Devanagari-script profile | 48 | 19,552,816 | 6,875,905–39,921,220 | bho_Deva |
| 49 | Punjabi, Gurmukhi-script profile | 37 | 19,393,058 | 7,214,028–38,398,074 | pan_Guru |
| 50 | Hakka Chinese, Simplified-script profile | 51 | 18,524,465 | 5,637,062–41,830,611 | common envelope |
| 51 | Uzbek, Latin-script profile | 54 | 17,951,469 | 5,462,697–40,536,711 | common envelope |
| 52 | Igbo, Latin-script profile | 56 | 17,945,322 | 6,267,833–37,339,167 | ibo_Latn |
| 53 | Sudanese Arabic, Arabic-script profile | 55 | 17,509,842 | 5,328,308–39,539,461 | common envelope |
| 54 | Saraiki, Arabic-script profile | 57 | 17,224,673 | 5,241,530–38,895,512 | common envelope |
| 55 | Cebuano, Latin-script profile | 58 | 16,489,398 | 5,792,931–33,947,185 | ceb_Latn |
| 56 | Yoruba, Latin-script profile | 53 | 16,223,657 | 5,868,853–32,896,594 | yor_Latn |
| 57 | Awadhi, Devanagari-script profile | 59 | 15,804,968 | 5,490,259–32,657,733 | awa_Deva |
| 58 | Min Nan Chinese, Simplified-script profile | 60 | 15,302,819 | 4,656,703–34,555,721 | common envelope |
| 59 | Malagasy, Latin-script profile | 61 | 15,076,827 | 4,587,933–34,045,403 | common envelope |
| 60 | Burmese, Myanmar-script profile | 46 | 14,876,938 | 5,746,932–28,802,470 | mya_Mymr |
| 61 | Gan Chinese, Simplified-script profile | 63 | 13,691,997 | 4,166,524–30,918,277 | common envelope |
| 62 | Ukrainian, Cyrillic-script profile | 62 | 13,681,980 | 4,837,925–27,946,199 | ukr_Cyrl |
| 63 | Bavarian, Latin-script profile | 64 | 12,979,402 | 3,949,679–29,309,150 | common envelope |
| 64 | Azerbaijani, Arabic-script profile | 65 | 12,807,237 | 3,897,289–28,920,378 | common envelope |
| 65 | Nepali, Devanagari-script profile | 66 | 12,362,580 | 3,761,978–27,916,285 | common envelope |
| 66 | Romanian, Latin-script profile | 68 | 11,796,814 | 4,138,069–23,954,389 | ron_Latn |
| 67 | Maithili, Devanagari-script profile | 67 | 11,522,314 | 4,061,376–23,809,199 | mai_Deva |
| 68 | Nyanja, Latin-script profile | 69 | 11,166,916 | 3,896,672–23,170,985 | nya_Latn |
| 69 | Somali, Latin-script profile | 70 | 10,667,282 | 3,767,168–21,845,790 | som_Latn |
| 70 | Amharic, Ethiopic-script profile | 41 | 10,139,854 | 4,192,238–18,900,993 | amh_Ethi |
| 71 | Madurese, Latin-script profile | 72 | 10,089,205 | 3,070,181–22,782,713 | common envelope |
| 72 | Magahi, Devanagari-script profile | 75 | 9,701,929 | 3,419,911–19,663,746 | mag_Deva |
| 73 | Assamese, Bangla-script profile | 71 | 9,698,578 | 3,498,573–19,312,565 | asm_Beng |
| 74 | Rangpuri, Bangla-script profile | 73 | 9,683,187 | 2,946,629–21,865,874 | common envelope |
| 75 | Haryanvi, Devanagari-script profile | 74 | 9,617,776 | 2,926,724–21,718,166 | common envelope |
| 76 | Marwari, Devanagari-script profile | 76 | 9,617,776 | 2,926,724–21,718,166 | common envelope |
| 77 | Northeastern Thai, Thai-script profile | 77 | 9,544,676 | 2,904,479–21,553,099 | common envelope |
| 78 | Nigerian Fulfulde, Latin-script profile | 78 | 9,427,287 | 3,267,255–19,652,445 | fuv_Latn |
| 79 | Chhattisgarhi, Devanagari-script profile | 79 | 8,859,563 | 3,131,912–18,126,548 | hne_Deva |
| 80 | Swedish, Latin-script profile | 87 | 8,595,279 | 2,935,387–17,821,088 | swe_Latn |
| 81 | Zulu, Latin-script profile | 81 | 8,577,486 | 3,042,718–17,364,401 | zul_Latn |
| 82 | Shona, Latin-script profile | 84 | 8,007,978 | 2,807,045–16,325,172 | sna_Latn |
| 83 | Deccan, Arabic-script profile | 83 | 7,934,665 | 2,414,547–17,917,487 | common envelope |
| 84 | Czech, Latin-script profile | 88 | 7,876,222 | 2,754,709–16,143,409 | ces_Latn |
| 85 | Kazakh, Cyrillic-script profile | 90 | 7,743,142 | 2,709,332–16,243,517 | kaz_Cyrl |
| 86 | Min Nan Chinese, Traditional-script profile | 86 | 7,663,232 | 2,331,949–17,304,556 | common envelope |
| 87 | Wolof, Latin-script profile | 89 | 7,539,675 | 2,663,154–15,263,071 | wol_Latn |
| 88 | Akan, Latin-script profile | 85 | 6,968,724 | 2,450,267–14,448,773 | aka_Latn |
| 89 | Hungarian, Latin-script profile | 91 | 6,904,214 | 2,447,869–14,000,203 | hun_Latn |
| 90 | Kinyarwanda, Latin-script profile | 94 | 6,871,180 | 2,422,456–14,031,008 | kin_Latn |
| 91 | Low German, Latin-script profile | 93 | 6,853,344 | 2,085,497–15,475,727 | common envelope |
| 92 | Tunisian Arabic, Arabic-script profile | 100 | 6,825,498 | 2,309,719–14,301,733 | aeb_Arab |
| 93 | Quechua, Latin-script profile | 95 | 6,792,664 | 2,067,032–15,338,703 | common envelope |
| 94 | Sinhala, Sinhala-script profile | 82 | 6,631,827 | 2,501,608–12,873,484 | sin_Sinh |
| 95 | Xhosa, Latin-script profile | 99 | 6,406,871 | 2,245,955–13,115,068 | xho_Latn |
| 96 | Luba-Lulua, Latin-script profile | 97 | 6,389,488 | 2,206,449–13,217,364 | lua_Latn |
| 97 | Iloko, Latin-script profile | 96 | 6,276,195 | 2,239,045–12,720,226 | ilo_Latn |
| 98 | Afrikaans, Latin-script profile | 105 | 6,259,618 | 2,160,727–13,013,521 | afr_Latn |
| 99 | Greek, Greek-script profile | 92 | 6,236,033 | 2,268,502–12,345,370 | ell_Grek |
| 100 | Umbundu, Latin-script profile | 101 | 6,058,396 | 2,139,308–12,437,394 | umb_Latn |

## Why the two orders can differ

Potential reach is the numerator. The common-package proxy divides it by an estimated end-to-end token-event workload for the same package. Script and tokenizer representation can change the workload estimate, but no claim is made that token counts capture all production difficulty. In the final model, a target with smaller potential reach can lead when a specific package produces a larger additional functional effect, costs less to produce and deliver, or uniquely reaches people not served by another edition.

## What remains before a final allocation claim

For each intervention the model still needs a named educational endpoint, an independently usable baseline, a defensible incremental effect, exposure and delivery pathways, accessibility costs, measured physical compute, reusable-work accounting, and beneficiary overlap. The correct final object is portfolio-marginal additional functional access per standardized physical compute, with uncertainty and reversal thresholds, not the nonordinal profile catalogue or this common-package proxy alone.

English academic-to-non-academic register translation remains a coequal but analytically separate intervention because its production process and audience nonoverlap cannot be inferred from ordinary English fluency. Signed-language, accessibility-format, displaced-community, and evidence-supported interlanguage interventions likewise remain possible outrankers outside this spoken/written CLDR table.

## Source and nonadditivity cautions

CLDR 48 is an open locale-planning source. Its language-population estimates represent people fluent enough to use a computer or smartphone interface and include L1 and L2 users. Resolving likely scripts improves edition specificity but does not prove literacy in that script. Multilingual people, macrolanguages and constituent languages, and alternative scripts can overlap; these rows cannot be summed into a world total. The direct Indonesian population context measures communicative ability, not independent academic reading. All such distinctions are preserved in the machine-readable evidence.
