# Indigenous Americas, Pacific and circumpolar package checkpoint

This checkpoint applies one inclusion rule: all 61 exact Indigenous-Americas/Canadian rows in the validated Americas evidence table, all 17 Pacific rows in the validated Oceania table, and 16 named Alaska–Greenland–Sápmi–Russian-Arctic profiles remain visible. No population threshold selected them.

It creates **564 unranked package hypotheses** across 94 routed profiles and all six stages. It also retains **17 route-less obligations**. A route is a research/design hypothesis, not a claim that a population needs a package or that the package works.

## What the evidence says the packages may need

- **P/F:** oral language, early literacy/numeracy, pictures and audio; diagnostics, exercises and explained answers that can work without a continuously available teacher.
- **S:** complete STEM where warranted, compared against a smaller bilingual bridge into the actual examination language.
- **V:** applied numeracy, household/enterprise finance, health, climate, land/marine knowledge and digital skills, localized to real livelihoods and delivery constraints.
- **U:** prerequisites, teacher education, terminology and scientific writing, with existing tertiary provision treated as a comparator rather than presumed usable access.
- **R:** advanced open texts and smaller terminology/navigation/methods layers for postgraduate and research self-education.
- **Every stage:** low-data semantic HTML/EPUB or tagged PDF, print/offline packages, captions/transcripts and screen-reader/keyboard operation remain delivery variables rather than afterthoughts.

## Population and overlap discipline

Counts for conversation, home use, mother tongue, territorial ceilings, approximate speakers and school enrolment are retained in the evidence packet. They are not converted into unmet need or people helped. Quechua, Nahuatl, Maya, Guaraní, Cree, Ojibwe, Inuktut, Sámi and Pacific varieties remain separate. Tok Pisin, Solomon Islands Pijin and Bislama are not one language, and no contact language or proposed interlanguage covers other communities merely by name.

## Routed profiles

| Evidence group | Profiles | Routes |
|---|---:|---:|
| Indigenous Americas, Haiti and named Canadian strata | 61 | 366 |
| Pacific empirical strata | 17 | 102 |
| Alaska, Greenland, Sápmi and Russian Arctic | 16 | 96 |
| **Total** | **94** | **564** |

## High-consequence unresolved obligations

- **Central Nahuatl:** Exact variety and locality unresolved; fifteen exact INALI varieties are routed separately, so this macro planning profile receives no blanket route.
- **Papua New Guinea named tok ples:** More than 850 languages are contextual evidence; each language, orthography, school stage and community must be named before a route or population is assigned.
- **Solomon Islands local-language set:** Twenty-four census local-language categories identified by the audit remain to be resolved individually; Pijin is not their substitute.
- **Hiri Motu and Pure Motu:** Separate language identities and audiences; neither Tok Pisin nor one Motu profile covers the other.
- **Australian Aboriginal and Torres Strait Islander language universe:** The audit identifies 167 languages with at least one reported user; Kriol and Yumplatok do not cover the remaining exact languages.
- **Named Pacific signed languages:** Each signed language, territory, school stage and video/visual-notation route needs its own evidence; spoken bridge languages do not cover signed access.
- **Hawaiʻi Sign Language:** Independent Indigenous signed language; it must not be folded into ASL in Hawaiʻi.
- **Pacific diaspora language-access strata:** Home-country editions may be reusable, but diaspora school systems and bridge-language overlap require separate denominators.
- **Samoan by territory and diaspora:** Samoa, American Samoa, New Zealand, Australia and United States access strata must remain separate.
- **Tongan by territory and diaspora:** Tonga and diaspora bridge-language cohorts require separate source-bound profiles.
- **Gilbertese / Kiribati:** Exact national and diaspora profiles remain an evidence obligation; a territorial ceiling is not an audience count.
- **Tuvaluan:** Exact national and diaspora profiles remain an evidence obligation; bridge-language comfort is unmeasured.
- **Niuean:** Niue and diaspora cohorts require separate measures and cannot be replaced by a pan-Polynesian label.
- **Cook Islands Māori varieties:** Rarotongan, Atiu, Mauke, Mitiaro and other island varieties require explicit identity and overlap treatment.
- **Polynesian Outlier languages:** Each exact language and island community remains eligible; no pan-Polynesian comprehension is credited.
- **Remaining circumpolar languages:** The named Alaska/Greenland/Sámi/Russian-Arctic set is not exhaustive; other exact languages remain visible through the universal register and need regional binding.
- **Remaining Amazonian and Caribbean Indigenous languages:** This packet is not the whole Americas; unbound exact languages remain eligible through the universal register.

## What this does not prove

It does not prove exact-language comfortable-reader counts, unmet need, causal package effects, resource absence, academic-language non-overlap, best package size, compute cost, interlanguage comprehension or a global allocation order. Missing evidence preserves eligibility and an evidence-acquisition obligation; it does not become zero or low priority.
