# Displacement corridor language-and-education evidence - bounded pass v3

Checkpoint: 2026-09-04T21:50:36Z

## What this checkpoint changes

Four rows that previously had only host-system evidence now have at least one bounded origin-host education observation. That closes the narrow source-absence question; it does not supply a current language-by-stage denominator, a measured intervention effect for the current corridor, a standardized compute cost, or an allocation rank.

The register still contains 28 corridors. Explicit source gaps fall from 5 to 1: **UNK-USA is now the only source-gap row**, and it remains prohibited from receiving a language assignment. Every status count and every one of the other 24 rows is preserved exactly from v2.

Stage legend: P = preschool, F = foundational/primary, S = secondary, V = vocational/practical, U = university, R = postgraduate/research. These are applicability labels, not scores.

## Four bounded source additions

| Corridor | Evidence now bound | Stage boundary | What remains unresolved |
|---|---|---|---|
| SYR-DEU | A Hamburg administrative panel follows five public-school starting cohorts from 2011 through 2015 into grade 7.… | F/S direct historical; V/U host-system context | Current home-language and variety distribution, script, German academic proficiency, literacy, prior curric… |
| AFG-DEU | A Hamburg administrative panel follows five public-school starting cohorts from 2011 through 2015 into grade 7.… | F/S direct historical; V/U host-system context | Current home-language and variety distribution, script, German academic proficiency, literacy, prior curric… |
| SOM-ETH | The World Bank case study directly covers Aw-Barre and Sheder camps in Ethiopia's Somali region and reports Som… | F/S direct case study; P/V/U host-system context | Current corridor distribution by exact Somali variety, Maay, minority Bantu or other language, script, lite… |
| VEN-USA | HISD's 2020-2021 administrative report records 306 Venezuela-origin students among 11,834 immigrant students. I… | F/S district context; origin not cross-tabbed by stage | Current national or corridor-wide home-language and exact-variety distribution, English proficiency, prior… |

## Interpretation

The new evidence supports more specific intervention comparisons without turning origin into language:

1. **Syria-Germany and Afghanistan-Germany.** The Hamburg study distinguishes a year-long, language-heavy separate preparatory model from immediate standard-curriculum access with added language support. The evidence argues against assuming that a separate German-first replacement is the default. It supports comparing a complete continuity sequence with a bounded, integrated academic-language and curriculum companion. The historical Hamburg sample is not a current national denominator, and the source contains no home-language cross-tab.
2. **Somalia-Ethiopia.** The Somali-region case study directly identifies a grades 1-4 Somali-medium to grades 5-12 English-medium transition, textbook shortages, English-comprehension problems, curriculum discontinuity, and limited study conditions. The resulting bounded alternative is a mother-tongue-to-English subject and prerequisite bridge with offline exercises and feedback. Exact Somali variety, minority-language, sign-language, and current-stage distributions remain unmeasured.
3. **Venezuela-United States.** The Houston district source proves that a bounded Venezuela-origin school cohort was present and identifies district transition mechanisms. Its country and language columns are separate aggregates: 306 Venezuela-origin pupils cannot be assigned the district's 88% English Learner or 76% Spanish rates. The immediate research action is a country-by-home-language-by-stage cross-tab, not an automatic Spanish edition.
4. **Unknown origin in the United States.** UNK-USA remains qualitatively different. It supplies no origin identity and therefore receives only an evidence-resolution action, never a language-production assignment.

## Changed corridor records

### SYR-DEU: Syrian Arab Rep. -> Germany

- **Evidence class:** direct_historical_hamburg_origin_host_administrative_school_intervention_language_identity_unresolved
- **Scope:** direct_hamburg_public_school_cohorts_2011_12_to_2015_16_F_S_plus_germany_host_context_F_S_V_U_not_current_national_corridor
- **Observed stages:** F/S/V/U (F/S direct historical; V/U host-system context)
- **Bounded evidence:** A Hamburg administrative panel follows five public-school starting cohorts from 2011 through 2015 into grade 7. Refugee status is a country-of-birth plus immigration-timing proxy because residence status was unavailable. Among 1,505 pupils with origin data, 44% were born in Syria and 34% in Afghanistan. The source supplies direct historical Syria-Germany F/S evidence; the existing BAMF sources remain host-system context for V/U. None supplies a current corridor-by-language-by-stage denominator.
- **Curriculum finding:** The separate preparatory model devoted 18 of 26 weekly hours to German before regular-class integration after about a year; direct integration used the standard curriculum plus added language support. Average fifth-grade results were lower after the separate model, especially in mathematics and German. This bounded comparison does not show that language support is generally harmful, does not prove an origin-specific effect, and does not generalize to current Germany.
- **Comparison to run:** Compare a complete curriculum-continuity sequence with a bounded integrated German academic-language, curriculum, prerequisite, transcript/credential, and transition companion; do not default to a year-long language-heavy separate replacement. Derive Syrian Arabic, Kurdish, Armenian, sign-language, low-literacy, and other arms from measured language and script evidence rather than origin.
- **Still unknown:** Current home-language and variety distribution, script, German academic proficiency, literacy, prior curriculum, stage, legal status, location, disability/accessibility, baseline usable supply, package effect, and standardized compute cost remain unresolved.
- **Current status-row context only:** 734,158 observations; not a language denominator, benefit estimate, or rank.

### AFG-DEU: Afghanistan -> Germany

- **Evidence class:** direct_historical_hamburg_origin_host_administrative_school_intervention_language_identity_unresolved
- **Scope:** direct_hamburg_public_school_cohorts_2011_12_to_2015_16_F_S_plus_germany_host_context_F_S_V_U_not_current_national_corridor
- **Observed stages:** F/S/V/U (F/S direct historical; V/U host-system context)
- **Bounded evidence:** A Hamburg administrative panel follows five public-school starting cohorts from 2011 through 2015 into grade 7. Refugee status is a country-of-birth plus immigration-timing proxy because residence status was unavailable. Among 1,505 pupils with origin data, 34% were born in Afghanistan and 44% in Syria. The source supplies direct historical Afghanistan-Germany F/S evidence; the existing BAMF sources remain host-system context for V/U. None supplies a current corridor-by-language-by-stage denominator.
- **Curriculum finding:** The separate preparatory model devoted 18 of 26 weekly hours to German before regular-class integration after about a year; direct integration used the standard curriculum plus added language support. Average fifth-grade results were lower after the separate model, especially in mathematics and German. No significant country-of-origin heterogeneity was detected, but that does not prove identical Afghan and Syrian effects or generalize to current Germany.
- **Comparison to run:** Compare a complete curriculum-continuity sequence with a bounded integrated German academic-language, curriculum, prerequisite, transcript/credential, and transition companion; do not default to a year-long language-heavy separate replacement. Derive Dari, Pashto, Hazaragi, Uzbek, sign-language, low-literacy, and other arms from measured language and script evidence rather than origin.
- **Still unknown:** Current home-language and variety distribution, script, German academic proficiency, literacy, prior curriculum, stage, legal status, location, gender, disability/accessibility, baseline usable supply, package effect, and standardized compute cost remain unresolved.
- **Current status-row context only:** 331,536 observations; not a language denominator, benefit estimate, or rank.

### SOM-ETH: Somalia -> Ethiopia

- **Evidence class:** direct_2019_somali_region_refugee_school_case_study_language_curriculum_transition
- **Scope:** direct_aw_barre_sheder_somali_region_case_study_F_S_not_current_corridor_prevalence_plus_host_context_P_V_U
- **Observed stages:** P/F/S/V/U (F/S direct case study; P/V/U host-system context)
- **Bounded evidence:** The World Bank case study directly covers Aw-Barre and Sheder camps in Ethiopia's Somali region and reports Somalia-origin context, shared Somali-region language at an unspecified variety level, lower-primary Somali medium, and an upper-primary/secondary transition to English. Books and supplies were the most common reported barrier; language and culture were second, with English-comprehension problems concentrated mostly in Somali region. Direct evidence applies to F/S; P/V/U remain host-system context. This is not current corridor prevalence.
- **Curriculum finding:** The observed configuration is a curriculum-and-medium transition, not simply an absent translation: Somali in grades 1-4, English in grades 5-8 and secondary, severe textbook constraints, curriculum discontinuity, large classes, and limited home study conditions. The study's shared-language description does not identify exact Somali varieties or every learner's language and literacy.
- **Comparison to run:** Compare a complete offline Somali-English curriculum sequence with a bounded mother-tongue-to-English subject bridge containing prerequisite diagnosis, catch-up, worked examples, exercises with feedback, exam navigation, and low-power/offline delivery. Keep Somali varieties, Maay, minority Bantu and other languages, Ethiopian and Somali sign languages, and script/literacy profiles as separately measured arms.
- **Still unknown:** Current corridor distribution by exact Somali variety, Maay, minority Bantu or other language, script, literacy, location, school medium, stage, gender, disability/accessibility, baseline usable supply, package effect, and standardized compute cost remains unresolved.
- **Current status-row context only:** 361,872 observations; not a language denominator, benefit estimate, or rank.

### VEN-USA: Venezuela (Bolivarian Republic of) -> United States of America

- **Evidence class:** direct_hisd_2020_21_origin_count_plus_aggregate_immigrant_language_and_outcome_evidence
- **Scope:** direct_HISD_2020_21_Venezuela_origin_count_with_districtwide_not_country_cross_tabbed_F_S_context_not_US_national_corridor
- **Observed stages:** F/S (F/S district context; origin not cross-tabbed by stage)
- **Bounded evidence:** HISD's 2020-2021 administrative report records 306 Venezuela-origin students among 11,834 immigrant students. Its 88% English Learner and 76% Spanish home-language values apply to all immigrant students and are not cross-tabbed to the Venezuelan subset. District-wide evidence identifies elementary bilingual/ESL services, secondary English-language-arts courses, content-area ESL methods, and secondary transition concerns. It does not provide a current national Venezuela-USA language-stage denominator or Venezuela-specific outcome.
- **Curriculum finding:** The district evidence establishes that a Venezuela-origin learner stratum exists and identifies concrete F/S transition mechanisms, but it does not establish that those 306 pupils were Spanish-speaking or share one prior curriculum. Aggregate district outcomes cannot be used as Venezuela-specific effects.
- **Comparison to run:** Use the origin count only to justify direct measurement. Compare a complete measured-language curriculum sequence with a bounded English-transition, prerequisite diagnosis, course-placement, credit/graduation, school-navigation, and offline-access companion. A Spanish-English arm is conditional on a country-by-home-language-by-stage cross-tab; preserve Indigenous, signed, and other language arms separately.
- **Still unknown:** Current national or corridor-wide home-language and exact-variety distribution, English proficiency, prior curriculum, credit, grade/stage, disability/accessibility, location, baseline usable supply, package effect, and standardized compute cost remain unresolved.
- **Current status-row context only:** 435,298 observations; not a language denominator, benefit estimate, or rank.

## Source snapshots

The exact cached bytes below make the source reading reproducible. The source publications remain governed by their own terms; caching them for analysis does not make them release payloads.

### [Starting off on the Right Foot—Language Learning Classes and the Educational Success of Refugee Children](https://academic.oup.com/ej/article/136/676/1217/8249266)

- **Source identity:** The Economic Journal / Oxford University Press; 2025-09-08; peer-reviewed administrative-panel intervention study.
- **Cached snapshot:** [sources/displacement_corridor_v3_20260904/Schilling_Hoeckel_Starting_off_on_the_Right_Foot_2025.html](sources/displacement_corridor_v3_20260904/Schilling_Hoeckel_Starting_off_on_the_Right_Foot_2025.html); 573,317 bytes; SHA-256 068EDA5538B6A51DE0449A39CC86C50CEA20B0F48C9E521BB704A2445F472E4F.
- **Inspection:** Official full-text HTML inspected locally and against the public article page on 2026-09-04.
- **Verified findings:**
  - The administrative panel covers five Hamburg public-school starting cohorts from 2011 through 2015 and follows children from primary school through grade 7.
  - Preparatory classes devoted 18 of 26 weekly instructional hours to German, plus four to mathematics and two to science, before regular-class integration after about one year; directly integrated pupils received added language support in regular classes.
  - The full sample has 1,509 pupils; country-of-origin data are present for 1,505, of whom 44% were born in Syria and 34% in Afghanistan.
  - Because residence status was unavailable, the study operationalized refugee status from country of birth and immigration timing; it is not a legal-status register.
  - Average fifth-grade standardized results were lower after the separate preparatory-class model, particularly in mathematics and German; the paper reports no statistically significant outcome heterogeneity by country of origin.
- **Scope limits:**
  - Historical Hamburg cohorts, not a current Germany-wide Syria-Germany or Afghanistan-Germany corridor estimate.
  - Country of birth is not home language, script, literacy, nationality, ethnicity, or legal refugee status.
  - The study does not publish an origin-by-home-language or origin-by-current-stage distribution.
  - The treatment comparison concerns one separate preparatory-class design; it does not show that language support generally is harmful or that every integrated model is effective.
  - The absence of significant country-of-origin heterogeneity does not establish identical effects for Syrian and Afghan learners.

### [Education for Resilience: Exploring the Experience of Refugee Students in Three Communities in Ethiopia](https://documents.worldbank.org/curated/en/988591562865883889/pdf/Education-for-Resilience-Exploring-the-experience-of-refugee-students-in-three-communities-in-Ethiopia.pdf)

- **Source identity:** World Bank; 2019-06-22; official qualitative case study with focus groups, interviews, school observations, and administrative context.
- **Cached snapshot:** [sources/displacement_corridor_v3_20260904/World_Bank_Education_for_Resilience_Ethiopia_2019.pdf](sources/displacement_corridor_v3_20260904/World_Bank_Education_for_Resilience_Ethiopia_2019.pdf); 1,778,458 bytes; SHA-256 3EF794AB9B3EE1080C83BB0300337249BE682368AB5F173648BBB9A7483536F5.
- **Inspection:** Official PDF text and rendered pages inspected locally on 2026-09-04.
- **Verified findings:**
  - The Somali-region cases are Aw-Barre and Sheder camps in the Jigjiga area; the report describes Somali-region refugee and host communities as sharing many clans and the same language, without identifying exact varieties.
  - The report states that many refugees in the Jigjiga camps came from Al-Shabaab-controlled areas of Somalia and had been unable to pursue education.
  - The school-language table records Somali in grades 1-4 and English in grades 5-8 and secondary for refugee and host-community schools in Somali region.
  - Books and supplies were the most common reported learning barrier; observers recorded textbook problems in 83% of observed classrooms, including sharing and near-absence patterns.
  - Language and culture were the second most common reported barrier. English-comprehension problems were reported mostly in Somali region; observed primary lessons used the regional mother tongue, while 60% of observed secondary lessons used only English and 40% mixed English with a mother tongue.
  - The report recommends catch-up provision and further attention to curriculum and language transitions rather than treating one language edition as the entire intervention.
- **Scope limits:**
  - A deliberately selected 2019 case study, not a representative current Somalia-Ethiopia corridor prevalence survey.
  - The report does not provide a current corridor-by-language-by-stage denominator or exact Somali-variety distribution.
  - The 83% textbook observation applies to the study's observed classrooms, not automatically to every Somali-region or Ethiopia refugee classroom.
  - The shared-language statement does not erase Maay, minority Bantu, other spoken languages, Ethiopian or Somali sign languages, scripts, or individual literacy differences.
  - The source supports foundational and secondary transition mechanisms directly; preschool, vocational, and university observations remain host-system context in the prior register.

### [Immigrant Student Program Evaluation Report 2020-2021](https://files.eric.ed.gov/fulltext/ED617769.pdf)

- **Source identity:** Houston Independent School District, Department of Research and Accountability; 2022-01-10; official district program evaluation using PowerSchool and assessment records.
- **Cached snapshot:** [sources/displacement_corridor_v3_20260904/HISD_Immigrant_Student_Program_Evaluation_2020_2021.pdf](sources/displacement_corridor_v3_20260904/HISD_Immigrant_Student_Program_Evaluation_2020_2021.pdf); 2,310,130 bytes; SHA-256 A85E5765313D3ACF7BD80A2290BD85082B543C59DA38C48BD72068CA98DB07D0.
- **Inspection:** Official ERIC-hosted PDF text and rendered pages inspected locally on 2026-09-04.
- **Verified findings:**
  - HISD enrolled 11,834 immigrant students during 2020-2021, including 306 whose home country was Venezuela.
  - Across all 11,834 immigrant students, 88% were English Learners and 76% had Spanish recorded as home language; Table 2 presents home-country and home-language columns as separate aggregate distributions.
  - The report does not publish a Venezuela-by-home-language, Venezuela-by-grade, or Venezuela-by-outcome cross-tab.
  - The district used immigrant-specific English language arts and reading courses in middle and high school, ESL methods in other content areas, and bilingual or ESL services at elementary level.
  - Across immigrants as a whole, the report identifies lower assessment performance and secondary transition/post-secondary-readiness concerns, not Venezuela-specific effect estimates.
- **Scope limits:**
  - One school district and one academic year, not a current United States-wide Venezuela-origin displaced-population estimate.
  - The 306 count is cumulative district enrollment and is not the UNHCR corridor count, a language denominator, or a benefit estimate.
  - The 88% English Learner and 76% Spanish values cannot be assigned to the 306 Venezuela-origin students.
  - Home country does not determine home language, exact Spanish variety, Indigenous language, sign language, disability, literacy, or prior curriculum.
  - District-wide outcome patterns identify mechanisms to measure; they are not Venezuela-specific causal effects.

## Invariants and next measurements

- Every population/status cell is unchanged from v2.
- Language distribution remains unmeasured for all four revised corridors.
- Allocation rank remains blank for every corridor.
- Complete and bounded packages remain conditional alternatives, not additive beneficiary claims.
- The next discriminating measurements are current home-language and script distributions by educational stage, baseline usable supply for the exact task and delivery mode, matched intervention effects, and standardized production/maintenance cost.

Machine-readable register: [structured/DISPLACEMENT_CORRIDOR_LANGUAGE_EDUCATION_EVIDENCE_v3.csv](structured/DISPLACEMENT_CORRIDOR_LANGUAGE_EDUCATION_EVIDENCE_v3.csv)

This is a bounded research checkpoint. It does not establish complete global corridor coverage or a funding order.
