# Hybrid population-plausibly-helped reference, version 1

**Status:** working comparison; not a moral priority list, funding rank, or final global order.

## What this measures

For a source-faithful educational edition in language or register family *i*, the working access-potential population is `A_i = P_i x q_i`. `P_i` is the source's current total-usage population (first- plus additional-language users). `q_i` is the share unable to use the academic-English register required by the source material independently and comfortably enough for the specified task.

The table is hybrid. Target-comparable research is retained. Where the matching population/threshold/stage/material cell is absent, the target receives the same disclosed imputation instead of disappearing. Existing evidence that concerns a different cohort or threshold remains visible in the final column; it is not discarded and it is not misused as a whole-population rate.

## The common imputation

The point seed is **89.57%**. It is the population-weighted share who did not report English across 17 India Census 2011 C-17 mother-tongue rows: 1,044,314,726 of 1,165,872,176 people. The unweighted row mean is 89.00%; the median is 89.90%. This is reported-language use, **not academic-English proficiency**, and India is not a global sample. It is therefore only a transparent missing-cell seed. The published range, **70% to 99%**, is a declared sensitivity interval rather than a confidence interval.

A later whole-community estimate replaces this imputation only if it measures the same academic-register task. National school tests, ordinary English use, oral ability and medium of instruction remain relevant research, but they are not silently promoted into that role.

## Current high-reach reference

The common multiplier means this displayed order follows the population source. It says how many people *could plausibly* be helped under the same missing-data assumption; it does not say whose rights, need, or education matter more.

| Display order | Language / source label | Current total usage | Sensitivity range plausibly helped | Point reference | Existing research retained |
|---:|---|---:|---:|---:|---|
| 1 | Mandarin Chinese | 1.2B | 840.0 million to 1.188 billion | 1.075 billion | spoken_standard_only; written and academic-English reach remain distinct |
| 2 | Hindi | 611.2M | 427.8 million to 605.1 million | 547.5 million | reported English-use and school context; no comparable academic-English population rate |
| 3 | Spanish | 561.3M | 392.9 million to 555.7 million | 502.8 million | no comparable cross-territory academic-English population rate |
| 4 | Standard Arabic | 334.9M | 234.4 million to 331.6 million | 300.0 million | macro written register; vernacular and territory evidence must remain separate |
| 5 | French | 333.5M | 233.4 million to 330.2 million | 298.7 million | country/stage evidence exists; no comparable global academic-English population rate |
| 6 | Bengali | 274.4M | 192.1 million to 271.7 million | 245.8 million | school cohorts and reported English-use evidence exist; not a comparable global rate |
| 7 | Portuguese | 269.4M | 188.6 million to 266.7 million | 241.3 million | territorial evidence exists; no comparable global academic-English population rate |
| 8 | Indonesian | 254.8M | 178.4 million to 252.3 million | 228.2 million | direct oral Indonesian reach and extensive stage evidence; academic-English population rate unmeasured |
| 9 | Urdu | 246.0M | 172.2 million to 243.5 million | 220.4 million | foundational and reported-language evidence; no comparable academic-English population rate |
| 10 | Russian | 210.3M | 147.2 million to 208.2 million | 188.4 million | target-specific stage evidence exists; academic-English population rate unmeasured |
| 11 | Standard German | 133.4M | 93.4 million to 132.1 million | 119.5 million | substantial supply evidence is package context, not a comparable reach rate |
| 12 | Japanese | 125.7M | 88.0 million to 124.4 million | 112.6 million | national school English thresholds and cross-stage evidence; not a whole-community academic-English rate |
| 13 | Nigerian Pidgin | 120.7M | 84.5 million to 119.5 million | 108.1 million | distinct from Standard English and from Nigeria's exact language communities |
| 14 | Egyptian Arabic | 118.4M | 82.9 million to 117.2 million | 106.1 million | territorial and diglossic profile; academic-English population rate unmeasured |
| 15 | Marathi | 99.2M | 69.4 million to 98.2 million | 88.9 million | reported English-use and tertiary-transition evidence; not a comparable academic-English rate |
| 16 | Vietnamese | 97.1M | 68.0 million to 96.1 million | 87.0 million | target-specific evidence retained; academic-English population rate unmeasured |
| 17 | Telugu | 95.9M | 67.1 million to 94.9 million | 85.9 million | reported English-use and tertiary-transition evidence; not a comparable academic-English rate |
| 18 | Swahili | 95.2M | 66.6 million to 94.2 million | 85.3 million | cross-territory bridge evidence; no comparable academic-English population rate |
| 19 | Hausa | 94.5M | 66.2 million to 93.6 million | 84.6 million | cross-stage and script evidence retained; no comparable academic-English population rate |
| 20 | Ukrainian | 30.8M | 21.6 million to 30.5 million | 27.6 million | paired cross-stage evidence retained; academic-English population rate unmeasured |

The top ten non-English source labels under this common reference are Mandarin Chinese, Hindi, Spanish, Standard Arabic, French, Bengali, Portuguese, Indonesian, Urdu and Russian. Simplified Standard Written Chinese is the first production profile for the Mandarin row, but spoken Mandarin, simplified writing, traditional writing and other Sinitic varieties are not interchangeable. Indonesian is eighth, at about **228.2 million** under the point seed. Ukrainian is explicitly retained with source rank 58 and a working range of **21.6 million to 30.5 million**; it is not removed because its comparable academic-English cell is missing.

## English is not the exception

The English total-usage population is 1.5 billion, but ordinary English use does not establish access to academic English. The current expression is therefore **1.5 billion x q_EN-register**, with `q_EN-register` still unmeasured globally. The target is a family of source-faithful adult register translations, not one universal Plain English. It remains eligible under the governing nonzero-benefit thesis while World Englishes, lingua-franca uses, discipline, educational stage and audience register are researched separately.

## Anti-hegemony constraints

- Wealth, prior schooling, measured attainment, prior local publication, data abundance and official-language prestige do not reduce the access-potential population.
- Familiarity with academic language is treated as unequally distributed linguistic capital, never as evidence of innate capability.
- A colonial, state, regional or geopolitical lingua franca supplies no automatic coverage credit. Credit requires the same technical task, actual material, accessible delivery and social and political acceptability.
- A standard language does not erase local varieties, signing communities, displaced populations or nonstandard adult registers.
- Scarcity, package effect, delivery, standardized production cost and interlanguage sharing are reported in separate layers. They can guide implementation but cannot make an unmeasured community disappear.

## Source limits

Ethnologue's public 2026 list reports rounded total usage (L1 plus L2) for individual languages. It does not by itself identify literacy, script, educational stage, independent academic reading, unmet need or the effect of a translated package. The explicit edition profiles are research decompositions, not claims that one edition serves every person in a source row. The full universal inclusion register remains the protection against treating this short high-reach display as the universe.
