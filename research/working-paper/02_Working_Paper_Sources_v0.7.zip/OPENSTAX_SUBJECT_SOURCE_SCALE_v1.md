# Cross-subject OpenStax source-scale checkpoint

**Status:** measured source portfolio, not an allocation ranking or an educational-effect estimate.  
**Evidence freeze:** 5 September 2026.  
**Coverage:** nine complete source collections spanning mathematics, statistics, life science, physical science, computing, management, finance, and allied-health foundations.

## What this resolves

The earlier cost illustration used one mathematics source. This checkpoint measures **1,444 CNXML modules and 4,463,123 cl100k content-text tokens** across nine complete collections. That makes clear that source size varies materially by subject, but it does not turn book length into educational value. Audience size, language fit, baseline supply, educational effect, physical compute, money, and global priority remain null.

| Source | Subject | Stage tags | Modules | cl100k content tokens | Bounded subset | Subset/full |
|---|---|---|---|---|---|---|
| Prealgebra 2e | mathematics | F/S/V/U | 75 | 364,270 | prior six-chapter quantitative-units scenario (173,958) | 47.76% |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | 102 | 396,969 | sampling and descriptive-statistics entry package (73,667) | 18.56% |
| Biology 2e | life science | S/U | 259 | 763,621 | first publisher-named biology unit (43,607) | 5.71% |
| Chemistry 2e | physical science | S/U | 149 | 625,793 | general-chemistry foundations sequence (111,308) | 17.79% |
| College Physics 2e | physical science | S/V/U | 283 | 950,860 | mechanics foundations sequence (214,815) | 22.59% |
| Principles of Management | business and management | V/U | 132 | 341,159 | managerial decisions, strategy, people, communication, and control toolkit (161,509) | 47.34% |
| Principles of Finance 2e | finance | V/U | 131 | 282,065 | publisher-recommended core finance chapters (194,805) | 69.06% |
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | 198 | 667,392 | publisher Unit 1: levels of organization (78,007) | 11.69% |
| Introduction to Python Programming | computing and data skills | S/V/U | 115 | 70,994 | programming foundations through functions (30,771) | 43.34% |

The stage tags are applicability labels, not scores: **P** preschool/early childhood, **F** foundational/primary, **S** secondary, **V** vocational/practical, **U** university, and **R** postgraduate/research. The source's original course stage and each adaptation hypothesis are kept separately in the machine-readable record.

## How to read the subset ratios

Each bounded subset is a reproducible source-selection scenario. Some use a publisher-named unit or publisher-recommended core; others are explicitly analyst-bounded chapter sequences. A 30% source ratio means only that the selected CNXML content has about 30% of the complete collection's measured token volume. It does **not** mean 30% of the learning, benefit, labor, compute, or cost.

For a same-community, same-endpoint comparison with equal variable traffic per source token and no unequal extra work, the smaller package needs a positive-yield ratio greater than its cost ratio to dominate. The structured output also reports scenarios in which common setup equals 10% or 100% of the complete package's variable source-token cost. Media, figures, interactivity, code execution, formula review, localization, accessibility, and delivery can invalidate the simple ratio and therefore remain explicit unmeasured work.

## Subject distinctions that matter before allocation

- **Prealgebra and statistics:** answer access, feedback, worked examples, notation, and prerequisite diagnosis can matter as much as prose translation.
- **Biology, chemistry, physics, and anatomy:** figures, equations, laboratory or safety context, terminology, and local curricular sequence add work not represented by extracted text.
- **Python:** the integrated code runner, executable examples, videos, and device constraints are outside the CNXML text count.
- **Management:** the bounded toolkit is an analyst scenario, not a universal claim about which managerial knowledge a community needs.
- **Finance:** the measured book is undergraduate corporate finance, not personal financial literacy. It must not be substituted for household or small-enterprise needs without separate evidence.
- **Health:** Anatomy and Physiology is an allied-health foundation, not public-health guidance, clinical training, or medical advice.

## Reproducibility and rights boundary

| Source | Commit | CNXML archive | Official scope page |
|---|---|---|---|
| Prealgebra 2e | `38cae454e644abf9f0a623e876994553881597c9` | 1,191,697 B; `E9020DA36693D94C0F16FA9CA0025531551E285B5C654BE02E42C85D0679D44A` | 275,827 B; `00770A79B5769689A3476D6CEC301DA7DBE2FA8BA5AC794265E6D61BDB902539` |
| Introductory Statistics 2e | `1f6a35825395bb4aa2834cf1eca37512655f920c` | 904,184 B; `36BB2394659825E65F9AFC80A1C8A23FA4199637D870002B9D69D041CF672E2E` | 282,306 B; `CA60F5453A99F53CB5DF57AEE23F9DEA3564961D555BBF357A4E36BB22E25194` |
| Biology 2e | `63f8b6f8d129dd1582989bb755011e9a6d523471` | 1,985,653 B; `C1C30ED81DF28836E87A345707F4C98F4C660E190F44AFD9832583A47325C81D` | 380,702 B; `416DE316E77159A3773C543188C062E2E619B3B429EB6A7726C5F5BA35BB5980` |
| Chemistry 2e | `3be4b60ff501f29a445f0cacf003e5f5cc16244d` | 1,576,120 B; `98A11D5A225605A2AEAB5321AB581AB86FFD8A4A38393A1C15FF52E62045ACAF` | 331,224 B; `8BF10B148E068B4FF9460ECD56BC1391589876737E81C449B2BC9E35081BBC8E` |
| College Physics 2e | `fd1b25dfd5d8c6580c6e2b2b34a19e29cc69ada9` | 2,710,394 B; `110662585FC94B498557C1E243BBC4F6C1C17DB7B6432ED1ADE3AEDBADFC9D04` | 374,925 B; `8DABF58FFA2F8AEC416FA4A57E6E67BD68ACE7DC9F9EDBC4C38BE03A6B298A5C` |
| Principles of Management | `f2b749648a176dbe114dbc4e35ec20c030be4713` | 878,136 B; `7669E9F348DD387C7F8856AB1369F3828E80F3F719F4A87FC4E6342C458D2F5C` | 298,230 B; `E64B8F2D1310ECCF415849B95B631FB36B1251B92FC2582E18669723B714957D` |
| Principles of Finance 2e | `e3e5135ae36e21282d7afb4cccd5ce09f421d830` | 707,511 B; `D635B59F0508761D2E02ADDB0B66102134E83C99EB38307C2151752D9B517132` | 308,175 B; `B65C3860032026036DF42261B3BD760406A4018C30358E0DE74FE8D776D08496` |
| Anatomy and Physiology 2e | `716383a4c6c16037b14d75a156c65145e75e895e` | 1,619,005 B; `F632F580E6723C6377524A43827D13536F70FFB058EAAE861C168377CBB56870` | 362,247 B; `EC28434AB1255B00C9FB571EB91584EDE96BEDADEB7CC432203B113E6BBF1A1A` |
| Introduction to Python Programming | `d215dd3b99c33db855c49315152ebd5fbadc8534` | 245,593 B; `C13C9D8401AB791948B529AE1FA106ACABF33B9AE28FFE6154093D84D3BA0FF1` | 268,369 B; `1F37D1DB02A7A3853FC1FCC7168FF33C75B9D415D647C12BC2CFDBF76D8F1445` |

Every new source archive contains only the exact collection XML, README, LICENSE, and referenced CNXML modules at the pinned commit; media are excluded. Official preface pages were separately frozen for course-scope evidence. Current source-version licensing and any model-use restrictions must be resolved title by title before later derivative production. This mechanical measurement is not production authorization and makes no legal conclusion.

## Remaining research

This checkpoint supplies a better denominator for text traffic. It does not answer which subject or language should receive compute. The next matched analysis must bind each candidate community and stage to existing usable supply, prerequisites, delivery format, a concrete educational endpoint, and an effect range; only then can complete and smaller packages enter a dominance or portfolio comparison.
