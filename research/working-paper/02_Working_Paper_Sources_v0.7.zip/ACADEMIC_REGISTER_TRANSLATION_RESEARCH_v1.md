# Full-content academic-register translation: evidence and production method

**Status:** governing research-and-production method, version 1. This is not a proposal to reduce intellectual content and not a test of whether readers deserve access.

## Executive conclusion

The programme should treat academic-to-nonacademic English as **full-content diaphasic intralingual translation**: translation across registers within English, for a specified adult audience, while keeping the entire intellectual object recoverable. The target can be longer and more explicit than the source. It may define, unpack, split, reorder with tracked dependencies, resolve references, and add labeled scaffolding. It may not summarize, abridge, generalize, silently strengthen or weaken, delete, infantilize, or substitute intuition for proof.

The governing premise is a sufficiently plausible access thesis, not a hypothesis that the literature may veto: inherited academic-register familiarity is one institutionally distributed access advantage, and any credible nonzero educational benefit makes a source-faithful register edition eligible. Research determines target profiles, fidelity safeguards, measurement, and revision. It does not turn correlations between schooling, wealth, test performance, language exposure, or attainment into claims of innate capacity, and it cannot use such claims to withhold translation.

## What is empirical and what is a governing choice

Several empirical literatures support different links: parent education and socioeconomic position are associated with unequal educational trajectories; institutional rules and academic discourse are often tacit; academic-language knowledge predicts comprehension in several school samples; jargon and document design can causally affect processing or understanding; and making hidden institutional knowledge explicit can improve some outcomes. No identified study tests the entire chain from parental education through academic-register translation to long-run attainment. That gap limits causal claims and determines the evaluation agenda. It does not cancel the production commitment.

The method therefore uses four distinct statements:

- **Normative and operational premise:** readers are presumed intellectually capable; inherited register fit is not a deservingness test.
- **Evidence-supported mechanism:** unfamiliar academic forms can add processing, navigation, identity, and institutional burdens.
- **Design thesis:** a complete, optional, audience-specific register translation can remove part of that burden without removing content.
- **Empirical unknown:** the size and distribution of learning, persistence, autonomy, or research benefits must be measured by target and task.

## Why this is translation rather than simplification

Jakobson's category of intralingual translation supplies the broad foundation. Diaphasic translation names movement between situation-linked registers. A target register is chosen by purpose and audience, but this project adds a stronger invariant than ordinary simplification or popularization: every source proposition and dependency must remain recoverable, and every target assertion must be source-supported or explicitly labeled as an addition.

Ordinary simplification corpora are unsafe as the governing objective. In one major document-level dataset, deletion represented 44% of sampled operations. Factuality studies find omitted and unsupported information that surface metrics miss. The project may borrow splitting, explicitness, anaphora resolution, navigation, and reordering only under claim-level and dependency constraints; deletion is disabled.

## There is no single Plain English

English is pluricentric. Academic genres vary by field, institution, country, professional community, educational history, and medium. Word difficulty also varies with first language, proficiency, and reading experience. A single universal Plain English would reproduce the same flattening that the intervention is intended to avoid. Each edition needs a declared adult target profile.

| Target profile | Intended users | Design consequences |
|---|---|---|
| International adult / ELF-friendly | Readers who use English across language backgrounds | Shorter dependency spans, explicit logical relations, controlled idiom, technical anchors with glosses; no imitation of one metropolitan accent or grammar as a condition of correctness. |
| Educated non-specialist adult | Readers with general education but not the discipline's institutional register | Define field terms, unpack nominalizations, make agents and relations explicit, add labeled examples, preserve all propositions and evidence. |
| Profession-adjacent novice | Readers entering a field from work or another discipline | Retain professional terminology with first-use glosses, expose prerequisites, preserve genre and citation structure. |
| Localized adult English | Readers using a legitimate local or regional English repertoire | Commission locale-specific lexical, pragmatic, orthographic, and example choices without treating metropolitan standards as intrinsically superior. |
| Academic-convention companion | Readers who want both the content and the prestige register used by institutions | Parallel display of full-content register translation and original academic formulation, with reversible term and phrase mappings. |
| Accessible-language edition | Readers requiring Easy Language, Easy Read, audio, signed, screen-reader-native, or cognitive-access formats | Separate specification and production path. It may share the content ledger but must not be collapsed into the general adult-register edition. |

The accessible-language edition is not a euphemism for the general adult translation. Easy Language, Easy Read, signed, audio, and cognitive-access editions have distinct audiences, standards, and multimodal requirements. They remain fully eligible and can share the same source ledger.

## Evidence synthesis

Evidence types are kept separate. Theoretical sources identify mechanisms and audit questions. Qualitative studies show possible institutional processes. Observational studies quantify associations. Experiments support only their tested contrast. Standards guide design but do not prove outcomes.

### Intergenerational And Institutional Access

**REG-001 — [Cataldi, Bennett, and Chen (2018), NCES 2018-421](https://nces.ed.gov/pubs2018/2018421.pdf).** nationally representative descriptive longitudinal evidence.

- Scope: Three United States longitudinal programmes: ELS:2002 (more than 15,000 high-school sophomores), BPS:04/09 (nearly 17,000 beginning postsecondary students), and B&B:08/12 (more than 17,000 bachelor's recipients).
- Finding: Postsecondary enrolment by 2012 was 72% where parents had never attended college, 84% where parents had some college, and 93% where a parent held at least a bachelor's degree. Six-year degree attainment or continued enrolment in BPS was 55.8%, 63.4%, and 74.5%, respectively.
- Use here: Establishes a large parent-education gradient that an access programme must take seriously.
- Limit: It does not identify academic register as the cause and cannot separate finances, prior schooling, institutional sector, employment, family obligations, discrimination, or other co-varying conditions.

**REG-002 — [Sirin (2005)](https://doi.org/10.3102/00346543075003417).** meta-analysis of correlational studies.

- Scope: Fifty-eight United States K-12 articles, 101,157 students, 6,871 schools, and 128 districts; the article reports 74 or 75 independent samples in different sections.
- Finding: The student-level random-effects association between socioeconomic status and achievement was r=.27, 95% CI [.23, .30]. Parental education specifically had k=30 and a reported mean association of r=.30.
- Use here: Shows that socially distributed resources and educational attainment are empirically associated.
- Limit: Association is not innate ability and is not a causal estimate of register, schooling, or parent education.

**REG-003 — [Holmlund, Lindahl, and Plug (2011)](https://doi.org/10.1257/jel.49.3.615).** causal-evidence review plus Swedish-register comparisons.

- Scope: Conventional, twin, adoption, and compulsory-schooling instrumental-variable designs; main Swedish samples included 336,083 mother-child and 269,648 father-child observations.
- Finding: Twin, adoption, and instrumental-variable estimates were generally smaller and less stable than ordinary regressions.
- Use here: Prevents the framework from treating an intergenerational schooling association as biological or deterministic transmission of capacity.
- Limit: The designs do not isolate academic-register translation and do not imply that parental education is irrelevant.

**REG-004 — [Ives and Castillo-Montoya (2020)](https://doi.org/10.3102/0034654319899707).** systematic review.

- Scope: Fifty-nine United States higher-education publications concerning first-generation students.
- Finding: Thirty articles primarily framed first-generation learners against conventional performance norms, while only seven used experimental or quasi-experimental methods; a smaller literature identified assets from lived experience.
- Use here: Requires an anti-deficit interpretation and explicit separation of institutional fit from intellectual capability.
- Limit: The literature is heterogeneous and does not estimate the effect of register translation.

**REG-005 — [Collier and Morgan (2008)](https://doi.org/10.1007/s10734-007-9065-5).** qualitative focus-group study.

- Scope: One urban public university, 15 faculty members and 63 students, including six first-generation and two continuing-generation student groups.
- Finding: Both groups wanted clearer expectations; first-generation discussions particularly described unfamiliarity with syllabus use, office hours, citation and writing formats, disciplinary expectations, and lecture terminology.
- Use here: Supports the existence of unequally distributed institutional discourse knowledge.
- Limit: It supplies themes, not prevalence, causal effects, or a representative population estimate.

**REG-006 — [Yee (2016)](https://doi.org/10.1080/00221546.2016.11780889).** two-year ethnography.

- Scope: Thirty-four students at an urban public comprehensive university and more than 800 hours of observation and interviews.
- Finding: Both groups worked hard, but continuing-generation students had a broader repertoire of institutionally rewarded interactive strategies, while first-generation students more often relied on strenuous independent strategies.
- Use here: Treats hidden rules and institutional valuation as access conditions rather than student defects.
- Limit: This is not a register-translation study and does not estimate population prevalence.

### Academic Register And Comprehension

**REG-007 — [Preece (2015)](https://doi.org/10.1016/j.linged.2014.10.003).** ethnographic case study.

- Scope: A compulsory academic-writing cohort of 93 first-year students at a London university, with repeated interviews of eight focal participants.
- Finding: Participants described academic English as unfamiliar and socially marked and experienced remedial positioning as erasing bilingual and bidialectal resources.
- Use here: Directly motivates optional register translation that respects adult identities and existing repertoires.
- Limit: The study is contextual, not a trial of full-content translation.

**REG-008 — [Uccelli et al. (2019)](https://doi.org/10.1111/cdev.13034).** small longitudinal observational study.

- Scope: Forty-two English-speaking parent-child dyads observed at 30 months and assessed in Grade 7.
- Finding: Socioeconomic status explained 31% of Grade-7 academic-language variance; parent and child decontextualized talk added variance in sequential models, with child talk remaining significant in the final model.
- Use here: Supports academic-discourse familiarity as learned through differential participation and exposure.
- Limit: The sample is small, observational, and does not establish that parental education causes later register knowledge.

**REG-009 — [Volodina and Weinert (2020)](https://doi.org/10.3389/fpsyg.2020.00814).** longitudinal cohort-sequential observational study.

- Scope: N=627 learners in German Grades 2-4, including 361 language-minority learners.
- Finding: Socioeconomic status predicted initial comprehension and growth for academic connectives; these paths became nonsignificant after receptive-language measures entered the model.
- Use here: Treats connectives and explicit logical relations as learned access tools that a translation can preserve and unpack.
- Limit: Statistical mediation is not causal proof and child German-school evidence does not directly estimate adult tertiary effects.

**REG-010 — [Uccelli et al. (2015)](https://doi.org/10.1002/rrq.104).** cross-sectional comprehension study.

- Scope: N=218 United States students in Grades 4-6; 65% qualified for subsidized meals and half were current or former English learners.
- Finding: Cross-disciplinary academic-language skills added 12% unique variance to reading comprehension after socioeconomic status, word-reading fluency, and academic vocabulary; the final model reported R-squared=.59.
- Use here: Shows that register knowledge can matter beyond vocabulary and decoding.
- Limit: It is neither adult evidence nor a causal estimate of translation benefit.

### Institutional Interventions

**REG-011 — [Stephens et al. (2012)](https://doi.org/10.1037/a0027143).** observational studies plus randomized framing experiments.

- Scope: Four United States studies, including 261 administrators from 60 institutions, a student cohort of 1,424, and randomized experiments with N=88 and N=147.
- Finding: First-generation participants performed worse after an independence-framed welcome message, while no gap appeared after an interdependence frame; first-generation performance improved under the interdependence frame.
- Use here: Demonstrates that institution-created framing can causally affect immediate performance.
- Limit: The outcome is short-term task performance, not document translation or attainment.

**REG-012 — [Stephens, Hamedani, and Destin (2014)](https://doi.org/10.1177/0956797613518349).** randomized controlled trial.

- Scope: N=168 incoming students at one private United States university.
- Finding: A one-hour difference-education panel made background-linked challenges, strengths, and navigation strategies explicit. The control first-generation/continuing-generation GPA gap was .30 grade points; no significant gap appeared in the intervention condition. The first-generation intervention-control contrast was d=.70.
- Use here: Supports making institutionally implicit knowledge explicit and rejects a fixed-capacity account.
- Limit: The intervention did not isolate language or translate academic content.

### Language Interventions And Comprehension

**REG-013 — [Bullock et al. (2019)](https://doi.org/10.1177/0963662519865687).** online randomized language experiment.

- Scope: N=650 participants reading messages about emerging technologies.
- Finding: Jargon reduced reported processing fluency, which statistically mediated greater resistance, higher perceived risk, and lower support.
- Use here: Treats jargon as a manipulable access burden.
- Limit: The main outcomes were metacognitive and persuasive, not objective educational comprehension.

**REG-014 — [Santesso et al. (2015)](https://doi.org/10.1016/j.jclinepi.2014.04.009).** randomized controlled trial.

- Scope: N=143 members of the public across Canada, Norway, Spain, Argentina, and Italy.
- Finding: A redesigned plain-language Cochrane summary yielded correct understanding of benefits, harms, and evidence quality in 53% versus 18% under the existing format; median correct answers were 3 versus 1.
- Use here: Provides objective evidence that a clear-language document package can improve understanding.
- Limit: The intervention combined wording, organization, absolute numbers, and evidence-quality presentation and concerned summaries rather than full courses.

**REG-015 — [Kim and Kim (2015)](https://doi.org/10.1177/1740774515571139).** randomized controlled trial.

- Scope: N=150 participants comparing standard and simplified cancer-trial consent documents.
- Finding: The redesigned document produced higher objective and subjective understanding.
- Use here: Supports full-document redesign as a plausible comprehension intervention.
- Limit: The intervention mixed plain wording, short sentences, diagrams, pictures, and bullets and was not an academic-course translation.

**REG-016 — [August et al. (2024)](https://doi.org/10.1145/3613904.3642289).** three randomized within-participant online studies.

- Scope: Three studies with N=199, N=191, and N=203 readers of scientific summaries.
- Finding: In the information-preserving study, lower-complexity versions retained 97.7% of manually coded information units. Readers with the lowest topic familiarity reported better ease outcomes, while higher-familiarity readers sometimes skipped more in overly plain versions.
- Use here: Supports audience-specific parallel versions and information-unit accounting.
- Limit: Outcomes were largely subjective and the sources were summaries, not complete courses or proofs.

**REG-017 — [August et al. (2023), Paper Plain](https://doi.org/10.1145/3589955).** formative think-aloud and small usability study.

- Scope: Think-aloud N=12 and partial within-participant usability N=24.
- Finding: Question-guided navigation, definitions, and section-level gists beside the original increased perceived ease and confidence; multiple-choice comprehension was not detectably different.
- Use here: Supports a parallel source-plus-translation interface rather than replacement.
- Limit: The sample was small and the intervention was multicomponent.

**REG-018 — [Stoll et al. (2022)](https://doi.org/10.1371/journal.pone.0268789).** systematic review.

- Scope: 7,714 database records plus 135 additional records; 90 reports included, 33 empirical.
- Finding: Only eight empirical studies directly compared alternative plain-language-summary forms and only six used experiments; heterogeneity prevented firm criteria.
- Use here: Defines the evidence gap and prevents overclaiming certainty.
- Limit: The review concerns brief summaries, not full-content register translation.

### Translation Studies And Register Theory

**REG-019 — [Jakobson (1959)](https://doi.org/10.4159/harvard.9780674731615.c18).** foundational translation theory.

- Scope: Conceptual distinction among intralingual, interlingual, and intersemiotic translation.
- Finding: Intralingual translation is rewording by means of signs in the same language.
- Use here: Establishes that academic-to-adult-register work is translation, not merely editing.
- Limit: The source does not supply a modern production or fidelity standard.

**REG-020 — [Zethsen (2009)](https://doi.org/10.7202/038904ar).** translation-studies synthesis.

- Scope: Descriptive model of intralingual translation using knowledge, time, culture, and space as parameters.
- Finding: Intralingual translation often uses extensive addition, omission, restructuring, and simplification.
- Use here: Supplies a descriptive map of transformations.
- Limit: Ordinary practice permits omission; this project tightens the model by prohibiting loss of source content.

**REG-021 — [Zethsen and Hill-Madsen (2016)](https://doi.org/10.7202/1039225ar).** translation-theory synthesis.

- Scope: Conceptual account of source existence, target derivation, and skopos-dependent relevant similarity.
- Finding: Intralingual products can count as translation when a target derives from a source for a communicative purpose.
- Use here: Supports a register-specific skopos while the project adds a stricter completeness invariant.
- Limit: Relevant similarity alone is too permissive for proofs and high-stakes academic claims.

**REG-022 — [Hill-Madsen (2015; 2024)](https://doi.org/10.7202/1114777ar).** register-translation analysis and quality-assessment framework.

- Scope: Diaphasic intralingual translation across expert and non-expert registers.
- Finding: Registerial adequacy can be assessed through transparency of meaning, including iconicity, familiar lexis, explicitness, groundedness, and coherence.
- Use here: Supplies the positive target-side criteria used after fidelity passes.
- Limit: A register score cannot compensate for lost content or changed logic.

### Plain-Language Standards

**REG-023 — [ISO 24495-1:2023](https://www.iso.org/standard/78907.html).** international standard.

- Scope: Governing principles and guidelines for plain-language documents, including technical writing and controlled languages.
- Finding: Plain language is audience- and purpose-oriented and may apply to technical communication.
- Use here: Supports findability, understandability, and usability as target-side dimensions.
- Limit: The standard does not by itself prove semantic equivalence or cover all accessibility formats.

**REG-024 — [CAN-ASC-3.1:2025](https://publications.gc.ca/collections/collection_2025/nac-asc/AS4-45-2025-eng.pdf).** national accessibility standard.

- Scope: Audience-centred plain-language standard covering relevance, findability, understanding, and use.
- Finding: Plain language varies by audience, topic, format, and context, and multiple audiences can require separate communications.
- Use here: Rules out a single universal Plain English target.
- Limit: It is a design standard, not an evaluation of full mathematical translation.

### World Englishes And Lingua-Franca Use

**REG-025 — [Kachru (2001)](https://doi.org/10.1146/annurev.anthro.30.1.527).** sociolinguistic synthesis.

- Scope: Global histories, functions, norms, and identities of World Englishes.
- Finding: English is pluricentric and used through multiple institutional and local norms rather than one invariant native-speaker standard.
- Use here: Requires locally and functionally specified adult English targets.
- Limit: The framework does not quantify academic-source mismatch for any population.

**REG-026 — [Jenkins, Cogo, and Dewey (2011)](https://doi.org/10.1017/S0261444811000115).** research review.

- Scope: Developments in research on English as a lingua franca.
- Finding: Lingua-franca English is variable, adaptive, and not adequately evaluated only against metropolitan native norms.
- Use here: Separates communicative success from prestige-standard conformity.
- Limit: The review does not identify one ready-made register for educational translation.

**REG-027 — [Gooding and Tragut (2022)](https://doi.org/10.18653/v1/2022.findings-naacl.27).** computational and reader-difference study.

- Scope: Lexical complexity across readers with differing first languages, proficiency, and reading experience.
- Finding: Word difficulty is not invariant across readers; first language, proficiency, and exposure affect lexical accessibility.
- Use here: Requires more than one adult English register and audience-specific terminology support.
- Limit: Lexical difficulty alone is not full-document comprehension or mathematical fidelity.

### Meaning-Preservation Risk

**REG-028 — [Sun, Jin, and Wan (2021)](https://doi.org/10.18653/v1/2021.emnlp-main.630).** document-level simplification corpus and modelling study.

- Scope: D-Wikipedia document pairs and baseline systems.
- Finding: Sentence deletion accounted for 44% of sampled document-level simplification operations; addition, splitting, joining, anaphora resolution, and reordering also occurred.
- Use here: Shows why ordinary simplification objectives are unsafe for a no-content-loss brief.
- Limit: Wikipedia simplification is not academic translation and the operation frequencies are descriptive, not normative.

**REG-029 — [Sulem, Abend, and Rappoport (2018)](https://doi.org/10.18653/v1/D18-1081).** metric-evaluation study.

- Scope: Sentence simplification with splitting and human judgments.
- Finding: BLEU had low or no correlation with human grammaticality and meaning-preservation judgments in relevant settings and could correlate negatively with simplicity.
- Use here: Prevents a surface metric from certifying fidelity.
- Limit: The result does not imply that every automatic diagnostic is useless.

**REG-030 — [Devaraj et al. (2022)](https://doi.org/10.18653/v1/2022.acl-long.506).** factuality evaluation of text simplification.

- Scope: Reference and system simplifications with factual-error analysis.
- Finding: Both references and system outputs contained factual errors that common metrics missed, including deletion and unsupported insertion.
- Use here: Requires claim-level source alignment and support checks.
- Limit: The study does not validate a complete replacement metric.

**REG-031 — [Agrawal and Carpuat (2024)](https://doi.org/10.1162/tacl_a_00653).** reading-comprehension evaluation of simplification systems.

- Scope: Question-answerability tests of supervised and other simplification systems.
- Finding: Even the strongest supervised system left at least 14% of comprehension questions unanswerable from the transformed text.
- Use here: Supports zero-tolerance checking of protected content rather than assuming readability implies completeness.
- Limit: Question answerability is an alarm and does not prove all remaining propositions are correct.

**REG-032 — [Joseph et al. (2024), FactPICO](https://doi.org/10.18653/v1/2024.acl-long.459).** expert-annotated factuality benchmark.

- Scope: 345 plain-language summaries of randomized-trial abstracts generated by three language models.
- Finding: Existing factuality metrics correlated poorly with expert judgments at the individual-summary level, including correctness of added explanations.
- Use here: Requires structured proposition and addition provenance rather than metric-only release.
- Limit: The benchmark concerns medical abstracts and summaries, not whole academic works.

### Mathematical Discourse

**REG-033 — [Schleppegrell (2007)](https://doi.org/10.1080/10573560601158461).** mathematics-language synthesis.

- Scope: Linguistic challenges of mathematics teaching and learning.
- Finding: Dense noun phrases, relational processes, conjunctions, and implicit logical relations carry mathematical meaning; everyday talk and technical register serve different functions.
- Use here: Makes logical connectives, relations, and technical anchors protected content.
- Limit: The paper does not specify an automated translation pipeline.

**REG-034 — [Ganesalingam (2013)](https://doi.org/10.1007/978-3-642-37012-0).** linguistic and computational monograph.

- Scope: The language and formal interpretation of mathematical texts.
- Finding: Mathematical prose depends on ambiguity resolution, typed objects, notation, and compositional relations between linguistic and symbolic material.
- Use here: Requires notation/type preservation and document-level mathematical parsing.
- Limit: It is not an outcome evaluation of plain-language mathematics.

### English-Medium Education And Research

**REG-035 — [Macaro et al. (2018)](https://doi.org/10.1017/S0261444817000350).** systematic review.

- Scope: An in-depth review of 83 higher-education EMI studies within a wider mapped literature.
- Finding: The evidence available then was insufficient to assert that EMI benefited language learning or was clearly detrimental to content learning; stakeholders expressed serious implementation concerns.
- Use here: Prevents automatic credit to English-medium provision as complete educational access.
- Limit: The 2018 evidence base was geographically uneven and has since expanded.

**REG-036 — [Curle et al. (2026 update of Macaro et al.)](https://doi.org/10.1016/j.system.2025.103892).** updated systematic review.

- Scope: 196 empirical EMI studies published from 2016 through 2023.
- Finding: The update reports positive receptive-language and vocabulary outcomes, mixed productive-language outcomes, no general pattern of worse content attainment, and persistent academic-writing and transition challenges; Asia and Europe remain most studied.
- Use here: Updates the evidence without equating EMI availability with comfortable independent academic access.
- Limit: Heterogeneity and regional imbalance prevent a universal person-level academic-access rate.

**REG-037 — [Amano et al. (2023)](https://doi.org/10.1371/journal.pbio.3002184).** online self-report survey.

- Scope: 908 published environmental scientists from eight nationalities stratified by national income and English-proficiency context.
- Finding: Compared with native-English peers, moderate- and low-English-proficiency nationality groups reported substantially more reading and writing time and more English-related rejection.
- Use here: Makes research-stage reading, writing, and dissemination burdens visible.
- Limit: Nationality categories are not individual proficiency, the data are self-reported, and the sample does not represent all disciplines.

### Critical And Anti-Hegemony Evidence

**REG-038 — [Bourdieu (1977)](https://doi.org/10.1177/053901847701600601).** sociological theory.

- Scope: Linguistic exchanges, social markets, legitimate discourse, and symbolic power.
- Finding: The social value of linguistic forms depends on institutions and speakers' positions rather than intrinsic linguistic merit.
- Use here: Forbids treating academic-register possession as neutral evidence of lower need or greater capability.
- Limit: The theory does not supply a numerical allocation coefficient.

**REG-039 — [Pennycook (1997)](https://doi.org/10.1016/S0889-4906%2897%2900019-7).** critical EAP analysis.

- Scope: Critique of neutrality and pragmatism in English for Academic Purposes.
- Finding: Presenting academic conventions as neutral can naturalize and reproduce institutional power.
- Use here: Frames academic register as situated and teachable, not the sole legitimate form of thought.
- Limit: This is conceptual critique, not an educational-effect experiment.

**REG-040 — [Lea and Street (1998)](https://doi.org/10.1080/03075079812331380364).** qualitative academic-literacies case study.

- Scope: Twenty-three staff and 47 students at two English universities using interviews, observation, assignments, feedback, and guidance documents.
- Finding: Judgments of good academic writing depended on tacit disciplinary epistemologies, identities, and institutional relations, not only generic skills.
- Use here: Requires discipline-specific translation and separates knowledge from conformity to tacit conventions.
- Limit: The authors did not claim statistical representativeness.

**REG-041 — [Flores and Rosa (2015)](https://doi.org/10.17763/0017-8055.85.2.149).** raciolinguistic theoretical synthesis.

- Scope: Educational categories of appropriateness and perceptions of racialized language.
- Finding: Racialized speakers can be perceived as deficient even when approximating supposedly appropriate forms; the listener and institution are part of the judgment.
- Use here: Requires matched-meaning variety audits and prohibits standard-language conformity from serving as semantic QA.
- Limit: The source does not estimate the effect of a translation programme.

**REG-042 — [Hofmann et al. (2024)](https://doi.org/10.1038/s41586-024-07856-5).** matched-guise probing experiments on language models.

- Scope: GPT-2, RoBERTa, T5, GPT-3.5, and GPT-4 tested with matched African American English and Standardized American English prompts.
- Finding: Dialect features alone elicited different stereotypes and hypothetical occupational and criminal decisions; model scaling and human-feedback training did not remove the covert dialect prejudice measured.
- Use here: Requires dialect-counterfactual invariance in AI allocation and translation QA.
- Limit: The constructed decision tasks do not estimate educational translation outcomes.

## Anti-hegemony implementation

The analysis treats academic-register familiarity as linguistic capital unequally distributed through institutions and social histories. It does not reward a target because its users already conform to a prestige register, have more money, attend better-funded schools, generate more web data, live in a wealthier state, or use a colonial or globally dominant language. Nor does it punish a target for lacking those advantages.

A register translation must preserve the reader's legitimate linguistic repertoire rather than silently normalize it. Matched-meaning inputs that differ only by racialized, classed, local, or non-metropolitan English features must not produce different judgments of intellectual ability, educational need, translation eligibility, or source fidelity. Surface convention is assessed only against the declared target brief and must remain separate from truth and reasoning.

Alternative access through another language or register counts only when the exact material is technically usable, linguistically intelligible, materially equivalent, voluntarily and politically acceptable, disability-accessible, affordable, discoverable, lawful, safe, and trustworthy. Official status, compulsory exposure, conversational fluency, or a bilingual label cannot establish those conditions.

## Protected content

| Object | Mandatory invariant |
|---|---|
| Atomic propositions | Every source claim maps to one or more target locations; every target assertion maps to source support or a labeled explanatory source. |
| Definitions | Preserve term, category, distinguishing conditions, scope, directionality, and every if-and-only-if relation. |
| Quantifiers and negation | Preserve all, every, any, no, some, exists, at least, at most, exactly, only, unless, except, and their scope. |
| Numbers and units | Preserve values, signs, ranges, inequalities, endpoints, precision, uncertainty, denominators, dates, sample sizes, and units. |
| Terminology | Retain the exact technical anchor on first use, add a plain gloss, and never collapse distinct technical co-hyponyms into one vague word. |
| Notation and types | Preserve symbols, case, subscripts, superscripts, primes, binding, domains, codomains, object types, and equation references. |
| Theorems and proofs | Preserve hypotheses, constructions, witnesses, cited lemmas, cases, inference types, equality chains, contradiction assumptions, and conclusions. |
| Cross-references | Resolve every section, figure, table, equation, theorem, note, and citation link after restructuring. |
| Coreference and cohesion | Resolve ambiguous pronouns and ellipsis; preserve rhetorical relations such as cause, contrast, concession, condition, and conclusion. |
| Epistemic and deontic force | Preserve may, suggests, is consistent with, proves, should, must, confidence, limitations, and conjectural status. |
| Prerequisites and assumptions | Inventory and introduce global and local assumptions before use without moving them outside their logical scope. |
| Additions | Label each gloss, example, intuition, background note, or translator explanation and record its source. |
| Multimodal relations | Keep formulas, diagrams, captions, tables, axes, accessibility descriptions, and surrounding prose mutually consistent. |

## Production workflow

1. Freeze the source identity, version, date, byte count, and SHA-256.
2. Assign stable identifiers to sections, paragraphs, equations, theorems, figures, tables, notes, and citations.
3. Build an atomic content ledger covering claims, definitions, assumptions, quantifiers, numbers, exceptions, examples, evidence status, and attribution.
4. Build a dependency graph for prerequisites, definitions, theorems, proof steps, cross-references, symbols, and coreference chains.
5. Define one adult target-register profile per deliverable: audience, purpose, field knowledge, English repertoire, locality, medium, and accessibility requirements.
6. State the positive translation purpose and the no-loss invariants.
7. Create a termbase with exact term, plain gloss, first-use treatment, later short form, prohibited flattenings, and notation.
8. Translate coherent sections with the whole document graph available; do not process isolated sentences without context.
9. Prefer expansion and explicitness: unpack nominalizations, restore agents and omitted subjects, split overloaded sentences, and make logical relations visible.
10. Retain every technical anchor on first use; examples and intuitions are additions beside, not replacements for, the abstract claim or proof.
11. Reorder only with a source-target map and a dependency-order check.
12. Maintain bidirectional alignment from every source ledger item to target text and from every target assertion to source support.
13. Run a full fidelity pass over every protected item; sampling is not allowed for definitions, claims, formulas, proofs, numbers, citations, or epistemic markers.
14. Run a separate register-quality pass for familiar lexicon, explicitness, groundedness, coherence, navigation, genre fit, locale fit, and audience fit.
15. Run matched-meaning dialect and register counterfactual tests so surface variety cannot change capability or priority judgments.
16. Run structural checks for numbers, units, math spans, symbols, cross-references, citation keys, terminology, quantifiers, negation, conditionals, and modal markers.
17. Use readability, similarity, NLI, generated QA, and language-model critique as alarms only; none certifies semantic equivalence.
18. Build and render phone, desktop, print, screen-reader, low-bandwidth, and offline forms where applicable.
19. Publish a reversible version with the source hash, target brief, termbase, content ledger, alignment, test results, model provenance, and correction channel.
20. Measure use and learning where possible and revise; missing human evidence never blocks a completed, mechanically audited edition.

## Release and QA rule

A critical fidelity error changes or loses a definition, proposition, quantifier, condition, exception, number, unit, mathematical symbol, proof dependency, cross-reference target, attribution, epistemic or deontic force, or prerequisite. Critical errors allowed in a released edition: **zero**. Major errors that could cause the target reader to form a materially different model of the source must also be resolved. Minor register or style issues remain revisable and may not be traded against accuracy.

Readability, sentence length, lexical frequency, SARI, BLEU, semantic similarity, natural-language inference, generated questions, and model critique are diagnostic alarms. None is a semantic certificate. Deterministic checks reconcile claims, numbers, units, formulas, symbols, links, citation keys, terms, quantifiers, negation, conditions, and modality. A second model pass may challenge the translation, but the auditable content ledger and exact source-target alignment remain the core evidence.

Human evidence can improve later revisions but is not a publication hold. A completed edition proceeds through deterministic and model-audit gates and remains versioned and reversible. Use studies, classroom studies, or community feedback measure outcomes and guide later profiles; they do not decide whether the audience was worthy of receiving the first edition.

## Research design for measuring benefit

The production premise is fixed; the following outcomes remain research questions:

- immediate proposition-level comprehension, including definitions, conditionality, and uncertainty;
- time and effort needed to reach the same answer or proof understanding;
- independent navigation, prerequisite recovery, exercise completion, and error correction;
- delayed retention and transfer to new problems;
- persistence through a course or research text;
- ability to move between the translated and conventional academic registers when the reader chooses;
- differences across adult target registers, fields, educational stages, disability modes, devices, and prior familiarity;
- whether a parallel source-plus-translation interface outperforms either version alone.

Measure the actual learning task, not conformity to one accent, orthography, or metropolitan grammar. Publish null and adverse effects, but use them to revise target design, not to infer deficient readers. Because an optional edition leaves the original available, heterogeneous preferences support a portfolio rather than one compulsory register.

## Immediate Open Logic implementation brief

The first bounded implementation can translate one complete Open Logic module into one declared international adult/ELF-friendly register while preserving the original beside it. Freeze the source; create stable claim, definition, formula, example, exercise, and reference IDs; build the termbase and dependency graph; produce the full-content translation; and run all protected-item checks. The pilot should compare at least two adult target profiles rather than declare one global Plain English.

Commissioning language:

> Produce a full-content diaphasic intralingual translation for the specified adult English register. Preserve every proposition, definition, quantifier and its scope, condition, exception, number and unit, term distinction, symbol and type, proof step and dependency, cross-reference, attribution, epistemic and deontic status, and prerequisite. Do not summarize, abridge, generalize, or delete. You may expand, define, split, reorder with tracked dependencies, resolve anaphora, add labeled scaffolding, and lower unnecessary formality. Retain each technical term and notation at first use with a plain gloss. Maintain bidirectional source-target claim alignment. Treat readability metrics as diagnostics only. Release only with zero critical accuracy errors.

## Bottom line

The access intervention is neither a claim that academic language is useless nor a claim that every reader wants the same register. It separates intellectual content from one inherited institutional form, keeps the conventional form available, and offers complete parallel routes. The literature makes the mechanism and the design obligation plausible; the project adopts production as the standing decision and uses research to make the editions more faithful, more varied, and more useful.
