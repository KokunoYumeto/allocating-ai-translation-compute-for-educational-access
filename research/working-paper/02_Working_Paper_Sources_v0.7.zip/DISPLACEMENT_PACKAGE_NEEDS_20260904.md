# Displacement and stateless-community package comparison

**Status:** bounded source-bound package pass; not a ranking, language-population estimate or claim of complete global displacement coverage.

Ten existing displacement/status portfolios now remain visible at every educational stage: P (preschool/early learning), F (foundational/primary), S (secondary), V (vocational/practical), U (university), and R (postgraduate/research). Each stage has two alternatives: a complete multilingual continuity sequence and a smaller host/origin-language bridge or companion around usable existing provision. That produces 120 unranked comparison routes.

The central restriction is non-negotiable: a refugee, displaced, migrant or stateless cohort is not a language population. The six portfolios with a source-stated status or enrolled-learner count retain that number only as context. Four portfolios retain no population value because the current bounded source register lacks a publication-ready cohort denominator. Neither state becomes zero need.

| Portfolio | Status-population context | Language/script arms | Evidence state |
|---|---:|---|---|
| DRC refugees and internal displacement — host-specific education portfolio | unmeasured | French; Lingala; Kiswahili; Tshiluba; Kikongo varieties and other named languages; each host-country language | SOURCE_DISCOVERY_REQUIRED_NO_POPULATION_ASSIGNED |
| Afghan displaced multi-language overlay | 3,700,000 (2025) | Dari; Pashto; Hazaragi; Uzbek and other explicitly measured Afghan languages; each host-country language | DIRECT_STATUS_COHORT_DENOMINATOR_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Palestinian Arabic refugee-status overlay | 6,000,000 (2025) | Palestinian Arabic; Modern Standard Arabic; each host-country language | DIRECT_STATUS_COHORT_DENOMINATOR_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Syrian/North Levantine Arabic refugee overlay | 4,900,000 (2025) | Syrian/North Levantine Arabic; Modern Standard Arabic; each host-country language | DIRECT_STATUS_COHORT_DENOMINATOR_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Rohingya stateless cohort - script interfaces | 1,800,000 (2025) | Rohingya Hanifi; Rohingya Latin; Rohingya Arabic; Bangla and Myanmar host/transition interfaces | DIRECT_STATUS_COHORT_DENOMINATOR_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Sudan internal-displacement multi-language overlay | 9,100,000 (2025) | Sudanese Arabic; Dinka; Nuer; named Darfur and Nuba languages; each host-country language | DIRECT_STATUS_COHORT_DENOMINATOR_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Somali refugees — host-specific education portfolio | unmeasured | Somali Latin; Arabic where directly measured; each host-country language | SOURCE_DISCOVERY_REQUIRED_NO_POPULATION_ASSIGNED |
| South Sudanese refugees — host-specific education portfolio | unmeasured | Juba Arabic; Dinka; Nuer; Bari and other named languages; each host-country language | SOURCE_DISCOVERY_REQUIRED_NO_POPULATION_ASSIGNED |
| Ukrainian-language/curriculum continuity cohort among displaced learners from Ukraine (language not enumerated) | 700,000 (2023/24) | Ukrainian Cyrillic continuity; Russian where directly measured; each host-country language | DIRECT_ENROLLED_LEARNER_COHORT_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Venezuelan refugees and migrants — host-specific education portfolio | unmeasured | Venezuelan Spanish; Brazilian Portuguese and each other host-country language; Indigenous-language arms where directly evidenced | SOURCE_DISCOVERY_REQUIRED_NO_POPULATION_ASSIGNED |

## What the package alternatives test

- **P/F:** early-learning and foundational continuity, caregiver support, host-school entry, literacy/numeracy diagnostics, practice and answers.
- **S:** subject continuity, prerequisite alignment, worked examples and credential-transition support.
- **V:** digital, financial, health, workplace, legal-navigation and quantitative practical skills.
- **U:** prerequisite repair, academic-language bridges, notation/terminology and degree/credential navigation.
- **R:** advanced reference, research methods, executable examples and literature navigation.

Every package is offline-first and resumable, with mobile, accessible and print fallbacks where feasible. Host and origin languages are parallel arms whose overlap must be measured. Full and smaller modes are competing alternatives for the same endpoint; their beneficiaries cannot be added.

## Current evidence boundary

Six portfolios retain direct status/enrolled-learner context; four remain source-discovery obligations. The current contextual counts range from 700,000 to 9,100,000, but no cross-portfolio sum is reported because definitions, times, locations and overlap differ.

DRC, Somali, South Sudanese and Venezuelan profiles require bounded source discovery before even a status-cohort denominator can be used. Afghan, Palestinian, Syrian, Rohingya, Sudanese and Ukraine-school-continuity contexts have source-stated cohort values, but their exact language, host and stage distributions remain unresolved. No current language route inherits those totals.

## Outputs

- `structured/DISPLACEMENT_PACKAGE_NEEDS_20260904.json`: source-bound profiles, stage templates and restrictions.
- `structured/DISPLACEMENT_PACKAGE_EXTENSION_v1.json`: ten profiles, six packages and 120 comparison routes.
- `qa/DISPLACEMENT_PACKAGE_NEEDS_QA_v1.json`: identity, stage, pairing, missingness, nonadditivity and no-rank checks.
