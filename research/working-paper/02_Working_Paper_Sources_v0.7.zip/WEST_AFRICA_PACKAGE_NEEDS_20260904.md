# West African language and educational-package needs

**Status:** bounded official-source omission checkpoint; not an exhaustive West African census, language ranking, beneficiary count or final allocation recommendation.

## Main finding

The strongest evidenced package is not the same in every country or language. Nigeria's survey directly exposes foundational reading and numeracy deficits and a language-assessment gap. Senegal supplies language-by-language literacy rates alongside large secondary, vocational and out-of-school gaps. Mali documents very low progression through secondary education, but its inspected language tables collapse all national languages. Ghana names exact literacy languages in the questionnaire, while the national table aggregates most as 'Ghanaian language'. These are different evidence states and must not be forced into one league table.

## Nigeria: foundational recovery plus subject-language transition

Nigeria's 2021 MICS reports foundational reading skills for 26.8% and foundational numeracy for 25.3% of assessed children aged 7-14. North-east and north-west totals are still lower, but they are regional, not Hausa, Kanuri or Fulfulde rates. Reading tasks were offered in English, Yoruba, Hausa and Igbo; 8% of interviewed children could not be evaluated in their home or school language (NBS Nigeria & UNICEF, 2022, PDF p. 60).

The current federal policy announcement places English as the medium from primary through tertiary while encouraging study of Nigerian languages. That creates a concrete comparison: a complete exact-language sequence versus a smaller exact-language-to-English subject bridge. The announcement does not prove implementation, English comprehension, or the effect of either package.

## Ghana: exact labels exist, but the published aggregate cannot choose an edition

Among 26,210,872 people aged six or older, Ghana reports 7,924,409 not literate in any language and 18,286,463 literate. Of the literate population, 9,662,938 are reported literate in a Ghanaian language, 17,610,870 in English and 183,443 in Hausa. Responses can contain multiple languages, so these columns overlap (Ghana Statistical Service, 2021, Volume 3D, Table 5.7).

The questionnaire separately names Akuapem Twi, Asante Twi, Fante, Nzema, Ga, Dangme, Ewe, Dagbani, Gonja, Dagaare, Kasem, Gruni and Hausa. But the inspected national table publishes one Ghanaian-language aggregate rather than a count for each label. Separately, the ethnic table reports 13,925,576 Akan, 5,638,881 Mole-Dagbani, 3,902,009 Ewe and 2,153,562 Ga-Dangme people among Ghanaian respondents. Ethnic identity is not literacy, language use, educational comfort, or a defensible denominator for a single edition.

## Mali: large stage gaps, exact national-language split missing

Mali reports national gross/net enrolment of 62.8/44.9% in fundamental 1, 43.8/22.4% in fundamental 2 and 36.4/15.2% at secondary level. Literacy among people aged 15+ is 34.6%; 61.2% of people aged 6+ are recorded with no instruction level and 2.9% at higher level (INSTAT Mali, 2025).

The report's synoptic table and Table 4.7 publish different language-of-literacy values: 15.5% versus 19.9% for one unspecified national language, 62.4% versus 70.3% for French, 18.5% versus 25.3% for English and 7.5% versus 8.2% for Arabic. Both readings are retained. Neither supports assigning the aggregate to Bambara, N'Ko, Fulfulde, Soninke, Songhay, Dogon, Senufo or another exact language.

## Senegal: direct language rates and stage-specific gaps

Senegal reports 13,108,118 residents aged 10+ and 8,151,034 literate in at least one language (62.2%). Table II7 reports literacy rates of 37.5% in French, 14.9% in Wolof, 11.9% in Arabic, 6.1% in Pulaar, 2.0% in Sereer, 0.8% in Mandingue, 0.6% in Diola and 0.3% in Soninke. These language rates may overlap and cannot be added. The 2023 coding list contains 22 national-language labels plus Arabic, several of which still require exact-variety crosswalks (ANSD, 2025, Tables II6-II7).

The same report records 20.9% of compulsory-age children as never having attended school and 40.7% as out of school; those are different constructs. It reports 91.0% of residents aged 6+ with no vocational training. The selected formal-system level counts do not exhaust the reported total, so no missing category is silently invented.

## What should be compared

1. Early learning: oral language, picture stories, pre-numeracy, caregiver prompts and audio, compared with a smaller sidecar to existing material.
2. Foundational self-study: reading, arithmetic and introductory science with diagnostics, exercises and explained answers, usable offline without assuming a continuously available teacher.
3. Secondary STEM and language transition: complete mathematics/science sequences versus exact-language-to-English or exact-language-to-French subject bridges.
4. Vocational and practical learning: bookkeeping, household and enterprise finance, agriculture, public health, measurement, data and digital skills, localized to tasks and institutions.
5. University foundations: calculus, linear algebra, statistics, computing, physical/life science, accounting and scientific writing, compared with prerequisite and terminology bridges.
6. Research access: complete advanced open editions versus terminology, theorem/navigation, abstract, example and citation layers. Formal structure may make smaller mathematical bridges useful, but the retained-benefit factor remains empirical.

Every package must compare a complete independently usable edition with a smaller bridge, count existing resources rather than assume absence, include phone-readable/offline/print delivery where relevant, and measure English/French/Arabic overlap rather than treating official use as universal access.

## Interlanguage and shared-register tests

Manding and Fula are the clearest West African shared-register hypotheses in this checkpoint. Bambara, Mandinka and Dyula must remain distinct while an N'Ko layer is tested for actual readers. Nigerian Fulfulde and Senegal Pulaar likewise remain separate until cross-variety comprehension and orthographic transfer are measured. The same safeguard applies to Akan/Twi/Fante, Hausa Boko/Ajami and Wolof Latin/Wolofal/Garay. Mathematical notation may reduce the prose burden, but it does not make a family name a comprehension result.

## Coverage and remaining evidence

The extension adds 72 unranked package comparisons across 44 visible profiles. 32 profiles remain visible without a fabricated intervention route. Missing matched evidence leaves them eligible at every stage and marks them as possible outrankers.

The next discriminating evidence is: exact language-by-age-and-stage learner denominators; current open-resource and licence inventories; comprehension in academic English/French/Arabic; exact script literacy; signed-language and audio access; delivery constraints; and matched outcomes for a complete sequence versus a smaller bridge. Additional West African country and exact-language packets remain required before regional coverage can be called broad.

## References

Agence Nationale de la Statistique et de la Demographie du Senegal. (2025). *RGPH-5 2023, Theme II: Alphabetisation, scolarisation, niveau d'instruction et formation professionnelle*. https://anads.ansd.sn/index.php/catalog/311/download/3095

Federal Ministry of Information and National Orientation, Nigeria. (2025, November 13). *FG reaffirms English as medium of instruction, launches inclusive language policy*. https://fmino.gov.ng/fg-reaffirms-english-as-medium-of-instruction-launches-inclusive-language-policy-to-promote-national-unity-2/

Ghana Statistical Service. (2021). *2021 Population and Housing Census General Report, Volumes 3C and 3D; PHC-1B questionnaire*. https://census2021.statsghana.gov.gh/

Institut National de la Statistique du Mali. (2025). *RGPH5 2022: Scolarisation, instruction et alphabetisation*. https://www.instat-mali.org/laravel-filemanager/files/shares/rgph/rapport-scolarisation-instruction-alphabetisation-rgph5_rgph.pdf

National Bureau of Statistics of Nigeria & UNICEF. (2022). *2021 Nigeria MICS and NICS: Statistical Snapshots Report*. https://www.nigerianstat.gov.ng/pdfuploads/2021%20MICS%20Statistical%20Snapshots%20Report.pdf
