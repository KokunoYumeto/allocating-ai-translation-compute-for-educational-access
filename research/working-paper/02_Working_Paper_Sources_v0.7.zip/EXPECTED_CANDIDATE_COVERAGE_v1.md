# Expected candidates and investigations still missing

The forecast names 100 candidates to investigate, not 100 ranked winners. This table shows which stages currently have a route in the bounded intervention calculation. An empty cell means work remains here—not that the language has no need, no evidence anywhere, or a low priority. Shared-register analyses are recorded separately.

Currently, 63 of the 100 expected profiles have at least one route here; 37 do not. Only 224 of the 600 possible forecast stage cells have such routes. This is research coverage, not educational coverage or a quality score.

P = preschool/early childhood; F = foundational/primary; S = secondary; V = vocational/practical; U = university; R = postgraduate/research. Preschool is now an explicit column rather than folded into foundation. Identifiers preserve the frozen forecast order; they are not ranks.

| ID | Expected candidate | Stages with current routes | Stages still without routes here |
|---|---|---|---|
| 001 | Indonesian | S | P, F, V, U, R |
| 002 | Hindi | U | P, F, S, V, R |
| 003 | Bangla | F, V | P, S, U, R |
| 004 | Standard Written Chinese, Simplified | U, R | P, F, S, V |
| 005 | Urdu | F | P, S, V, U, R |
| 006 | Telugu | U | P, F, S, V, R |
| 007 | Tamil | U | P, F, S, V, R |
| 008 | Marathi | U | P, F, S, V, R |
| 009 | Vietnamese | S | P, F, V, U, R |
| 010 | Hausa | P, F, S, V, U, R | None |
| 011 | Standard Kiswahili | S | P, F, V, U, R |
| 012 | Modern Standard Arabic | P, F, S, V, U, R | None |
| 013 | Brazilian Portuguese | F, S, V, U, R | P |
| 014 | Spanish, Latin American educational profiles | F, S, V, U, R | P |
| 015 | English, underserved learner profiles | None yet | P, F, S, V, U, R |
| 016 | French, underserved learner profiles | None yet | P, F, S, V, U, R |
| 017 | Turkish | None yet | P, F, S, V, U, R |
| 018 | Iranian Persian | P, F, S, V, U, R | None |
| 019 | Thai | S, V | P, F, U, R |
| 020 | Burmese | S | P, F, V, U, R |
| 021 | Filipino | F, S, V | P, U, R |
| 022 | Standard Malay, Malaysia | S | P, F, V, U, R |
| 023 | Gujarati | None yet | P, F, S, V, U, R |
| 024 | Kannada | None yet | P, F, S, V, U, R |
| 025 | Odia | None yet | P, F, S, V, U, R |
| 026 | Malayalam | None yet | P, F, S, V, U, R |
| 027 | Eastern Punjabi | None yet | P, F, S, V, U, R |
| 028 | Russian | S, V, U, R | P, F |
| 029 | Japanese | S, R | P, F, V, U |
| 030 | Korean, South Korean standard | None yet | P, F, S, V, U, R |
| 031 | Amharic | P, F | S, V, U, R |
| 032 | West-Central Oromo educational profile | P, F | S, V, U, R |
| 033 | Somali | F | P, S, V, U, R |
| 034 | Yoruba | P, F, S, V, U, R | None |
| 035 | Igbo | P, F, S, V, U, R | None |
| 036 | Kinyarwanda | F, S, V | P, U, R |
| 037 | Kirundi | S, V | P, F, U, R |
| 038 | Lingala | None yet | P, F, S, V, U, R |
| 039 | Central Kanuri | P, F, S, V | U, R |
| 040 | Wolof | P, F, S, V, U, R | None |
| 041 | Bambara | P, F, S, V, U, R | None |
| 042 | Pulaar | None yet | P, F, S, V, U, R |
| 043 | Nigerian Fulfulde | P, F, S, V | U, R |
| 044 | Zulu | F | P, S, V, U, R |
| 045 | Northern Sotho / Sepedi standard | F | P, S, V, U, R |
| 046 | Haitian Creole | P, F, S, V, U, R | None |
| 047 | Nepali | None yet | P, F, S, V, U, R |
| 048 | Sinhala | None yet | P, F, S, V, U, R |
| 049 | Northern Pashto | F | P, S, V, U, R |
| 050 | Dari | P, F, S, V, U, R | None |
| 051 | Sindhi, Pakistan standard | F | P, S, V, U, R |
| 052 | Saraiki | F | P, S, V, U, R |
| 053 | Bhojpuri | None yet | P, F, S, V, U, R |
| 054 | Maithili | None yet | P, F, S, V, U, R |
| 055 | Chhattisgarhi | None yet | P, F, S, V, U, R |
| 056 | Haryanvi | None yet | P, F, S, V, U, R |
| 057 | Santali | None yet | P, F, S, V, U, R |
| 058 | Sylheti | None yet | P, F, S, V, U, R |
| 059 | Chittagonian | None yet | P, F, S, V, U, R |
| 060 | Javanese | None yet | P, F, S, V, U, R |
| 061 | Sundanese | None yet | P, F, S, V, U, R |
| 062 | Cebuano | P, F, V | S, U, R |
| 063 | Central Khmer | S, V | P, F, U, R |
| 064 | Lao | F | P, S, V, U, R |
| 065 | Northern Uzbek / Uzbekistan standard | F, S, V, U, R | P |
| 066 | Kazakh | F, S, V, U, R | P |
| 067 | Tajik | P, F, S, V, U, R | None |
| 068 | Uyghur | F, S, V, U, R | P |
| 069 | Central Kurdish / Sorani | P, F, S, V, U, R | None |
| 070 | Northern Kurdish / Kurmanji | P, F, S, V, U, R | None |
| 071 | Ukrainian | S, V, R | P, F, U |
| 072 | Polish | None yet | P, F, S, V, U, R |
| 073 | Romanian | None yet | P, F, S, V, U, R |
| 074 | Bulgarian | None yet | P, F, S, V, U, R |
| 075 | Belarusian | None yet | P, F, S, V, U, R |
| 076 | Serbian standard | None yet | P, F, S, V, U, R |
| 077 | Tigrinya | F, S | P, V, U, R |
| 078 | Kabyle | None yet | P, F, S, V, U, R |
| 079 | Central Atlas Tamazight | None yet | P, F, S, V, U, R |
| 080 | Tachelhit | None yet | P, F, S, V, U, R |
| 081 | Ayacucho Quechua | P, F, S, V, U, R | None |
| 082 | Cusco Quechua | P, F, S, V, U, R | None |
| 083 | Paraguayan Guarani | P, F, S, V, U, R | None |
| 084 | Central Nahuatl | None yet | P, F, S, V, U, R |
| 085 | K'iche' | P, F, S, V, U, R | None |
| 086 | Tok Pisin | P, F, S, V, U, R | None |
| 087 | Bislama | P, F, S, V, U, R | None |
| 088 | Kalaallisut / West Greenlandic | P, F, S, V, U, R | None |
| 089 | American Sign Language | S, V, U, R | P, F |
| 090 | Brazilian Sign Language / Libras | F, S, V, U, R | P |
| 091 | Indian Sign Language | S, V, U, R | P, F |
| 092 | Kenyan Sign Language | F, S, V | P, U, R |
| 093 | South African Sign Language | S, V, U, R | P, F |
| 094 | Interslavic mathematical register | None yet | P, F, S, V, U, R |
| 095 | Hindi-Urdu shared mathematical register | None yet | P, F, S, V, U, R |
| 096 | Malay-Indonesian shared technical profile | None yet | P, F, S, V, U, R |
| 097 | Persian-Dari-Tajik shared technical profile | None yet | P, F, S, V, U, R |
| 098 | Oghuz-focused Inter-Turkic design hypothesis | None yet | P, F, S, V, U, R |
| 099 | N'Ko literary Manding educational profile | P, F, S, V, U, R | None |
| 100 | Romance mathematical intercomprehension profile | None yet | P, F, S, V, U, R |

## Challengers outside the frozen forecast

- Western/Pakistani Punjabi, Shahmukhi comparison profile: F; all six stages retained.
- Hiligaynon/Ilonggo: F; all six stages retained.
- Ilocano: F; all six stages retained.
- Bikol/Bicol: F; all six stages retained.
- Waray: F; all six stages retained.
- Kapampangan: F; all six stages retained.
- Maguindanao: F; all six stages retained.
- Pangasinan/Panggalato: F; all six stages retained.
- Filipino Sign Language: F, V; all six stages retained.
- Bisaya/Binisaya census aggregate: no route yet; all six stages retained.
- Tagalog home-language census label: no route yet; all six stages retained.
- Other Philippine home-language aggregate: no route yet; all six stages retained.
- Philippine household language not reported: no route yet; all six stages retained.
- Kyrgyz: F, S, V, U, R; all six stages retained.
- Turkmen: F, S, V, U, R; all six stages retained.
- Mongolian / Khalkha national standard: F, S, V, U, R; all six stages retained.
- Karakalpak: F, S, V, U; all six stages retained.
- Tuvan varieties in Mongolia: no route yet; all six stages retained.
- Southern Uzbek: no route yet; all six stages retained.
- Pamiri language identities (unresolved set): no route yet; all six stages retained.
- Central Asian signed-language profiles (unresolved set): no route yet; all six stages retained.
- Pulaar, Senegal: P, F, S, V, U, R; all six stages retained.
- Sereer-Sine / Senegal standard profile: P, F, S, V, U, R; all six stages retained.
- Mandinka, Senegal: P, F, S, V, U, R; all six stages retained.
- Soninke, Senegal: P, F, S, V, U, R; all six stages retained.
- Akuapem Twi, Ghana: no route yet; all six stages retained.
- Asante Twi, Ghana: no route yet; all six stages retained.
- Fante, Ghana: no route yet; all six stages retained.
- Nzema, Ghana: no route yet; all six stages retained.
- Ga, Ghana: no route yet; all six stages retained.
- Dangme, Ghana: no route yet; all six stages retained.
- Ewe, Ghana/Togo profiles: no route yet; all six stages retained.
- Dagbani, Ghana: no route yet; all six stages retained.
- Gonja, Ghana: no route yet; all six stages retained.
- Dagaare, Ghana: no route yet; all six stages retained.
- Kasem, Ghana: no route yet; all six stages retained.
- Gruni, Ghana census label: no route yet; all six stages retained.
- Hausa Ajami literacy profile: no route yet; all six stages retained.
- Central Kanuri Ajami literacy profile: no route yet; all six stages retained.
- Wolofal and Garay script profiles: no route yet; all six stages retained.
- Joola/Diola official census label: no route yet; all six stages retained.
- Other Senegal coded national-language profiles: no route yet; all six stages retained.
- Mali national-language literacy aggregate: no route yet; all six stages retained.
- West African signed-language profiles: no route yet; all six stages retained.
- Nigerian Pidgin: no route yet; all six stages retained.
- Krio, Sierra Leone: no route yet; all six stages retained.
- Moore, Burkina Faso: no route yet; all six stages retained.
- Fon, Benin: no route yet; all six stages retained.
- Mende, Sierra Leone: no route yet; all six stages retained.
- Temne, Sierra Leone: no route yet; all six stages retained.
- Liberia Kpelle: no route yet; all six stages retained.
- Guinea Kpelle: no route yet; all six stages retained.
- Susu, Guinea/Sierra Leone profiles: no route yet; all six stages retained.
- Cape Verdean Creole variety profiles: no route yet; all six stages retained.
- Guinea-Bissau Kriol: no route yet; all six stages retained.
- Dyula/Dioula country profiles: no route yet; all six stages retained.
- Mauritania Hassaniya, Pulaar, Soninke and Wolof profiles: no route yet; all six stages retained.
- Achi childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Central Aymara evaluation variety in La Paz, Bolivia: P, F, S, V, U, R; all six stages retained.
- Southern Aymara in Peru: P, F, S, V, U, R; all six stages retained.
- Kaqchikel childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Chol del noroeste in Mexico: P, F, S, V, U, R; all six stages retained.
- Chol del sureste in Mexico: P, F, S, V, U, R; all six stages retained.
- Anishinaabemowin (Chippewa), Canada Census category: P, F, S, V, U, R; all six stages retained.
- Inu Ayimun (Southern East Cree) in Canada: P, F, S, V, U, R; all six stages retained.
- Nehiyawēwin (Plains Cree) in Canada; Latin SRO resource stratum: P, F, S, V, U, R; all six stages retained.
- Iyiyiw-Ayimiwin (Northern East Cree) in Canada: P, F, S, V, U, R; all six stages retained.
- Ilimowin (Moose Cree) in Canada: P, F, S, V, U, R; all six stages retained.
- Nehinawewin (Swampy Cree) in Canada: P, F, S, V, U, R; all six stages retained.
- Nihithawiwin (Woods Cree) in Canada: P, F, S, V, U, R; all six stages retained.
- Guaraní Ñandéva pueblo/language in Paraguay: P, F, S, V, U, R; all six stages retained.
- Guarani Nhandeva in Brazil: P, F, S, V, U, R; all six stages retained.
- Guaraní Occidental / Pueblo Guaraní in Paraguay: P, F, S, V, U, R; all six stages retained.
- Paĩ Tavyterã pueblo/language in Paraguay: P, F, S, V, U, R; all six stages retained.
- Guarani Mbyá in Brazil: P, F, S, V, U, R; all six stages retained.
- Mbyá Guaraní pueblo/language in Paraguay: P, F, S, V, U, R; all six stages retained.
- Inuktitut in Canada (Census category; regional varieties/scripts unresolved): P, F, S, V, U, R; all six stages retained.
- Inuinnaqtun in Canada; Latin-script stratum: P, F, S, V, U, R; all six stages retained.
- Inga in Colombia: P, F, S, V, U, R; all six stages retained.
- Inuvialuktun in Canada; Statistics Canada category: P, F, S, V, U, R; all six stages retained.
- Ixil childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Jaqaru in Peru: P, F, S, V, U, R; all six stages retained.
- Q’eqchi’ childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Guarani Kaiowá in Brazil: P, F, S, V, U, R; all six stages retained.
- Q’anjob’al childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Mam childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Náhuatl central de Veracruz: P, F, S, V, U, R; all six stages retained.
- Náhuatl del centro de Puebla: P, F, S, V, U, R; all six stages retained.
- Mexicano de la Huasteca hidalguense: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Huasteca potosina: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Huasteca veracruzana: P, F, S, V, U, R; all six stages retained.
- Náhuatl del Istmo: P, F, S, V, U, R; all six stages retained.
- Náhuatl del Istmo bajo: P, F, S, V, U, R; all six stages retained.
- Mexicano de Guerrero: P, F, S, V, U, R; all six stages retained.
- Mexicano del oriente central: P, F, S, V, U, R; all six stages retained.
- Náhuatl del noroeste central: P, F, S, V, U, R; all six stages retained.
- Náhuatl de Oaxaca: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Sierra negra, norte: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Sierra negra, sur: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Sierra noreste de Puebla: P, F, S, V, U, R; all six stages retained.
- Náhuatl de la Sierra oeste de Puebla: P, F, S, V, U, R; all six stages retained.
- Avá Guarani in Brazil: P, F, S, V, U, R; all six stages retained.
- Ava Guaraní pueblo/language in Paraguay: P, F, S, V, U, R; all six stages retained.
- Oji-Cree / Anishininiimowin in Canada: P, F, S, V, U, R; all six stages retained.
- Saulteau (Western Ojibway) in Canada: P, F, S, V, U, R; all six stages retained.
- Daawaamwin (Odawa) in Canada: P, F, S, V, U, R; all six stages retained.
- Poqomchi’ childhood-language population in Guatemala: P, F, S, V, U, R; all six stages retained.
- Tseltal del oriente in Mexico: P, F, S, V, U, R; all six stages retained.
- Tseltal del norte in Mexico: P, F, S, V, U, R; all six stages retained.
- Tsotsil del centro in Mexico: P, F, S, V, U, R; all six stages retained.
- Tsotsil del norte alto in Mexico: P, F, S, V, U, R; all six stages retained.
- Tsotsil del noroeste in Mexico: P, F, S, V, U, R; all six stages retained.
- Maayat’aan / Yucatec Maya in Mexico: P, F, S, V, U, R; all six stages retained.
- Chuukese: P, F, S, V, U, R; all six stages retained.
- Drehu: P, F, S, V, U, R; all six stages retained.
- iTaukei Fijian: P, F, S, V, U, R; all six stages retained.
- ʻŌlelo Hawaiʻi: P, F, S, V, U, R; all six stages retained.
- Fiji Hindi: P, F, S, V, U, R; all six stages retained.
- Marshallese: P, F, S, V, U, R; all six stages retained.
- te reo Māori: P, F, S, V, U, R; all six stages retained.
- Nauruan: P, F, S, V, U, R; all six stages retained.
- Palauan: P, F, S, V, U, R; all six stages retained.
- Solomon Islands Pijin: P, F, S, V, U, R; all six stages retained.
- Paicî: P, F, S, V, U, R; all six stages retained.
- Rapa Nui: P, F, S, V, U, R; all six stages retained.
- Australian Kriol: P, F, S, V, U, R; all six stages retained.
- Yumplatok: P, F, S, V, U, R; all six stages retained.
- Tokelauan: P, F, S, V, U, R; all six stages retained.
- Unangam Tunuu: P, F, S, V, U, R; all six stages retained.
- Iñupiaq: P, F, S, V, U, R; all six stages retained.
- St. Lawrence Island Yupik / Yupigestun: P, F, S, V, U, R; all six stages retained.
- Tunumiisut / East Greenlandic: P, F, S, V, U, R; all six stages retained.
- Inuktun / Avanersuarmiutut: P, F, S, V, U, R; all six stages retained.
- North Sámi: P, F, S, V, U, R; all six stages retained.
- Lule Sámi: P, F, S, V, U, R; all six stages retained.
- South Sámi: P, F, S, V, U, R; all six stages retained.
- Inari Sámi: P, F, S, V, U, R; all six stages retained.
- Skolt Sámi: P, F, S, V, U, R; all six stages retained.
- Pite Sámi: P, F, S, V, U, R; all six stages retained.
- Ume Sámi: P, F, S, V, U, R; all six stages retained.
- Kildin Sámi: P, F, S, V, U, R; all six stages retained.
- Chaplinski Siberian Yupik: P, F, S, V, U, R; all six stages retained.
- Naukan Yupik: P, F, S, V, U, R; all six stages retained.
- Papua New Guinea named tok ples: no route yet; all six stages retained.
- Solomon Islands local-language set: no route yet; all six stages retained.
- Hiri Motu and Pure Motu: no route yet; all six stages retained.
- Australian Aboriginal and Torres Strait Islander language universe: no route yet; all six stages retained.
- Named Pacific signed languages: no route yet; all six stages retained.
- Hawaiʻi Sign Language: no route yet; all six stages retained.
- Pacific diaspora language-access strata: no route yet; all six stages retained.
- Samoan by territory and diaspora: no route yet; all six stages retained.
- Tongan by territory and diaspora: no route yet; all six stages retained.
- Gilbertese / Kiribati: no route yet; all six stages retained.
- Tuvaluan: no route yet; all six stages retained.
- Niuean: no route yet; all six stages retained.
- Cook Islands Māori varieties: no route yet; all six stages retained.
- Polynesian Outlier languages: no route yet; all six stages retained.
- Remaining circumpolar languages: no route yet; all six stages retained.
- Remaining Amazonian and Caribbean Indigenous languages: no route yet; all six stages retained.
- DRC refugees and internal displacement — host-specific education portfolio: P, F, S, V, U, R; all six stages retained.
- Afghan displaced multi-language overlay: P, F, S, V, U, R; all six stages retained.
- Palestinian Arabic refugee-status overlay: P, F, S, V, U, R; all six stages retained.
- Syrian/North Levantine Arabic refugee overlay: P, F, S, V, U, R; all six stages retained.
- Rohingya stateless cohort - script interfaces: P, F, S, V, U, R; all six stages retained.
- Sudan internal-displacement multi-language overlay: P, F, S, V, U, R; all six stages retained.
- Somali refugees — host-specific education portfolio: P, F, S, V, U, R; all six stages retained.
- South Sudanese refugees — host-specific education portfolio: P, F, S, V, U, R; all six stages retained.
- Ukrainian-language/curriculum continuity cohort among displaced learners from Ukraine (language not enumerated): P, F, S, V, U, R; all six stages retained.
- Venezuelan refugees and migrants — host-specific education portfolio: P, F, S, V, U, R; all six stages retained.

The next worldwide selection must explain every absent expected candidate and check the same selection rule across the wider universe. Neither appearing in this table nor accumulating more research notes confers a priority advantage.
