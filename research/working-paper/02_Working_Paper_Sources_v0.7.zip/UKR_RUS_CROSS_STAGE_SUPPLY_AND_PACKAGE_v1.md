# Ukraine and Russia: paired cross-stage evidence gate

This is an omission-control comparison, not a country ranking. It asks the same questions of two independently defined contexts and keeps their populations, languages, evidence and package implications separate. Russia's large education system and Russian-language catalogue do not cover Ukrainian; Ukrainian evidence does not stand in for Russia's 168 linked language nodes. Missing matched evidence never becomes zero need or a low position.

## What remains visible

The validated register contains **183 distinct Glottolog language-level nodes**: 32 linked to UA, 168 linked to RU, and 17 appearing in both registry associations. The union contains 1 bookkeeping node and 2 signed-language nodes. Country association is only a discovery link; it does not establish current residence, language use, literacy, vitality or educational need.

All 183 nodes retain P/F/S/V/U/R research obligations and null audience, effect, compute, currency, dominance and rank fields. **58 profiles** receive an explicit first evidence question; the remaining 125 stay visible possible outrankers rather than being classified as low need.

## Population and language observations are not interchangeable

The World Bank's latest retained country series reports 38,980,376 people for Ukraine in 2025 and 143,513,328 for the Russian Federation in 2025. Neither is a language audience. Ukraine's 2001 census reported 67.5% Ukrainian and 29.6% Russian as native language; those historical shares are not multiplied by current country or displacement totals. A 2026 KIIS sample in government-controlled Ukraine reported 62% mainly/always Ukrainian at home, 23% both and 14% mainly/always Russian, but excluded occupied-territory residents and people abroad. Its categories do not establish educational-language preference.

Eurostat reported 4.41 million people who fled Ukraine under temporary protection in the EU on 30 June 2026, with 29.6% minors. The rounded product is about 1,305,360, but it is demographic context, not a language, school-age or unmet-need count. The UN's statement that more than 250 million people speak Russian has no supplied denominator method, literacy or stage decomposition; it is retained only as a scale flag.

## Stage comparisons

The letters are use labels, not grades or ranks: **P** preschool/early childhood; **F** foundational/primary; **S** secondary; **V** vocational/practical; **U** university/taught tertiary; **R** postgraduate/research.

| Stage | Ukraine: strongest bounded signal | Russian Federation: strongest bounded signal | Package comparison |
|---|---|---|---|
| **P** | 83% of the assessed 15-year-old frame in 18 of 27 regions reported at least one year of pre-primary attendance; not current coverage. | 6.3853 million preschool enrolments; exact-language supply remains unmeasured. | For which exact child/caregiver language and modality does a complete or bounded package add usable early-learning tasks beyond current provision? |
| **F** | 2024 primary-completion indicator 94.572%; country-level, not a learning or language rate. | 2019 primary-completion indicator 100.024%; a gross/completion statistic can exceed 100 and is not an exact-language result. | Which exact-language complete route or smaller diagnostic bridge produces more new task access at the same foundational endpoint and standardized cost? |
| **S** | In PISA 2022's 18-region frame, 42% were below Level 2 in mathematics, 41% in reading and 34% in science. | The 2023 national PISA-based assessment reported 7.6% below basic mathematics, 7.4% reading and 11.2% science; not directly comparable to Ukraine's OECD frame. | At one secondary endpoint, does a complete sequence or a task-specific language/prerequisite bridge add more usable mathematics/science access after current supply is counted? |
| **V** | Matched trade/language audiences remain unmeasured; a recovery-training source is retained only as a locator. | 0.586 million skilled-worker and 3.265 million mid-level programme enrolments; participation is not unmet need. | Which exact language × trade × qualification × delivery combination adds demonstrable task access, and does a bounded bridge or complete course do so more efficiently? |
| **U** | Research-system disruption and missing-prerequisite routes are observed; exact gateway-course audiences remain unmeasured. | 4.432 million bachelor's/specialist's/master's enrolments plus large platform supply; current supply narrows additionality. | For which exact learner-language and gateway course does a complete route or smaller companion add successful task completion beyond current university/platform supply? |
| **R** | UNESCO reports 12% of scientists/university teachers relocated and about 30% of scientists remote by January 2024. | 125,900 postgraduate enrolments and substantial MCCME/Math-Net supply; exact modern topic, rights and accessibility gaps must be named. | At one prepared-reader research endpoint, which native-language, bilingual or experimental interlanguage package yields more additional usable access per standardized total cost? |

At every stage, a complete independently usable sequence competes with a smaller prerequisite, terminology, worked-answer, navigation, accessibility or host-language bridge at the same endpoint. Existing provision changes that comparison; it never reduces the underlying educational need of a population.

## Exact-language and displacement routes

Ukrainian and Russian remain separate edition profiles. Belarusian, Crimean Tatar, Bashkir, Tatar, four retained Romani nodes, Eastern Yiddish, Erzya, Lak, Lezgian, North-Central Dargwa, Kipchak Urum, Polish and every other intersection node remain separate too. Russia-only regional and circumpolar profiles—including Chechen, Avar, Chuvash, Sakha, Russia Buriat, Tuvinian, Mari, Udmurt, Komi, Moksha, Ossetian, Kabardian, Ingush, Kalmyk, Nenets, Evenki, Chukchi, Koryak, Nivkh, Aleut, Yupik and Yukaghir nodes—receive no automatic Russian coverage. The complete JSON retains every exact registry identity and question.

Ukrainian Sign Language and Russian-Tajik Sign Language are distinct signed-language nodes. Signed video, notation, regional variation, low-bandwidth segmentation and visual QA have production costs that written token traffic does not represent.

Displaced learners require host-curriculum routes rather than one refugee-language count. An EU package can pair Ukrainian explanation with the actual host instructional language and offer Russian terminology where the learner chooses it. Estonia's audited Russian-medium-to-Estonian route supports a distinct subject-language bridge; its 63% B1 observation is not transported to other countries.

## Interslavic remains a mathematics experiment

Mathematical notation and repeated formal structure may make a prepared-reader interlanguage more useful for mathematics than for ordinary prose. The comparison therefore retains worked-example, new-definition, proof and research-navigation tasks separately. It assigns no Interslavic comprehension rate, population or coverage. The bridge is more efficient than matched separate editions only if its retained additional benefit exceeds its total-cost ratio; the current evidence leaves that benefit unknown.

Ukrainian, Russian, Belarusian and Polish are initial exact candidate comparators, not communities declared covered. Script familiarity, prior study, directionality, subject knowledge and overlap with native editions must be explicit. Crimean Tatar, Romani, Yiddish, signed languages and non-Slavic Russia-linked languages are not Interslavic targets by association.

## Source baselines

All nine measured OpenStax source packages are retained: Prealgebra 2e, Introductory Statistics 2e, Biology 2e, Chemistry 2e, College Physics 2e, Principles of Management, Principles of Finance 2e, Anatomy and Physiology 2e, Introduction to Python Programming. Each is a complete-versus-bounded source-scale option, never an automatic recommendation. `forall x: Calgary`, the Open Logic modular corpus and the Stacks Project add introductory logic, intermediate/advanced logic and graduate/research algebraic-geometry baselines with distinct prerequisites and rights.

Russian provision is material: Yandex displays school mathematics/computing, Stepik an introductory statistics course, OpenEdu a large course/programme catalogue, MCCME full mathematical books and Math-Net journal archives. This is precisely why a Russian package must state the missing topic, prerequisite, format, accessibility feature or independent-study advantage. It does not justify excluding Russian learners, and it says nothing by itself about the exact needs of Russia's other languages. Ukraine's disruption evidence motivates portable, restartable and offline packages without implying that every Ukrainian learner lacks material.

## Decision

No Ukraine-versus-Russia, Ukrainian-versus-Russian or interlanguage-versus-native funding order is claimed. Exact addressable audience, incremental educational effect, physical compute, currency cost and dominance remain null. The next comparison binds one exact language/script/sign profile, stage, subject, prerequisites, current usable supply, complete and bounded source bytes, delivery modes and common endpoint. Until then, all 183 nodes remain eligible possible outrankers.

## Evidence and reproducibility

The source audit passes 257 checks across 359 preserved PDF pages, 11 page-bound claim groups, 13 local web-source groups, 10 World Bank indicators and 11 visually inspected renders. Its primary transport retained 25 of 38 bounded requests and recorded 13 failures; one supplement succeeded and 13 failed. Failed retrievals remain explicit locators, never evidence of absence.

Primary source URLs and exact hashes are in `qa/UKR_RUS_CROSS_STAGE_SOURCE_AUDIT_v1.json`; every language identity is in `structured/UKR_RUS_COUNTRY_LINKED_LANGUAGE_NODES_v1.csv`; package rows are in `structured/UKR_RUS_CROSS_STAGE_SUPPLY_AND_PACKAGE_v1.csv` and `.json`.
