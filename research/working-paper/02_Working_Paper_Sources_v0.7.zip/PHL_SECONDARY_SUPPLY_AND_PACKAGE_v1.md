# Philippines: what educational package would add access?

Status: bounded target checkpoint; not a language rank, effect estimate, or global completion claim.

## Result in ordinary language

The Philippines is not a no-materials case. It has thousands of official K-12 records and a broad ALS curriculum. The measurable problems are a very large secondary learning burden, strong English/Tagalog concentration in the current ALS catalog, fragmented records rather than demonstrated autonomous paths, an exact anonymous download barrier, non-universal connectivity, and a K-3 transition policy that makes first-language routes consequential. The strongest next comparison is therefore exact-language autonomous companions versus complete sequences at the same endpoint, plus distinct early-grade, ALS, FSL and access portfolios. No route can be ranked until its audience, added effect and standardized production cost are bound.

## What is directly measured

- The 2024 FLEMMS reports 60.17 million functionally literate people among an estimated 85.00 million people aged 10-64. The displayed difference is 24.83 million, derived from rounded values and not attributable to language.
- PISA 2022 represents 1,782,895.59 Philippine age-15 learners. Below-Level-2 estimates are 1,498,418.70 in mathematics (84.04%), 1,360,902.22 in reading (76.33%), and 1,376,890.20 in science (77.23%). These are overlapping learners and are never summed.
- From those three marginals alone, at least 1,498,418.70 and at most 1,782,895.59 represented learners were below Level 2 in at least one subject. This is a set-theoretic bound, not an estimated joint distribution.
- The 2020 census reports household language, not people: Tagalog 10,522,507; Bisaya/Binisaya 4,214,122; Hiligaynon/Ilonggo 1,933,512; Ilocano 1,863,409; Cebuano 1,716,080; Bikol/Bicol 1,033,457; and smaller published rows. Bisaya/Binisaya and Cebuano stay separate.

## Existing supply is substantial but not the same as usable progression

The current DepEd portal displays 2,053 Grade 7 records, including 717 mathematics and 383 science records. It therefore falsifies a blanket claim that Philippine foundation materials do not exist. It does not show that records are prerequisite-ordered, complete, independently usable, available in each learner's most comfortable language, or anonymously downloadable.

Two bounded subject-list samples were entirely English-labelled on their first 15 rows. The numbers-and-number-sense IP Education filter showed two English-labelled records, while its Madrasah and SPED filters showed no records. The corresponding category/list totals disagreed (172 versus 158; 93 versus 91), so catalog counts are retained as observations rather than treated as a clean course inventory.

The complete current ALS row census found:

| ALS stage | English | Tagalog | other labels | stage rows |
|---|---:|---:|---:|---:|
| Basic Literacy | 14 | 136 | 5 | 155 |
| Elementary | 118 | 48 | 4 | 170 |
| Secondary | 151 | 8 | 1 | 160 |

Across 485 stage rows there are 482 unique resource IDs. Only ten rows use non-English/non-Tagalog labels, and those include broad catalog labels that still require exact-language resolution. One advertised ALS mathematics download returned an anonymous authorization error. None of this proves that the files themselves are pedagogically weak; it identifies language, coherence, and delivery questions that the intervention must test.

## Delivery cannot assume continuous broadband

The 2024 National ICT Household Survey reports home internet for 48.8% of households and any-location internet use for 67.3% of people aged 10+. Among those internet users, 98.8% used a cellphone. That conditional cellphone share is not evidence that almost everyone owns a suitable phone. The package comparison therefore keeps phone-readable, download-once, printable/local-share, and fully offline modes together.

## Same-endpoint package alternatives

### 1. PHL-S-EXACT-LANGUAGE-AUTONOMOUS-FOUNDATION-COMPANIONS

Three separable but interoperable Grade VII-first companions in each justified exact language and script route: mathematics, reading/scientific language, and science, sharing diagnostics, navigation and an offline shell. Filipino and English are school-media references, not automatic substitutes for comfortable access.

**Common endpoint:** A learner can diagnose prerequisites, study the sampled Grade VII domains, practise, receive worked feedback, remediate errors, and continue offline without assuming continuous teacher access.

**Existing supply retained:** The Grade VII portal shows extensive mathematics and science records, including learner modules; the sampled lists are English-labelled and anonymously inaccessible at the tested endpoints.

**Language rule:** Commission Filipino, Cebuano, Ilocano, Hiligaynon, Waray or any other route only after binding the exact variety, orthography/script, learner stage, current supply and academic comprehension. Do not distribute national PISA burden by household shares.

### 2. PHL-S-COMPLETE-AUTONOMOUS-FOUNDATION-SEQUENCE

A complete independently usable lower-secondary mathematics, reading/scientific-language and science sequence in each justified exact language route, with prerequisites, exercises, answers, remediation and offline delivery.

**Common endpoint:** The same autonomous lower-secondary endpoint as the companion alternative, extended across a complete progression rather than selected bottlenecks.

**Existing supply retained:** Existing K-12 and ALS records remain valid supply; the complete option must show incremental coherence, language, access or feedback value rather than relabeling existing modules as absent.

**Language rule:** Compare exact-language editions independently. A national or macro label does not cover every home-language community, and a current program language does not prove comfortable comprehension.

### 3. PHL-PF-EXACT-L1-TO-FILIPINO-ENGLISH-TRANSITION-PORTFOLIO

Separate early-literacy and numeracy routes from each exact first language and orthography into Filipino and/or English under the current K-3 policy; no undifferentiated 'regional language' package.

**Common endpoint:** Learners build initial literacy/numeracy and reach a readiness-based transition into the school medium while retaining first-language scaffolding where useful.

**Existing supply retained:** The current policy recognizes regional languages as auxiliary/bridging media and allows defined exceptions. The portal contains isolated other-language resources, not a demonstrated complete route.

**Language rule:** Census labels are household rows, not people or beneficiaries. Keep Bisaya/Binisaya separate from Cebuano; resolve aggregated labels such as Bikol/Bicol and Manobo before production.

### 4. PHL-FV-ALS-EXACT-LANGUAGE-AUTONOMOUS-PATHWAY

Exact-language autonomous ALS pathways across communication, science/critical thinking, mathematics, life/career, self/society and digital citizenship, compared with a smaller terminology, navigation, feedback and offline-access layer over lawful existing modules.

**Common endpoint:** An out-of-school youth or adult can select a route, study independently, practise, receive explained feedback, and prepare for the relevant equivalency or work-readiness endpoint.

**Existing supply retained:** The current catalog contains 485 stage rows and the official program already spans six strands and life skills. Its visible language labels are concentrated in English and Tagalog, and one anonymous download test failed.

**Language rule:** Treat each exact language separately; portal labels and the seven FLEMMS questionnaire languages are locators, not proof of complete educational coverage.

### 5. PHL-FSL-SIGNED-INDEPENDENT-STUDY

Filipino Sign Language video with accessible text, diagrams, captions and transcripts, beginning with autonomous numeracy, scientific reasoning, practical finance and digital citizenship and extending by stage.

**Common endpoint:** FSL users can access explanations and assessments directly in a signed language while retaining searchable text and visual mathematical structure.

**Existing supply retained:** The K-3 policy names FSL as the medium for deaf and hard-of-hearing learners. This does not establish a complete autonomous signed-resource supply at any stage.

**Language rule:** Measure signing and written-language comfort separately; do not infer a signing population from a hearing-loss count or treat captions as a signed edition.

### 6. PHL-ACCESS-OFFLINE-ACCESSIBILITY-LAYER

Semantic HTML/MathML, reflowable EPUB, tagged PDF, printable units, low-bandwidth audio/video, keyboard and screen-reader navigation, local sharing and resumable offline progress.

**Common endpoint:** The same educational content remains usable under different device, bandwidth, sensory and access conditions.

**Existing supply retained:** Current internet and cellphone use is substantial but non-universal; an official portal can list a file while anonymous download remains blocked.

**Language rule:** This is a non-additive access layer, not a new language population and never a duplicate beneficiary count.

## How the nine OpenStax sources fit

The sources are donors and workload comparators, not automatic Philippine priorities. Prealgebra can support a Grade VII/ALS remediation endpoint; statistics a later data-literacy endpoint; biology, chemistry and physics later secondary or university endpoints; management and finance ALS/vocational/university progression; anatomy and physiology allied-health preparation; and Python a runnable digital-skills pathway. Existing ALS and Grade VII supply must be subtracted at the component level, not by declaring the whole population served.

The source file contains measured content-text token counts for complete books and bounded subsets. Those counts measure source size only. A target-language expansion factor, QA traffic, physical compute, money, effect and rank all remain null.

## What remains unknown

- exact comfortable academic-language audience at each stage and for each variety/script
- joint language-by-literacy, language-by-PISA and language-by-connectivity distributions
- completeness and prerequisite coherence of the current K-12 and ALS catalogs
- anonymous access state and exact reuse rights for every listed resource
- incremental educational access caused by each proposed package
- learning effects and durability
- actual target-language model token use and physical compute
- currency cost
- screen-reader, signed-video and low-end-device interoperability
- allocation rank or dominance

## Primary sources and local evidence

- Philippine Statistics Authority. (2023). *Tagalog is the Most Widely Spoken Language at Home (2020 Census of Population and Housing).*
- Philippine Statistics Authority. (2025). *For every 10 Filipinos, 9 have Basic Literacy, while 7 have Functional Literacy.*
- Philippine Statistics Authority. (2025). *Percentage of Households with Internet Connection Increased to 48.8 Percent in 2024; Two in Every Three Individuals Aged 10 Years and Over Used the Internet.*
- Department of Education. (2025). *Policy on the Medium of Instruction for Kindergarten to Grade 3 Effective School Year 2025-2026.*
- Department of Education. (observed 2026). *Learning Resources Management and Development System* K-12 and ALS catalogs and Terms of Use.
- OECD. (2023). *PISA 2022 Results, Volume I*, Annex A2 and Tables I.B1.3.1-I.B1.3.3, as source-bound in the project artifact.

Exact source paths, URLs, hashes, calculations and caveats are preserved in the JSON artifact and the linked source receipts.
