# Global country, territory and major-population omission audit

**Status:** bounded zero-disappearance and explicit-gap checkpoint; not a funding ranking and not the completed global study.

This audit answers a narrow but consequential question: can a country, territory, very large population context, signed-language obligation or evidence-poor geography disappear merely because the current research has not yet attached a usable intervention estimate? In this checkpoint, no. All 247 country, additional-locator and unlocated rows from the validated universal matrix survive in the CSV. Missing population or language evidence becomes an explicit research obligation, never zero need or a low rank.

The extended major-population gate covers all 31 country contexts at or above 50 million people. It contains both billion-person contexts and all 16 contexts at or above 100 million. These are country-scale sentinels only: country population is not a language population, a count of comfortable readers, unmet educational need, or expected beneficiaries.

## Hundred-million-person gate

| Country context | Population (year) | Current route state | Universal observed nodes / associated nodes | Signed-language local-source gap | Nonexhaustive next omission test |
|---|---:|---|---:|---|---|
| India | 1,463,865,525 (2025) | 14 explicit country/profile routes; not country coverage | 93 / 518 | yes | Complete all twenty-two Scheduled Language group stage profiles without treating census groups as exact varieties. |
| China | 1,406,585,000 (2025) | 2 explicit country/profile routes; not country coverage | 14 / 452 | yes | Separate Simplified Standard Written Chinese by stage and subject from spoken Sinitic varieties. |
| United States | 341,784,857 (2025) | 36 explicit country/profile routes; not country coverage | 6 / 323 | yes | Measure U.S. Spanish educational-resource gaps separately from Latin-American territory profiles. |
| Indonesia | 285,721,236 (2025) | 1 explicit country/profile routes; not country coverage | 8 / 756 | yes | Complete Indonesian stage and subject comparisons beyond the current secondary route. |
| Pakistan | 255,219,554 (2025) | 6 explicit country/profile routes; not country coverage | 13 / 86 | yes | Extend the current five-route census-margin work across P/F/S/V/U/R. |
| Nigeria | 237,527,782 (2025) | 32 explicit country/profile routes; not country coverage | 0 / 589 | yes | Bind language-specific stage need for Hausa, Yoruba, Igbo, Kanuri and Fulfulde instead of transferring national or zonal results. |
| Brazil | 212,812,405 (2025) | 40 explicit country/profile routes; not country coverage | 4 / 337 | yes | Measure Portuguese stage-specific open-resource gaps without treating national population as unmet need. |
| Bangladesh | 175,686,899 (2025) | 2 explicit country/profile routes; not country coverage; 12 context-only status-portfolio routes | 13 / 50 | yes | Extend Bangla beyond the current foundational and vocational routes. |
| Russian Federation | 143,513,328 (2025) | 24 explicit country/profile routes; not country coverage | 51 / 168 | yes | Audit Tatar, Bashkir, Chechen, Chuvash, Buryat, Sakha and other exact profiles independently. |
| Ethiopia | 135,472,051 (2025) | 12 explicit country/profile routes; not country coverage | 0 / 105 | yes | Bind region- and stage-specific need for Amharic, Oromo, Tigrinya and Somali profiles. |
| Mexico | 131,946,900 (2025) | 143 explicit country/profile routes; not country coverage | 18 / 339 | yes | Retain the fifteen routed INALI Nahuatl profiles and other Maya-family profiles as exact varieties. |
| Japan | 123,366,734 (2025) | 2 explicit country/profile routes; not country coverage | 0 / 25 | yes | Measure Japanese gaps by stage and subject, especially open advanced/research and accessible material, rather than using industrialization as a negative control. |
| Egypt, Arab Rep. | 118,365,995 (2025) | 14 context-only language routes; no country-specific route | 0 / 15 | yes | Separate Egyptian Arabic, Modern Standard Arabic and English/French academic overlap by stage. |
| Philippines | 116,786,962 (2025) | 15 explicit country/profile routes; not country coverage | 45 / 179 | yes | Continue exact household-language profiles beyond the current leading labels. |
| Congo, Dem. Rep. | 112,832,473 (2025) | 1 context-only language routes; no country-specific route; 12 country/status-portfolio routes | 2 / 244 | yes | Create country-specific Lingala, Congo Swahili/Kingwana, Tshiluba and Kituba/Kikongo profiles. |
| Viet Nam | 101,598,527 (2025) | 2 explicit country/profile routes; not country coverage | 2 / 120 | yes | Extend Vietnamese to all stages and compare subject-specific open-resource supply. |

The table deliberately shows that India and China are billion-person contexts while the United States, Indonesia, Pakistan, Nigeria, Brazil, Bangladesh, Russia, Ethiopia, Mexico, Japan, Egypt, the Philippines, the Democratic Republic of the Congo and Viet Nam all cross the hundred-million threshold. None is omitted. A national-language route cannot discharge the minority-, regional-, signed-, accessibility- or displacement-language obligations inside the same country.

## Extended 50-million gate

The additional contexts are Iran, Türkiye, Germany, Thailand, Tanzania, the United Kingdom, France, South Africa, Italy, Kenya, Myanmar, Colombia, South Korea, Sudan and Uganda. Each has a manual route crosswalk or an explicit no-route state in the structured sentinel file. No-route means **uninvestigated in the present comparison**, not unimportant, well served or ineligible.

## Whole-universe retention findings

- Complete country/additional-locator/unlocated rows retained: **247**.
- Rows with no country-population value retained: **34**.
- Rows whose associated language nodes have no observation anywhere in the current universal source set: **80**.
- Rows with at least one typed signed-language node but no locally linked signed-language source observation: **142**.
- Major contexts with explicit country/profile routes: **21 of 31**; context-only routes without a direct country profile: **5**; no current route crosswalk: **5**.

Those last three values are research-workflow diagnostics. They are not educational coverage rates. In particular, an explicit route can cover only one stage, subject, variety, script or modality, while a country may contain hundreds of other retained language nodes.

## Stage and package interpretation

The route ledger uses P = preschool/early learning, F = foundational/primary, S = secondary, V = vocational/practical, U = university and R = postgraduate/research. Presence at one stage never implies presence at another. Every major-population crosswalk therefore supplies nonexhaustive next tests rather than a single national verdict.

## Files

- `structured/GLOBAL_COUNTRY_TERRITORY_OMISSION_AUDIT_v1.csv`: all 247 retained rows, evidence-gap reasons and no-rank dispositions.
- `structured/MAJOR_POPULATION_SENTINELS_v1.json`: the complete ≥50-million gate, with exact route IDs, direct-versus-context-only distinctions, country metrics and omission prompts.
- `qa/GLOBAL_COUNTRY_TERRITORY_OMISSION_AUDIT_QA_v1.json`: deterministic source, arithmetic, retention, route-resolution and row-hash checks.

## Limits

This pass does not yet measure the marginal benefit of any route, audit every community within every country, or finish the stateless, displaced, diaspora, signed-language and accessibility portfolios. It makes those omissions visible and prevents country size, missing evidence or current route availability from silently deciding a funding order.
