# Anti-hegemony audit for educational-access reach models

**Status:** controlling method and deterministic failure specification. This
document governs the hybrid reach comparison and later package comparisons.
It is not a rhetorical caveat and it does not reduce any community's
eligibility.

## Governing position

The analysis presumes learner capability. Familiarity with the register that
schools, universities, publishers or professional institutions reward is an
unequally distributed access condition, not an intelligence measure. Schooling,
income, test performance, dominant-language exposure, formal literacy and
academic-register familiarity are entangled with earlier access to education
and resources. None may be used as a proxy for intrinsic capacity or as a
reason to withhold a potentially useful edition.

The register-translation programme is justified by a sufficiently plausible
access thesis: academic-register distance is one removable institutional
barrier, and a source-faithful translation that produces a credible nonzero
benefit is worth making. Research improves target selection, design, semantic
fidelity and evaluation. It is not a gate that can veto production by adopting
a deficit explanation.

## Access-potential model

For language/register community `l`, intersectional stratum `s`, and exact
content/register/task `d`, define:

`N_ld = sum_s(P_ls x q_lsd)`

`P_ls` is the plausible population of potential users. It includes people who
are not currently enrolled, people whose earlier education limited literacy,
displaced and diaspora populations, signing communities, and people requiring
non-print formats. `q_lsd` is the **source-user mismatch rate**: the share who
cannot reach the intended learning objective from the actual academic-English
source independently and comfortably enough for the task, without bespoke
human mediation. It is not a property of a language or a person. It changes
with domain, difficulty, genre, register, modality, supports and circumstances.

Here, “independently” permits ordinary assistive technology and culturally
normal collaborative learning. It does not mean solitary print reading.

When `q_lsd` is not measured comparably, the published hybrid comparison uses
the disclosed common imputation and wide sensitivity range. Research replaces
that imputation only when population, register threshold, task, stage and
material endpoint match. Missingness therefore widens uncertainty; it never
lowers the access-potential population.

## When another language or edition counts as coverage

An alternative `a` can reduce distinct reach only for people facing the
academic-source mismatch and only when the following joint gates pass:

| Gate | Question |
|---|---|
| Technical access | Can the person obtain and use it on the relevant device, bandwidth, encoding, font and offline conditions, without DRM blocking the use? |
| Linguistic access | Is the exact variety, register, script and modality intelligible for this task? |
| Material equivalence | Is it correct, complete enough, current, and matched to the same domain and educational level? |
| Voluntary acceptability | Is use socially and politically acceptable rather than merely compulsory, colonial, stigmatized or geopolitically coercive? |
| Disability access | Do captions, sign, screen-reader semantics, audio, visual, cognitive and motor-access requirements pass for the relevant stratum? |
| Practical availability | Is it affordable, discoverable and lawfully obtainable? |
| Safety and trust | Can it be used without unreasonable surveillance, identity exposure or other safety cost? |

Only a defensible lower bound on their **joint** satisfaction can be deducted.
Missing evidence for any indispensable gate means zero coverage deduction. The
model must not multiply marginal gate rates as though they were independent.
With marginal lower bounds `g_1 ... g_K`, the conservative Frechet lower bound
is `max(0, sum(g_k) - (K - 1))`; it will often correctly be zero.

For verified alternative coverage `o_lsd`, residual eligible reach is:

`R_ld = sum_s(P_ls x q_lsd x (1 - o_lsd))`

Delivery usability for the *proposed* new edition, `u_lsd`, remains separate:

`R_initial_ld = sum_s(P_ls x q_lsd x (1 - o_lsd) x u_lsd)`

A low `u_lsd` is a design problem to repair through offline, phone-readable,
audio, signed, printable or assistive formats. It is not evidence of lower
underlying need.

## Mechanisms that would reproduce privilege

| Exclusion mechanism | Prohibited shortcut | Required protection |
|---|---|---|
| Elite linguistic capital | University, urban or online-test respondents stand for everyone; ordinary English or years of schooling imply academic autonomy. | Use task-matched evidence, retain unsampled strata, and impute missing groups without a downward penalty. |
| Data abundance | Confidence or source count multiplies reach; complete-case filtering drops poorly documented communities. | Confidence changes interval width and research priority only. |
| National wealth | GDP, enrolment, internet access or predicted uptake lowers need. | Keep underlying need separate from production and delivery feasibility. |
| Colonial-language exposure | Official status, compulsory schooling or historical exposure proves proficiency or voluntary preference. | Require task competence and voluntary, safe, community-acceptable use. |
| Standard-language dominance | A macrolanguage, state standard or one orthography automatically covers local varieties, scripts, mixed codes or oral communities. | Use exact variety/register/script/modality gates; preserve every unresolved community. |
| Corpus and model abundance | Better NLP support or lower production cost makes a language more deserving. | Cost is operational information, never a need or eligibility multiplier. |
| Literacy norms | Only current readers enter the denominator. | Preserve people excluded from literacy and design audio, sign, visual and supported routes. |
| Able-bodied assumptions | An online PDF or uncaptioned video is called accessible. | Retain disability-specific strata and format gates. |
| Geopolitical coercion | Forced dominant-language use or a census label proves acceptable coverage. | Compulsion is non-evidence; record affiliation, safety and political acceptability separately. |
| Aggregate averaging | High-proficiency elites suppress rural, classed, gendered, caste, disability, age or displaced tails. | Stratify where lawful and test aggregate results for masking and Simpson reversals. |
| Population thresholds | Small communities disappear from a headcount order. | Publish raw headcount separately from protected inclusion, rights, vitality and prestige-domain lanes. |
| Material-count proxies | One title, one machine translation or a large catalogue proves coverage. | Require semantic, curricular, level, licensing and delivery equivalence for the same task. |
| “Bilingual” labels | Knowing another language proves access in every domain and register. | Count only an actually suitable alternative that passes every joint gate. |
| Prestige-English testing | Accent, grammar or conformity to British/American norms stands in for comprehension. | Test comprehension of the actual source; World Englishes are legitimate target and user registers. |
| English-first-language shortcut | English identity sets academic-source mismatch to zero. | Apply the same task/register test to English users and retain multiple adult English targets. |
| Deficit framing | The user is described as deficient rather than the source as inaccessible. | Describe removable source-user mismatch and assume intellectual capability. |

## Critical-theory crosswalk

The implementation must explicitly engage several partly overlapping bodies of
work rather than use “inclusion” as a generic label:

- **Linguistic capital and social reproduction:** institutions reward language
  practices unequally distributed through family and schooling; the model must
  not treat possession of the rewarded register as neutral evidence of lower
  need.
- **Critical EAP and EMI:** access to academic English can be useful while the
  institutions and norms that make it compulsory reproduce unequal power. A
  translation portfolio expands choices; it does not demand assimilation to a
  prestige register.
- **Raciolinguistics:** judgements of “appropriate,” “professional,” or
  “academic” language can reside in a powerful listener or institution rather
  than in objective communicative failure. Target design and QA must not encode
  white, elite or metropolitan listening norms as semantic correctness.
- **Linguistic imperialism and decolonial multilingual education:** colonial
  and global prestige languages cannot be credited as neutral substitutes
  merely because they are official or widespread. Language choice, local
  epistemologies, material control and the right to continue a local language
  in high-prestige domains remain visible.
- **World Englishes and English as a lingua franca:** there is no one universal
  non-academic English. Audience-specific adult registers may differ while
  preserving the same intellectual content.
- **Disability and signed-language justice:** written-language counts do not
  measure access for signing, blind, low-vision, print-disabled, DeafBlind,
  cognitive-access or motor-access communities.

These lenses do not convert structural disadvantage into an opaque bonus
score. They define denominators, prevent invalid coverage deductions, require
separate strata, and identify design obligations.

## Evidence supporting the audit design

The following sources support different parts of the audit. Theoretical work
identifies mechanisms and questions; qualitative cases show possible processes;
observational studies quantify associations or reported burdens; and experiments
support only their tested contrasts. None supplies a universal causal
coefficient for the allocation model.

| Source | Design and bounded finding | Operational use here |
|---|---|---|
| Bourdieu (1977), [The economics of linguistic exchanges](https://doi.org/10.1177/053901847701600601) | Sociological theory: linguistic value is produced in social markets and institutions help establish a legitimate discourse. | Do not mistake prestige-register conformity for intrinsic linguistic or intellectual quality. |
| Pennycook (1997), [Vulgar pragmatism, critical pragmatism, and EAP](https://doi.org/10.1016/S0889-4906(97)00019-7) | Critical analysis of EAP's claimed neutrality. | Present academic conventions as situated choices and power relations, not a natural benchmark that every target must imitate. |
| Lea and Street (1998), [Student writing in higher education](https://doi.org/10.1080/03075079812331380364) | Case study at two English universities: 23 staff and 47 students, using interviews, observation, assignments, feedback and guidance documents. The authors did not claim statistical representativeness. | Use discipline-aware register analysis and separate content fidelity from tacit institutional writing conventions. |
| Macaro et al. (2018), [Systematic review of English-medium instruction in higher education](https://doi.org/10.1017/S0261444817000350) | Mapped 285 empirical studies and reviewed 83 in depth. At that point, evidence did not settle broad claims that EMI improves English or harms/benefits content; regions were unevenly studied. | Give English-medium provision no assumed return premium and treat geographical evidence gaps as uncertainty, not lower need. |
| Flores and Rosa (2015), [Undoing appropriateness](https://doi.org/10.17763/0017-8055.85.2.149) | Critical synthesis: racialized speakers may be heard as deficient even when approximating supposedly appropriate forms. | Audit the model and evaluator with matched-meaning variety tests; standard-language matching alone cannot certify fairness. |
| Flores (2020), [From academic language to language architecture](https://doi.org/10.1080/00405841.2019.1665411) | Conceptual and ethnographic application argues that “academic language” can operate as a deficit-producing raciolinguistic ideology. | Describe multiple ways of constructing disciplinary meaning rather than remediating supposedly deficient speakers. |
| Hofmann et al. (2024), [Dialect prejudice predicts AI decisions about people's character, employability, and criminality](https://doi.org/10.1038/s41586-024-07856-5) | Matched-guise probing across GPT-2, RoBERTa, T5, GPT-3.5 and GPT-4 found different stereotyped and consequential outputs for African American English versus Standardized American English while propositional cues were held comparable. | Require dialect-counterfactual invariance and prohibit register or dialect from becoming a proxy for merit, readiness, risk or value. |
| Phillipson (1992), [Linguistic imperialism](https://books.google.com/books?id=4jVeGWtzQ1oC) | Historical and theoretical account of structural and cultural inequalities sustaining English dominance. | Treat official status, global centrality and market size as potentially endogenous to power, never as positive need weights. |
| Veronelli (2015), [The coloniality of language](https://digitalcommons.cortland.edu/wagadu/vol13/iss1/5/) | Historical-conceptual analysis of conquest, racialization and denial of colonized people as communicative agents. | Attribute uncertainty to system coverage and method rather than deficient speakers; retain pragmatic, cultural and epistemic expression. |
| Sah and Li (2024), [Translanguaging or unequal languaging?](https://doi.org/10.1016/j.learninstruc.2024.101904) | Four-month ethnography in one Nepalese EMI school: English-Nepali translanguaging coexisted with exclusion and stigmatization of Bhojpuri. | A national prestige language plus English cannot discharge exact home-language obligations. |
| Laitin, Ramachandran and Walter (2019), [The legacy of colonial language policies and their impact on student learning](https://doi.org/10.1086/700617) | Twelve Kom-medium primary schools were matched with twelve English-medium schools. The programme also changed teacher training and textbook supply, so language was not isolated; early advantages weakened after return to English-only schooling. | Investigate sustained local-language routes and never transplant the bundled programme's effect as a universal language coefficient. |
| Amano et al. (2023), [The manifold costs of being a non-native English speaker in science](https://doi.org/10.1371/journal.pbio.3002184) | Online self-report survey of 908 published environmental scientists across eight nationalities found substantial extra reported time and career burdens associated with working in English. Nationality categories are not individual proficiency measures. | Retain research-stage reading, writing and dissemination burdens and intersectional strata without generalizing the sample to all fields. |
| Blasi, Anastasopoulos and Neubig (2022), [Systematic inequalities in language technology performance](https://doi.org/10.18653/v1/2022.acl-long.376) | Global analysis across several NLP tasks found strong concentration in a small set of languages and showed that approximate GDP predicted NLP publication volume better than speaker population. The relation is associational. | Present tool and research abundance as an outcome needing audit, not evidence that already favored languages deserve more access compute. |
| Kreutzer et al. (2022), [Quality at a glance](https://doi.org/10.1162/tacl_a_00447) | Manual audit of 205 language-specific web corpora found at least 15 with no usable text and many with less than half acceptable sentences. | Raw crawl volume is not readiness or coverage; scarcity triggers provenance, language-ID and curation work rather than exclusion. |
| Nekoto et al. (2020), [Participatory research for low-resourced machine translation](https://doi.org/10.18653/v1/2020.findings-emnlp.195) | Participatory case study produced datasets and benchmarks for more than 30 African languages and enabled contributors without formal NLP training to make scientific contributions. | Treat institutional and geographic exclusion as part of low-resourcedness and budget for speaker/community governance, curation and evaluation. |
| UNESCO GEM (2025), [The right multilingual education policies can unlock learning and inclusion](https://www.unesco.org/gem-report/en/publication/right-multilingual-education-policies-can-unlock-learning-and-inclusion) | Global policy synthesis supports sustained home-language instruction and identifies material and implementation shortages. | Do not treat a brief transition to a dominant language as complete coverage; preserve local-language materials and implementation routes. |

The synthesis used by this model is an inference across these sources: observed
demand, corpus size, academic prestige and standardized-language visibility are
partly produced by earlier institutional investment and exclusion. They are not
neutral measurements of educational need.

## Allocation order without an opaque equity score

If a decision must be sequenced, use a transparent Pareto or lexicographic
view: (1) minimum coverage floor breaches; (2) worst-group source-user mismatch;
(3) stakes of the educational task; (4) directly documented burden; (5)
underserved users and locally expressed priorities; and only then (6) verified
marginal production cost. Publish unweighted headcounts beside any equity or
rights-based lane. GDP, revenue, citation volume, academic prestige, web share,
existing product use and colonial-language status receive no positive benefit
weight.

Observed demand is censored by availability, price, schooling and historical
exclusion. Data scarcity is therefore a repair signal: it routes work to
provenance, language identification, curation and evaluation instead of lowering
the target. A minoritized language also requires knowledge-in and knowledge-out
support; one-way extraction into a prestige language is not reciprocal access.

## Required deterministic tests

1. **Missingness monotonicity:** deleting evidence cannot lower inclusive
   planning reach or remove a row.
2. **Barrier monotonicity:** increasing `P` or `q` cannot lower reach.
3. **Joint-gate veto:** any false or unknown indispensable alternative gate
   makes the coverage deduction zero.
4. **Disaggregation safety:** splitting a stratum cannot lower the sum unless
   new verified coverage is discovered.
5. **Partition invariance:** splitting or merging identical populations without
   changing facts preserves aggregate reach.
6. **Label invariance:** changing only “language,” “dialect,” “official,” “L1”
   or “bilingual” labels has no numerical effect.
7. **Wealth counterfactual:** communities differing only in GDP, connectivity,
   enrolment, test participation or data density have identical underlying
   need.
8. **Colonial-status counterfactual:** official or compulsory prestige-language
   status cannot lower mismatch or create coverage without task evidence.
9. **World-Englishes counterfactual:** nonconformity to metropolitan accent or
   grammar cannot create mismatch if the actual source is understood; ordinary
   fluency cannot erase mismatch if the academic source is not understood.
10. **Tail audit:** recompute lawful class, rurality, gender, age, disability,
    displacement, caste/ethnicity and educational strata and flag aggregate
    masking.
11. **Source deletion:** removing any source cannot make a community disappear.
12. **Delivery separation:** worsening bandwidth or predicted uptake affects
    realizable delivery, not underlying need.
13. **Small-community retention:** no minimum-size or cost-per-person threshold
    can remove eligibility.
14. **No capability inference:** attainment, schooling and register familiarity
    do not appear in a formula as innate intellectual-capacity parameters.

## Hard failures

The model fails if a missing record becomes zero; if evidence confidence,
wealth, enrolment, literacy, connectivity, official status or NLP support
multiplies need downward; if an alternative creates coverage while a required
gate is unknown; if a standard variety erases a distinct variety, script,
modality or political community; if English first-language or bilingual status
forces mismatch to zero; if a point estimate is presented without provenance
and sensitivity; or if potential access is described as actual uptake or
learning.

The central rule is simple: absence of evidence may widen uncertainty and make
research more urgent, but it may never be converted into evidence of access.
