"""Independent readback audit for the reach and common-package comparison."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REACH_JSON = ROOT / "structured" / "GLOBAL_EDITION_REACH_BASELINE_v3.json"
REACH_CSV = ROOT / "structured" / "GLOBAL_EDITION_REACH_BASELINE_v3.csv"
PROXY_JSON = ROOT / "structured" / "GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.json"
PROXY_CSV = ROOT / "structured" / "GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv"
RECEIPT = ROOT / "qa" / "GLOBAL_REACH_AND_COMMON_PACKAGE_SOURCE_RECEIPT_v1.json"
OUT = ROOT / "qa" / "GLOBAL_REACH_AND_COMMON_PACKAGE_INDEPENDENT_AUDIT_v1.json"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def close(a: float, b: float, *, rel: float = 1e-11, abs_: float = 1e-6) -> bool:
    return math.isclose(a, b, rel_tol=rel, abs_tol=abs_)


def main() -> None:
    reach = json.loads(REACH_JSON.read_text(encoding="utf-8"))
    proxy = json.loads(PROXY_JSON.read_text(encoding="utf-8"))
    reach_csv = load_csv(REACH_CSV)
    proxy_csv = load_csv(PROXY_CSV)
    receipt = json.loads(RECEIPT.read_text(encoding="utf-8"))

    ranked = reach["all_ranked_rows"]
    computed = proxy["all_rows"]
    by_target = {(r["language_code"], r["script_code"]): r for r in ranked}
    proxy_by_target = {(r["language_code"], r["script_code"]): r for r in computed}

    failures: list[str] = []
    checks: dict[str, bool] = {}

    def check(name: str, value: bool) -> None:
        checks[name] = bool(value)
        if not value:
            failures.append(name)

    check("reach_json_csv_same_row_count", len(ranked) == len(reach_csv))
    check("proxy_json_csv_same_row_count", len(computed) == len(proxy_csv))
    check("unique_reach_ids", len({r["row_id"] for r in ranked}) == len(ranked))
    check("unique_proxy_ids", len({r["row_id"] for r in computed}) == len(computed))
    check("reach_positions_complete", [r["reach_position"] for r in ranked] == list(range(1, len(ranked) + 1)))
    check("proxy_positions_complete", [r["proxy_position"] for r in computed] == list(range(1, len(computed) + 1)))
    check(
        "reach_sort_reproduced",
        [r["row_id"] for r in ranked]
        == [
            r["row_id"]
            for r in sorted(
                ranked,
                key=lambda r: (-r["plausibly_helped_point"], r["edition_profile"], r["row_id"]),
            )
        ],
    )
    check(
        "proxy_sort_reproduced",
        [r["row_id"] for r in computed]
        == [
            r["row_id"]
            for r in sorted(
                computed,
                key=lambda r: (
                    -r["conditional_reach_per_million_fecu_point"],
                    r["edition_profile"],
                    r["row_id"],
                ),
            )
        ],
    )
    check("top100_reach_exact", reach["top100"] == ranked[:100])
    check("top100_proxy_exact", proxy["top100"] == computed[:100])

    q = float(reach["common_imputation"]["point"])
    formula_errors = []
    for row in ranked:
        expected = round(int(row["population_point"]) * q)
        if int(row["plausibly_helped_point"]) != expected:
            formula_errors.append(row["row_id"])
    check("all_reach_point_formulas_reproduced", not formula_errors)

    proxy_formula_errors = []
    for row in computed:
        expected = row["plausibly_helped_point"] / row["compute_scenario_point"] * 1_000_000
        expected_low = row["plausibly_helped_low"] / row["compute_scenario_high"] * 1_000_000
        expected_high = row["plausibly_helped_high"] / row["compute_scenario_low"] * 1_000_000
        if not (
            close(row["conditional_reach_per_million_fecu_point"], expected)
            and close(row["conditional_reach_per_million_fecu_low"], expected_low)
            and close(row["conditional_reach_per_million_fecu_high"], expected_high)
        ):
            proxy_formula_errors.append(row["row_id"])
    check("all_proxy_formulas_reproduced", not proxy_formula_errors)

    receipt_errors = []
    for item in receipt["files"]:
        path = ROOT / Path(item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            receipt_errors.append(item["path"])
    check("all_source_receipt_bytes_and_hashes_match", not receipt_errors)

    required = [("zh", "Hans"), ("id", "Latn"), ("hi", "Deva"), ("ru", "Cyrl"), ("uk", "Cyrl")]
    check("all_headline_targets_present", all(key in by_target and key in proxy_by_target for key in required))
    check("simplified_chinese_reach_first", by_target[("zh", "Hans")]["reach_position"] == 1)
    check("indonesian_direct_population_retained", by_target[("id", "Latn")]["population_point"] == 248_501_794)
    check("indonesian_override_explicit", by_target[("id", "Latn")]["research_overrides_baseline"] is True)
    check("ukrainian_not_missing", by_target[("uk", "Cyrl")]["plausibly_helped_point"] > 0)
    check("profile_ids_are_not_positions", all("position" not in r["row_id"].lower() for r in ranked[:100]))

    measured = [r for r in computed if r["compute_profile"] is not None]
    envelope = [r for r in computed if r["compute_profile"] is None]
    check("both_measured_and_common_compute_paths_used", bool(measured) and bool(envelope))
    check("common_envelope_rows_explicit", all(r["compute_binding"] == "COMMON_LANGUAGE_BLIND_ENVELOPE" for r in envelope))
    check("no_physical_compute_claim", all(r["physical_compute_status"] == "NOT_INFERABLE_FROM_TOKEN_EVENTS" for r in computed))
    check("no_final_allocation_claim", all("NOT_FINAL_ALLOCATION_ORDER" in r["allocation_status"] for r in computed))

    reach_csv_ids = [r["row_id"] for r in reach_csv]
    proxy_csv_ids = [r["row_id"] for r in proxy_csv]
    check("reach_csv_order_matches_json", reach_csv_ids == [r["row_id"] for r in ranked])
    check("proxy_csv_order_matches_json", proxy_csv_ids == [r["row_id"] for r in computed])

    report = {
        "schema": "interlanguage/global-reach-common-package-independent-audit/1.0.0",
        "status": "PASS" if not failures else "FAIL",
        "scope": (
            "Independent output/readback, position, arithmetic, source-identity, headline-retention, "
            "missing-compute fallback, and claim-boundary audit. It does not validate the common q scenario "
            "as an observed worldwide rate or turn token events into physical compute."
        ),
        "checks": checks,
        "check_count": len(checks),
        "failure_details": {
            "failed_checks": failures,
            "reach_formula_rows": formula_errors,
            "proxy_formula_rows": proxy_formula_errors,
            "receipt_files": receipt_errors,
        },
        "counts": {
            "reach_rows": len(ranked),
            "proxy_rows": len(computed),
            "measured_compute_rows": len(measured),
            "common_envelope_rows": len(envelope),
        },
        "headline_positions": {
            f"{code}-{script}": {
                "reach": by_target[(code, script)]["reach_position"],
                "common_package_proxy": proxy_by_target[(code, script)]["proxy_position"],
            }
            for code, script in required
        },
        "audited_outputs": [
            {"path": str(path.relative_to(ROOT)).replace("\\", "/"), "bytes": path.stat().st_size, "sha256": digest(path)}
            for path in [REACH_JSON, REACH_CSV, PROXY_JSON, PROXY_CSV, RECEIPT]
        ],
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if failures:
        raise AssertionError(report["failure_details"])
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
