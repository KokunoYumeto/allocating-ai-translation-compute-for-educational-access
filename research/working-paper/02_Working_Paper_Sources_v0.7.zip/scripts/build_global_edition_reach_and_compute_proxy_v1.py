"""Build the worldwide edition-reach and common-package workload comparisons.

This is deliberately two tables, not one ambiguous list:

1. potential reach under a common academic-English nonaccess scenario; and
2. potential reach per fresh-equivalent token event for the same 100,000-source-
   token text package and the same nominal QA target.

The second table is a workload-normalized reach proxy.  It is not the final
educational-allocation result because matched incremental educational effects,
delivery, physical compute, and beneficiary overlap remain incomplete.
"""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CLDR_DIR = ROOT / "sources" / "cldr48_language_population_20260906"
TERRITORY_INFO = CLDR_DIR / "territoryInfo.json"
LANGUAGE_NAMES = CLDR_DIR / "languages_en.json"
SCRIPT_NAMES = CLDR_DIR / "scripts_en.json"
TERRITORY_NAMES = CLDR_DIR / "territories_en.json"
LIKELY_SUBTAGS = CLDR_DIR / "likelySubtags.json"
CLDR_LICENSE = CLDR_DIR / "LICENSE"
ACADEMIC = ROOT / "structured" / "academic_language_nonoverlap.json"
HIGH_REACH = ROOT / "structured" / "HIGH_REACH_CONDITIONAL_EVIDENCE_CELLS_v1.csv"
COMPUTE_ESTIMATES = ROOT / "structured" / "standardized_compute_estimates.csv"
COMPUTE_ALIASES = ROOT / "structured" / "standardized_compute_language_alias_crosswalk.csv"
ISO_TABLE = ROOT / "qa" / "_standard_compute_tmp" / "iso-639-3.tab"
MACRO_TABLE = ROOT / "qa" / "_standard_compute_tmp" / "iso-639-3-macrolanguages.tab"

OUT_REACH_JSON = ROOT / "structured" / "GLOBAL_EDITION_REACH_BASELINE_v3.json"
OUT_REACH_CSV = ROOT / "structured" / "GLOBAL_EDITION_REACH_BASELINE_v3.csv"
OUT_COMPUTE_JSON = ROOT / "structured" / "GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.json"
OUT_COMPUTE_CSV = ROOT / "structured" / "GLOBAL_COMMON_PACKAGE_COMPUTE_PROXY_v1.csv"
OUT_MD = ROOT / "GLOBAL_REACH_AND_COMMON_PACKAGE_ALLOCATION_CHECKPOINT_v1.md"
OUT_QA = ROOT / "qa" / "GLOBAL_REACH_AND_COMMON_PACKAGE_ALLOCATION_QA_v1.json"
OUT_RECEIPT = ROOT / "qa" / "GLOBAL_REACH_AND_COMMON_PACKAGE_SOURCE_RECEIPT_v1.json"

SOURCE_COMMIT = "5eecf657671a24429cb0a67d627782184d755695"
Q_LOW = 0.70
Q_HIGH = 0.99
SPECIAL_CODES = {"und", "mul", "mis", "zxx"}
COMMON_COMPUTE_ID = "STD-ENV-100K-TEXT"
PACKAGE_DESCRIPTION = (
    "One 100,000-source-token, text-only educational package translated and "
    "checked to the independent-context-plus-deterministic-QA-v2 target"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def load_display_names(path: Path, branch: str) -> dict[str, str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return data["main"]["en"]["localeDisplayNames"][branch]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def parse_tag(tag: str) -> list[str]:
    return tag.replace("_", "-").split("-")


def explicit_script(tag: str) -> str | None:
    for part in parse_tag(tag)[1:]:
        if len(part) == 4 and part.isalpha():
            return part.title()
    return None


def resolve_script(tag: str, territory: str, likely: dict[str, str]) -> tuple[str, str]:
    direct = explicit_script(tag)
    if direct:
        return direct, "EXPLICIT_CLDR_TAG"
    normalized = tag.replace("_", "-")
    base = normalized.split("-", 1)[0]
    keys = [f"{normalized}-{territory}", f"{base}-{territory}", normalized, base]
    seen: set[str] = set()
    for key in keys:
        if key in seen:
            continue
        seen.add(key)
        resolved = likely.get(key)
        if not resolved:
            continue
        script = explicit_script(resolved)
        if script:
            return script, f"CLDR_LIKELY_SUBTAG:{key}->{resolved}"
    return "Zzzz", "UNRESOLVED_SCRIPT"


def fmt_people(value: int | float | None) -> str:
    if value is None:
        return "unmeasured"
    value = float(value)
    if value >= 1_000_000_000:
        return f"{value / 1_000_000_000:.3f} billion"
    if value >= 1_000_000:
        return f"{value / 1_000_000:.1f} million"
    return f"{value:,.0f}"


def profile_label(language_code: str, language_name: str, script: str, script_name: str) -> str:
    special = {
        ("zh", "Hans"): "Simplified Standard Written Chinese profile",
        ("zh", "Hant"): "Traditional Written Chinese profile",
        ("pa", "Guru"): "Punjabi, Gurmukhi-script profile",
        ("pa", "Arab"): "Punjabi, Shahmukhi/Perso-Arabic-script profile",
        ("sr", "Cyrl"): "Serbian, Cyrillic-script profile",
        ("sr", "Latn"): "Serbian, Latin-script profile",
    }
    return special.get((language_code, script), f"{language_name}, {script_name}-script profile")


def load_q_point() -> tuple[float, int, int]:
    academic = json.loads(ACADEMIC.read_text(encoding="utf-8"))
    seed = [r for r in academic["evidence_records"] if r.get("source_id") == "IND_C17_2011"]
    denominator = sum(int(r["denominator"]["value"]) for r in seed)
    nondeclared = sum(int(r["nonoverlap"]["base"]) for r in seed)
    return nondeclared / denominator, denominator, nondeclared


def load_iso() -> tuple[dict[str, str], dict[str, str], dict[str, list[str]], dict[str, str]]:
    rows = read_tsv(ISO_TABLE)
    part1_to_id = {r["Part1"]: r["Id"] for r in rows if r.get("Part1")}
    id_to_name = {r["Id"]: r["Ref_Name"] for r in rows}
    macro_members: dict[str, list[str]] = defaultdict(list)
    member_to_macro: dict[str, str] = {}
    for row in read_tsv(MACRO_TABLE):
        macro_members[row["M_Id"]].append(row["I_Id"])
        member_to_macro[row["I_Id"]] = row["M_Id"]
    return part1_to_id, id_to_name, dict(macro_members), member_to_macro


def load_direct_population_contexts() -> dict[tuple[str, str], list[dict]]:
    contexts: dict[tuple[str, str], list[dict]] = defaultdict(list)
    with HIGH_REACH.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("analytical_role") != "LANGUAGE_POPULATION_BASIS_ONLY":
                continue
            tag = row.get("language_tag_or_profile", "")
            parts = parse_tag(tag)
            if len(parts) < 2:
                continue
            code = parts[0]
            script = explicit_script(tag)
            if not script:
                continue
            # The Chinese source is stored under cmn while CLDR uses zh.
            if code == "cmn":
                code = "zh"
            point = row.get("population_base")
            contexts[(code, script)].append(
                {
                    "cell_id": row["cell_id"],
                    "label": row["label"],
                    "measure_class": row["measure_class"],
                    "population_low": int(float(row["population_low"])) if row.get("population_low") else None,
                    "population_point": int(float(point)) if point else None,
                    "population_high": int(float(row["population_high"])) if row.get("population_high") else None,
                    "definition": row.get("population_definition"),
                    "reference_year": row.get("population_reference_year"),
                    "source_ids": json.loads(row.get("source_ids_json") or "[]"),
                    "mapping_status": row.get("candidate_mapping_status"),
                    "exact_edition_audience_status": row.get("exact_edition_audience_status"),
                    "allowed_as_population_override": False,
                    "reason_not_automatic_override": (
                        "This is a speaking, first-language, home-language, or contextual population basis; "
                        "it does not by itself measure the independently usable audience for this written edition."
                    ),
                }
            )
    return contexts


def load_compute_profiles() -> tuple[dict[str, dict], dict, dict[tuple[str, str], dict]]:
    profiles: dict[str, dict] = {}
    common: dict | None = None
    with COMPUTE_ESTIMATES.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            cid = row["candidate_id"]
            if cid == COMMON_COMPUTE_ID:
                common = row
            prefix = "STD-MF-"
            suffix = "-100K-TEXT"
            if cid.startswith(prefix) and cid.endswith(suffix):
                profile = cid[len(prefix) : -len(suffix)]
                profiles[profile] = row
    if common is None:
        raise RuntimeError(f"Missing {COMMON_COMPUTE_ID}")

    aliases: dict[tuple[str, str], dict] = {}
    with COMPUTE_ALIASES.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("point_binding_allowed", "").lower() != "true":
                continue
            aliases[(row["source_language_code"], row["script_code"])] = row
    return profiles, common, aliases


def numeric_compute(row: dict) -> dict:
    return {
        "candidate_id": row["candidate_id"],
        "low": float(row["standard_compute_scenario_low"]),
        "point": float(row["standard_compute_scenario_base"]),
        "high": float(row["standard_compute_scenario_high"]),
        "unit": row["standard_compute_unit"],
        "status": row["estimate_status"],
    }


def main() -> None:
    territory_payload = json.loads(TERRITORY_INFO.read_text(encoding="utf-8"))
    territories = territory_payload["supplemental"]["territoryInfo"]
    likely = json.loads(LIKELY_SUBTAGS.read_text(encoding="utf-8"))["supplemental"]["likelySubtags"]
    language_names = load_display_names(LANGUAGE_NAMES, "languages")
    script_names = load_display_names(SCRIPT_NAMES, "scripts")
    territory_names = load_display_names(TERRITORY_NAMES, "territories")
    part1_to_id, id_to_name, macro_members, member_to_macro = load_iso()
    direct_contexts = load_direct_population_contexts()
    compute_profiles, common_raw, compute_aliases = load_compute_profiles()
    common_compute = numeric_compute(common_raw)
    q_point, q_denominator, q_nondeclared = load_q_point()

    per_profile_territory: dict[tuple[str, str], dict[str, dict]] = defaultdict(dict)
    script_resolution_counts: dict[str, int] = defaultdict(int)
    source_entries = 0
    for territory_code, territory in territories.items():
        territory_population = float(territory["_population"])
        grouped: dict[tuple[str, str], list[tuple[str, dict, float, str]]] = defaultdict(list)
        for exact_tag, details in territory.get("languagePopulation", {}).items():
            source_entries += 1
            base = exact_tag.split("_", 1)[0]
            if base in SPECIAL_CODES or details.get("_populationPercent") is None:
                continue
            script, resolution = resolve_script(exact_tag, territory_code, likely)
            script_resolution_counts[resolution.split(":", 1)[0]] += 1
            grouped[(base, script)].append(
                (exact_tag, details, float(details["_populationPercent"]), resolution)
            )

        for key, variants in grouped.items():
            maximum = max(v[2] for v in variants)
            selected = [v for v in variants if v[2] == maximum]
            all_tags = sorted({v[0] for v in variants})
            resolutions = sorted({v[3] for v in variants})
            per_profile_territory[key][territory_code] = {
                "territory_population": territory_population,
                "population_percent": maximum,
                "estimated_language_users": territory_population * maximum / 100.0,
                "maximum_tags": sorted(v[0] for v in selected),
                "all_observed_tags": all_tags,
                "script_resolution": resolutions,
                "official_statuses": sorted(
                    {
                        v[1]["_officialStatus"]
                        for v in variants
                        if v[1].get("_officialStatus")
                    }
                ),
            }

    rows: list[dict] = []
    for (language_code, script), territory_rows in per_profile_territory.items():
        population_unrounded = sum(v["estimated_language_users"] for v in territory_rows.values())
        population = round(population_unrounded)
        iso3 = part1_to_id.get(language_code, language_code if language_code in id_to_name else None)
        name = language_names.get(language_code)
        if not name and iso3:
            name = id_to_name.get(iso3)
        name = name or language_code
        sname = script_names.get(script, script)
        contributions = sorted(
            (
                {
                    "territory": code,
                    "territory_name": territory_names.get(code, code),
                    **details,
                }
                for code, details in territory_rows.items()
            ),
            key=lambda item: (-item["estimated_language_users"], item["territory"]),
        )
        contexts = direct_contexts.get((language_code, script), [])
        rows.append(
            {
                "row_id": f"CLDR48-EDITION:{language_code}-{script}",
                "language_code": language_code,
                "iso639_3": iso3,
                "language_name": name,
                "script_code": script,
                "script_name": sname,
                "edition_profile": profile_label(language_code, name, script, sname),
                "population_base": population,
                "population_base_unrounded": population_unrounded,
                "population_low": population,
                "population_point": population,
                "population_high": population,
                "population_selection_rule": "CLDR48_RESOLVED_SCRIPT_PROFILE",
                "population_measure": (
                    "CLDR 48 territory population multiplied by the maximum fluent-user percentage "
                    "for this language-and-resolved-script profile within each territory, then summed "
                    "across territories; includes L1 and L2 interface-fluent users"
                ),
                "academic_english_nonaccess_low": Q_LOW,
                "academic_english_nonaccess_point": q_point,
                "academic_english_nonaccess_high": Q_HIGH,
                "q_status": "COMMON_IMPUTATION_PENDING_COMPARABLE_EDITION_AUDIENCE_EVIDENCE",
                "plausibly_helped_low": round(population * Q_LOW),
                "plausibly_helped_point": round(population * q_point),
                "plausibly_helped_high": round(population * Q_HIGH),
                "research_overrides_baseline": False,
                "direct_population_contexts": contexts,
                "territory_count": len(territory_rows),
                "observed_cldr_tags": sorted(
                    {tag for v in territory_rows.values() for tag in v["all_observed_tags"]}
                ),
                "top_territory_contributions": contributions[:8],
                "all_territory_contributions": contributions,
                "iso_macrolanguage_members": sorted(macro_members.get(iso3 or "", [])),
                "iso_member_of_macrolanguage": member_to_macro.get(iso3 or ""),
                "nonadditivity": (
                    "This edition profile may overlap other languages, varieties, scripts, and multilingual rows; "
                    "do not sum rows into unique beneficiaries without an overlap model."
                ),
            }
        )

    # Exact source-bound Indonesian communicative-ability evidence is retained as
    # the point population for the Indonesian delivery-language profile.  It does
    # not establish literacy or the educational effect of a particular package.
    indonesian = next(
        (r for r in rows if r["language_code"] == "id" and r["script_code"] == "Latn"),
        None,
    )
    if indonesian:
        official = next(
            (
                c
                for c in indonesian["direct_population_contexts"]
                if c["cell_id"] == "LANG-LLPS-ID-ID-ABILITY-2022" and c["population_point"]
            ),
            None,
        )
        if official:
            cldr_value = indonesian["population_base"]
            point = int(official["population_point"])
            indonesian.update(
                {
                    "population_low": min(cldr_value, point),
                    "population_point": point,
                    "population_high": max(cldr_value, point),
                    "population_selection_rule": "DIRECT_BPS_2022_INDONESIAN_COMMUNICATIVE_ABILITY_POINT_WITH_CLDR_CONTEXT",
                    "population_measure": (
                        "Point: BPS weighted estimate of people aged 5+ able to understand and produce "
                        "comprehensible Indonesian; sensitivity bound also retains the lower CLDR interface-fluent aggregate"
                    ),
                    "plausibly_helped_low": round(min(cldr_value, point) * Q_LOW),
                    "plausibly_helped_point": round(point * q_point),
                    "plausibly_helped_high": round(max(cldr_value, point) * Q_HIGH),
                    "research_overrides_baseline": True,
                }
            )

    english_rows = [r for r in rows if r["language_code"] == "en"]
    ranked = [r for r in rows if r["language_code"] != "en"]
    ranked.sort(key=lambda r: (-r["plausibly_helped_point"], r["edition_profile"], r["row_id"]))
    for position, row in enumerate(ranked, 1):
        row["reach_position"] = position
        row["in_reach_top100"] = position <= 100
    for row in english_rows:
        row["reach_position"] = None
        row["in_reach_top100"] = False
        row["q_status"] = "SEPARATE_INTRALINGUAL_ACADEMIC_REGISTER_INTERVENTION"

    # Bind the identical 100k text package.  If a measured language/script
    # profile is absent, use the common envelope: missing tokenization evidence
    # never deletes or lowers a target merely because it is unmeasured.
    compute_rows: list[dict] = []
    for reach in ranked:
        iso3 = reach["iso639_3"]
        script = reach["script_code"]
        profile = f"{iso3}_{script}" if iso3 else None
        alias = compute_aliases.get((reach["language_code"], script))
        alias_limitation = None
        binding = "COMMON_LANGUAGE_BLIND_ENVELOPE"
        compute = common_compute
        if profile and profile in compute_profiles:
            compute = numeric_compute(compute_profiles[profile])
            binding = "DIRECT_ISO6393_SCRIPT_PROFILE"
        elif alias:
            alias_profile = f"{alias['profile_language_code']}_{script}"
            if alias_profile in compute_profiles:
                profile = alias_profile
                compute = numeric_compute(compute_profiles[alias_profile])
                binding = alias["relation_type"]
                alias_limitation = alias.get("proxy_limitation") or None
        else:
            profile = None

        eff_low = reach["plausibly_helped_low"] / compute["high"] * 1_000_000
        eff_point = reach["plausibly_helped_point"] / compute["point"] * 1_000_000
        eff_high = reach["plausibly_helped_high"] / compute["low"] * 1_000_000
        compute_rows.append(
            {
                "row_id": f"COMMON100K:{reach['language_code']}-{script}",
                "reach_row_id": reach["row_id"],
                "reach_position": reach["reach_position"],
                "language_code": reach["language_code"],
                "iso639_3": iso3,
                "language_name": reach["language_name"],
                "script_code": script,
                "edition_profile": reach["edition_profile"],
                "plausibly_helped_low": reach["plausibly_helped_low"],
                "plausibly_helped_point": reach["plausibly_helped_point"],
                "plausibly_helped_high": reach["plausibly_helped_high"],
                "compute_profile": profile,
                "compute_binding": binding,
                "compute_alias_limitation": alias_limitation,
                "compute_scenario_low": compute["low"],
                "compute_scenario_point": compute["point"],
                "compute_scenario_high": compute["high"],
                "compute_unit": compute["unit"],
                "compute_status": compute["status"],
                "conditional_reach_per_million_fecu_low": eff_low,
                "conditional_reach_per_million_fecu_point": eff_point,
                "conditional_reach_per_million_fecu_high": eff_high,
                "incremental_effect_assumption": (
                    "Held equal at one solely for the common-package workload-normalized reach proxy; "
                    "not an empirical educational-effect estimate"
                ),
                "delivery_assumption": "Held equal and excluded from this proxy",
                "overlap_treatment": "Standalone row only; portfolio marginal benefit not yet calculated",
                "physical_compute_status": "NOT_INFERABLE_FROM_TOKEN_EVENTS",
                "allocation_status": "CONDITIONAL_COMMON_PACKAGE_PROXY_NOT_FINAL_ALLOCATION_ORDER",
            }
        )

    compute_rows.sort(
        key=lambda r: (
            -r["conditional_reach_per_million_fecu_point"],
            r["edition_profile"],
            r["row_id"],
        )
    )
    for position, row in enumerate(compute_rows, 1):
        row["proxy_position"] = position
        row["in_proxy_top100"] = position <= 100

    reach_payload = {
        "schema": "interlanguage/global-edition-reach-baseline/3.0.0",
        "status": "WORKING_REACH_INPUT_NOT_FINAL_ALLOCATION",
        "question": (
            "For each language-and-script edition profile, how many interface-fluent or directly measured "
            "users could plausibly lack independent access to the academic-English source register under "
            "the disclosed common missing-data scenario?"
        ),
        "formula": "A_i = P_i * q_i",
        "common_imputation": {
            "point": q_point,
            "low": Q_LOW,
            "high": Q_HIGH,
            "seed_denominator": q_denominator,
            "seed_nondeclared_english": q_nondeclared,
            "warning": (
                "This is a preservation baseline derived from reported English non-declaration in selected "
                "India Census rows, not an observed worldwide academic-English rate."
            ),
        },
        "source": {
            "dataset": "Unicode CLDR 48 territory language-population data",
            "commit": SOURCE_COMMIT,
            "definition": (
                "CLDR language population estimates people fluent enough to use a computer or smartphone "
                "interface and includes first- and second-language users."
            ),
        },
        "aggregation": {
            "source_entries": source_entries,
            "edition_rows": len(rows),
            "ranked_non_english_rows": len(ranked),
            "top100_rows": min(100, len(ranked)),
            "script_resolution_counts": dict(sorted(script_resolution_counts.items())),
        },
        "english_register_frontier": english_rows,
        "top100": ranked[:100],
        "all_ranked_rows": ranked,
    }
    compute_payload = {
        "schema": "interlanguage/global-common-package-compute-proxy/1.0.0",
        "status": "CONDITIONAL_WORKLOAD_NORMALIZED_REACH_NOT_FINAL_ALLOCATION",
        "research_question": (
            "Which target editions could expose the same fixed package to the most otherwise non-academic-English-accessible "
            "readers per standardized token-event workload, before target-specific effect, delivery, and overlap are known?"
        ),
        "package": PACKAGE_DESCRIPTION,
        "numerator": "Potential reach from GLOBAL_EDITION_REACH_BASELINE_v3",
        "denominator": (
            "Fresh-equivalent token-event workload scenario from standardized compute model 2.0.0; "
            "measured FLORES language/script representation where bound, otherwise the common envelope"
        ),
        "formula": "conditional proxy = plausibly helped people / fresh-equivalent token events",
        "critical_limits": [
            "Token-event workload is not physical compute, time, energy, money, or model quality.",
            "Incremental educational effect is held equal, not measured.",
            "Delivery and accessibility costs are held equal and excluded.",
            "Rows are standalone and nonadditive; multilingual, macro/member, script, and interlanguage overlap is not subtracted.",
            "The final allocation result requires target-specific endpoint effects and portfolio-marginal benefit per measured physical compute.",
        ],
        "top100": compute_rows[:100],
        "all_rows": compute_rows,
    }

    OUT_REACH_JSON.write_text(json.dumps(reach_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    OUT_COMPUTE_JSON.write_text(json.dumps(compute_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    reach_fields = [
        "reach_position", "row_id", "language_code", "iso639_3", "language_name", "script_code",
        "script_name", "edition_profile", "population_low", "population_point", "population_high",
        "population_selection_rule", "plausibly_helped_low", "plausibly_helped_point",
        "plausibly_helped_high", "q_status", "research_overrides_baseline", "territory_count",
        "iso_member_of_macrolanguage", "iso_macrolanguage_member_count", "direct_population_context_ids_json",
        "nonadditivity",
    ]
    with OUT_REACH_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=reach_fields)
        writer.writeheader()
        for row in ranked:
            writer.writerow(
                {
                    **{key: row.get(key) for key in reach_fields},
                    "iso_macrolanguage_member_count": len(row["iso_macrolanguage_members"]),
                    "direct_population_context_ids_json": json.dumps(
                        [c["cell_id"] for c in row["direct_population_contexts"]], separators=(",", ":")
                    ),
                    "research_overrides_baseline": str(row["research_overrides_baseline"]).lower(),
                }
            )

    compute_fields = [
        "proxy_position", "row_id", "reach_position", "reach_row_id", "language_code", "iso639_3",
        "language_name", "script_code", "edition_profile", "plausibly_helped_low",
        "plausibly_helped_point", "plausibly_helped_high", "compute_profile", "compute_binding",
        "compute_scenario_low", "compute_scenario_point", "compute_scenario_high", "compute_unit",
        "conditional_reach_per_million_fecu_low", "conditional_reach_per_million_fecu_point",
        "conditional_reach_per_million_fecu_high", "physical_compute_status", "allocation_status",
    ]
    with OUT_COMPUTE_CSV.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=compute_fields)
        writer.writeheader()
        for row in compute_rows:
            writer.writerow({key: row.get(key) for key in compute_fields})

    reach_table = []
    for row in ranked[:100]:
        reach_table.append(
            f"| {row['reach_position']} | {row['edition_profile']} | {fmt_people(row['population_point'])} | "
            f"{fmt_people(row['plausibly_helped_point'])} | {fmt_people(row['plausibly_helped_low'])}–{fmt_people(row['plausibly_helped_high'])} | "
            f"{row['population_selection_rule']} |"
        )
    proxy_table = []
    for row in compute_rows[:100]:
        binding = row["compute_profile"] or "common envelope"
        proxy_table.append(
            f"| {row['proxy_position']} | {row['edition_profile']} | {row['reach_position']} | "
            f"{row['conditional_reach_per_million_fecu_point']:,.0f} | "
            f"{row['conditional_reach_per_million_fecu_low']:,.0f}–{row['conditional_reach_per_million_fecu_high']:,.0f} | {binding} |"
        )
    lookup = {(r["language_code"], r["script_code"]): r for r in ranked}
    proxy_lookup = {(r["language_code"], r["script_code"]): r for r in compute_rows}
    md = f"""# Worldwide reach and common-package allocation checkpoint

**Status:** ongoing research checkpoint. This restores the quantitative allocation chain; it is not the final package-specific allocation result.

## What is being answered

The research question remains: how should AI compute be distributed so that educational-material availability produces the greatest additional functional understanding for as many people as possible?

The answer needs more than one list. The first table estimates potential reach. The second asks how that reach changes when every target receives exactly the same {PACKAGE_DESCRIPTION.lower()}. Later target-specific tables must replace the held-equal assumptions with evidence about the actual stage, subject, baseline supply, learning effect, delivery conditions, accessibility work, reusable setup, and overlapping beneficiaries.

Profile IDs are never ranks. Ordinal positions appear only in columns explicitly named **Reach position** or **Common-package proxy position**.

## Result 1: potential reach under one common missing-data scenario

The point multiplier is {q_point:.2%}; the displayed sensitivity range is {Q_LOW:.0%}–{Q_HIGH:.0%}. Missing comparable academic-register evidence keeps the common scenario instead of deleting or lowering a target. Chinese in the Simplified-script profile is position {lookup[('zh', 'Hans')]['reach_position']}. Indonesian is position {lookup[('id', 'Latn')]['reach_position']} after retaining the direct 2022 BPS communicative-ability population as its point population. Russian is position {lookup[('ru', 'Cyrl')]['reach_position']}; Ukrainian is position {lookup[('uk', 'Cyrl')]['reach_position']} in the pinned CLDR reach layer. Those are potential-reach positions, not judgments about people or final funding positions.

| Reach position | Exact edition profile | Population point | Plausibly helped point | Sensitivity range | Population basis |
|---:|---|---:|---:|---:|---|
{chr(10).join(reach_table)}

## Result 2: the same package divided by standardized token-event workload

This is the first quantitative compute-allocation bridge. It holds the package and nominal QA target fixed, uses a measured language/script workload where a defensible binding exists, and otherwise uses the identical language-blind envelope. Missing tokenization evidence therefore cannot remove a row. The displayed unit is potential readers per one million fresh-equivalent token events.

It is a conditional proxy, not the final efficiency result: it assumes equal incremental educational effect and equal delivery. Fresh-equivalent token events are not physical compute, time, energy, money, or quality.

| Common-package proxy position | Exact edition profile | Reach position | Point readers per 1m FECU | Sensitivity range | Workload profile |
|---:|---|---:|---:|---:|---|
{chr(10).join(proxy_table)}

## Why the two orders can differ

Potential reach is the numerator. The common-package proxy divides it by an estimated end-to-end token-event workload for the same package. Script and tokenizer representation can change the workload estimate, but no claim is made that token counts capture all production difficulty. In the final model, a target with smaller potential reach can lead when a specific package produces a larger additional functional effect, costs less to produce and deliver, or uniquely reaches people not served by another edition.

## What remains before a final allocation claim

For each intervention the model still needs a named educational endpoint, an independently usable baseline, a defensible incremental effect, exposure and delivery pathways, accessibility costs, measured physical compute, reusable-work accounting, and beneficiary overlap. The correct final object is portfolio-marginal additional functional access per standardized physical compute, with uncertainty and reversal thresholds—not the nonordinal profile catalogue and not this common-package proxy alone.

English academic-to-non-academic register translation remains a coequal but analytically separate intervention because its production process and audience nonoverlap cannot be inferred from ordinary English fluency. Signed-language, accessibility-format, displaced-community, and evidence-supported interlanguage interventions likewise remain possible outrankers outside this spoken/written CLDR table.

## Source and nonadditivity cautions

CLDR 48 is an open locale-planning source. Its language-population estimates represent people fluent enough to use a computer or smartphone interface and include L1 and L2 users. Resolving likely scripts improves edition specificity but does not prove literacy in that script. Multilingual people, macrolanguages and constituent languages, and alternative scripts can overlap; these rows cannot be summed into a world total. The direct Indonesian population context measures communicative ability, not independent academic reading. All such distinctions are preserved in the machine-readable evidence.
"""
    OUT_MD.write_text(md, encoding="utf-8")

    source_paths = [
        TERRITORY_INFO, LANGUAGE_NAMES, SCRIPT_NAMES, TERRITORY_NAMES, LIKELY_SUBTAGS,
        CLDR_LICENSE, ACADEMIC, HIGH_REACH, COMPUTE_ESTIMATES, COMPUTE_ALIASES,
        ISO_TABLE, MACRO_TABLE,
    ]
    receipt = {
        "schema": "interlanguage/global-reach-common-package-source-receipt/1.0.0",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "cldr_commit": SOURCE_COMMIT,
        "files": [
            {
                "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in source_paths
        ],
        "credential_material": False,
    }
    OUT_RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    top_reach = ranked[:100]
    top_proxy = compute_rows[:100]
    unresolved_top_names = [r["row_id"] for r in top_reach if r["language_name"] == r["language_code"]]
    unresolved_top_scripts = [r["row_id"] for r in top_reach if r["script_code"] == "Zzzz"]
    checks = {
        "cldr_version_48": territory_payload["supplemental"]["version"]["_cldrVersion"] == "48",
        "source_inputs_hashed": len(receipt["files"]) == len(source_paths),
        "at_least_100_non_english_edition_rows": len(ranked) >= 100,
        "exactly_100_reach_rows": len(top_reach) == 100,
        "reach_positions_contiguous": [r["reach_position"] for r in top_reach] == list(range(1, 101)),
        "exactly_100_proxy_rows": len(top_proxy) == 100,
        "proxy_positions_contiguous": [r["proxy_position"] for r in top_proxy] == list(range(1, 101)),
        "simplified_chinese_first_reach": lookup[("zh", "Hans")]["reach_position"] == 1,
        "indonesian_present": ("id", "Latn") in lookup,
        "russian_present": ("ru", "Cyrl") in lookup,
        "ukrainian_present": ("uk", "Cyrl") in lookup,
        "no_missing_reach_points": all(r["plausibly_helped_point"] is not None for r in ranked),
        "no_missing_compute_points": all(r["compute_scenario_point"] > 0 for r in compute_rows),
        "all_reach_intervals_ordered": all(
            r["plausibly_helped_low"] <= r["plausibly_helped_point"] <= r["plausibly_helped_high"]
            for r in ranked
        ),
        "all_proxy_intervals_ordered": all(
            r["conditional_reach_per_million_fecu_low"]
            <= r["conditional_reach_per_million_fecu_point"]
            <= r["conditional_reach_per_million_fecu_high"]
            for r in compute_rows
        ),
        "no_unresolved_top100_names": not unresolved_top_names,
        "no_unresolved_top100_scripts": not unresolved_top_scripts,
        "english_register_separate": bool(english_rows),
        "profile_ids_not_positions": all(
            not r["row_id"].endswith(f":{r['reach_position']}") for r in top_reach
        ),
        "all_rows_warn_nonadditive": all(r.get("nonadditivity") for r in ranked),
        "missing_compute_uses_common_envelope": all(
            r["compute_profile"] is not None or r["compute_binding"] == "COMMON_LANGUAGE_BLIND_ENVELOPE"
            for r in compute_rows
        ),
        "physical_compute_not_claimed": all(
            r["physical_compute_status"] == "NOT_INFERABLE_FROM_TOKEN_EVENTS" for r in compute_rows
        ),
        "zero_final_allocation_claims": all(
            r["allocation_status"] == "CONDITIONAL_COMMON_PACKAGE_PROXY_NOT_FINAL_ALLOCATION_ORDER"
            for r in compute_rows
        ),
    }
    if not all(checks.values()):
        raise AssertionError({
            "failed": [k for k, v in checks.items() if not v],
            "unresolved_top_names": unresolved_top_names,
            "unresolved_top_scripts": unresolved_top_scripts,
        })
    qa = {
        "schema": "interlanguage/global-reach-common-package-qa/1.0.0",
        "status": "PASS",
        "checks": checks,
        "check_count": len(checks),
        "counts": {
            "reach_rows": len(ranked),
            "compute_rows": len(compute_rows),
            "measured_compute_bindings": sum(r["compute_profile"] is not None for r in compute_rows),
            "common_envelope_bindings": sum(r["compute_profile"] is None for r in compute_rows),
        },
        "headline": {
            "reach": {
                f"{code}-{script}": {
                    "position": lookup[(code, script)]["reach_position"],
                    "population_point": lookup[(code, script)]["population_point"],
                    "plausibly_helped_point": lookup[(code, script)]["plausibly_helped_point"],
                }
                for code, script in [("zh", "Hans"), ("id", "Latn"), ("hi", "Deva"), ("ru", "Cyrl"), ("uk", "Cyrl")]
            },
            "proxy": {
                f"{code}-{script}": {
                    "position": proxy_lookup[(code, script)]["proxy_position"],
                    "reach_position": proxy_lookup[(code, script)]["reach_position"],
                    "readers_per_million_fecu_point": proxy_lookup[(code, script)]["conditional_reach_per_million_fecu_point"],
                }
                for code, script in [("zh", "Hans"), ("id", "Latn"), ("hi", "Deva"), ("ru", "Cyrl"), ("uk", "Cyrl")]
            },
        },
        "outputs": [
            {
                "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in [OUT_REACH_JSON, OUT_REACH_CSV, OUT_COMPUTE_JSON, OUT_COMPUTE_CSV, OUT_MD, OUT_RECEIPT]
        ],
    }
    OUT_QA.write_text(json.dumps(qa, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(qa, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
