# Pakistan cross-stage educational-access gate

**Evidence freeze:** 2026-09-05  
**Status:** high-consequence multilingual country context retained; no exact audience, effect, physical compute, currency cost, dominance relation or funding rank has been assigned.

## Plain-language result

Pakistan is not one language. The source-bound 2023 detailed census frame records 25,373,350 out-of-school children ages 5–16, while the country-linked register contains 86 language-level nodes: 83 non-bookkeeping, three bookkeeping and two signed-language nodes. Those facts make Pakistan a high-consequence place to investigate, but they do not say that one Urdu, English or other edition serves everyone.

The current evidence supports five broad kinds of work: exact child/caregiver-language early learning and school re-entry; secondary mathematics, statistics and scientific-reading bridges; qualification-bound practical and vocational courses; university gateway and prerequisite support; and advanced source chains for prepared researchers. Each must be compared as a complete route and as a smaller bounded package. Existing textbooks, accelerated programmes and digital libraries change what adds value; they do not erase need.

## What is measured by stage, and what to compare

P = preschool; F = foundational/primary; S = secondary; V = vocational/practical; U = university; R = postgraduate/research.

| Stage | Non-additive context | Existing supply signal | Complete comparison | Bounded comparison |
|---|---|---|---|---|
| P — preschool / early childhood | gross enrolment ratio, pre-primary: 57 percent; participation in organised learning at age 4: 35 percent; primary schools offering early-childhood facilities: 32 percent | The education report records limited ECE facility coverage. A policy framework presents a mother-tongue-only prototype through Grade 3, while the current inclusive scheme displays Urdu/English literacy and English numeracy. These are competing design and supply signals, not a measured language effect. | An exact child-and-caregiver-language early sequence in oral language, picture stories, print readiness, number concepts, pattern, play and worked caregiver guidance, with separately specified print, audio, signed and tactile routes. | A source-bound oral-language and early-number sidecar for one exact community, with picture/audio/print variants and an explicit uncovered-scope manifest. |
| F — foundational / primary and school re-entry | children ages 5-16 in detailed census frame: 71270068 persons; out-of-school children ages 5-16: 25373350 persons; never attended school, ages 5-16: 20033448 persons; dropouts, ages 5-16: 5339902 persons; five selected census-category OOS union: [9929282, 25373350] logical-bound persons; non-formal education learners: 1073704 programme enrolments | The NFE census records NFBE, adult literacy and 30-month primary / 18-month middle-tech accelerated routes. The inclusive scheme places mathematics in Urdu in A/B/C and D/E packages. National assessment used English, Urdu and Sindhi instruments. Exact-language supply beyond those displayed routes remains unmeasured, not absent. | A diagnostic-entry, exact-language literacy/numeracy-to-primary-completion route with age-respectful branches, explanations, abundant practice, worked answers, science/measurement/data reading, and offline print/phone/audio/signed options. | A diagnostic literacy/numeracy catch-up module for one exact language/script and one A/B/C or D/E transition, with worked feedback and a precise uncovered-scope manifest. |
| S — secondary education | gross enrolment ratio, middle: 59 percent; gross enrolment ratio, high school: 49 percent; gross enrolment ratio, higher secondary: 28 percent; Grade 8 mathematics mean: 42 percent correct; Balochistan Grade 8 mathematics mean: 30.6 percent correct; Grade 8 statistics and probability mean: 32.9 percent correct | Sindh exposes Urdu/Sindhi/English textbooks, Punjab reports 6.2 million Urdu/English books dispatched, Balochistan lists Primer-Grade 12 resources, NCC exposes Grades 6-8 teacher manuals, and eLearn is a web-only science/math locator. Portal and dispatch counts do not establish complete, open, accessible, independent-study supply. | A complete lower/upper-secondary route with mathematics, statistics, scientific reading, biology, chemistry, physics, computing, exercises and worked answers in an exact language/script and delivery profile. | A Grade-8 bridge in fractions-to-algebra, statistics/probability, graphs, scientific reading and one science bottleneck, aligned to a named curriculum and assessment endpoint. |
| V — vocational / practical education | National Vocational Qualifications Framework levels: 8 levels; visible NAVTTC report inventory: 19 reports; ALP middle / middle-tech learners: 38686 programme enrolments | The inclusive scheme names Matric-Tech, Inter-Tech, Functional Mathematics and Urdu-medium accelerated Middle-Tech; NAVTTC exposes an eight-level framework and policy/research reports. Exact trade, language, open-course, exercise/answer and offline inventories remain unmeasured. | A qualification-linked practical route combining applied numeracy, workplace science, digital skills, communication, bookkeeping/finance, management/operations and one locally relevant trade with safety procedures and worked practice. | One exact trade or livelihood module plus functional mathematics/data/finance and digital/offline instructions, tied to a named qualification task. |
| U — university / tertiary education | higher-education institution enrolment: 1964147 enrolments; digital-skills programme learners since inception: 80000 reported learners; digital-skills cumulative course enrolments: 500000 course enrolments | HEC reports substantial HEI enrolment and digital-skills activity. Its digital library is institution/IP/subscription/cost-sharing bounded rather than an open individual licence. The gate has not established exact-language first-year or degree-course coverage. | A complete first-year or degree-foundation sequence in mathematics/statistics, scientific reading/writing, programming and field prerequisites, with exercises, solutions, glossaries and offline-accessible formats. | A prerequisite and academic-language bridge for one gateway course—such as calculus/statistics, programming, chemistry or scientific writing—with bilingual terminology and worked problems. |
| R — postgraduate / research education | PhD Country Directory registrants: 31353 registrants; Pakistan Research Repository public dissertations: 19250 dissertations; digital-library journals reported: 30,000+ journals | HEC reports a large institutional journal route and public dissertation repository. The number of journals or dissertations does not establish open rights, source availability, field completeness, language accessibility, mathematical notation usability or access outside subscribing institutions. | A source-faithful graduate/research chain in one field: prerequisites, advanced monographs, canonical references, definitions, proofs, exercises where available, terminology concordance, search/navigation and offline semantic formats. | A bilingual terminology/definition/proof-dependency layer or one selected open monograph/reference segment with formula-aware QA and explicit prerequisite links. |

## Exact language, variety, script and signed-language obligations

Twenty-three named profiles are investigated below. The remaining 63 country-linked nodes remain visible in the machine-readable register as source-research obligations. Unprofiled never means excluded, already served, low need or low priority.

| Target profile | Glottocode(s) | Script or mode | Why it remains separate |
|---|---|---|---|
| Urdu, Pakistan educational route | urdu1245 | Arab, Nastaliq | Exact Urdu node; Pakistan terminology and Nastaliq rendering remain edition-specific. |
| Western Panjabi / Pakistani Punjabi hypothesis | west2386 | Arab?, Shahmukhi hypothesis | Exact Western Panjabi node; the census label Punjabi does not identify an exact variety or script readership. |
| Eastern Panjabi, multinational linkage | panj1256 | Guru, other local route unresolved | Exact multinational node linked to BD/IN/PK; Indian Gurmukhi publication evidence cannot be assigned to Pakistani readers automatically. |
| Sindhi, Pakistan standard route | sind1272 | Arab | Exact Sindhi node; Pakistani Arabic-script schooling and Indian/Devanagari routes remain distinct. |
| Central Pashto | cent1973 | Arab | Exact Central Pashto node; the census label Pushto does not resolve this variety. |
| Northern Pashto | nort2646 | Arab | Exact Northern Pashto node; Afghanistan, India and Pakistan routes require separate audience and provision evidence. |
| Southern Pashto | sout2649 | Arab | Exact multinational Southern Pashto node; no equivalence to other Pashto nodes is inferred. |
| Saraiki | sera1259 | Arab | Exact Saraiki node; it is not absorbed into Punjabi or Urdu. |
| Eastern Balochi | east2304 | script/orthography to bind | Exact Eastern Balochi node; neither one Balochi standard nor one census category is assumed. |
| Southern Balochi | sout2642 | script/orthography to bind | Exact multinational Southern Balochi node; no cross-variety comprehension is credited. |
| Western Balochi | west2368 | script/orthography to bind | Exact multinational Western Balochi node; no cross-variety comprehension is credited. |
| Brahui | brah1256 | script/orthography to bind | Exact Dravidian-language node with multinational linkage; no Balochi or Urdu coverage assumption. |
| Shina | shin1264 | script/orthography to bind | Exact Shina node; it is distinct from Kohistani Shina. |
| Kohistani Shina | kohi1248 | script/orthography to bind | Exact Kohistani Shina node; no automatic Shina-edition coverage. |
| Balti | balt1258 | script/orthography to bind | Exact Balti node; script cohorts and cross-border routes require separate evidence. |
| Northern Hindko | nort2662 | script/orthography to bind | Exact Northern Hindko node; it is distinct from Southern Hindko. |
| Southern Hindko | sout2668 | script/orthography to bind | Exact Southern Hindko node; it is distinct from Northern Hindko. |
| Kashmiri, Pakistan-linked route | kash1277 | script cohort to bind | Exact multinational Kashmiri node; scripts, territories and educational systems remain separate. |
| Khowar | khow1242 | script/orthography to bind | Exact Khowar node; no Urdu or neighboring-language coverage assumption. |
| Burushaski | buru1296 | script/orthography to bind | Exact isolate node; no neighboring-language comprehension is inferred. |
| Gujari | guja1253 | script/orthography to bind | Exact multinational Gujari node; it is distinct from Gujarati. |
| Pakistan Sign Language | paki1242 | signed video, visual diagrams, caption/transcript parallel route | Exact signed-language node; regional variation remains an investigation dimension. |
| Indian Sign Language, multinational registry linkage | indi1237 | signed video, visual diagrams, caption/transcript parallel route | Glottolog links this exact node to BD/IN/PK. That linkage does not prove Pakistani community size, identity or equivalence to Pakistan Sign Language. |

The broad census category 'Punjabi' is not assigned wholly to Western Panjabi, Eastern Panjabi, Shahmukhi or Gurmukhi. 'Pushto' is not assigned wholly to Central, Northern or Southern Pashto. Eastern, Southern and Western Balochi remain separate, as do Shina/Kohistani Shina, Northern/Southern Hindko, and Pakistan/Indian Sign Language. Every other node is preserved in the JSON even where no matched source yet exists.

## Foundational and re-entry population bounds

| Census mother-tongue category | All-age count | OOS ages 5–16 lower bound | OOS ages 5–16 upper bound |
|---|---:|---:|---:|
| Urdu | 22,249,307 | 0 | 7,778,163 |
| Punjabi | 88,915,544 | 0 | 12,140,704 |
| Sindhi | 34,401,564 | 3,098,795 | 8,757,513 |
| Pushto | 43,633,946 | 0 | 13,298,209 |
| Saraiki | 28,849,579 | 0 | 12,167,106 |

The sharp union interval for these five categories is **9,929,282–25,373,350** out-of-school children in the retained 2023 margins. The five separate upper bounds sum to 54,141,695, but cannot be jointly realized; they are never added as a portfolio audience. A zero lower endpoint means missing intersection information, not zero need.

## Current supply and delivery

- Sindh's portal displays Sindhi, Urdu and English books; Punjab reports 6.2 million Urdu/English textbooks dispatched; Balochistan lists resources from Primer through Grade 12; federal and KP pages expose curriculum and teacher-material routes. These are supply signals, not proofs of completeness, open rights, accessibility, independent-study design or learner effect.
- National assessment used English, Urdu and Sindhi instruments and found Grade 8 mathematics at 42% overall; Balochistan's sample mean was 30.6%. Statistics/probability was the lowest listed Grade 8 mathematics content domain at 32.9%. These locate tasks to investigate; they do not identify a causal language intervention.
- The World Bank reports 57.253% internet use and 95.7% electricity access in 2024, plus 76.854 mobile subscriptions per 100 people. These measures are not interchangeable and do not establish smartphone ownership, permission, reliable data/power, storage, accessibility or learning success.
- HEC reports 1,964,147 higher-education enrolments, 31,353 PhD-directory registrants, 19,250 public dissertations and 30,000+ journals, but the digital-library route is institutional, IP- and subscription/cost-sharing-bounded. Those counts do not establish open individual or local-language research access.

## Open-source comparison portfolio

| Source | Subject | Possible stages | Pakistan comparison hypothesis |
|---|---|---|---|
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | Compare a complete allied-health foundation with a bounded health-science terminology and prerequisite bridge. |
| Biology 2e | life science | S/U | Compare a complete university biology route with a secondary scientific-reading and life-science bridge. |
| Chemistry 2e | physical science | S/U | Compare a complete chemistry sequence with a bounded secondary-to-university quantitative chemistry bridge. |
| College Physics 2e | physical science | S/V/U | Compare a complete algebra-based physics course with a bounded quantities, graphs and mechanics bridge. |
| Introduction to Python Programming | computing and data skills | S/V/U | Compare a complete programming course with a low-bandwidth digital-skills/data module connected to HEC and vocational pathways. |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | Compare complete statistics/data literacy with the measured Grade-8 statistics/probability bottleneck and later vocational/university uses. |
| Prealgebra 2e | mathematics | F/S/V/U | Compare a complete prerequisite-rebuilding route with a bounded re-entry numeracy/algebra bridge at F/S/V/U transition points. |
| Principles of Finance 2e | finance | V/U | Compare a complete finance course with practical numeracy, household/small-enterprise finance and bookkeeping modules. |
| Principles of Management | business and management | V/U | Compare a complete management course with a bounded small-enterprise operations, planning and decision-making module in V/U routes. |

The nine OpenStax entries are measured source-scale comparisons, not automatic recommendations and not claims that equivalent Pakistani materials are absent. forall x: Calgary, the Open Logic modular corpus and the Stacks Project provide separately bounded introductory, university and advanced-research comparisons. Formula-rich texts may sometimes be easier for prepared interlanguage readers, but definitions, negation and proof dependencies still require exact semantic QA.

## Current allocation result

Pakistan has a source-bound 25,373,350 out-of-school population in the 2023 detailed census frame, steep stage attrition, measured mathematics/science bottlenecks, functioning accelerated and textbook channels, institution-bounded tertiary supply, and 86 noncoextensive country-linked language nodes. This supports urgent exact-target comparison, not one national-language allocation. The actionable unit is exact language/variety × script/mode × stage × subject × package × delivery route.

No package is ranked here. Exact addressable audiences, marginal educational effects, physical compute and delivery costs are not yet on common endpoints. Every missing exact-language measurement remains a possible outranker; evidence absence cannot lower need.

## Source and audit basis

- Primary transport: 19 of 25 succeeded; a bounded supplement recovered three of six missing sources. Three official pages remain web-only locators and carry no local hash claim.
- Eight preserved PDFs, 1,055 pages total; 23 page-bound claim groups; nine local HTML sources; five World Bank indicators; 14 visually inspected renders; 179 source/identity/render/arithmetic checks, all passing.
- Poppler emitted display-font substitution warnings on several inspected pages. The rendered facts remained legible, but the audit does not certify the source files' typography or accessibility.
- All country, territory, enrolment, assessment, programme, catalogue, repository and infrastructure observations retain their own denominators and are non-additive.
