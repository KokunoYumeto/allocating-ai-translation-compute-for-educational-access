# Conditional global portfolios for educational-access compute

**Working result, not an ordinal world-language ranking.** The current evidence does not identify a unique global winner. This document nevertheless gives an actionable first allocation for a funder who must act now, while publishing exactly what could displace it.

## How to use the result

The recommended first action is a **ten-program measurement-and-production tranche**. Each program uses the same 100,000-source-token benchmark protocol for comparable workflow measurement while retaining the different target-specific first package listed below. The work records actual target-specific production, QA, accessibility and delivery costs and evaluates the resulting functional-access tasks. Subsequent sequencing and scale follow the measured intervals. The ten programs are slots in one feasible diversified hedge, not ranks 1–10 or a unique solution.

The accompanying **100-profile portfolio** is the broader research and production queue. It is also not ordered. All 10,525 entities outside that communication set remain possible outrankers in the universal register. Missing evidence cannot exclude them.

`P` = preschool/early childhood; `F` = foundational/primary; `S` = secondary; `V` = vocational/technical/practical; `U` = university/taught tertiary; `R` = postgraduate/research.

## The ten-program first tranche

### Bahasa Indonesia secondary catch-up and autonomous STEM progression

- **Scope:** Bahasa Indonesia in Latin orthography; first-language and additional-language users kept separate; Javanese, Sundanese, signed and other regional-language routes are not treated as covered.
- **Stages:** `F|S|V|U|R` — foundational/primary; secondary; vocational/technical/practical; university/taught tertiary; postgraduate/research.
- **First package:** Secondary mathematics/science prerequisite repair with exercises and complete solutions, offline/mobile delivery, followed by statistics, computing, finance/business and open tertiary/research bridges.
- **Why it is in this hedge:** BPS reports 248,501,794 age-5+ users by its conversational-ability definition, while the source-bound Indonesian secondary cohort shows a large below-Level-2 context. Neither figure is treated as exact edition uptake or effect.
- **Evidence and scaling rule:** The Indonesian programme remains eligible. A source-and-task audit selects the stage, subject, register and format with the largest credible additional access; strong existing supply redirects the next package rather than removing Indonesian learners from consideration.
- **Named possible outrankers:** Javanese, Sundanese, Bangla, Filipino and named Philippine languages, Telugu, Tamil, Marathi.

### Bangla/Bengali Bangladesh–India parallel foundational and STEM package

- **Scope:** Bangladesh Bangla and India Bengali outputs with terminology and curriculum overlays; Sylheti and Chittagonian remain separate profiles rather than automatic beneficiaries.
- **Stages:** `F|S|V|U|R` — foundational/primary; secondary; vocational/technical/practical; university/taught tertiary; postgraduate/research.
- **First package:** Foundational numeracy and reading-supported mathematics, then secondary science/statistics and practical finance/health modules, with one reusable source core and two explicit national interfaces.
- **Why it is in this hedge:** The country-disjoint parallel-package population context is 264,588,675–264,605,657 people, while Bangladesh has a high learning-poverty context. The aggregate is not copied into either output's uptake estimate.
- **Evidence and scaling rule:** Bangladesh Bangla and India Bengali remain eligible as distinct outputs. Supply audits choose the most useful common task and determine how much source preparation can be shared without flattening national terminology or separately named varieties.
- **Named possible outrankers:** Sylheti, Chittagonian, Hindi–Urdu package, Telugu, Hausa, Kiswahili.

### Hindi–Urdu Devanagari/Nastaliq parallel educational package

- **Scope:** Separate Standard Hindi/Devanagari and Urdu/Perso-Arabic-Nastaliq outputs plus an experimentally shared mathematical register; other Hindi-group mother tongues and Punjabi varieties remain separate.
- **Stages:** `F|S|V|U|R` — foundational/primary; secondary; vocational/technical/practical; university/taught tertiary; postgraduate/research.
- **First package:** Parallel foundational/secondary mathematics and science, practical finance/business and tertiary logic/statistics, measuring what terminology and formal structure can be reused across scripts.
- **Why it is in this hedge:** The enumerated L1 lower-bound package context is 395,205,166 country-and-census-category-disjoint people. Pakistan's country context also shows high learning and literacy gaps; those rates are not multiplied into the language counts.
- **Evidence and scaling rule:** Retain the native Hindi and Urdu outputs in every scenario. Treat a shared-register layer as an additional experiment whose scale follows task-specific comprehension and production-reuse evidence; it never substitutes for either native output by name alone.
- **Named possible outrankers:** Western/Pakistani Punjabi, Eastern Punjabi, Telugu, Marathi, Tamil, Bangla, Pashto, Sindhi, Saraiki.

### Simplified Standard Written Chinese targeted tertiary, research and accessibility package

- **Scope:** PRC Standard Written Chinese in normative simplified characters; Putonghua ability, written-character use, formal enrolment and other Sinitic languages are distinct measures.
- **Stages:** `S|V|U|R` — secondary; vocational/technical/practical; university/taught tertiary; postgraduate/research.
- **First package:** Audit first for missing open, downloadable and accessible advanced mathematics/science/computing; translate high-value research and tertiary gaps, with MathML/HTML, reflow and offline formats rather than duplicating adequate school supply.
- **Why it is in this hedge:** A conditional adult standardized-character-use bound exceeds 1.05 billion and formal enrolment is 280,404,300. The opportunity scale is enormous even though existing supply may make target-specific additionality smaller.
- **Evidence and scaling rule:** The Simplified Written Chinese programme remains eligible. Independent supply audits identify the exact stage, subject, register and accessibility gaps where a new edition adds most; existing provision redirects the package and never turns industrialization into evidence of low need.
- **Named possible outrankers:** Vietnamese, Japanese research access, Korean research access, Thai, Burmese, Traditional Chinese regional profiles.

### Philippine multilingual foundational and secondary package

- **Scope:** Filipino and Cebuano plus separately named Hiligaynon, Ilocano, Bikol, Waray, Kapampangan and Filipino Sign Language interfaces; Filipino exposure is not Tagalog L1 or nationwide comprehension of one edition.
- **Stages:** `P|F|S|V` — preschool/early childhood; foundational/primary; secondary; vocational/technical/practical.
- **First package:** Early numeracy and reading-supported mathematics, secondary science, disaster/health education and practical financial capability in downloadable mobile formats, sharing diagrams and exercises while localizing prose.
- **Why it is in this hedge:** The Philippines country sentinel is 116,786,962 people and carries a very high learning-poverty context. The Filipino exposure ceiling of 112,729,484 is not used as a language-specific need count.
- **Evidence and scaling rule:** Retain every named Philippine interface as a candidate. Exact home-, school- and task-language evidence determines whether to expand, split or repartition the package rather than forcing separate language communities through Filipino alone.
- **Named possible outrankers:** Other Philippine languages, Burmese, Central Khmer, Lao, Indonesian regional languages, named Pacific languages.

### Ethiopian multilingual foundational, science and practical-learning package

- **Scope:** Amharic, West-Central Oromo, Tigrinya and Somali interfaces are separate; Ethiopia's population and country indicators are not assigned to any one language.
- **Stages:** `P|F|S|V|U` — preschool/early childhood; foundational/primary; secondary; vocational/technical/practical; university/taught tertiary.
- **First package:** Foundational literacy/numeracy, secondary science and locally adaptable agriculture, health, technical and small-enterprise modules designed for offline/low-bandwidth use.
- **Why it is in this hedge:** The Ethiopia sentinel covers 135,472,051 people and shows severe country-level learning, literacy and connectivity gaps. Exact language audiences remain a first-order measurement requirement, not a reason to omit the context.
- **Evidence and scaling rule:** Begin with bounded multilingual production while resolving language-of-instruction, literacy, script, region, stage and supply cells. Scale multiple interfaces wherever one national-language output would miss learners; missing measurements do not postpone eligibility.
- **Named possible outrankers:** Other Ethiopian languages, Somali displaced learners, Sudanese language portfolios, South Sudanese portfolios, DRC multilingual package.

### DRC multilingual and displacement-continuity package

- **Scope:** Lingala, Kivu/Congo Swahili, French, Tshiluba, Kikongo varieties and other named languages plus host-language interfaces; no national or refugee total is assigned to one language.
- **Stages:** `P|F|S|V|U` — preschool/early childhood; foundational/primary; secondary; vocational/technical/practical; university/taught tertiary.
- **First package:** Resumable foundational and secondary mathematics/science, public-health and practical livelihood modules, with school-continuity and credential-navigation paths for displaced learners.
- **Why it is in this hedge:** The DRC sentinel is 112,832,473 people with extremely severe country-level learning and connectivity contexts. The current displacement row lacks a publication-ready language denominator and remains visible rather than scored down.
- **Evidence and scaling rule:** Begin with a bounded origin-host continuity package and keep origin, host, stage and language as separate cells. Evidence refines its scale and composition; offline, print and accessible routes remain part of the design wherever connectivity would otherwise prevent use.
- **Named possible outrankers:** Named DRC languages not yet profiled, Sudan displacement, South Sudan displacement, Somali displacement, Hausa, Kiswahili national profiles.

### Hausa Boko/Ajami cross-border foundational and practical package

- **Scope:** Hausa country profiles with Boko and Ajami literacy routes kept separate; Nigerian and cross-border totals are not added.
- **Stages:** `P|F|S|V|U` — preschool/early childhood; foundational/primary; secondary; vocational/technical/practical; university/taught tertiary.
- **First package:** Foundational numeracy/literacy, secondary science and practical health, agriculture, financial capability and enterprise modules in low-bandwidth text/audio and both evidenced literacy interfaces.
- **Why it is in this hedge:** The source register retains a global lower bound of 100 million mixed L1/L2 users and an 80 million Nigeria lower bound. Nigeria's country context shows major literacy and connectivity gaps without supplying a Hausa-specific rate.
- **Evidence and scaling rule:** Measure Boko/Ajami literacy and national supply separately; preserve a parallel interface where shared content lowers production cost without excluding either script community.
- **Named possible outrankers:** Nigerian Pidgin, Yoruba, Igbo, Central Kanuri, Nigerian Fulfulde, other West African language profiles.

### Kiswahili multistandard cross-border STEM and practical-learning package

- **Scope:** Tanzania, Kenya, Uganda, Rwanda, Burundi and Kivu/Congo Swahili standards and L1/L2 audiences kept explicit; a global lower bound is not inherited by one edition.
- **Stages:** `F|S|V|U` — foundational/primary; secondary; vocational/technical/practical; university/taught tertiary.
- **First package:** Secondary mathematics/science, statistics/computing and practical health, agriculture, finance and management modules with national terminology overlays and offline/mobile delivery.
- **Why it is in this hedge:** The source register retains a cross-border lower bound of 200 million mixed L1/L2 users. Multiple education systems may allow substantial reuse, but usable academic register and national supply must be measured.
- **Evidence and scaling rule:** Retain the national and variety-specific Kiswahili outputs as candidates. Audience and production evidence determines the useful balance between a common core and national overlays without treating all Swahili varieties as identical.
- **Named possible outrankers:** Hausa, Amharic, Oromo, Somali, Kinyarwanda, Kirundi, named DRC languages.

### Modern Standard Arabic with explicit vernacular and displacement interfaces

- **Scope:** MSA as a learned written educational register plus separately specified Egyptian, Palestinian, Syrian/North Levantine, Sudanese and other vernacular interfaces; no vernacular is replaced by the Arabic umbrella.
- **Stages:** `F|S|V|U|R` — foundational/primary; secondary; vocational/technical/practical; university/taught tertiary; postgraduate/research.
- **First package:** Reading-supported mathematics/science bridges into MSA, practical health/finance/management modules and advanced open tertiary/research sources, with host/origin-language continuity for displaced learners.
- **Why it is in this hedge:** The Arab World education-exposure context is 503,356,133 and the separate umbrella estimate is 450 million speakers. Their relation to exact written comfort, vernacular use and unmet supply remains unmeasured.
- **Evidence and scaling rule:** Treat MSA, vernacular and host-language interfaces as distinct eligible routes. Task-level evidence determines their relative scale and combination; MSA exposure never erases a vernacular route by assumption.
- **Named possible outrankers:** Dari/Pashto displaced learners, Kurdish varieties, Somali, Tigrinya, Haitian Creole, Ukrainian displacement continuity.

## The 100-profile portfolio

The table is grouped by analytical lane. Member numbers identify records only; there is no ordinal rank.

| Member | Profile | Lane | Stages | Current evidence band | Ten-program link |
|---|---|---|---|---|---|
| `P100-001` | Indonesian | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-ID-SECONDARY-TO-TERTIARY |
| `P100-002` | Hindi | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-HI-UR-PARALLEL |
| `P100-003` | Bangla | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-BN-BD-IN-PARALLEL |
| `P100-004` | Standard Written Chinese, Simplified | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-ZH-HANS-TARGETED |
| `P100-005` | Urdu | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-HI-UR-PARALLEL |
| `P100-006` | Telugu | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-007` | Tamil | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-008` | Marathi | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-009` | Vietnamese | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-010` | Hausa | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-HAUSA-MULTISCRIPT |
| `P100-011` | Standard Kiswahili | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-DRC-MULTILINGUAL-DISPLACEMENT, T10-SWAHILI-MULTISTANDARD |
| `P100-012` | Modern Standard Arabic | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-ARABIC-REGISTER-INTERFACES |
| `P100-013` | Brazilian Portuguese | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-014` | Spanish, Latin American educational profiles | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-015` | English, underserved learner profiles | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-016` | French, underserved learner profiles | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-017` | Turkish | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-018` | Iranian Persian | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-019` | Thai | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-020` | Burmese | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-021` | Filipino | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | T10-PH-MULTILINGUAL |
| `P100-022` | Standard Malay, Malaysia | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-023` | Gujarati | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-024` | Kannada | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-025` | Odia | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-026` | Malayalam | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-027` | Eastern Punjabi | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `F|S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-028` | Russian | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-029` | Japanese | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-030` | Korean, South Korean standard | `HIGH_REACH_AND_MAJOR_EDUCATIONAL_LANGUAGE` | `U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-031` | Amharic | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | T10-ETH-MULTILINGUAL |
| `P100-032` | West-Central Oromo educational profile | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | T10-ETH-MULTILINGUAL |
| `P100-033` | Somali | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | T10-ETH-MULTILINGUAL |
| `P100-034` | Yoruba | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-035` | Igbo | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-036` | Kinyarwanda | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-037` | Kirundi | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-038` | Lingala | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | T10-DRC-MULTILINGUAL-DISPLACEMENT |
| `P100-039` | Central Kanuri | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-040` | Wolof | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-041` | Bambara | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-042` | Pulaar | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-043` | Nigerian Fulfulde | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-044` | Zulu | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-045` | Northern Sotho / Sepedi standard | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-046` | Haitian Creole | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-047` | Nepali | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-048` | Sinhala | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-049` | Northern Pashto | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-050` | Dari | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-051` | Sindhi, Pakistan standard | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-052` | Saraiki | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-053` | Bhojpuri | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-054` | Maithili | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-055` | Chhattisgarhi | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-056` | Haryanvi | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-057` | Santali | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-058` | Sylheti | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-059` | Chittagonian | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-060` | Javanese | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-061` | Sundanese | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-062` | Cebuano | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | T10-PH-MULTILINGUAL |
| `P100-063` | Central Khmer | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-064` | Lao | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-065` | Northern Uzbek / Uzbekistan standard | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-066` | Kazakh | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `S|V|U|R` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-067` | Tajik | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_AND_ROUTES_PRESENT` | — |
| `P100-068` | Uyghur | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-069` | Central Kurdish / Sorani | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-070` | Northern Kurdish / Kurmanji | `REGIONAL_DEPTH_AND_LANGUAGE_TRANSITION` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-071` | Ukrainian | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V|U|R` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-072` | Polish | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-073` | Romanian | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-074` | Bulgarian | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-075` | Belarusian | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-076` | Serbian standard | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-077` | Tigrinya | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | T10-ETH-MULTILINGUAL |
| `P100-078` | Kabyle | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-079` | Central Atlas Tamazight | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-080` | Tachelhit | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-081` | Ayacucho Quechua | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-082` | Cusco Quechua | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-083` | Paraguayan Guarani | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-084` | Central Nahuatl | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-085` | K'iche' | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-086` | Tok Pisin | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-087` | Bislama | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `F|S|V` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-088` | Kalaallisut / West Greenlandic | `RESEARCH_ACCESS_COMPARATOR_AND_REGIONAL_DEPTH` | `S|V|U|R` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-089` | American Sign Language | `NAMED_SIGN_LANGUAGE` | `F|S|V|U|R` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-090` | Brazilian Sign Language / Libras | `NAMED_SIGN_LANGUAGE` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-091` | Indian Sign Language | `NAMED_SIGN_LANGUAGE` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-092` | Kenyan Sign Language | `NAMED_SIGN_LANGUAGE` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-093` | South African Sign Language | `NAMED_SIGN_LANGUAGE` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-094` | Interslavic mathematical register | `INTERLANGUAGE_AND_SHARED_REGISTER` | `U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-095` | Hindi-Urdu shared mathematical register | `INTERLANGUAGE_AND_SHARED_REGISTER` | `S|V|U` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | T10-HI-UR-PARALLEL |
| `P100-096` | Malay-Indonesian shared technical profile | `INTERLANGUAGE_AND_SHARED_REGISTER` | `S|V|U` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-097` | Persian-Dari-Tajik shared technical profile | `INTERLANGUAGE_AND_SHARED_REGISTER` | `S|V|U|R` | `SOURCE_BOUND_POPULATION_OR_PACKAGE_CONTEXT_NO_CURRENT_ROUTE` | — |
| `P100-098` | Oghuz-focused Inter-Turkic design hypothesis | `INTERLANGUAGE_AND_SHARED_REGISTER` | `U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |
| `P100-099` | N'Ko literary Manding educational profile | `INTERLANGUAGE_AND_SHARED_REGISTER` | `F|S|V|U` | `ROUTES_PRESENT_WITHOUT_HIGH_REACH_POPULATION_CELL` | — |
| `P100-100` | Romance mathematical intercomprehension profile | `INTERLANGUAGE_AND_SHARED_REGISTER` | `U|R` | `PROSPECTIVE_PROFILE_NO_CURRENT_ROUTE_OR_HIGH_REACH_CELL_NOT_ZERO_NEED` | — |

## Mandatory overlays

Every applicable language package must consider all 17 accessibility modes. These include semantic responsive HTML, reflowable EPUB, synchronized text/audio, captions/transcripts, named sign-language video, plain-language/Easy Read, braille, tactile graphics, MathML and low-bandwidth/offline modes. They are not added as independent beneficiary populations.

The 10 current displacement portfolios remain separate origin/host/language/stage overlays. Status-cohort totals are not language counts. Ukrainian school continuity, Afghan, Palestinian, Syrian, Rohingya, Sudanese, Somali, South Sudanese, DRC and Venezuelan routes remain visible even when exact language distributions are missing.

The 10 bridge designs remain experiments, including Interslavic, Hindi–Urdu, Malay–Indonesian, Persian–Dari–Tajik, Oghuz, Romance and Germanic alternatives. Mathematics may lower prose burden for prepared readers, but every design still requires task-specific comprehension, script, prerequisite and overlap bounds.

## Partial-order result

Among the 100 candidate profiles there are 4,950 unordered pairs. None currently has a demonstrated global dominance relation on compatible exact audience, incremental effect, physical compute and overlap intervals. This is not equality: it is an explicit statement of what the evidence has not yet resolved.

The first-tranche recommendation is therefore a risk-managed allocation under uncertainty. It protects enormous potential reach, severe underserved contexts, cross-border reuse, advanced research access and displacement while producing the measurements needed for a less ambiguous next decision.
