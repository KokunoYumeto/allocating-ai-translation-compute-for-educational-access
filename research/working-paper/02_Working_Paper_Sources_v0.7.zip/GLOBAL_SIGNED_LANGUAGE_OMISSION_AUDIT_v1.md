# Global signed-language omission audit

**Status:** bounded identity, evidence and current-route crosswalk; not a ranking, population estimate, coverage claim or completed worldwide provision census.

The universal register contains **227 typed signed-language nodes** and **7 possibly signed but taxonomically unresolved nodes**. All 234 survive this audit as separate rows. A missing population measure, missing course audit or missing current intervention route is recorded as unknown—not zero need, low value or coverage by a neighboring spoken or signed language.

Only six universal nodes currently have a route crosswalk in the bounded intervention calculator. That is a workflow fact, not a recommendation to fund only six languages.

| Universal node | Current route profile | Routes | Stages | Crosswalk status |
|---|---|---:|---|---|
| American Sign Language (`amer1248`) | American Sign Language | 12 | S;V;U;R | EXACT_NAMED_NODE_LINK_SCOPE_STILL_TERRITORY_SPECIFIC |
| Brazilian Sign Language (`braz1236`) | Brazilian Sign Language / Libras | 10 | F;S;V;U;R | EXACT_NAMED_NODE_LINK_SCOPE_STILL_TERRITORY_SPECIFIC |
| Indian Sign Language (`indi1237`) | Indian Sign Language | 10 | S;V;U;R | EXACT_NAMED_NODE_LINK_SCOPE_STILL_TERRITORY_SPECIFIC |
| Kenya-Somali Sign Language (`keny1241`) | Kenyan Sign Language | 6 | F;S;V | POSSIBLE_SCOPE_MISMATCH_KENYAN_VS_KENYA_SOMALI_NO_EXACT_COVERAGE_CREDIT |
| Philippine Sign Language (`phil1239`) | Filipino Sign Language | 2 | F;V | LABEL_VARIANT_LINK_PHILIPPINE_VS_FILIPINO_SCOPE_TO_VERIFY |
| South African Sign Language (`sout1404`) | South African Sign Language | 10 | S;V;U;R | EXACT_NAMED_NODE_LINK_SCOPE_STILL_TERRITORY_SPECIFIC |

The Kenya entry exposes a real identity-control issue: the current route says ‘Kenyan Sign Language’, while the universal node is named ‘Kenya-Somali Sign Language’. The audit preserves the link as a possible scope mismatch and gives it no exact-language coverage credit. The Filipino/Philippine label pair is retained as a label-variant link whose territorial and community scope still requires source verification.

## Evidence visibility

- Exact signed nodes with a numeric source-label observation in the current universal matrix: **2 of 227**.
- Exact signed nodes with at least one scope-unverified direct target relation: **34 of 227**.
- Named sign evidence records in the separate source table: **18**; records linked through an exact edition-target relation to at least one retained signed node: **15**.
- Exact or possible signed nodes without a current route: **228 of 234**.

Three named evidence records do not currently resolve through an exact edition-target relation in the universal matrix: `SL-HSL-US-HI-GAP` (Hawaiʻi Sign Language), `SL-LSQ-CA-2021-KNOW` (Langue des signes québécoise), and `SL-SPAIN-SIGN-2020-USE` (the Spanish census sign-language-use record). They remain explicit evidence-graph repair obligations; their source evidence is not discarded and is not reassigned to another signed-language node by name similarity.

These counts describe the present evidence graph. They do not imply that only two signed languages have speakers, that a target relation proves population scope, or that a route provides a complete course. Deaf/hard-of-hearing population totals, disability prevalence and spoken-language literacy are never substituted for exact signed-language populations.

## Package implication

Signed-language educational production is not a text-token translation with a different locale tag. It requires sign-video or avatar/performance decisions, exact notation synchronization, captions/transcripts, exercises and answers, navigation, offline packaging, and modality-specific QA. The five existing package studies—ASL, Libras, Indian Sign Language, Kenyan Sign Language and South African Sign Language—therefore remain evidence-bearing prototypes, not a blanket template for the other nodes. Filipino Sign Language currently has a route but not the same package audit.

For every signed language, the same six educational stages remain eligible: P (preschool/early learning), F (foundational/primary), S (secondary), V (vocational/practical), U (university), and R (postgraduate/research). Eligibility does not assert equal package design or equal benefit at every stage.

## Machine-readable outputs

- `structured/GLOBAL_SIGNED_LANGUAGE_OMISSION_AUDIT_v1.csv` retains every exact and possibly signed node, source visibility, named-evidence links, current route IDs, scope status and no-rank disposition.
- `qa/GLOBAL_SIGNED_LANGUAGE_OMISSION_AUDIT_QA_v1.json` verifies identity retention, route resolution, hashes and the no-zero/no-rank rules.

## Remaining work

This audit prevents disappearance; it does not yet supply 234 source-bound package comparisons. Next work must prioritize source retrieval and package construction across diverse sign-language families, village sign languages, national sign languages, multiple-country nodes and displaced communities, while keeping exact language identity and modality cost separate from country population.
