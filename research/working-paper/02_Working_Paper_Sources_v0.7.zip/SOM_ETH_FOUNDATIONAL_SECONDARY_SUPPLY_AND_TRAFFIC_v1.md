# Somali-region foundational and secondary supply and traffic

Bounded checkpoint. This is not a global rank, production authorization, or claim that one generic Somali label covers every learner.

## Result

The evidence does not support either extreme—neither “nothing exists” nor “Somali mathematics is already served.” Historical grades 1–8 Somali mathematics books are discoverable and readable, but the mirror calls them out of date, the sampled books reserve electronic-reuse rights, and current official evidence shows severe textbook scarcity. The strongest directly observed mechanism is the Somali-to-English transition between lower and upper schooling, compounded by missing books and limited teacher capacity.

A six-chapter Somali–English arithmetic-to-algebra bridge is therefore the provisional bounded comparator: algebra language, fractions, decimals, percents, linear equations and graphs, with prerequisites, worked examples, exercises, answers and offline delivery. It is not declared superior. Its effect and matched audience remain unmeasured, and a complete open sequence stays live as an alternative.

## What exists, and what that does not prove

- The historical mirror exposes **196 Somali-tagged PDF links** across biology, chemistry, civics, mathematics, physics and social studies.
- Mathematics accounts for **84 links**: 8 full student books, 8 teacher guides and 68 chapter files across grades 1–8.
- The sampled grade 5 and grade 8 books are legible and ministry-identified, but both state that copying, publication and electronic dissemination require written permission or a legal licence.
- The mirror says its textbooks are eight years old or more and out of date. The file host also failed HTTPS certificate-name validation during this retrieval. Historical discoverability is not current usable supply.

## Direct educational evidence

- Ethiopia's 2021/22 statistics report Somali-region textbook-to-pupil ratios of **0.30 in primary and 0.42 in middle school**. For secondary school, Somali has less than one book per student; the reported stock includes 39,946 books in total and 3,360 mathematics books. The report warns about under-reporting and misclassification.
- A selected 2019 World Bank study of refugee and host-community schools records **Somali in grades 1–4 and English in grades 5–8 and secondary** in the Somali region. Textbook problems appeared in 83% of twelve observed classrooms; language and culture were the second most common reported barrier, with English problems reported mostly in the Somali region.
- Ethiopia's curriculum framework independently says English is the medium in secondary and tertiary education, beginning in grade 7 in most regions and grade 5 in very few.
- Somalia's 2022–2026 national plan is origin-system context, not evidence about the Ethiopia-hosted corridor. It reports only 15% qualified public secondary teachers, some schools with no books, and 2019 ratios from 15 pupils per Somali-language Form 1 book to 73 pupils per mathematics Form 4 book.

## Lawful open-source scale comparison

OpenStax Prealgebra 2e is used only as a measurable CC BY-NC-SA 4.0 source-scale comparator. It is not asserted to match the Ethiopian or Somali curriculum.

| Package | Measured source tokens | Modules | Somali text-traffic scenario, low–base–high FECU |
|---|---:|---:|---:|
| Complete source collection | 364,270 | 75 | 5,527,879 – 5,698,723 – 5,832,200 |
| Six-chapter transition proxy | 186,978 | 38 | 2,837,433 – 2,925,126 – 2,993,640 |
| Fractions-only lower comparator | 41,336 | 8 | 627,283 – 646,670 – 661,816 |

FECU is a standardized token-event traffic index. It is not physical compute, money, quality, or impact. Rendering, accessibility production, validation, deployment, maintenance, and other unequal work remain unmeasured.

At equal per-token variable cost and zero common setup, the six-chapter proxy is **51.33%** of the full source scale. It is more efficient at the same endpoint if it retains more than 51.33% of the full package's positive yield; the full sequence must yield more than **1.948×** as much to be more efficient. No such yields have yet been measured.

## Provisional package implication

If a bounded first implementation must be chosen before matched outcome data exist, select the Somali–English transition bridge as the provisional comparator because it targets the directly observed transition mechanism at roughly half the measured source traffic. Keep the complete sequence live where current usable supply is absent or where its additional outcomes exceed the break-even threshold.

The bridge should include:

- Somali explanation paired with English classroom and subject language;
- prerequisite diagnostics and catch-up paths;
- worked examples, exercises, answers and feedback usable without a teacher;
- phone-readable, low-bandwidth and offline delivery;
- printable and screen-reader-native alternatives; and
- an explicit curriculum and examination-navigation map.

The matched audience, exact variety/script/literacy distribution, current complete open supply, package effect, physical compute, currency cost and global rank all remain unresolved. The 361,872 corridor status observations are not a language or learner denominator.

## Sources

- [Curriculum Framework for Ethiopian Education (KG–Grade 12)](https://www.moe.gov.et/storage/Books/Curriculum%20Framework%20for%20Ethiopian%20Education%20%28KG%20%E2%80%93%20Grade%2012%29.pdf) — Federal Democratic Republic of Ethiopia, Ministry of Education; 2020. Snapshot: sources/som_eth_supply_20260905/Ethiopia_Curriculum_Framework_KG_12_official.pdf; 540,732 bytes; SHA-256 B78174A5F581663559FA1B42FB1E66F86837E9F9F6314E11645D611F70F30807.
- [Education Statistics Annual Abstract 2021/22](https://moe.gov.et/storage/Books/ESAA%202014%20EC%20%282021-22%20G.C%29%20Final.pdf) — Federal Democratic Republic of Ethiopia, Ministry of Education; 2021/22. Snapshot: sources/som_eth_supply_20260905/Ethiopia_ESAA_2021_22_official.pdf; 5,519,151 bytes; SHA-256 BAC3B4EC77F499B5A677A6D8878AF30BA982B45AF8F7BD4F18DF0B7F982A9DBE.
- [Ethiopia Learning Library textbook index](https://www.ethiopialearning.com/) — Ethiopia Learning Library; retrieved 2026-09-05. Snapshot: sources/som_eth_supply_20260905/Ethiopia_Learning_Library_index.html; 272,376 bytes; SHA-256 BC9E2CE700E1F071D4C729111C11F7C779B616DC17D81DD74EF72CEB7DA416AE.
- [Xisaab Buugga Ardayga Fasalka 5aad](http://files.ethiopialearning.com/textbooks/Grade%2005/Grade_5_Subject_MATH_Language_SOMALI_Retrieved_20150101.pdf) — Federal Democratic Republic of Ethiopia, Ministry of Education; 2002 E.C. / copyright 2011; mirror filename 2015-01-01. Snapshot: sources/som_eth_supply_20260905/Somali_Grade5_Math_mirror_20150101.pdf; 19,294,139 bytes; SHA-256 DDAE46A206341BA36ABA8C838A8F03FE2E3969DDC98AE6F9C733A219FB72E246.
- [Xisaab Buugga Ardayga Fasalka 8aad](http://files.ethiopialearning.com/textbooks/Grade%2008/Grade_8_Subject_MATH_Language_SOMALI_Retrieved_20150101.pdf) — Federal Democratic Republic of Ethiopia, Ministry of Education; 2002 E.C. / copyright 2011; mirror filename 2015-01-01. Snapshot: sources/som_eth_supply_20260905/Somali_Grade8_Math_mirror_20150101.pdf; 20,131,678 bytes; SHA-256 327B3A7A38A48A71B7DD726CB2DE83A6B02E741B1C55CD8CB75E4E60CB29D779.
- [National Education Sector Strategic Plan 2022–2026](https://planipolis.iiep.unesco.org/sites/default/files/ressources/somalia_essp-2022-2026.pdf) — Federal Government of Somalia, Ministry of Education, Culture and Higher Education; 2022. Snapshot: sources/som_eth_supply_20260905/Somalia_ESSP_2022_2026_Planipolis_mirror.pdf; 2,823,752 bytes; SHA-256 4BCCAD86B9A15CC8300DB6CE630260B35297F20DF392F14766358ED3036E0CF2.
- [National Education Sector Strategic Plan 2022–2026 (secondary mirror)](https://spotlight.so/wp-content/uploads/2023/03/FINAL-Updated-23-may-ESSP.pdf) — Federal Government of Somalia, Ministry of Education, Culture and Higher Education; 2022. Snapshot: sources/som_eth_supply_20260905/Somalia_ESSP_2022_2026_Spotlight_mirror.pdf; 2,828,621 bytes; SHA-256 762B978309280D3BC551341A7178661F050789FB52AD024D648EAD6532976C1F.
- [Education for Resilience: Exploring the Experience of Refugee Students in Three Communities in Ethiopia](https://documents.worldbank.org/curated/en/988591562865883889/pdf/Education-for-Resilience-Exploring-the-experience-of-refugee-students-in-three-communities-in-Ethiopia.pdf) — World Bank, 2019. Snapshot: sources/displacement_corridor_v3_20260904/World_Bank_Education_for_Resilience_Ethiopia_2019.pdf; 1,778,458 bytes; SHA-256 3EF794AB9B3EE1080C83BB0300337249BE682368AB5F173648BBB9A7483536F5.
- [OpenStax Prealgebra 2e source repository](https://github.com/openstax/osbooks-prealgebra-bundle/tree/38cae454e644abf9f0a623e876994553881597c9) — measured at commit 38cae454e644abf9f0a623e876994553881597c9; CC BY-NC-SA 4.0.

This checkpoint narrows one comparison. It does not establish a final funding order.
