# Brazil cross-stage supply and package comparison

This checkpoint asks what specific open educational packages could add in Brazil. It does not treat Brazil as one language, does not assume Portuguese covers every learner, and does not assign a global rank.

## Stage legend

| Code | Meaning |
|---|---|
| P | preschool / early childhood |
| F | foundational / primary |
| S | secondary |
| V | vocational / practical |
| U | university |
| R | postgraduate / research |

## Main finding

Brazil has very large mainstream learner populations, consequential foundational and secondary outcome gaps, a large distance-tertiary and postgraduate system, and many exact Indigenous and signed-language routes. No single Portuguese, Indigenous, signed or accessibility package represents them all. Compare matched interventions on newly usable access and standardized full cost.

The source freeze retains 337 Brazil-linked Glottolog language-level nodes and 304 separate IBGE census language labels. Those are not interchangeable inventories. No census label has been automatically mapped to a Glottolog node, and no Portuguese, Libras or interlanguage edition is treated as blanket coverage.

## Scale and non-additivity

| Context | Source-bound value |
|---|---:|
| National population, 2025 | 212,812,405 |
| Basic-education enrolments, 2024 | 47,088,922 |
| Undergraduate enrolments, 2024 | 10,226,873 |
| Distinct stricto-sensu postgraduate people, 2024 | 419,915 |
| Indigenous-language home use among Indigenous persons age 5+, 2022 | 433,980 |
| Indigenous persons age 15+ not literate under the simple-note definition, 2022 | 178,707 |

These are different source frames, not one additive population. The 1,023,294 integrated-vocational enrolments, for example, occur in both the secondary and vocational views. Portuguese and Indigenous-language home use also overlap.

## Exact-language boundary

All 337 country-linked Glottolog nodes and all 304 census labels remain visible in the JSON and CSV. Seven signed-language nodes are retained separately:

- Brazilian Sign Language (braz1236; ISO 639-3 bzs)
- Macushi Sign Language (macu1262)
- Marajo Sign Language (mara1418)
- Maxakali Sign Language (maxa1248)
- Papiu Yanomama Sign Language (papi1256)
- Terena Sign Language (tere1282)
- Urubú-Kaapor Sign Language (urub1243; ISO 639-3 uks)

The largest IBGE language-label counts below are descriptive source counts, not a priority order and not necessarily unique persons:

| Census label | Count |
|---|---:|
| Tikúna | 51,978 |
| Guarani Kaiowá | 38,658 |
| Guajajara | 29,212 |
| Kaingang | 27,482 |
| Xavante | 21,773 |
| Yanomami | 19,177 |
| Sateré-Mawé | 15,421 |
| Nheengatu | 13,070 |
| Munduruku | 12,961 |
| Tukano | 12,435 |
| Terena | 9,570 |
| Kaxinawá | 9,493 |
| Guarani Mbya | 8,538 |
| Kayapó | 8,525 |
| Guarani | 8,235 |
| Makuxí | 7,530 |
| Kulina Madijá | 6,633 |
| Baniwa | 6,338 |
| Guarani Nhandeva | 6,284 |
| Pataxó | 5,426 |
| Wapixana | 5,192 |
| Xerente | 4,005 |
| Ka'apor | 3,817 |
| Krahô | 3,623 |
| Wai Wai | 3,603 |

## Stage comparisons

### P — preschool / early childhood

Observed supply and context: A large mainstream early-childhood system exists, while Indigenous policy and language evidence establish distinct child/caregiver-language routes. The current freeze does not inventory exact-language, open-reuse, signed, audio, print or offline early-learning completeness.

Complete alternative: A coherent open early-language, pre-literacy, early-numeracy, play and learning-to-learn sequence in the exact child/caregiver language, with educator/caregiver guidance, illustrations, audio or signed video, print and offline delivery.

Bounded alternative: A phone/print/audio/signed activity pack for number sense, patterns, spatial language and caregiver prompts in one exact route, with the uncovered remainder stated explicitly.

Next comparison: Bind one exact child/caregiver language or signed route, current material supply, delivery conditions and a common early-language/numeracy endpoint.

### F — foundational / primary

Observed supply and context: Mainstream schools, Indigenous-school policy, teacher training, some signed subject materials and multilingual home use are all observed. Exact-language curriculum completeness, autonomous feedback, accessibility and open-reuse remain unmeasured.

Complete alternative: A coherent open literacy, numeracy, science and learning-strategy pathway with full worked feedback, exact-language and academic-Portuguese bridges, semantic mathematics, audio/signed alternatives, print and resumable offline use.

Bounded alternative: A diagnostic prerequisite-and-language bridge at one grade or adult-literacy transition, with worked examples, wrong-answer feedback and one exact language, signed or accessibility route.

Next comparison: Compare complete and bounded packages for the same exact community and literacy/numeracy endpoint, preserving adult and school-age cohorts separately.

### S — secondary

Observed supply and context: Very large secondary enrolment coexists with mathematics, reading and science proficiency bottlenecks among represented 15-year-olds. These outcomes do not identify whether the binding constraint is language, prerequisites, pedagogy, access or another mechanism.

Complete alternative: Open secondary mathematics, statistics, computing, biology, chemistry and physics pathways with prerequisites, exercises, answers, worked feedback, accessibility, exact-language or academic-Portuguese bridges, print and offline delivery.

Bounded alternative: One transition package targeting algebra, quantitative science, reading, statistics/data literacy or academic language, with the remainder explicitly uncovered.

Next comparison: Use one exact cohort, current course/resource, common assessment or progression endpoint and standardized full production cost; do not generalize from PISA to unrepresented youth.

### V — vocational / practical

Observed supply and context: Technical, qualification and adult-education routes are large, but this freeze does not establish which occupations lack openly reusable, language-matched and accessible materials or which prerequisite failures dominate.

Complete alternative: Open modular pathways in quantitative reasoning, financial management, business management, computing/data, science/health foundations and workplace safety, with projects, answers, feedback, exact terminology and offline use.

Bounded alternative: A credential- or task-aligned toolkit such as practical statistics, finance, management decisions, Python/data or quantitative health/safety, paired with its required prerequisite repair.

Next comparison: Bind one occupational or qualification pathway, entry prerequisites, exact language/access route, current open supply, completion or task endpoint and full standardized cost.

### U — university / taught tertiary

Observed supply and context: A large university system and major distance route exist. Current supply of an exact Portuguese, Indigenous-language, signed, accessible, offline and self-study-complete package still requires course- and license-level comparison.

Complete alternative: Open degree-core and prerequisite sequences across mathematics, statistics, computing, life/physical sciences, finance, management and allied health with full exercises, solutions, semantic notation and offline access.

Bounded alternative: A prerequisite repair, terminology bridge or source-faithful edition for one high-friction course, exact language or accessibility route.

Next comparison: Inventory the exact current course/source and license; compare matched comprehension, completion or task performance under a common delivery condition and full cost.

### R — postgraduate / research

Observed supply and context: A large postgraduate system and domestic-journal platform coexist with mixed Portuguese/English publication practice. Journal abundance does not supply every advanced open textbook, monograph, historical school or proof corpus.

Complete alternative: Open advanced textbook, monograph and research-corpus editions with source terminology, formula/proof preservation, linked references, machine-readable mathematics and offline archival forms.

Bounded alternative: A source-faithful edition of one high-value absent work, or a bilingual terminology, proof-reading and search/navigation scaffold around a formal corpus.

Next comparison: Bind a named field/work, current Portuguese/English/open alternatives, prepared-reader population, comprehension or research-use endpoint and full cost. Mathematical structure may reduce prose burden but does not prove complete intelligibility.

## Cross-subject source-scale baselines

The nine measured OpenStax sources provide workload baselines across mathematics, statistics, biology, chemistry, physics, management, finance, anatomy/physiology and Python. Their source size does not establish Brazilian need, benefit, language fit, production compute or priority.

| Source | Subject | Stages to test | Complete text tokens | Brazil-specific hypothesis |
|---|---|---|---:|---|
| Prealgebra 2e | mathematics | F/S/V/U | 364,270 | Test complete versus prerequisite-repair packages for F/S/EJA/V/U transitions, including one exact Indigenous-language, Portuguese-bridge or signed/accessibility route. |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | 396,969 | Test data literacy for S/V/U pathways, including public reasoning, management, finance and research prerequisites; match Brazilian examples and current Portuguese supply. |
| Biology 2e | life science | S/U | 763,621 | Test a secondary-to-university life-science bridge or full major sequence, with exact terminology and health/agriculture relevance established for the chosen pathway. |
| Chemistry 2e | physical science | S/U | 625,793 | Test a secondary/university chemistry bridge, including the documented signed-chemistry lexicon route, but do not infer subject completeness from one catalogue entry. |
| College Physics 2e | physical science | S/V/U | 950,860 | Test algebra-based physics at S/V/U against mathematics prerequisites, laboratory access, current Portuguese supply and low-bandwidth media constraints. |
| Principles of Management | business and management | V/U | 341,159 | Test one V/U management pathway with locally meaningful cases, projects and an occupational or programme endpoint rather than assuming generic business-text usefulness. |
| Principles of Finance 2e | finance | V/U | 282,065 | Test practical and degree-level finance with local legal/institutional adaptation, prerequisite numeracy and task-based outcomes; source translation alone is not sufficient. |
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | 667,392 | Test allied-health V/U pathways with local professional terminology, accessible diagrams and a matched qualification; do not generalize from the medical-student route. |
| Introduction to Python Programming | computing and data skills | S/V/U | 70,994 | Test S/V/U computing and data skills with runnable low-bandwidth exercises, offline tooling and a project or employment-linked endpoint. |

## Near-term matched tests — workflow order, not rank

- One exact Indigenous-language F package inside or outside Indigenous Lands, with a verified IBGE-to-language boundary, current supply and literacy/numeracy endpoint.
- One Libras/written-Portuguese or other exact signed-language mathematics/science package with signed video, semantic text and a common subject endpoint.
- One Portuguese or bilingual S prerequisite package targeting a measured mathematics, reading or science bottleneck, including out-of-sample limitations.
- One EJA/V practical package in finance, management, statistics, computing or health/safety, bound to a real qualification or task.
- One low-bandwidth/offline U prerequisite package for the distance-learning route and one named R bilingual/full advanced-source comparison.

## Decision boundary

No exact addressable audience, incremental effect, physical compute, currency cost, dominance relation or funding rank is assigned. Existing supply changes the additionality of a matched package; it never lowers a person's educational need. Missing evidence remains an evidence priority, never a reason to exclude a language.
