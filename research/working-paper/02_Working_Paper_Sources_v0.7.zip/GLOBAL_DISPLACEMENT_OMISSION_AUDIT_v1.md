# Global displacement and statelessness omission audit

**Status:** all-row end-2025 UNHCR API audit; magnitude is used only to catch omissions. This is not a language ranking, an additive global population, or a claim that a country/status cohort speaks one language.

The frozen source contains 6,290 origin-host population rows, 10,084 population-type-specific demographic rows and 110 source footnotes. The audit retains all 209 origin contexts and all 178 host contexts, including small and unknown-coded rows. Thresholds flag 46 origin and 75 host contexts for omission inspection; they do not order funding.

## What the official totals mean

The API/Global Trends annex reports 28,461,306 refugees under UNHCR mandate, 8,998,097 asylum-seekers, 7,177,473 other people in need of international protection, and 64,239,352 IDPs of concern to UNHCR at end-2025. These fields are not one language population. The separate 5,964,782 Palestine refugees under UNRWA mandate remain external, not an extra row silently added to the API.

A broader global headline for conflict- and violence-related internal displacement is not interchangeable with `IDPs of concern to UNHCR`. This audit binds the exact API/annex measure and preserves broader headlines only as separately labelled context.

## Largest origin contexts to inspect (not a recommendation order)

### Cross-border current display sum

| Context | ISO3 | Refugees + asylum + OIP |
|---|---|---|
| Venezuela (Bolivarian Republic of) | VEN | 7,640,872 |
| Ukraine | UKR | 5,250,714 |
| Syrian Arab Rep. | SYR | 5,020,119 |
| Afghanistan | AFG | 3,972,525 |
| Sudan | SDN | 3,761,034 |
| South Sudan | SSD | 2,510,483 |
| Unknown | UNK | 1,803,367 |
| Myanmar | MMR | 1,592,202 |
| Dem. Rep. of the Congo | COD | 1,344,910 |
| Somalia | SOM | 1,128,308 |
| Central African Rep. | CAF | 756,822 |
| Eritrea | ERI | 673,335 |

### IDPs of concern to UNHCR

| Context | ISO3 | IDPs |
|---|---|---|
| Sudan | SDN | 9,139,309 |
| Colombia | COL | 7,157,716 |
| Dem. Rep. of the Congo | COD | 5,669,479 |
| Syrian Arab Rep. | SYR | 5,542,227 |
| Yemen | YEM | 4,795,983 |
| Ukraine | UKR | 3,712,000 |
| Myanmar | MMR | 3,628,840 |
| Nigeria | NGA | 3,544,519 |
| Somalia | SOM | 3,347,408 |
| Afghanistan | AFG | 3,199,023 |
| Ethiopia | ETH | 2,378,000 |
| Burkina Faso | BFA | 2,062,534 |

### Stateless persons under UNHCR's mandate, by host/context country

| Context | ISO3 | Stateless |
|---|---|---|
| Bangladesh | BGD | 1,177,962 |
| Cote d'Ivoire | CIV | 930,958 |
| Thailand | THA | 610,791 |
| Myanmar | MMR | 519,647 |
| Latvia | LVA | 167,512 |
| Syrian Arab Rep. | SYR | 160,000 |
| Malaysia | MYS | 134,676 |
| Kuwait | KWT | 92,000 |
| Russian Federation | RUS | 87,826 |
| Cambodia | KHM | 75,000 |
| Saudi Arabia | SAU | 70,000 |
| Estonia | EST | 62,043 |

The API uses the special origin code `XXA` for the aggregate statelessness field, so country-level inspection must use the host/context aggregation shown here. Statelessness is not itself a language identity and can overlap refugee or asylum status.

## Largest host contexts to inspect (not a language assignment)

| Context | ISO3 | Refugees + asylum + OIP |
|---|---|---|
| United States of America | USA | 4,176,592 |
| Germany | DEU | 2,952,694 |
| Colombia | COL | 2,829,663 |
| Türkiye | TUR | 2,492,911 |
| Uganda | UGA | 1,971,968 |
| Peru | PER | 1,661,572 |
| Iran (Islamic Rep. of) | IRN | 1,650,014 |
| Chad | TCD | 1,511,634 |
| Pakistan | PAK | 1,419,098 |
| Bangladesh | BGD | 1,178,105 |
| Ethiopia | ETH | 1,123,453 |
| Egypt | EGY | 1,098,301 |

A host total does not prove that the host country's dominant language is usable for every learner. Each consequential route still requires exact origin-language and script evidence, the host educational language, stage, location, disability/access mode, usable existing provision, and a non-overlapping learner denominator.

## Existing portfolio crosswalk

| Origin | Existing portfolio | Coverage interpretation |
|---|---|---|
| Afghanistan (AFG) | `displacement:glob_afghan_displaced` | PARTIAL_STATUS_CONTEXT_LANGUAGE_AND_HOST_DISTRIBUTION_UNRESOLVED |
| Dem. Rep. of the Congo (COD) | `displacement:drc-regional` | SENTINEL_ONLY_NO_PRIOR_DENOMINATOR |
| Myanmar (MMR) | `displacement:glob_rhg_stateless` | SUBSET_ONLY_ROHINGYA_IS_NOT_ALL_MYANMAR_ORIGIN_CONTEXT |
| Palestinian (PSE) | `displacement:glob_ajp_palestinian_refugee` | EXTERNAL_UNRWA_STATUS_CONTEXT_NOT_API_ORIGIN_TOTAL |
| Sudan (SDN) | `displacement:glob_sudan_displaced` | PARTIAL_IDP_PORTFOLIO_CROSS_BORDER_AND_LANGUAGE_DISTRIBUTION_UNRESOLVED |
| Somalia (SOM) | `displacement:somalia-regional` | SENTINEL_ONLY_NO_PRIOR_DENOMINATOR |
| South Sudan (SSD) | `displacement:south-sudan-regional` | SENTINEL_ONLY_NO_PRIOR_DENOMINATOR |
| Syrian Arab Rep. (SYR) | `displacement:glob_apc_sy_refugee` | PARTIAL_REFUGEE_PORTFOLIO_IDP_AND_HOST_DISTRIBUTION_UNRESOLVED |
| Ukraine (UKR) | `displacement:ukraine-eu-school-continuity` | SUBSET_ONLY_ENROLLED_CHILDREN_IN_EU_HOST_SCHOOLS |
| Venezuela (Bolivarian Republic of) (VEN) | `displacement:venezuela-regional` | SENTINEL_ONLY_NO_PRIOR_DENOMINATOR |

The ten pre-existing portfolios are therefore useful starting profiles, not global coverage. The all-row screen exposes 34 additional high-consequence named origin contexts without one of those portfolios, plus 2 high-consequence special-code contexts that cannot be assigned to a country-language route. The structured file retains their exact counts and omission reasons without inventing languages or setting their need to zero.

## Children and educational stages

The population-type-specific demographic endpoint contains 28,856,667 observed 0–17 records across the selected status types, versus 70,584,469 age-classified observations. These are coverage-bound observations, not a complete global child denominator. Missing age cells remain unknown, and preschool/foundational/secondary allocations must be tied to local enrolment, curriculum and language evidence before effect is estimated.

## Required next evidence

For every origin and host sentinel, research must identify exact language varieties, scripts, comprehension and literacy distributions, host-language transition requirements, current open educational provision, educational stage, connectivity/accessibility constraints, and displacement-specific credential continuity. Counts in this audit are omission alarms. They are never substituted for those missing causal inputs.

## Source surfaces

- UNHCR Refugee Data Finder API: <https://api.unhcr.org/docs/refugee-statistics.html>
- Global Trends annexes: <https://www.unhcr.org/refugee-statistics/insights/annexes/trends-annexes.html?situation=2>
- Global Trends 2025: <https://www.unhcr.org/global-trends>
