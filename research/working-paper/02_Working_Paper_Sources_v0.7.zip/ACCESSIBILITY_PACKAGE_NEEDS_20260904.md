# Accessibility and delivery package comparison

**Status:** bounded source-linked structural-lane checkpoint; not a population ranking, beneficiary total, language substitute or completed accessibility audit.

Accessibility is a separate marginal-access axis. The current evidence register contains 17 modes, 46 source records and 18 non-additive population or supply-context records. Every mode remains visible at P/F/S/V/U/R. The comparison creates 102 mode-stage cells and two alternatives per cell: complete integration and a bounded addition. Its 204 routes are designs, not people.

## Universal package baselines and conditional parallel modes

The six `UNIVERSAL_OPEN_PACKAGE_BASELINE` rows are architecture or content-type obligations: semantic responsive HTML, reflowable EPUB 3.3, native MathML, image descriptions, offline download packaging and low-bitrate media variants. “Universal” does not require an irrelevant asset—for example, low-bitrate video where no video exists—but it does require the architecture to preserve the relevant access path whenever that content type is present.

The other eleven modes are `CONDITIONAL_PARALLEL_ACCESS_ROUTE` interventions whose need depends on the exact learner, language, content and task: synchronized text/audio, prerecorded and live captions, downloadable transcripts, named sign-language video, plain language, Easy Read, declared-code braille, tactile graphics, audio description and large print. Conditional does not mean optional for a learner who needs the mode.

| Mode | Band | Context anchor (never a route denominator) | Source-linked stages / retained research stages |
|---|---|---|---|
| Semantic responsive HTML canonical content layer | UNIVERSAL_OPEN_PACKAGE_BASELINE | unmeasured | P,F,S,V,U,R / none |
| Downloadable born-accessible reflowable EPUB 3.3 | UNIVERSAL_OPEN_PACKAGE_BASELINE | unmeasured | F,S,V,U,R / P |
| Navigable full text synchronized with narration | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 7.10 percent_primary_school_children_pooled_dyslexia_prevalence | P,F,S,V,U / R |
| Localized closed captions for prerecorded instructional media | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 430000000 persons_disabling_hearing_loss_rehabilitation_proxy | P,F,S,V,U,R / none |
| Localized live captions for synchronous instruction | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 430000000 persons_disabling_hearing_loss_rehabilitation_proxy | F,S,V,U,R / P |
| Downloadable full transcript for instructional audio or video | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 430000000 persons_disabling_hearing_loss_rehabilitation_proxy | P,F,S,V,U,R / none |
| Instructional video in one named national or regional sign language, paired with text and captions | CONDITIONAL_PARALLEL_ACCESS_ROUTE | unmeasured | P,F,S,V,U / R |
| Localized plain-language version alongside the precise source | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 739000000 persons_adults_15plus_lacking_basic_literacy_proxy | F,V / P,S,U,R |
| Localized Easy Read version with supportive images and reduced memory load | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 10.37 persons_per_1000_population_intellectual_disability_meta_analysis | F,V / P,S,U,R |
| Navigable eBraille and embossable braille in a declared language and specialist code | CONDITIONAL_PARALLEL_ACCESS_ROUTE | unmeasured | P,F,S,V,U / R |
| Tactile graphics for spatial instructional diagrams | CONDITIONAL_PARALLEL_ACCESS_ROUTE | unmeasured | P,F,S,V,U / R |
| Native MathML for mathematical expressions | UNIVERSAL_OPEN_PACKAGE_BASELINE | unmeasured | P,S,V,U,R / F |
| Concise and extended text descriptions for meaningful instructional images | UNIVERSAL_OPEN_PACKAGE_BASELINE | 43000000 persons_blind_GBD_2020_proxy | P,F,S,V,U,R / none |
| Localized audio description for instructional video and essential visuals | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 43000000 persons_blind_GBD_2020_proxy | P,F,S,V,U,R / none |
| Self-contained downloadable offline accessible learning package | UNIVERSAL_OPEN_PACKAGE_BASELINE | 2200000000 persons_not_using_internet_previous_3_months | P,F,S,V,U,R / none |
| Optional downloadable low-bitrate media variant preserving accessibility content | UNIVERSAL_OPEN_PACKAGE_BASELINE | unmeasured | P,F,S,V,U,R / none |
| Reflowed large-print output with user-controlled size, spacing, and contrast | CONDITIONAL_PARALLEL_ACCESS_ROUTE | 1106000000 persons_vision_loss_VLEG_GBD_2020_proxy | P,F,S,V,U / R |

A source-linked stage means the existing synthesis names that stage or a functional equivalent. A retained research stage is not a claim of measured relevance; it prevents a mode from disappearing and requires a stage-specific source test. Presence at one stage never proves access at another.

## What complete and bounded mean

Complete integration applies the mode throughout one coherent educational package, localizes every language-bearing component and tests navigation, task completion, devices, assistive technology and offline persistence. A bounded addition covers named high-consequence units and publishes an exact coverage manifest. For a baseline mode, the bounded version is only a migration checkpoint; it cannot be labelled equivalent to a completely accessible edition. For a parallel mode, uncovered units remain an explicit access gap.

## Population and cost boundary

The contextual anchors—including 2.2 billion people not using the Internet in the preceding three months, hearing-loss and vision-loss estimates, adult-literacy estimates and supply-side accessibility failures—overlap and use different definitions, dates and units. None is a format-user count. The calculator therefore leaves every mode-specific need, effect and cost value unknown. It does not add contexts, substitute disability prevalence for user preference or price signed video, braille, tactile graphics, narration or interoperability testing as text tokens.

Named sign-language video is also not a single global format. It must bind to one exact sign language and community; the separate signed-language audit currently retains 227 typed and seven possible/unresolved nodes. Captions, transcripts and a written-language edition are complementary access routes, not replacements for a named sign language.

## Outputs

- `structured/ACCESSIBILITY_PACKAGE_NEEDS_20260904.json`: exact mode records, source links, context evidence and governing restrictions.
- `structured/ACCESSIBILITY_PACKAGE_COMPARISONS_v1.json`: 102 retained mode-stage cells and 204 complete-versus-bounded alternatives.
- `qa/ACCESSIBILITY_PACKAGE_NEEDS_QA_v1.json`: source, identity, hash, stage, pairing, nonadditivity, no-rank and deterministic-build checks.

## Remaining research

This checkpoint does not measure how many people would newly gain usable access from any mode, which languages and devices have the largest interoperability failures, or the production cost of each format. Those are the next matched comparisons. All 17 modes remain eligible while those measurements are missing.
