# India cross-stage supply and package gate

**Evidence freeze:** 2026-09-05  
**Status:** high-consequence multilingual target retained; no exact audience, effect, compute cost, dominance relation, or funding rank has been assigned.

## What this gate establishes

India is not a language. Standard Hindi in Devanagari is one comparison profile, not a proxy for India, the Census `HINDI` group, or every learner using a Hindi-medium institution. The gate retains 518 India-linked Glottolog language-level nodes, including 27 bookkeeping nodes and four signed-language nodes, plus all 22 scheduled-language Census groups.

The 2011 Census `HINDI` group contains 528,347,193 people across 57 named/residual component rows. The source's `Hindi` component is 322,230,097; the group also contains large separately named components. These historical categories are context, not current addressable audiences.

## Largest source-labelled components inside the Census HINDI group

| Source label | 2011 people | Identity state | Linked Glottolog name(s) |
|---|---:|---|---|
| Hindi | 322,230,097 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Hindi |
| Bhojpuri | 50,579,447 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Bhojpuri |
| Rajasthani | 25,806,344 | UNRESOLVED_INCLUDED | unresolved/residual |
| 6 Others | 16,711,170 | NONLANGUAGE_RESIDUAL_BUCKET | unresolved/residual |
| Chhattisgarhi | 16,245,190 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Chhattisgarhi |
| Magadhi/Magahi | 12,706,825 | UNRESOLVED_INCLUDED | unresolved/residual |
| Haryanvi | 9,806,519 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Haryanvi |
| Khortha/Khotta | 8,038,735 | UNRESOLVED_INCLUDED | unresolved/residual |
| Marwari | 7,831,749 | UNRESOLVED_INCLUDED | unresolved/residual |
| Bundeli/Bundel khandi | 5,626,356 | UNRESOLVED_INCLUDED | unresolved/residual |
| Malvi | 5,212,617 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Malvi |
| Sadan/Sadri | 4,345,677 | UNRESOLVED_INCLUDED | unresolved/residual |
| Mewari | 4,212,262 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Mewari |
| Awadhi | 3,850,906 | MAPPED_ONE_GLOTTOLOG_LANGUAGE_EXACT_OR_CONTROLLED_ALIAS | Awadhi |
| Lamani/Lambadi | 3,276,548 | UNRESOLVED_INCLUDED | unresolved/residual |

## All 22 scheduled-language-group contexts

| Census group | 2011 people | Largest named component | NPTEL unique title labels | Allocation state |
|---|---:|---|---:|---|
| Hindi | 528,347,193 | Hindi (322,230,097) | 292 | retained; unranked |
| Bengali | 97,237,669 | Bengali (96,177,835) | 181 | retained; unranked |
| Marathi | 83,026,680 | Marathi (82,801,140) | 199 | retained; unranked |
| Telugu | 81,127,740 | Telugu (80,912,459) | 209 | retained; unranked |
| Tamil | 69,026,881 | Tamil (68,888,839) | 248 | retained; unranked |
| Gujarati | 55,492,554 | Gujarati (55,036,204) | 212 | retained; unranked |
| Urdu | 50,772,631 | Urdu (50,725,762) | not in frozen catalogue set | retained; unranked |
| Kannada | 43,706,512 | Kannada (43,506,272) | 188 | retained; unranked |
| Odia | 37,521,324 | Odia (34,059,266) | 16 | retained; unranked |
| Malayalam | 34,838,819 | Malayalam (34,776,533) | 199 | retained; unranked |
| Punjabi | 33,124,726 | Punjabi (31,144,095) | 35 | retained; unranked |
| Assamese | 15,311,351 | Assamese (14,816,414) | 1 | retained; unranked |
| Maithili | 13,583,464 | Maithili (13,353,347) | not in frozen catalogue set | retained; unranked |
| Santali | 7,368,192 | Santali (6,973,345) | not in frozen catalogue set | retained; unranked |
| Kashmiri | 6,797,587 | Kashmiri (6,554,369) | not in frozen catalogue set | retained; unranked |
| Nepali | 2,926,168 | Nepali (2,925,796) | not in frozen catalogue set | retained; unranked |
| Sindhi | 2,772,264 | Sindhi (1,679,246) | not in frozen catalogue set | retained; unranked |
| Dogri | 2,596,767 | Dogri (2,596,763) | not in frozen catalogue set | retained; unranked |
| Konkani | 2,256,502 | Konkani (2,146,906) | not in frozen catalogue set | retained; unranked |
| Manipuri | 1,761,079 | Manipuri (1,760,913) | not in frozen catalogue set | retained; unranked |
| Bodo | 1,482,929 | Bodo/Boro (1,454,547) | not in frozen catalogue set | retained; unranked |
| Sanskrit | 24,821 | Sanskrit (24,709) | not in frozen catalogue set | retained; unranked |

Catalogue presence is not complete provision. Missing catalogue rows are evidence gaps, never evidence of low need.

## What is measured by stage, and what to compare

P = preschool/early childhood; F = foundational/primary; S = secondary; V = vocational/practical; U = university/tertiary; R = postgraduate/research.

| Stage | Non-additive context | What is already visible | Complete comparison | Bounded comparison |
|---|---|---|---|---|
| P — preschool / early childhood | rural age-3 pre-primary enrolment: 77.4 percent; rural age-4 pre-primary enrolment: 83.4 percent; rural age-5 pre-primary enrolment: 71.4 percent; UDISE foundational-stage enrolment: 52312506 persons | NCERT's current primer page visibly enumerates many Indian-language primers, and DIKSHA exposes multi-language content routes. The gate has not established exact language/variety coverage, licence, caregiver usability, audio/visual accessibility, offline completeness, or effect. | An exact child-and-caregiver-language early literacy, oral-language, numeracy, pattern, play and learning-to-learn sequence, with pictures, audio, print, captions, ISL or other exact signed route where applicable, and offline phone packages. | A phone/print/audio starter pack at a named child-caregiver-language endpoint, with number, pattern, story, vocabulary and caregiver prompts plus an explicit uncovered-scope manifest. |
| F — foundational / primary | UDISE foundational-stage enrolment: 52312506 persons; UDISE preparatory-stage enrolment: 66115921 persons; rural government Std III reading Std II text: 23.4 percent; rural all-school Std III subtraction: 33.7 percent | NCERT and DIKSHA establish substantial visible school supply, while ASER observes low performance on named rural reading and arithmetic tasks. Neither fact alone identifies the marginal effect of translation, and national-platform language menus do not cover all 518 IN-linked nodes. | An exact-language coherent literacy, mathematics, science and study-skills pathway with explanations, worked examples, exercises, complete feedback, semantic mathematics, print, low-bandwidth and resumable offline use. | Diagnostic and worked-feedback units for reading, place value, operations, fractions and word problems at a named grade/language endpoint, with home-language-to-school-language bridges and accessible alternatives. |
| S — secondary | UDISE middle-stage enrolment: 63695100 persons; UDISE secondary-stage enrolment: 64809153 persons; UDISE secondary gross enrolment ratio: 68.5 percent; rural age 15-16 not enrolled: 7.9 percent | The 2017-18 NSS table shows sharply different higher-secondary medium patterns by reported home-language group. It measures study-material language among attendees, not proficiency or transition causality. DIKSHA supply and NCERT textbooks are visible but exact subject, answer, licence, accessibility and offline completeness remain to be audited. | An exact curriculum-matched open secondary sequence in mathematics, physics, chemistry, biology, data, computing and academic language, with exercises, answers, low-equipment activities and offline/accessibility formats. | A transition package at one evidenced bottleneck—fractions/algebra, scientific reading, graphs/data, laboratory reasoning or school-language change—with prerequisite diagnosis and complete worked feedback. |
| V — vocational / practical | PMKVY 4.0 candidates trained: 2817000 programme count; JSS beneficiaries trained since 2018: 3652000 programme count; NAPS apprentices engaged since 2016: 5441000 engagements; CTS/ITI enrolment FY 2025-26: 1470000 enrolments | Large national skill systems and NPTEL regional-language formats exist. Their counts do not establish complete occupation-specific explanations, safe practice, assessment feedback, local regulation, accessibility, offline job aids, or exact-language reach. | A qualification- or occupation-specific pathway with prerequisites, numeracy, measurement, safety, procedures, simulation/low-equipment practice, assessment, captions/signed options and offline job aids. | A named practical package—financial recordkeeping, farm/health measurement, small-business operations, digital/AI basics, technical maths or safety—localized to law, currency, units and qualification requirements. |
| U — university / tertiary | higher-education enrolment: nearly 45,000,000 persons; higher-education GER ages 18-23: 30.0 percent; STEM enrolment across UG/PG/integrated/PhD: 10188988 enrolments | NPTEL states that technical courses are mainly English and translates course content into eleven named languages. The inspected catalogue has 292 unique Hindi title labels but only 1 Assamese, 16 Odia and 35 Punjabi; catalogue counts are presence evidence, not complete accessible courses or need rankings. Hindi and Telugu sampled books already contain explanations, worked examples, results and glossaries. | A complete open degree-course source sequence at one exact endpoint, with prerequisites, exercises, solutions, semantic equations, runnable examples, terminology/search bridges and offline/accessibility formats. | A prerequisite/navigation bridge tied to the actual course—e.g. arithmetic/algebra repair, mathematical English/regional-language terminology, worked examples, formula reading or offline lab setup—only where comparison finds additionality. |
| R — postgraduate / research | PhD enrolment: 343559 persons; PhD share in Science: 23.4 percent; PhD share in Engineering and Technology: 20.5 percent | Advanced regional-language catalogues, Indian-language universities and English-medium research routes coexist. Exact open coverage of proofs, research monographs, terminology, source search and accessible mathematical structure is not measured by enrolment or title counts. | A coherent exact-language graduate/research source chain in a named field, with prerequisites, proofs, terminology, source links, exercises/worked arguments, semantic mathematics and offline/accessibility formats. | A proof-and-search bridge around a named open source such as Open Logic or the Stacks Project, with bilingual terminology, argument maps, prerequisite pointers and mathematically structure-preserving translation. |

## Direct package implications

- **P/F:** test exact child/caregiver/home-language routes, not just a platform language menu. Compare coherent literacy/numeracy pathways with smaller diagnostic and worked-feedback packs, in phone, print, audio and appropriate signed forms.
- **S:** match a state/board, exact language, subject and transition. High-value hypotheses include fractions-to-algebra, scientific reading, graphs/data, laboratory reasoning and school-language changes.
- **V:** bind training to a qualification or job task. Finance/records, measurement, health, agriculture, business operations, digital/AI basics and technical safety are candidates only after local law, units, language and current provision are matched.
- **U:** NPTEL confirms substantial translated technical supply but very uneven catalogue visibility. Audit actual course bytes, rights, exercises/answers, accessibility and offline use before choosing full-course translation or a prerequisite/navigation bridge.
- **R:** education includes research. Compare complete graduate source chains and bounded proof/search/terminology bridges around exact open sources; mathematically structured text may reduce some prose burden, but its effect must be tested rather than assumed.

## Delivery and accessibility

CMS reports 86.3% of households with internet at home and, by adding mutually exclusive categories, 85.5% with some smartphone. That is not personal ownership or continuous educational access. In rural ASER data, individual smartphone ownership among 14–16-year-olds was 36.2% for boys and 26.9% for girls; among respondents reporting smartphone ability, 57% used one for education in the preceding week. One-download, small-screen, resumable offline, print and shared-device designs therefore remain separate comparison factors.

Indian Sign Language has a 10,000-term video dictionary with academic and vocational categories and recorded regional variation. A dictionary is not a curriculum, and Indian Sign Language does not cover every signed variety. Captions/transcripts, semantic HTML/MathML, screen-reader navigation, audio, large print and exact signed-language video remain distinct access modes.

## Open-source comparison portfolio

| Source | Subject | Possible stages | India comparison hypothesis |
|---|---|---|---|
| Prealgebra 2e | mathematics | F/S/V/U | Compare full arithmetic/prealgebra and narrow diagnostic-feedback bridges at F/S/V/U transitions in exact languages. |
| Introductory Statistics 2e | statistics and data literacy | S/V/U | Compare secondary, vocational and university statistics/data-literacy routes, including offline computation. |
| Biology 2e | life science | S/U | Test complete and bounded life-science routes at S/V/U, including health/agriculture applications. |
| Chemistry 2e | physical science | S/U | Test secondary/university chemistry and vocational measurement/safety bridges with low-equipment alternatives. |
| College Physics 2e | physical science | S/V/U | Test algebra-based physics at S/V/U with simulations, low-equipment activities and accessible diagrams. |
| Principles of Management | business and management | V/U | Compare full management education and bounded planning, operations, communication and team-decision units at V/U. |
| Principles of Finance 2e | finance | V/U | Compare a complete finance course and bounded household/small-business finance, records and decision units at V/U. |
| Anatomy and Physiology 2e | health and allied-health foundations | V/U | Test allied-health foundations at V/U and bounded health-literacy derivatives where the endpoint supports them. |
| Introduction to Python Programming | computing and data skills | S/V/U | Test runnable offline computing/data routes at S/V/U and phone-compatible/no-code alternatives. |

These are measured source-scale comparisons, not automatic recommendations or evidence that the corresponding Indian-language material is absent. Exact source rights and model-use terms must be resolved before any production.

## Current allocation result

India contains very large measured educational cohorts, low performance on some named foundational tasks, substantial multilingual digital and translated technical supply, large practical-learning systems, and a deeply noncoextensive language universe. The useful allocation question is therefore exact language × stage × subject × format × delivery package additionality—not whether 'India' or 'Hindi' is served.

No package is ranked here because the exact addressable audience, marginal educational effect, full physical compute and delivery cost are not yet measured on common endpoints. Every missing exact-language measurement remains a possible outranker; missing evidence cannot lower need.

## Source and audit basis

- Four preserved PDFs, 2,029 pages total; ten page-level claim checks; nine visually inspected renders; 54 source/render checks, all passing.
- UDISE 2024-25 national stage counts are retained as an official web-text locator because repeated direct PDF URLs returned 404; no local PDF bytes are claimed.
- AISHE 2023-24 supplies higher-education and research context; CMS Telecom 2025 supplies connectivity context; NSS Report 585 supplies the historical home-language/medium table; ASER 2024 supplies rural task evidence.
- DIKSHA, NPTEL, Skill India, ISLRTC and NCERT pages establish named supply/programme facts only within their stated scopes.
- All administrative, survey, catalogue and programme figures are non-additive and are not beneficiary or causal-effect estimates.
