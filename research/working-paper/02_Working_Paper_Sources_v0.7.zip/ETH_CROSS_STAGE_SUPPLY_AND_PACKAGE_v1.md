# Ethiopia: cross-stage educational supply and package comparison

Status: source-bound comparison, not a country rank or language league table.

## What the evidence establishes

Ethiopia is not one language audience. The retained register contains 105 country-linked language-level nodes, including two bookkeeping nodes and Ethiopian Sign Language. All remain visible at every stage. The evidence directly identifies several different access problems: severe early reading outcomes that differ across printed language groups; incomplete textbook distribution; a Grade 9 English-medium transition; limited Internet, electricity and home device access; vocational language and remote-access barriers; signed-language, Braille and assistive-format obligations; and a research-infrastructure question. These are not interchangeable measurements.

The 2007 census counts are historical. They are not projected into the current 2025 national population, and broad labels such as Oromo are not assigned to one exact Glottolog node. No national statistic becomes an exact beneficiary count.

## Stage-by-stage package findings

| Code | Stage | Source-bound finding | Complete package | Bounded alternative |
|---|---|---|---|---|
| P | preschool and early childhood | Current law and sector planning make mother-tongue and inclusive provision explicit from pre-primary. Administrative data warn that disability may be missing or misrecorded and report low pre-primary special-needs GER. No exact child/caregiver-language early-learning inventory or effect estimate is yet bound. | A coherent exact child-and-caregiver-language oral-language, picture-story, early numeracy, pattern, play and learning-to-learn sequence with audio, print, signed and adaptive alternatives. | A curriculum-linked oral-language, number-concept and caregiver sidecar for one exact language and delivery route, with an uncovered-scope manifest. |
| F | foundational and primary | The 2021 nine-language assessment summary reports 68 percent Grade 2 and 51 percent Grade 3 zero readers nationally, with large differences between printed language groups. The assessment report associates reading with same home/school language and mother-tongue materials but explicitly says correlation is not causation. The sector plan specifies mother-tongue readers, numeracy practice packets and independently usable workbooks; the administrative report records incomplete textbook distribution. | An exact-language literacy, arithmetic, introductory science and study-skills pathway with explanations, many exercises, worked answers, audio/print/signed alternatives and offline phone use. | A source-language and curriculum-matched decoding/reading plus place-value, operations, fractions and word-problem package with diagnostic feedback and worked solutions. |
| S | secondary | The 2022/23 administrative report says new-curriculum secondary textbooks and teacher guides were not distributed in the described pilot period. Only 11 percent of respondent secondary schools reported Internet; functional biology, chemistry and physics laboratories were each below 36 percent. Current law makes English compulsory as medium from Grade 9, creating a subject-plus-language transition question rather than proof of comfortable English access. | A coherent exact-language and transition-aware algebra, geometry, statistics, biology, chemistry, physics, computing and academic-reading sequence with exercises, worked solutions and low-resource experiments or simulations. | A fractions-to-algebra and scientific-reading bridge plus selected biology/chemistry/physics/data modules aligned to one regional curriculum and English transition. |
| V | vocational, technical and practical | Sector planning names vocational, digital, financial and life skills, and the 2025 strategy requires community skill-gap analysis. The strategy explicitly identifies language barriers, remote access, digital illiteracy and fragmented recognition of prior learning. Refugee and host-community integration is an explicit route. | An exact-language applied numeracy, bookkeeping, household and enterprise finance, agriculture, health, measurement, technical safety, digital skills, management and entrepreneurship pathway tied to local qualifications and law. | One community-selected job or certification package with terminology, worked procedures, forms, safety checks, numeracy and recognition-of-prior-learning support. |
| U | taught university and other tertiary | The digital strategy reports 36 universities on EthERNet but describes student/staff home connectivity and device/broadband access in its cited table as almost none. The STEM source spans post-secondary preparation and identifies laboratories, budget, data, teacher and institution-linkage constraints. The inclusive-education strategy identifies weak TVET and higher-education support for learners with disabilities. | A first-year-to-degree open sequence in mathematics, statistics, computing, physical/life science, health, finance and management with prerequisites, exercises, answers, offline/accessibility variants and explicit academic-language transitions. | A prerequisite, terminology, scientific-writing, formula-reading, runnable-computing or course-navigation bridge into one named programme. |
| R | postgraduate study and research | The digital strategy names open science, research collaboration and access to shared infrastructure as needs. The current gate has no exact-language inventory of graduate proof, reference, methods or research-navigation supply and no measured research-task effect. Mathematically structured texts may permit prepared-reader and interlanguage experiments, but no comprehension credit is assigned without evidence. | An exact-language or demonstrably intelligible graduate/research source chain in a named field, including prerequisites, proofs, terminology, references, worked arguments, reproducible methods and semantic/offline/accessibility forms. | A theorem-navigation, terminology, abstract/example, methods, citation and source-search bridge around Open Logic, the Stacks Project, an open course or a field-specific corpus. |

## What should be tested sooner rather than later

The evidence supports early effect tests in four non-exclusive domains: exact-language foundational reading and numeracy; offline secondary STEM plus language transition; community-selected vocational, digital and financial tasks; and signed/Braille/adaptive access. This is an effect-measurement order, not a declaration that one language or life stage matters more than another. University prerequisites and postgraduate research remain first-class educational access questions and should be tested at their own endpoints.

A serious package should be independently usable: explanations, exercises, worked answers, navigation and one-download offline forms are part of the intervention. Classroom use remains possible, but teacher availability is not assumed.

## Exact-language boundary

Fourteen source-visible identities are profiled explicitly, including three separate Oromo nodes and Ethiopian Sign Language. The other 91 nodes are not discarded: they remain in the 630-row language-by-stage CSV, each marked as a possible outranker. The source-label crosswalk records where labels are strong, provisional or unresolved.

## OpenStax source-scale comparison

The nine measured OpenStax books total 4,463,123 cl100k content-text tokens. That is a workload-scale baseline, not a compute bill, benefit estimate or curriculum order.

| Source | Candidate stages | Ethiopia-specific use hypothesis |
|---|---|---|
| Prealgebra 2e | F, S, V, U | A worked prealgebra pathway can support secondary catch-up, vocational numeracy and tertiary prerequisites; the subset is not a substitute for decoding or primary arithmetic. |
| Introductory Statistics 2e | S, V, U | Statistics and data literacy can support school science, community surveys, labour-market analysis and undergraduate study. |
| Biology 2e | S, U | A biology sequence answers the cross-stage STEM need and can pair with low-resource experiment and health-context sidecars. |
| Chemistry 2e | S, U | Chemistry can address secondary and first-year science access when paired with safe low-resource laboratory alternatives. |
| College Physics 2e | S, V, U | Algebra-based physics can support secondary, technical and university pathways, especially with simulation or low-cost practical alternatives. |
| Principles of Management | V, U | Management content can support entrepreneurship, community organizations and tertiary business study named in the vocational strategy. |
| Principles of Finance 2e | V, U | Finance can support formal study and parts of enterprise/financial-skills pathways. |
| Anatomy and Physiology 2e | V, U | Anatomy and physiology can support allied-health and tertiary life-science prerequisites. |
| Introduction to Python Programming | S, V, U | A small measured programming source can support the stated digital-skills and higher-education cascade with runnable offline exercises. |

## Beyond OpenStax

The comparison retains teacher education, nursing, agriculture, computing, research methods, reproducibility, Open Logic, MIT OpenCourseWare and the Stacks Project as separate source candidates. Each must be matched to a real stage, community, prerequisite chain, licence, format and task. Advanced mathematics is not dismissed because it serves fewer people; it is compared at a research endpoint rather than against early reading as though they were the same outcome.

## Current partial order

- For foundational reading and numeracy, an exact-language complete pathway cannot be declared dominated by an English-only or Amharic-only package. Assessment outcomes vary strongly across printed language groups, law and planning recognize mother-tongue routes, and no cross-language coverage evidence closes the alternatives.
- At secondary stage, print/offline packages remain non-dominated by online-only packages. The retained respondent-school Internet and national access context rule out treating online delivery as universally reachable.
- A bounded package may be more compute-efficient than a complete package only if its independently measured educational gain exceeds the source-scale threshold at the same endpoint. OpenStax subset/full token ratios measure source workload only; they do not measure benefit, media, localization or delivery.
- Signed-language, Braille and adaptive routes are not dominated by written-language editions for the populations who require them. Law and strategy treat these as distinct access modes, and written-language comprehension cannot be assumed.
- Research-stage packages remain eligible even when their audience is smaller than foundational packages. The research question includes education through postgraduate/research, and no common-endpoint evidence permits a raw-population-only comparison.

## What remains unknown

No Ethiopia language-package pair yet has a matched exact audience, incremental educational effect, physical compute requirement, monetary cost or dominance relation. Therefore this gate produces no language or funding rank. Missing supply evidence does not lower need; it identifies the next research obligation.

The next valid comparison binds one exact community and production standard to one stage, subject, current open-material inventory, delivery route and independent task endpoint, then measures complete and bounded packages at the same endpoint.
