# Central Asian language and educational-package needs

**Status:** bounded source-linked omission checkpoint; not a language ranking, beneficiary count or final allocation recommendation.

## What the evidence actually measures

Kazakhstan's 2021 census table reports 17,194,712 people in its table frame. It records 13,750,439 who freely read Kazakh, 14,356,787 who freely read Russian and 5,670,216 who freely read English. These columns overlap. Their sums and differences are not counts of monolingual or educationally underserved people. The same table cross-tabulates nationality, not home or preferred educational language (Bureau of National Statistics of Kazakhstan, 2021).

Uzbekistan's 2021/22 school table directly reports instruction-language enrollments: 5,355,701 Uzbek, 642,636 Russian, 125,850 Karakalpak, 65,358 Tajik, 53,558 Kazakh, 10,902 Turkmen, 8,183 Kyrgyz and 1,538 other. The displayed rows sum to 6,263,726. These are students in language-of-instruction categories, not speaker populations or unmet need (State Committee of Uzbekistan on Statistics, 2022).

Kyrgyzstan's 2024 table reports 695,209 students in single-language organizations and 841,424 in organizations with two or more languages. The largest displayed multilingual configuration is Kyrgyz-Russian (660,688). The displayed named values leave residual differences of 2,180 and 5,100; blank cells are not imputed. Organization labels do not prove individual bilingual proficiency (National Statistical Committee of the Kyrgyz Republic, 2024).

Xinjiang's 2020 census bulletin reports 25,852,345 residents and 11,624,257 people of Uyghur ethnicity. This is a high-consequence scale flag, but ethnicity is not a measure of Uyghur use, literacy, preferred educational language or marginal benefit (Xinjiang Statistics Bureau, 2021).

## National learning context, kept separate from language

In the source-bound PISA 2022 comparison, mathematics below Level 2 is 49.6% in Kazakhstan, 80.7% in Uzbekistan and 51.1% in Mongolia. These jurisdiction results justify investigating secondary packages, but they do not identify which language caused the result or which language edition would help. The World Bank/UIS briefs similarly report national learning-poverty values of 10%, 32%, 64% and 39% for Kazakhstan, Uzbekistan, Kyrgyz Republic and Mongolia; Turkmenistan's inspected comparative panel reports no country value. Missing evidence is not low need.

## What should be compared

For Uzbek, Kazakh, Uyghur, Kyrgyz, Turkmen, Mongolian/Khalkha and Karakalpak, the packet retains stage-specific comparisons from foundational through research where the present evidence supports a concrete hypothesis. Russian is retained as a cross-border secondary, practical, university and research bridge. Tajik is not duplicated because the existing study packet already retains complete and smaller alternatives at all six stages.

At each stage the comparison is between a complete, independently usable exact-language sequence and a smaller prerequisite, terminology, navigation or worked-answer bridge. The smaller option may be efficient where readers already have partial access through Russian, English or a national language; the complete option may dominate where that overlap is weak. The required overlap measurement is an empirical input, not a regional assumption.

The route designs cover: foundational reading/numeracy/science; secondary mathematics and science; vocational numeracy, finance, data and digital skills; first-year calculus, linear algebra, statistics, computing and scientific writing; and advanced open editions or research-navigation layers. All must remain printable, phone-readable and downloadable for offline use where delivery evidence supports those formats.

## Script and identity safeguards

Uzbek Latin/Cyrillic, Kazakh Cyrillic/transition cohorts, Uyghur Perso-Arabic and diaspora scripts, Kyrgyz Cyrillic, Turkmen Latin/legacy Cyrillic, Mongolian Cyrillic/traditional script, and Karakalpak Latin/Cyrillic are separate production and comprehension questions. A transliteration is not automatically an educational edition. Southern Uzbek, Tuvan varieties in Mongolia, Pamiri languages and Central Asian signed languages remain explicit research obligations rather than being collapsed into a national standard.

## What remains unknown

The packet adds 38 unranked comparison routes across 13 visible profiles. Every new route keeps its exact-language need count and net-access yield unknown. The next evidence priorities are language-by-stage learner cross-tabs, current open-material inventories, academic Russian/English overlap, exact script use, delivery constraints, and matched outcomes for a complete package versus a smaller bridge.

## References

Bureau of National Statistics of Kazakhstan. (2021). *National composition, religion and language proficiency in the Republic of Kazakhstan*. https://stat.gov.kz/en/national/2021/

Government of Mongolia. (2020). *Mongolian State Report on the implementation of the 1960 Convention and Recommendation against Discrimination in Education*. https://media.unesco.org/sites/default/files/webform/r2e002/mongolian-state-report-on-the-implementation-of-the-1960-convention-and-recommendation-against-discrimination-in-education-15-nov-2020.pdf

National Statistical Committee of the Kyrgyz Republic. (2024). *Students in daytime general educational organizations by language of instruction*. https://stat.gov.kg/kg/opendata/category/4263/

State Committee of the Republic of Uzbekistan on Statistics. (2022). *Main statistical indicators of the activity of general secondary educational institutions*. https://stat.uz/images/umumtalim-eng-30_03_2022.pdf

World Bank & UNESCO Institute for Statistics. (2024). *Learning Poverty Briefs: Kazakhstan, Kyrgyz Republic, Mongolia, and Uzbekistan*. https://www.worldbank.org/en/topic/education/brief/learning-poverty

Xinjiang Uyghur Autonomous Region Statistics Bureau. (2021). *Seventh National Population Census Bulletin No. 1*. https://tjj.xinjiang.gov.cn/tjj/tjgn/202106/e3605637963f4f7280654a6f07af0b0e.shtml
