# Normalized conditional-portfolio model

**Machine-checkable research model—not a world-language rank or optimizer result.**

## Governing thesis

Inherited familiarity with academic language is an institutionally distributed access advantage. A complete, source-faithful translation into an audience-specified adult register remains eligible whenever any credible nonzero educational benefit is plausible. Evidence determines design, effect, cost and scale; it never functions as an innate-capacity screen, permission test or language-level withholding rule.

The thesis is not scored. Effect evidence determines implementation, expected yield and scale; it cannot make a community ineligible.

## What is normalized

- 83 source-typed population frames.
- 1,069 single-stage intervention records: 1,022 source routes and 47 first-tranche program-stage records.
- 4,284 typed parameters with `direct`, `inference`, `scenario`, or `unmeasured` evidence mode.
- 217 endpoint records; comparisons require identical endpoint, stage, horizon and population frame.
- 75 overlap sets, none assigned invented intersections or union totals.
- 36 preserved matched-endpoint threshold comparisons and zero robust global dominance edges.
- 10,625 possible-outranker entities from the complete synthesis universe.

## What it can support now

1. Reproduce the existing matched-endpoint break-even inequalities without calling either side a winner.
2. Apply named effect scenarios to compatible endpoints while keeping scenario values out of measured fields.
3. Compare a common 100,000-source-token workflow benchmark across targets without mistaking it for the target-specific educational package or physical compute.
4. Express four disclosed portfolio-governance templates without claiming that their quotas are empirical need weights.
5. Preserve every unselected entity as an eligible possible outranker.

## What it cannot support yet

It cannot produce a measured global efficiency ranking. Route-specific effects and standardized physical compute remain unmeasured; exact edition audiences and overlap are mostly unresolved; cross-stage benefits have no agreed scalar weights. The ten-program tranche is therefore one replaceable feasible hedge, and the Top 100 is a nonordinal communication set.

## Portfolio fronts

| Front | Members | Interpretation |
|---|---:|---|
| Conditional first tranche | 10 programs | One expert-constructed, nonunique measurement-and-production hedge; no ordinal positions. |
| Top 100 communication set | 100 profiles | A broad research/production roster; member numbers are identifiers, not ranks. |

All 10,625 entities in the source universe remain possible outrankers. Selection from the displayed portfolios never changes eligibility.

## Validation

All 36 constructor checks pass. See `qa/CONDITIONAL_PORTFOLIO_MODEL_QA_v1.json` for exact checks and hashes.
